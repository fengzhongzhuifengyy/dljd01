/**
 * 包装类: 将8种基本数据类型,包装成了引用的数据类型
 *
 * @author 虞渊
 * @since 2022年12月04日 20:24
 */
public class IntegerDemo {
    /*
        为什么需要包装类型
        1. 因为集合中泛型的限定,只能存储引用数据类型,要想存储(整数, 小数, 字符, 布尔...),就要使用对应的包装类
        2. 只要是类,里面就会有方便的方法直接使用 --Integer.parseInt():将数字字符串->数字

        包装类的分类:
        byte        Byte
        short       Short
        int         Integer
        char        Character
        long        Long
        float       Float
        double      Double

        Integer类的构造方法(已过时):
        public Integer(int value):
        public Integer(String s):
        推荐: 使用 public static Integer valueOf(Sting s);

        自动拆装箱:今后基本数据类型可以跟对应的引用数据类型,直接做运算
         valueOf():
            判断数值是否在-128 -127之间,在不会重新创建,而是从底层的数组中,取出并返回;如果不在就会重新new Integer()对象


     */
    public static void main(String[] args) {

        // 已过时
        Integer i1 = new Integer(100);
        Integer i2 = new Integer("100");

        // 手动装箱
        System.out.println(Integer.valueOf(100));
        System.out.println(Integer.valueOf("100"));
        System.out.println(Long.valueOf(100));

        // 自动装箱
        Integer num1 = 100;

        // 手动拆箱:手动的将引用数据类型 -> 基本数据类型
        int i3 = num1.intValue();

        // 自动拆箱
        int i4 = num1;

        // 将数字字符串转换为数字
        String s = "123";
        int result = Integer.parseInt(s);
        /*
            所有的包装类,除了Character没有parse,其余都有
         */
    }
}
