package example05_singleton;

/**
 * 功能说明: 适配器设计模式
 *
 * @author 虞渊
 * @since 2023-09-24-23:57
 */
public class AdapterDemo {
    /*
        适配器设计模式:
            场景: 如果要实现接口, 但是因为语法规则, 我不得不重写所有抽象方法
                    但是实际上, 我只想重写一个抽象方法, 这时候就可以根据这个接口, 做一个适配器类
     */
}

interface 和尚 {
    void 打坐();

    void 撞钟();

    void 念经();

    void 习武();
}

abstract class 和尚Adapter implements 和尚 {

    @Override
    public void 打坐() {

    }

    @Override
    public void 撞钟() {

    }

    @Override
    public void 念经() {

    }

    @Override
    public void 习武() {

    }

}

class 鲁智深 extends 和尚Adapter {
    @Override
    public void 习武() {
        System.out.println("倒拔垂杨柳");
        System.out.println("拳打镇关西");
        System.out.println("大闹野猪林");
        System.out.println("传智学Java");
    }
}
