package example05_singleton;

/**
 * 功能说明: 单例设计模式: 保证类在内存中，只有一个对象 -- 饿汉式
 *
 * @author 虞渊
 * @since 2023-09-24-23:10
 */
public class SingletonDemo01 {
    public static void main(String[] args) {
        SingleDog instance1 = SingleDog.getInstance();
        SingleDog instance2 = SingleDog.getInstance();
        System.out.println(instance1 == instance2);
    }
}

class SingleDog{
    // 1.私有化构造方法
    private SingleDog(){}

    // 2.自己创建对象
    private static final SingleDog singleDog = new SingleDog();

    // 3.提供静态方法,方法返回单例对象
    public static SingleDog getInstance(){
        return singleDog;
    }
}