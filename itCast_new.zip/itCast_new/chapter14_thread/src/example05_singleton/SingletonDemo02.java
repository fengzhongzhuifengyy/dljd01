package example05_singleton;

/**
 * 功能说明: 单例设计模式: 保证类在内存中，只有一个对象 -- 懒汉式
 *
 * @author 虞渊
 * @since 2023-09-24-23:18
 */
public class SingletonDemo02 {
    public static void main(String[] args) {
        // SingleCat s1 = SingleCat.getInstance();
        // SingleCat s2 = SingleCat.getInstance();
        // System.out.println(s1 == s2);

        for (int i = 1; i <= 10; i++) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    SingleCat instance = SingleCat.getInstance();
                    System.out.println(instance);
                }
            }).start();
        }
    }
}

class SingleCat{
    //1.私有化构造方法 --- 不让别人创建对象
    private SingleCat(){}
    // 懒汉式
    // 核心：延迟加载
    // 多线程并发操作, 会出现多个对象
    private static SingleCat singleCat;

    public static SingleCat getInstance(){
        // 提升效率, 不希望每一个线程都阻塞在这里
        if (singleCat == null){
            synchronized (SingleCat.class) {
                // 保证对象的唯一性
                if (singleCat == null){
                    singleCat = new SingleCat();
                }
            }
        }
        return singleCat;
    }
}