package example04_threadPool;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 功能说明: 自定义线程池 ThreadPoolExecutor
 *
 * @author 虞渊
 * @since 2023-09-24-21:09
 */
public class ThreadPoolDemo03 {
    /*
        构造方法:
            用给定的初始参数创建一个新的 `ThreadPoolExecutor`
            ThreadPoolExecutor(int corePoolSize,  int maximumPoolSize, long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory,  RejectedExecutionHandler handler)

        参数详解:
            参数一：核心线程对象数量
                解释 :  理解为正式员工, 就算没有线程任务提交, 这些线程对象, 也不会释放

            参数二：最大线程对象数
                解释 :  理解为正式员工 + 临时员工, 临时员工 ---> 临时线程, 面临着, 空闲要被销毁
                注意 :  最大线程数 >= 核心线程数量

            参数三：空闲线程最大存活时间

            参数四：时间单位
                解释 :   60秒   50分钟

            参数五：任务队列
                解释 :  理解为排队, 线程任务在排队
                new ArrayBlockingQueue<>(10) : 有界队列
                new LinkedBlockingQueue<>(): 无界队列

            参数六：创建线程工厂
                解释 : 线程工厂来负责创建线程对象

            参数七：任务的拒绝策略
                解释 :  核心数量为2, 最大数量为5, 任务队列 10,  最多只能服务15个线程任务啊
                    提交了16个线程任务, 第16个任务, 就要拒绝 !
                ThreadPoolExecutor.AbortPolicy: 丢弃任务并抛出RejectedExecutionException异常。是默认的策略。
                ThreadPoolExecutor.DiscardPolicy: 丢弃任务，但是不抛出异常 这是不推荐的做法。
                ThreadPoolExecutor.DiscardOldestPolicy: 抛弃队列中等待最久的任务 然后把当前任务加入队列中。
                ThreadPoolExecutor.CallerRunsPolicy: 调用任务的run()方法绕过线程池直接执行。

            提交线程任务的方式, 推荐使用 submit, 因为能够同时接收 Runnable 和 Callable
                 void  execute(Runnable command)
                 Future<T>  submit(Callable<T> task)

            推荐使用 submit , 因为能够同时接收 Runnable 和 Callable
     */
    public static void main(String[] args) {
        ThreadPoolExecutor threadPool = new ThreadPoolExecutor(
                2,  // 公司请求并发量的平均值
                5, // 高峰值 * 2
                60,
                TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(10), // 最大线程数量 * 1.5倍
                Executors.defaultThreadFactory(),
                new ThreadPoolExecutor.AbortPolicy()
        );

        for (int i = 1; i <= 16; i++) {
            threadPool.submit(new Runnable() {
                @Override
                public void run() {
                    System.out.println(Thread.currentThread().getName() + "正在执行...");
                }
            });
        }

        threadPool.shutdown(); // 关闭线程池
    }
}
