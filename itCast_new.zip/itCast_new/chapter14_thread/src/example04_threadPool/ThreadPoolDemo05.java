package example04_threadPool;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 功能说明: 定时器 ScheduledExecutorService
 *
 * @author 虞渊
 * @since 2023-09-24-22:58
 */
public class ThreadPoolDemo05 {
    /*
        这东西本质来讲就是个线程池

        public class ScheduledThreadPoolExecutor
            extends ThreadPoolExecutor
            implements ScheduledExecutorService {
            }

        创建方式:
        Executors.newScheduledThreadPool(10);
        // 前面的太长了, 建议.var直接生成
        ScheduledExecutorService pool = Executors.newScheduledThreadPool(10);

        两种定时器的区别:
        1. Timer : 单线程 (有错, 全废)
        2. ScheduledExecutorService : 线程池, 效率好 (有错只影响自己, 不会影响其他线程任务)

     */
    public static void main(String[] args) {
        // 获取定时器对象
        ScheduledExecutorService pool = Executors.newScheduledThreadPool(10);

        // 设置定时任务
        pool.scheduleAtFixedRate(
                // 参数1: 定时任务的内容
                new Runnable() {
                    @Override
                    public void run() {
                        System.out.println("起床啦~~~");
                    }
                },
                // 参数2: 延迟时间
                2,
                // 参数3: 定时时间
                1,
                // 参数4; 时间单位
                TimeUnit.SECONDS
        );
    }
}
