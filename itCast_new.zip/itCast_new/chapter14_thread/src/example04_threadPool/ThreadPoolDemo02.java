package example04_threadPool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 功能说明: java自带线程池2 --- 不推荐使用
 *
 * @author 虞渊
 * @since 2023-09-24-21:05
 */
public class ThreadPoolDemo02 {
    /*
        static newFixedThreadPool ( int nThreads ) 创建一个指定最多线程数量的线程池
     */
    public static void main(String[] args) {
        // 创建指定线程数量的线程池对象
        ExecutorService pool = Executors.newFixedThreadPool(10);

        while (true){
            pool.submit(new Runnable() {
                @Override
                public void run() {
                    System.out.println(Thread.currentThread().getName() + "正在执行");
                }
            });
        }
    }
}
