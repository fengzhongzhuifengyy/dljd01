package example04_threadPool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 功能说明: java自带线程池1 --- 不推荐使用
 *
 * @author 虞渊
 * @since 2023-09-24-20:58
 */
public class ThreadPoolDemo01 {
    /*
        static ExecutorService newCachedThreadPool ( ) 创建一个默认的线程池
     */
    public static void main(String[] args) {
        // 获取线程池对象
        ExecutorService pool = Executors.newCachedThreadPool();

        // 向池子中提交线程任务
        while (true) {
            pool.submit(new Runnable() {
                @Override
                public void run() {
                    System.out.println(Thread.currentThread().getName() +"正在执行...");
                }
            });
        }

    }
}
