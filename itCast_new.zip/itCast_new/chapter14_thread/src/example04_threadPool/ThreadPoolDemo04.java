package example04_threadPool;

import java.util.Timer;
import java.util.TimerTask;

/**
 * 功能说明: 定时器 Timer --- 不推荐使用
 *
 * @author 虞渊
 * @since 2023-09-24-22:48
 */
public class ThreadPoolDemo04 {
    /*
        Timer
            构造方法
            public Timer()
            public Timer(String name)

        弊端:
            1、Timer是单线程，处理多个任务按照顺序执行，存在延时与设置定时器的时间有出入。
            2、可能因为其中的某个任务的异常使Timer线程死掉，从而影响后续任务执行
     */
    public static void main(String[] args) {
        // 创建定时器对象,并指定名称
        Timer t = new Timer("闹钟");
        // 设置定时任务
        t.schedule(new TimerTask() {
            @Override
            public void run() {
                System.out.println(Thread.currentThread().getName() + "起床啦~~");
            }
        }, 3000, 2000);
    }
}
