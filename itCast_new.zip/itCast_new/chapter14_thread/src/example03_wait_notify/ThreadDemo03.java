package example03_wait_notify;


import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 功能说明: 新等待唤醒await 和 signal : 可以唤醒指定对应的线程
 *
 * @author 虞渊
 * @since 2023-09-22-0:21
 */
public class ThreadDemo03 {
    /*

     */
    public static void main(String[] args) {
        Printer2 printer = new Printer2();
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    try {
                        printer.p1();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }.start();

        new Thread() {
            @Override
            public void run() {
                while (true) {
                    try {
                        printer.p2();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }.start();

        new Thread() {
            @Override
            public void run() {
                while (true) {

                    try {
                        printer.p3();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }.start();
    }
}


class Printer2 {
    /*
        按照指定的顺序进行打印
     */
    int flag = 1;

    // 锁对象
    ReentrantLock locks = new ReentrantLock();
    // 因为有3个线程, 所以开了3个监视器
    Condition c1 = locks.newCondition();
    Condition c2 = locks.newCondition();
    Condition c3 = locks.newCondition();

    public void p1() throws InterruptedException {

        locks.lock();
        while (flag != 1) {
          c1.await();
        }
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.println();
        flag = 2;
        // 唤醒指定线程2
        c2.signal();
        locks.unlock();
    }

    public void p2() throws InterruptedException {
        locks.lock();
        while (flag != 2) {
            c2.await();
        }
        System.out.print("5");
        System.out.print("6");
        System.out.print("7");
        System.out.print("8");
        System.out.println();
        flag = 3;
        c3.signal();
        locks.unlock();
    }

    public void p3() throws InterruptedException {
        locks.lock();
        while (flag != 3) {
            c3.await();
        }
        System.out.print("9");
        System.out.print("10");
        System.out.print("J");
        System.out.print("Q");
        System.out.println();
        flag = 1;
        c1.signal();
        locks.unlock();
    }
}
