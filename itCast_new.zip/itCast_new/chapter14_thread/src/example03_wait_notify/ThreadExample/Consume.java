package example03_wait_notify.ThreadExample;

/**
 * 功能说明: 消费者类
 *
 * @author 虞渊
 * @since 2023-09-24-15:08
 */
public class Consume implements Runnable {

    /*
        判断有没有资源
            没有: 等待

            有: 消费
            flag = false;
            通知生产者进行生产
     */
    @Override
    public void run() {
        // 首先进行多次消费
        while (true){
            synchronized (Source.class){
                if (Source.flag){
                    System.out.println("消费者消费了...");
                    Source.flag = false;
                    // 通知生产者进行消费
                    Source.class.notify();
                }else {
                    try {
                        // 等待生产
                        System.out.println("消费者等待...");
                        Source.class.wait();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
    }
}
