package example03_wait_notify.ThreadExample;

/**
 * 功能说明: 共享的资源类(可以理解为盒子类)
 *
 * @author 虞渊
 * @since 2023-09-24-15:12
 */
public class Source {
    // 标记是否有包子
    public static boolean flag = false;
}
