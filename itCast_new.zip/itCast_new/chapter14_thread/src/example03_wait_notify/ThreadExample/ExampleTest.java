package example03_wait_notify.ThreadExample;

/**
 * 功能说明: 生产 消费 测试类
 *
 * @author 虞渊
 * @since 2023-09-24-18:06
 */
public class ExampleTest {
    public static void main(String[] args) {
        // 创建线程对象
        new Thread(new Consume(), "消费者线程").start();
        new Thread(new Maker(), "生产者线程").start();
    }
}
