package example03_wait_notify.ThreadExample;

/**
 * 功能说明: 生产者类
 *
 * @author 虞渊
 * @since 2023-09-24-15:08
 */
public class Maker implements Runnable {

    /*
        判断有没有资源
            没有: 生产
            flag = true;
            通知消费者进行消费

            有: 等待
     */
    @Override
    public void run() {
         // 多次生产
        while (true) {
            synchronized (Source.class) {
                if (!Source.flag) {
                    System.out.println("生产者开始制作...");
                    Source.flag = true;
                    // 通知消费者消费
                    Source.class.notify();
                } else {
                    try {
                        System.out.println("生产者等待...");
                        Source.class.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

    }
}
