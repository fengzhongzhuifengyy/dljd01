package example03_wait_notify;

/**
 * 功能说明: 等待唤醒机制 --三个线程
 *
 * @author 虞渊
 * @since 2023-09-21-23:59
 */
public class ThreadDemo02 {
    /*
        实现线程逐一打印
        notify: 随机唤醒, 在哪里等待, 就在哪里醒来, 代码会继续向下执行
        notifyAll : 全部唤醒等待的线程

        synchronized同步代码块, 包裹的内容,会进行同步状态--上锁

        wait() 与 sleep()的区别
        1. sleep()就算进入睡眠状态, 也是抱着锁的,不会释放锁
        2. wait() 进行等待状态后, 就会释放锁

        3. sleep() 时间到达后, 就会自动醒来
        4. wait() 必须有人调用notify(), 才会唤醒
     */
    public static void main(String[] args) {
        Printer1 printer = new Printer1();
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    synchronized (Printer.class){
                        try {
                            printer.p1();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }.start();

        new Thread() {
            @Override
            public void run() {
                while (true) {
                    synchronized (Printer.class) {
                        try {
                            printer.p2();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }.start();

        new Thread() {
            @Override
            public void run() {
                while (true) {
                    synchronized (Printer.class) {
                        try {
                            printer.p3();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }.start();
    }
}


class Printer1 {
    /*
        设计思想
        flag = 1 调用p1()-线程1执行
        flag = 2 调用p2()-线程2执行
     */
    int flag = 1;

    public void p1() throws InterruptedException {
        // 为了让唤醒的线程继续判断,if -> while
        while (flag != 1){
            // 当前线程再次等待
            // 锁对象调用wait()
            Printer.class.wait();
        }
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.println();
        flag = 2;
        // 唤醒其他线程
        Printer.class.notifyAll();
    }

    public void p2() throws InterruptedException {
        while (flag != 2){
            Printer.class.wait();
        }
        System.out.print("5");
        System.out.print("6");
        System.out.print("7");
        System.out.print("8");
        System.out.println();
        flag = 3;
        Printer.class.notifyAll();
    }

    public void p3() throws InterruptedException {
        while (flag != 3){
            Printer.class.wait();
        }
        System.out.print("9");
        System.out.print("10");
        System.out.print("J");
        System.out.print("Q");
        System.out.println();
        flag = 1;
        Printer.class.notifyAll();
    }
}
