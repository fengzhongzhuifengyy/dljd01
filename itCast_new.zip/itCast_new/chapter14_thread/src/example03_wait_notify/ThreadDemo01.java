package example03_wait_notify;

/**
 * 功能说明: 线程的等待唤醒机制
 *
 * @author 虞渊
 * @since 2023-09-21-0:06
 */
public class ThreadDemo01 {
    /*
        实现线程逐一打印
     */
    public static void main(String[] args) {
        Printer printer = new Printer();
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    synchronized (Printer.class){
                        try {
                            printer.p1();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }.start();

        new Thread() {
            @Override
            public void run() {
                while (true) {
                    synchronized (Printer.class) {
                        try {
                            printer.p2();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }.start();
    }
}


class Printer {
    /*
        设计思想
        flag = 1 调用p1()-线程1执行
        flag = 2 调用p2()-线程2执行
     */
    int flag = 1;

    public void p1() throws InterruptedException {
        if (flag != 1){
            // 当前线程再次等待
            // 锁对象调用wait()
            Printer.class.wait();
        }
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.println();
        flag = 2;
        // 唤醒其他线程
        Printer.class.notify();
    }

    public void p2() throws InterruptedException {
        if (flag != 2){
            Printer.class.wait();
        }
        System.out.print("5");
        System.out.print("6");
        System.out.print("7");
        System.out.print("8");
        System.out.println();
        flag = 1;
        Printer.class.notify();
    }
}