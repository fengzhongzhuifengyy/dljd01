package example01_thread;

/**
 * 功能说明: 线程休眠
 *
 * @author 虞渊
 * @since 2023-09-16-16:26
 */
public class ThreadDemo06 {
    /*
        public static void sleep(long millis): 让线程休息xx秒
     */
    public static void main(String[] args) throws InterruptedException {
        for (int i = 0; i < 10; i++) {
            System.out.println(i + "秒");
            Thread.sleep(1000);
        }
    }
}
