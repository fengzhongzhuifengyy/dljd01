package example01_thread;

/**
 * 功能说明:线程优先级
 *
 * @author 虞渊
 * @since 2023-09-16-16:31
 */
public class ThreadDemo07 {
    /*
        java的调度方式: 抢占式调度, 通过设置线程的优先级, 可以让优先级高的线程, 优先使用CPU的执行权
        默认是5, 设置完也不一定高
     */
    public static void main(String[] args) {
        C c1 = new C("C1的线程");
        c1.setPriority(10);
        c1.start();

        C c2 = new C("C2的线程");
        c2.setPriority(1);
        c2.start();

        System.out.println(Thread.currentThread().getPriority()); // 5
    }
}

class C extends Thread{
    public C(String name) {
        super.setName(name);
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + Thread.currentThread().getPriority());
    }
}