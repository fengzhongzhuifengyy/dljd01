package example01_thread;

/**
 * 功能说明:线程的介绍与创建方式1
 *
 * @author 虞渊
 * @since 2023-09-16-9:47
 */
public class ThreadDemo01 {
    /*
        注意: Java程序(进程),在执行起来之后,至少有有2条线程开启
            1. main线程(主线程)
            2. 垃圾回收线程
        什么是垃圾回收机制?
            当一个对象的地址值, 没有任何引用去记录的时候, 就会被判定为内存中的垃圾,此时就会被java中的垃圾回收器在不定时的时候[自动]进行清理

        开启线程的第一种方式:
            继承Thread类:
                1.编写一个类, 继承Thread类
                2.重写run(), 将线程中,需要执行的任务, 写在run()里面
                3.创建线程对象,调用start()开启线程
     */
    public static void main(String[] args) {
        // 这里也需要注意代码执行的顺序, 如果放在最后, 不会进行交替执行
        MyThread th = new MyThread();
        // 这里只能调用start(), 如果调用run()就是简单的对象方法调用
        th.start();

        for (int i = 0; i < 100000; i++) {
            System.out.println("main线程...");
        }
    }
}

class MyThread extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 100000; i++) {
            System.out.println("myThread线程...");
        }
    }
}
