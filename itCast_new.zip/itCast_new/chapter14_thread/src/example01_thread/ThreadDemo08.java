package example01_thread;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

/**
 * 功能说明: 匿名内部类, 开启线程
 *
 * @author 虞渊
 * @since 2023-09-20-20:31
 */
public class ThreadDemo08 {
    /*
        1.继承Thread类
        2.重写run()
        3.创建对象,调用start()
     */
    public static void main(String[] args) {

        new Thread("线程A") {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    System.out.println(Thread.currentThread().getName() + "---" + i);
                }
            }
        }.start();

        new Thread("线程B") {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    System.out.println(Thread.currentThread().getName() + "---" + i);
                }
            }
        }.start();


        /*
              实现Runnable
             1. 创建Thread对象,传参传入Runnable实现类对象
         */
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    System.out.println(Thread.currentThread().getName() + "---" + i);
                }
            }
        }, "线程C").start();

        /*
            实现Callable接口: ---不建议
            但是 我们知道获取线程返回结果 的get(), 这里根本无法拿到
        Integer res = futureTask.get();
         */
        new Thread(new FutureTask(new Callable<Integer>(){

            @Override
            public Integer call() throws Exception {
                int sum = 0;
                for (int i = 0; i < 100; i++) {
                    sum += i;
                    System.out.println(Thread.currentThread().getName() + "---" + i);
                }
                return sum;
            }
        }), "线程D").start();

    }
}
