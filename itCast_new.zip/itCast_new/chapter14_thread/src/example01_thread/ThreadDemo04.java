package example01_thread;

/**
 * 功能说明: 线程中的相关方法
 *
 * @author 虞渊
 * @since 2023-09-16-15:05
 */
public class ThreadDemo04 {
    /*
            public String getName(): 获取线程名字
            public void setName(): 设置线程名字
     */
    public static void main(String[] args) {
        A a = new A("线程1");
        // a.setName("线程1");
        a.start();

        A a1 = new A("线程2");
        // a.setName("线程2");
        a1.start();
    }
}

class A extends Thread{

    //方式二：通过Thread类的构造器方式进行设置线程名称
    public A(String name) {
        super.setName(name);
    }

    @Override
    public void run() {
        for (int i = 0; i < 2000; i++) {
            System.out.println(getName() +"-------"+ i);
        }
    }
}