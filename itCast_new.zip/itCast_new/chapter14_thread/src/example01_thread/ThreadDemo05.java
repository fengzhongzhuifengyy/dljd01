package example01_thread;

/**
 * 功能说明: 获取运行时的线程对象
 *
 * @author 虞渊
 * @since 2023-09-16-15:47
 */
public class ThreadDemo05 {
    /*
         public static Thread currentThread(): 获取当前正在执行的线程对象
     */
    public static void main(String[] args) {
        B b = new B();
        Thread thread = new Thread(b, "线程B");
        thread.start();

        for (int i = 0; i < 2000; i++) {
            System.out.println(Thread.currentThread().getName()+ "-------" + i);
        }
    }
}

class B implements Runnable {

    @Override
    public void run() {
        for (int i = 0; i < 2000; i++) {
            // 此时就不能使用getName(),使用Thread.currentThread().getName()
            System.out.println(Thread.currentThread().getName()+ "-------" + i);
        }
    }
}