package example01_thread;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * 功能说明: 创建线程的第三种方法
 * 为什么需要这种方法? ---因为有返回值
 *
 * @author 虞渊
 * @since 2023-09-16-12:14
 */
public class ThreadDemo03 {
    /*
        实现Callable接口
            1.类实现Callable接口
            2.重写call(), 将线程任务, 写在call()里面
            3.创建Thread对象
            4.创建FutureTask类对象, 将实现类对象, 传入其构造方法
            5.将FutureTask类对象, 传入Thread对象的构造方法
            6.Thread对象调用start()开启线程
     */
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        // 这里就是一个线程资源对象，维护就是线程任务
        MyCallable myCallable = new MyCallable();

        // 这里是线程任务对象
        FutureTask<Integer> futureTask = new FutureTask<>(myCallable);

        // 这里是线程对象, 传参传入线程任务对象
        Thread thread = new Thread(futureTask);

        thread.start();


        int sum = 0;
        for (int i = 0; i < 2000; i++) {
            if (i %2 == 0){
                sum += i;
                System.out.println("偶数sum = " + sum);
            }
        }
        /*
            思考, 这个返回值去哪里了?
         */
        // 获取获取线程任务结果(返回值)
        Integer res = futureTask.get();
        System.out.println("奇数总和= " + res);
        System.out.println("偶数总和= " + sum);



    }
}

class MyCallable implements Callable<Integer> {

    @Override
    public Integer call() throws Exception {
        int sum = 0;
        for (int i = 0; i < 2000; i++) {
            if (i % 2 == 1) {
                sum += i;
                System.out.println("奇数sum = " + sum);
            }
        }
        return sum;
    }
}
