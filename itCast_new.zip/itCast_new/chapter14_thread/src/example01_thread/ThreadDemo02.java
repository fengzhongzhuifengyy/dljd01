package example01_thread;

/**
 * 功能说明: 创建线程的第二种方法
 *
 * @author 虞渊
 * @since 2023-09-16-10:49
 */
public class ThreadDemo02 {
    /*
        实现Runnable接口,开启线程 --- java只能单继承
            1. 类实现Runnable接口, 重写run(), 将线程任务在写run()中
            2. 创建Runnable实现类对象, 将其作为资源[参数]传入Thread对象的构造方法中
            3. 通过Thread对象, 调用start()开启线程
     */
    public static void main(String[] args) {

        MyRunnable myRunnable = new MyRunnable();
        Thread th = new Thread(myRunnable);
        th.start();

        for (int i = 0; i < 200000; i++) {
            System.out.println("main线程...");
        }
    }
}

class MyRunnable implements Runnable{

    @Override
    public void run() {
        for (int i = 0; i < 200000; i++) {
            System.out.println("MyRunnable线程...");
        }
    }
}
