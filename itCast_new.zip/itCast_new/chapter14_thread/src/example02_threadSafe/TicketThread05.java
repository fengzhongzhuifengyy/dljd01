package example02_threadSafe;

/**
 * 功能说明:死锁
 *
 * @author 虞渊
 * @since 2023-09-20-23:54
 */
public class TicketThread05 {
    public static void main(String[] args) {
        Object a = new Object();
        Object b = new Object();
        new Thread(new Runnable() {
            @Override
            public void run() {

                while (true) {
                    synchronized (a) {
                        System.out.println(Thread.currentThread().getName() + "抢到了执行权, 上A锁");

                        synchronized (b) {
                            System.out.println(Thread.currentThread().getName() + "抢到了执行权, 上B锁");
                        }
                    }

                }
            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {

                while (true) {
                    synchronized (b) {
                        System.out.println(Thread.currentThread().getName() + "抢到了执行权, 上B锁");

                        synchronized (a) {
                            System.out.println(Thread.currentThread().getName() + "抢到了执行权, 上A锁");
                        }
                    }

                }
            }
        }).start();
    }
}
