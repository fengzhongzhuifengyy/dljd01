package example02_threadSafe;

/**
 * 功能说明: 电影院3台机器卖100张票 ---引出synchronized(){}同步代码块
 *
 * @author 虞渊
 * @since 2023-09-20-21:03
 */
public class TicketThread01 {
    /*
        可以看出以下有线程安全问题, 出现了多卖的问题?
        什么是线程安全问题?
            多条线程,共享一份数据,进行操作的时候就有可能出现线程安全问题

        解决方案 --上锁 synchronized(锁对象){ 多条语句操作共享数据的代码}
        但是需要多个线程的锁对象 , 保证锁对象是同一把锁
        建议 : 锁对象可以使用类的字节码对象, 因为字节码对象在程序中只有一个对象
     */
    public static void main(String[] args) {
        Ticket t1 = new Ticket("一号机");
        Ticket t2 = new Ticket("二号机");
        Ticket t3 = new Ticket("三号机");

        t1.start();
        t2.start();
        t3.start();
    }
}

class Ticket extends Thread {
    private static int ticket = 100;

    public Ticket(String name) {
        super(name);
    }

    @Override
    public void run() {
        while (true) {
            // 进行上锁操作
            synchronized (Ticket.class) {
                if (ticket <= 0) {
                    break;
                } else {
                    System.out.println(Thread.currentThread().getName() + "正在售卖第" + ticket + "号票");
                    ticket--;
                }
            }
        }
    }
}
