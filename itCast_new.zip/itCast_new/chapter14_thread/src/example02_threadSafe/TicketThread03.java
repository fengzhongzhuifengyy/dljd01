package example02_threadSafe;

/**
 * 功能说明: 使用同步方法解决卖票问题
 *
 * @author 虞渊
 * @since 2023-09-20-22:48
 */
public class TicketThread03 {
    /*
        同步方法:
        格式:
        修饰符 synchronized 返回值类型 方法名(方法参数){方法体;}
        同步方法的锁对象:
            非静态同步方法的锁对象是 this
            静态同步方法的锁对象是 类的字节码对象

     */
    public static void main(String[] args) {
        Ticket3 ticket3 = new Ticket3();
        Thread t1 = new Thread(ticket3, "售票机1");
        Thread t2 = new Thread(ticket3, "售票机2");
        t1.start();
        t2.start();
        /*
            上述代码执行后发现并不能锁住, 因为 非静态的锁对象是this, 不一致导致, 改成this后即可
         */
    }
}

class Ticket3 implements Runnable {
    // 这里思考为什么不需要加static, 因为我们自始至终只有一个线程任务对象
    private int tNum = 100;

    @Override
    public void run() {
        while (true) {
            // A线程使用同步代码块解决。线程B使用同步方法进行解决
            if ("售票机1".equals(Thread.currentThread().getName())) {
                // synchronized (Ticket3.class) {
                synchronized (this) {  // 这里为什么是this?? --> 非静态同步方法的锁对象是 this
                    if (tNum <= 0) {
                        break;
                    } else {
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        System.out.println(Thread.currentThread().getName() + "售卖第" + tNum + "号票");
                        tNum--;
                    }
                }
                // 同步代码方法
            } else if ("售票机2".equals(Thread.currentThread().getName())) {
                // 使用同步方法来实现
                if (check()) {
                    break;
                }
            }

        }
    }

    // 这个就是同步方法 进行上锁
    private synchronized boolean check() {
        if (tNum <= 0) {
            return true;
        } else {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(Thread.currentThread().getName() + "售卖第" + tNum + "号票");
            tNum--;
        }
        return false;
    }
}