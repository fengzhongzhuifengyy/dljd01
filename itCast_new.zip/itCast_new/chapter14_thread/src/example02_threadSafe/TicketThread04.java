package example02_threadSafe;

import java.util.concurrent.locks.ReentrantLock;

/**
 * 功能说明: Lock 锁
 *
 * @author 虞渊
 * @since 2023-09-20-23:20
 */
public class TicketThread04 {
    public static void main(String[] args) {

        Ticket4 ticket4 = new Ticket4();

        Thread t1 = new Thread(ticket4, "售票机1");
        Thread t2 = new Thread(ticket4, "售票机2");
        t1.start();
        t2.start();
    }

}

class Ticket4 implements Runnable {
    // 这里思考为什么不需要加static, 因为我们自始至终只有一个线程任务对象
    private int tNum = 100;

    // 使用Lock技术,创建lock对象, Lock是接口
    private ReentrantLock lock = new ReentrantLock();

    @Override
    public void run() {
        while (true) {
            // 需要上锁
            try {
                lock.lock();
                if (tNum <= 0) {
                    break;
                } else {
                    Thread.sleep(100);
                    System.out.println(Thread.currentThread().getName() + "售卖第" + tNum + "号票");
                    tNum--;
                }
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            } finally {
                // 释放锁 -- 就算有异常也总能释放--try-catch-finally推荐
                lock.unlock();
            }

        }
    }
}
