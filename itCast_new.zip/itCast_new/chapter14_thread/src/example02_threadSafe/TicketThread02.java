package example02_threadSafe;

/**
 * 功能说明: Runnable实现卖票
 *
 * @author 虞渊
 * @since 2023-09-20-22:26
 */
public class TicketThread02 {
    public static void main(String[] args) {
        Ticket2 ticket2 = new Ticket2();

        Thread t1 = new Thread(ticket2);
        Thread t2 = new Thread(ticket2);
        Thread t3 = new Thread(ticket2);

        t1.start();
        t2.start();
        t3.start();
    }

}

class Ticket2 implements Runnable{
    // 这里思考为什么不需要加static, 因为我们自始至终只有一个线程任务对象
    private int tNum = 100;

    @Override
    public void run() {
        while (true){
            synchronized (Ticket2.class){
                if (tNum <= 0){
                    break;
                }else {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    System.out.println(Thread.currentThread().getName() +"售卖第"+ tNum +"号票");
                    tNum--;
                }
            }

        }
    }
}