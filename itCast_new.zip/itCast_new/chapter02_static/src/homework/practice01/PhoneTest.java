package homework.practice01;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月05日 13:13
 */
public class PhoneTest {
    public static void main(String[] args) {

        Phone phone = new Phone("洛基亚", 12.5);
        phone.call();
        phone.sendMessage();
        phone.playGame();
        System.out.println(Phone.size);
    }
}
