package homework.practice06;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:54
 */
public class Dog extends Animal{
    @Override
    public void eat() {
        System.out.println("啃骨头");
    }

    public void watchHome(){
        System.out.println("狗儿看家");
    }
}
