package homework.practice06;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:55
 */
public class Cat extends Animal{
    @Override
    public void eat() {
        System.out.println("猫吃鱼");
    }

    public void catchCat(){
        System.out.println("猫儿抓老鼠");
    }
}

