package homework.practice06;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:54
 */
public abstract class Animal {
    public abstract void eat();
}
