package homework.practice06;

/**
 * 根据需求完成代码:
 * 1.定义动物类
 * 行为:
 * eat方法(无具体行为,不同动物吃的不一样)
 * <p>
 * 2.定义狗类继承动物类
 * 行为:
 * eat方法(啃骨头),看家方法
 * <p>
 * 3.定义猫类继承动物类
 * 行为:
 * eat方法(吃鱼),抓老鼠方法
 * <p>
 * 4.测试类:
 * 以多态的形式创建猫和狗的对象，调用公共的方法，和特有的方法
 *
 * @author 虞渊
 * @since 2022年11月10日 22:53
 */
public class AnimalTest {
    public static void main(String[] args) {

        Animal a = new Dog();
        a.eat();

        Animal c = new Cat();
        c.eat();

        if (a instanceof Dog) {
            ((Dog) a).watchHome();
        }
        if (c instanceof Cat) {
            ((Cat) c).catchCat();
        }
    }
}
