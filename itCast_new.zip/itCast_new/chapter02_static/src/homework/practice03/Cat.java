package homework.practice03;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月05日 16:42
 */
public class Cat extends Animal{

    public Cat(int age, String color) {
        super(age, color);
    }

    @Override
    public void eat(String str) {
        System.out.println("颜色为" + getColor() + "的" + getAge() + "岁的猫, 在吃" + str);
    }

    public void catchMouse(){
        System.out.println("猫抓鼠");
    }
}
