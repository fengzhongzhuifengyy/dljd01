package homework.practice03;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月05日 16:54
 */
public class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void keepPet(Dog dog, String str){
        dog.eat(str);
    }

    public void keepPet(Cat cat, String str){
        cat.eat(str);
    }
}
