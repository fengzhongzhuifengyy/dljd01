package homework.practice03;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月05日 17:01
 */
public class PersonTest {
    public static void main(String[] args) {

        Dog dog = new Dog(3,"黑色");
        Cat cat = new Cat(4, "白色");
        Person person = new Person("张三", 15);
        person.keepPet(dog, "骨头");
        person.keepPet(cat, "小鱼干");
    }
}
