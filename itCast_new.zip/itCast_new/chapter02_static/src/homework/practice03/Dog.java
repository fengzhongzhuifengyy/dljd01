package homework.practice03;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月05日 14:45
 */
public class Dog extends Animal {

    public Dog(int age, String color) {
        super(age, color);
    }

    @Override
    public void eat(String str){
        System.out.println("颜色为" + getColor()+"的" + getAge() + "岁的狗, 在吃" + str);
    }

    public void lookHome(){
        System.out.println("小狗看家");
    }
}
