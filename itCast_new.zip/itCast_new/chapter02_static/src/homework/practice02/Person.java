package homework.practice02;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月05日 14:02
 */
public class Person {
    private String name;
    private char gender;
    private int age;
    public static String nationality = "中国";

    public void eat() {
        System.out.println("吃饭");
    }

    public void sleep() {
        System.out.println("睡觉");
    }

    public void work(){
        System.out.println("工作");
    }

    public Person() {
    }

    public Person(String name, char gender, int age) {
        this.name = name;
        this.gender = gender;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
