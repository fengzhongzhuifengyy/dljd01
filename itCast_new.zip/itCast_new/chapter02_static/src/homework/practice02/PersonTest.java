package homework.practice02;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月05日 14:21
 */
public class PersonTest {
    public static void main(String[] args) {

        Student student = new Student();
        student.work();
        Worker worker = new Worker();
        worker.work();
        StudentLeader sl = new StudentLeader();
        sl.meeting();
    }
}
