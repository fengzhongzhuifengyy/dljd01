package homework.practice02;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月05日 14:13
 */
public class StudentLeader extends Student{
    private String job;

    public StudentLeader() {
    }

    public StudentLeader(String name, char gender, int age, String school, String stuNumber, String job) {
        super(name, gender, age, school, stuNumber);
        this.job = job;
    }

    public void meeting(){
        System.out.println("开会");
    }
}
