package homework.practice07;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 23:07
 */
public class Waiter  extends Employee{

    public Waiter(String number, String name) {
        super(number, name);
    }

    @Override
    public String work() {
        return super.work() + ", 并且为客户服务" ;
    }
}
