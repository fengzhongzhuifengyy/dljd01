package homework.practice07;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 23:02
 */
public class Employee {

    private String number;
    private String name;

    public Employee(String number, String name) {
        this.number = number;
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String work(){
        return getName() + "在工作";
    }
}
