package homework.practice07;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 23:04
 */
public class Manager extends Employee{

    private double bonus;

    public Manager(String number, String name, double bonus) {
        super(number, name);
        this.bonus = bonus;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public String work() {
        return super.work() + ", 并且管理员工";
    }
}
