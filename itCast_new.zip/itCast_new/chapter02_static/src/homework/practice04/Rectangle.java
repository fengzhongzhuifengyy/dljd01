package homework.practice04;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:33
 */
public class Rectangle implements Shape {

    private double length;
    private double weight;

    @Override
    public double calculatePerimeter() {
        return (length + weight) * 2;
    }

    @Override
    public double calculateArea() {
        return length * weight;
    }

    public Rectangle(double length, double weight) {
        this.length = length;
        this.weight = weight;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
