package homework.practice04;

/**
 * 形状类
 *
 * @author 虞渊
 * @since 2022年11月10日 22:18
 */
public interface Shape {



    //求面积
     double calculateArea();

    //求周长
    double calculatePerimeter();


}
