package homework.practice04;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:26
 */
public class Round implements Shape {
    private double pi;
    private double r;

    @Override
    public double calculatePerimeter() {
        return 2 * pi * r;
    }

    @Override
    public double calculateArea() {
        return pi * r * r;
    }

    public Round(double pi, double r) {
        this.pi = pi;
        this.r = r;
    }

    public double getPi() {
        return pi;
    }

    public void setPi(double pi) {
        this.pi = pi;
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }
}
