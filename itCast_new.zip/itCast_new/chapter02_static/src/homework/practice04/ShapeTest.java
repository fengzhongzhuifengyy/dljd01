package homework.practice04;

/**
 * 分析以下需求用代码实现:
 * 	1.定义形状类Shape:
 * 		功能:
 * 			求面积,求周长
 * 	2.定义圆形类Round:
 * 		属性:
 * 			半径,圆周率
 * 		功能:
 * 			求面积,求周长
 *
 * 	3.定义长方形类 Rectangle:
 * 	属性:
 * 			长和宽
 * 		功能:
 * 			求面积,求周长
 * 	4.定义测试类:
 * 	分别创建圆形和长方形对象,为相应的属性赋值
 * 		分别调用求面积和求周长的方法
 *
 * @author 虞渊
 * @since 2022年11月10日 22:17
 */
public class ShapeTest {
    public static void main(String[] args) {

        Round round = new Round(1, 3.14);
        System.out.println(round.calculateArea());
        System.out.println(round.calculatePerimeter());

        Rectangle rectangle = new Rectangle(1, 2);
        System.out.println(rectangle.calculateArea());
        System.out.println(rectangle.calculatePerimeter());
    }
}
