package homework.practice05;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:47
 */
public class OldPhone extends Phone{
    @Override
    public void call() {
        System.out.println("普通的打电话功能");
    }

    @Override
    public void send() {
        System.out.println("普通的发短信功能");
    }
}
