package homework.practice05;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:45
 */
public abstract class Phone {

    public abstract void  call();
    public abstract void  send();

}
