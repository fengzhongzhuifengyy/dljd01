package homework.practice05;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:48
 */
public class NewPhone extends Phone implements IPlay{
    @Override
    public void playGame() {
        System.out.println("新手机可以玩游戏");
    }

    @Override
    public void call() {
        System.out.println("新手机视频通话");
    }

    @Override
    public void send() {
        System.out.println("新手机发送语音和图片");
    }
}
