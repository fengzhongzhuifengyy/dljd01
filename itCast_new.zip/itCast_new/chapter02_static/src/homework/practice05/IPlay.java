package homework.practice05;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 22:46
 */
public interface IPlay {

    void playGame();
}
