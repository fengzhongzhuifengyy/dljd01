package homework.practice08;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 23:14
 */
public class JiDuDog extends Dog implements Drugs{
    @Override
    public void bellow() {
        System.out.println("汪汪叫");
    }

    @Override
    public void eat() {
        System.out.println("啃骨头");
    }

    @Override
    public void jidu() {
        System.out.println("用鼻子测毒品");
    }
}
