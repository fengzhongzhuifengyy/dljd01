package homework.practice08;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月15日 22:47
 */
public class Dog implements Animal{
    @Override
    public void bellow() {
        System.out.println("汪汪汪~");
    }

    @Override
    public void eat() {
        System.out.println("狗吃肉");
    }
}
