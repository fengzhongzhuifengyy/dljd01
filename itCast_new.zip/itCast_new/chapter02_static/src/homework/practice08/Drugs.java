package homework.practice08;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 23:14
 */
public interface Drugs {
     void jidu();
}
