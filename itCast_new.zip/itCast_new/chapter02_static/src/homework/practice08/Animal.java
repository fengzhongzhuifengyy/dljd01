package homework.practice08;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月10日 23:13
 */
public interface Animal {
    void bellow();
    void eat();
}
