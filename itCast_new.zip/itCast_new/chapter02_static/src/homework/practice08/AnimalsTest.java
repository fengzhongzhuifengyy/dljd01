package homework.practice08;

/**
 * 根据需求完成代码:
 * 1.定义动物类：
 * 行为：
 * 吼叫 bellow；没有具体的吼叫行为
 * 吃饭 eat:没有具体的吃饭行为
 * 2.定义缉毒接口 Drugs
 * 行为:
 * 缉毒
 * 3.定义缉毒狗:犬的一种
 * 行为：
 * 吼叫:汪汪叫
 * 吃饭:狗啃骨头
 * 缉毒:用鼻子侦测毒
 * 4.定义测试类:
 * 以多态的形式创建缉毒狗对象,调用缉毒方法和吼叫方法
 *
 * @author 虞渊
 * @since 2022年11月10日 23:12
 */
public class AnimalsTest {

    public static void main(String[] args) {
        Animal a = new JiDuDog();
        a.bellow();
        a.eat();

        Drugs d = new JiDuDog();
        d.jidu();
    }
}
