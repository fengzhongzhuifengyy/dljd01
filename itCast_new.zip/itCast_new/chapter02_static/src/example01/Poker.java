package example01;

import java.util.ArrayList;
import java.util.Collections;

/**
 * 扑克类--模拟打扑克游戏
 * 熟悉static的特点：
 * 1.被类的所以对象所共享
 * 2.多了一种调用方式，可以直接通过类目.成员名直接调用
 * 3.随着类的加载而加载，优先于对象存在
 *
 *
 * @author 虞渊
 * @since 2022年10月31日 6:22
 */
public class Poker {

    public static ArrayList<String> pokers = new ArrayList<>();

    // 54张牌初始化
    static {
        String[] colors = new String[]{"红桃", "黑桃", "方块", "梅花"};
        String[] numbers = new String[]{"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

        // 进行拼接
        for (String color : colors) {
            // String color = colors[i];
            for (String number : numbers) {
                String result = color + number;
                pokers.add(result);
            }
        }
        pokers.add("大王");
        pokers.add("小王");
        // 如果需要打乱发牌顺序怎么办? --- 洗牌
        Collections.shuffle(pokers);// 随机排列指定的列表
        System.out.println(pokers);

        // 现在实现发牌
        // 考虑是不是准备4个集合(3个玩家, 一个底牌)
        ArrayList<String> player1 = new ArrayList<>();
        ArrayList<String> player2 = new ArrayList<>();
        ArrayList<String> player3 = new ArrayList<>();
        ArrayList<String> box = new ArrayList<>();

        for (int i = 0; i < pokers.size(); i++) {
            // 前三张牌作为底牌
            if (i <= 2) {
                box.add(Poker.pokers.get(i));
                // 任何一个数%3 都会得到: 0, 1, 2
            } else if (i % 3 == 0) { // 存入玩家1
                player1.add(Poker.pokers.get(i));
            } else if (i % 3 == 1) {// 存入玩家2
                player2.add(Poker.pokers.get(i));
            } else {// 存入玩家3
                player3.add(Poker.pokers.get(i));
            }
        }

        //看牌
        System.out.println("player1的牌" + player1);
        System.out.println("player2的牌" + player2);
        System.out.println("player3的牌" + player3);
    }
}
