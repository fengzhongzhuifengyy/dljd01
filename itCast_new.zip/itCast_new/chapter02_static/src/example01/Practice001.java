package example01;

/**
 * 斗地主游戏
 * 需求：在启动游戏房间的时候，应该提前准备好54张牌，后续才可以直接使用这些牌数据。
 * 分析：
 * 该房间只需要一副牌
 * 定义一个静态的 ArrayList 集合存储54张牌对象，静态的集合只会加载一份。
 * 在启动游戏房间前，应该将54张牌初始化好
 * 当系统启动的同时需要准备好54张牌数据，此时可以用静态代码块完成。
 *
 * @author 虞渊
 * @since 2022年10月31日 6:20
 */
public class Practice001 {
    public static void main(String[] args) {
        Poker poker = new Poker();
    }
    //体验一下静态代码块的好处,类加载的时候就已经加载完毕,且只执行一次,因为class文件也只加载一次
}
