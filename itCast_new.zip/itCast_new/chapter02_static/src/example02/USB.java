package example02;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月08日 6:59
 */
public interface USB {
    void turnOn();
    void pullOut();
}
