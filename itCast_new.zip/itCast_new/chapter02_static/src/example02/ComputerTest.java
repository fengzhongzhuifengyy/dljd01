package example02;

/**
 * 多态综合案例：
 * 使用面向对象编程模拟:设计一个电脑对象,可以安装2个usb设备
 * 鼠标:被安装时,可以完成接入,调用点击功能,拔出功能
 * 键盘:被安装时,可以完成接入,调用打字功能,拔出功能
 *
 * @author 虞渊
 * @since 2022年11月08日 7:00
 */
public class ComputerTest {
    public static void main(String[] args) {
        Keyboard keyboard = new Keyboard();
        Mouse mouse = new Mouse();
        Computer computer = new Computer();
        computer.useUsb(keyboard);
        computer.useUsb(mouse);
    }
}
