package example02;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月08日 6:59
 */
public class Computer {

    public void useUsb(USB u){
        u.turnOn();
        u.pullOut();

        if (u instanceof Mouse){
            Mouse m = (Mouse)u;
            m.click();
        }else if (u instanceof Keyboard){
            Keyboard k = (Keyboard) u;
            k.input();
        }
    }
}
