package example02;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月08日 7:04
 */
public class Keyboard implements USB{
    @Override
    public void turnOn() {
        System.out.println("键盘接入");
    }

    @Override
    public void pullOut() {
        System.out.println("键盘拔出");
    }

    public void input(){
        System.out.println("键盘打字");
    }
}
