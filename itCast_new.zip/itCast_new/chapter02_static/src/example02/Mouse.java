package example02;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月08日 7:03
 */
public class Mouse implements USB{
    @Override
    public void turnOn() {
        System.out.println("鼠标接入");
    }

    @Override
    public void pullOut() {
        System.out.println("鼠标拔出");
    }

    public void click(){
        System.out.println("鼠标点击");
    }
}
