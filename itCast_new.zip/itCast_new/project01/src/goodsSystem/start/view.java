package goodsSystem.start;

import com.itCast.study.project.goodsSystem.bean.Goods;
import goodsSystem.exception.CountOutOfBoundsException;
import goodsSystem.exception.DescNoSuchException;
import goodsSystem.exception.PriceOutOfBoundsException;
import goodsSystem.exception.TypeNoSuchException;
import goodsSystem.exception.nameParseException;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * @author: 虞渊
 * @date: 2023/6/18
 */
public class view {

    static HashMap<String, ArrayList<Goods>> shoppingMap = new HashMap<>();
    // 增删改查都需要键盘录入, 直接提取
    static Scanner sc = new Scanner(System.in);

    // 初始化加载
    static {
        //添加第一个店铺
        ArrayList<Goods> list1 = new ArrayList<>();
        list1.add(new Goods("《数据库从删库到跑路》", 50.27, "图书", 50, "作者：高斯林", new Date()));
        list1.add(new Goods("《颈椎病康复指南》", 20.34, "图书", 20, "作者：XX教授", new Date()));
        list1.add(new Goods("《金瓶梅》", 120.91, "图书", 10, "作者：阿玮", new Date()));
        list1.add(new Goods("《富婆通讯录》", 200, "图书", 5, "作者：张三", new Date()));
        shoppingMap.put("黑马图书专卖", list1);

        //添加第二个店铺
        ArrayList<Goods> list2 = new ArrayList<>();
        list2.add(new Goods("《霸王防脱洗发露》", 10.27, "生活商品", 100, "越洗越脱", new Date()));
        list2.add(new Goods("《生姜生发指南》", 20.14, "生活商品", 20, "越擦越亮", new Date()));
        list2.add(new Goods("《富婆快乐球》", 120.91, "生活商品", 5, "越擦越快乐", new Date()));
        list2.add(new Goods("《奥特曼泡酒》", 1200, "生活商品", 150, "越喝越上头", new Date()));
        shoppingMap.put("黑马生活专卖", list2);
    }

    public static void main(String[] args) {
        boolean isFlag = true;
        Scanner sc = new Scanner(System.in);
        do {

            System.out.println("===========欢迎进入黑马商场管理系统===========");
            System.out.println("1. 查看全部商品信息");
            System.out.println("2. 上架商品信息");
            System.out.println("3. 下架商品信息");
            System.out.println("4. 修改商品信息");
            System.out.println("5. 查询单个的商品信息");
            System.out.println("6. 退出系统");

            System.out.print("请输入你的选择: ");
            String choose = sc.nextLine();

            switch (choose) {
                case "1":
                    showGoodsInfo();
                    break;
                case "2":
                    addGoods();
                    break;
                case "3":
                    deleteGoods();
                    break;
                case "4":
                    System.out.println("修改商品信息");
                    break;
                case "5":
                    System.out.println("查询单个的商品信息");
                    break;
                case "6":
                    System.out.println("退出系统");
                    isFlag = false;
                    break;
                default:
                    System.out.println("输入有误,请重新输入");
            }

        } while (isFlag);
    }

    /**
     *  下架商品信息
     */
    private static void deleteGoods() {
        // 最后需要放入集合中,所以需要提权
        ArrayList<Goods> list;
        while (true) {
            System.out.println("请输入下架的店铺名称: ");
            String shopName = sc.nextLine();

            if (shoppingMap.containsKey(shopName)) {
                // 已存在,找到店铺的list,删除
                list = shoppingMap.get(shopName);
                System.out.println("请输入下架的商店名称: ");
                String goodsName = sc.nextLine();

                int index = -1;
                for (int i = 0; i < list.size(); i++) {
                    if (goodsName.equals(list.get(i).getName())){
                        index = i;
                    }
                }
                if (index != -1){
                    list.remove(index);
                    break;
                }else {
                    System.out.println("您输入的商品不存在!");
                }
            } else {
                //不存在,提示
                System.out.println("您输入的店铺不存在!");
            }
        }
    }

    /**
     * 上架商品信息
     */
    private static void addGoods() {
        System.out.println("请输入上架的店铺名称: ");
        String shopName = sc.nextLine();
        // 最后需要放入集合中,所以需要提权
        ArrayList<Goods> list;
        if (shoppingMap.containsKey(shopName)) {
            // 已存在,找到店铺的list,继续添加
            list = shoppingMap.get(shopName);
        } else {
            //不存在,创建新的集合
            list = new ArrayList<>();
        }
        // 将商品信息放入list中
        Goods goods = new Goods();
        String goodsName = null;
        // 名称唯一且合法(包含书名号) --正则校验
        while (true) {
            System.out.println("请输入商品名称: ");
            goodsName = sc.nextLine();
            // 校验商品是否存在
            if (queryGoods(goodsName, list)) {
                // 需要重新输入
                System.out.println("输入的商品名称已存在,请重新输入!");
            } else {
                // 不存在,就添加
                // 判断名称是否合法, 书名号,这里使用自定义异常实现
                try {
                    goods.setName(goodsName);
                    break;
                } catch (nameParseException e) {
                    System.out.println("输入的书名不合法,请重新输入!");
                    ;
                }
            }
        }
        // 价格合法接不能为负数
        while (true) {
            System.out.println("请输入商品价格: ");
            try {
                double goodsPrice = Double.parseDouble(sc.nextLine());
                goods.setPrice(goodsPrice);
                break;
            } catch (NumberFormatException e) {
                System.out.println("您输入的价格不合法,请重新输入!");
            } catch (PriceOutOfBoundsException e) {
                System.out.println("您输入的价格不能是负数,请重新输入!");
            }
        }
        // 类型不能没有内容
        while (true) {
            System.out.println("请输入商品类型: ");
            try {
                String goodsType = sc.nextLine();
                goods.setType(goodsType);
                break;
            } catch (TypeNoSuchException e) {
                System.out.println("商品内容不能为空,请重新输入!");
            }
        }
        // 库存必须大于1
        while (true) {
            System.out.println("请输入商品库存: ");
            try {
                int goodsCount = Integer.parseInt(sc.nextLine());
                goods.setCount(goodsCount);
                break;
            } catch (NumberFormatException e) {
                System.out.println("输入的数量不是整数,请重新输入!");
            } catch (CountOutOfBoundsException e) {
                System.out.println("输入的数量小于1,请重新输入!");
            }
        }
        // 描述不能没有内容
        while (true) {
            System.out.println("请输入商品描述: ");
            try {
                String goodsDesc = sc.nextLine();
                goods.setDesc(goodsDesc);
                break;
            } catch (DescNoSuchException e) {
                System.out.println("您输入的描述不能为空,请重新输入!");
            }
        }

        goods.setTime(new Date());

        // 将货物添加到list中
        list.add(goods);
        shoppingMap.put(shopName, list);
    }

    /**
     * 查询商品名称是否存在
     */
    private static boolean queryGoods(String goodsName, ArrayList<Goods> list) {
        for (Goods goods : list) {
            if (goods.getName().equals(goodsName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 查看全部商品信息
     */
    private static void showGoodsInfo() {
        System.out.println("===========商品展示页面===========");
        Set<Map.Entry<String, ArrayList<Goods>>> entrySet = shoppingMap.entrySet();
        for (Map.Entry<String, ArrayList<Goods>> entry : entrySet) {
            System.out.println("店铺: " + entry.getKey());
            for (Goods good : entry.getValue()) {
                System.out.println("\t\t商品名称: " + good.getName());
                System.out.println("\t\t商品价格: " + good.getPrice());
                System.out.println("\t\t商品类型: " + good.getType());
                System.out.println("\t\t商品库存: " + good.getCount());
                System.out.println("\t\t商品描述: " + good.getDesc());
                System.out.println("\t\t商品上架时间: " + good.getTime());
                System.out.println("----------------------------");
            }
        }
    }
}
