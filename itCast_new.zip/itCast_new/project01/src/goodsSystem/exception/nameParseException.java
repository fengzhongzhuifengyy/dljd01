package goodsSystem.exception;

/**
 * @author: 虞渊
 * @date: 2023/6/18
 */
public class nameParseException extends RuntimeException {
}
