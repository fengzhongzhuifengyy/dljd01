package goodsSystem.exception;

/**
 * @author: 虞渊
 * @date: 2023/6/19
 */
public class TypeNoSuchException extends RuntimeException {
}
