package goodsSystem.bean;

import goodsSystem.exception.CountOutOfBoundsException;
import goodsSystem.exception.DescNoSuchException;
import goodsSystem.exception.PriceOutOfBoundsException;
import goodsSystem.exception.TypeNoSuchException;
import goodsSystem.exception.nameParseException;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author: 虞渊
 * @date: 2023/6/18
 */
public class Goods {
    private String name;        // 商品名称
    private double price;       // 商品价格
    private String type;        // 商品类型
    private int count;          // 商品库存
    private String desc;        // 商品描述
    private Date time;          // 上架时间

    public Goods() {
    }

    public Goods(String name, double price, String type, int count, String desc, Date time) {
        this.name = name;
        this.price = price;
        this.type = type;
        this.count = count;
        this.desc = desc;
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.matches("《.+》")) {
            this.name = name;
        } else {
            throw new nameParseException();
        }

    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0) {
            throw new PriceOutOfBoundsException();
        } else {
            this.price = price;
        }

    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        if (type.length() < 1) {
            throw new TypeNoSuchException();
        } else {
            this.type = type;
        }

    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        if (count < 1) {
            throw new CountOutOfBoundsException();
        }else {
            this.count = count;
        }

    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        if (desc.length() < 1){
            throw new DescNoSuchException();
        }
        this.desc = desc;
    }

    public String getTime() {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss E a");
        String dateString = sdf.format(time);
        return dateString;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", type='" + type + '\'' +
                ", count=" + count +
                ", desc='" + desc + '\'' +
                ", time=" + time +
                '}';
    }
}
