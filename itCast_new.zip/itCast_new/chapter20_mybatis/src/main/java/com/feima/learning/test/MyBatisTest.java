package com.feima.learning.test;


import com.feima.learning.mapper.BrandMapper;
import com.feima.learning.mapper.UserMapper;
import com.feima.learning.pojo.Brand;
import com.feima.learning.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 功能说明:测试类
 *
 * @author 虞渊
 * @since 2024-01-20-14:25
 */
public class MyBatisTest {

    @Test
    public void selectAllTest() throws IOException {
        // 1.加载核心配置文件（mybatis-config.xml），获取sqlSessionFactory对象，官网直接复制
        String source = "mybatis-config.xml";
        InputStream resourceStream = Resources.getResourceAsStream(source);
        // 读取流中的数据，解析xml文件中的内容并封装
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceStream);
        // 2.获取 sqlSession 对象，相当于之前的获取链接
        SqlSession sqlSession = sqlSessionFactory.openSession();
        // 3.获取 Mapper 接口代理对象，底层使用的是动态代理技术
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        // 4.调用Mapper接口代理对象CRUD方法，执行结果，获取结果
        List<User> users = userMapper.selectAll();
        // 5.处理结果，释放资源
        users.forEach(System.out::println);
        sqlSession.close();
    }

    @Test
    public void selectById() throws IOException {
        String sourceFile = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(sourceFile);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        User user = userMapper.selectById(1);
        System.out.println(user);
    }

    @Test
    public void addUser() throws IOException {
        String sqlSource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(sqlSource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        // 方法二： 设置为自动提交
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        User user = new User();
        user.setUsername("张益达");
        user.setPassword("123455");
        user.setGender("男");
        user.setAddr("爱情公寓");
        int line = userMapper.addUser(user);
        // 默认不是自动提交
        // 方法1：手动提交
        // sqlSession.commit();
        System.out.println("影响的行数：" + line);
    }

    @Test
    public void updateUser() throws IOException {
        String source = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(source);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        User user = new User();
        user.setId(7);
        user.setUsername("张伟");
        user.setPassword("123455");
        user.setGender("男");
        user.setAddr("爱情公寓");
        int line = userMapper.updateUser(user);
        System.out.println("影响的行数：" + line);
    }

    @Test
    public void deleteUser() throws IOException {
        UserMapper userMapper = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true).getMapper(UserMapper.class);
        int line = userMapper.deleteById(5);
        System.out.println("影响的行数：" + line);
    }

    //============brand测试==============//
    @Test
    public void selBrandAll() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        List<Brand> brands = mapper.selectAllBrand();
        System.out.println(brands);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void selBrandById() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        Brand brand = mapper.selBrandById(3);
        System.out.println(brand);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void addBrand() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        Brand brand = new Brand();
        brand.setBrandName("白象");
        brand.setCompanyName("白象食品公司");
        brand.setOrdered(1);
        brand.setDescription("好吃不贵");
        brand.setStatus(2);
        mapper.addBrand(brand);
        System.out.println(brand);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void updateBrand() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        Brand brand = new Brand();
        brand.setId(4);
        brand.setBrandName("白象X");
        brand.setCompanyName("白象X食品公司");
        brand.setOrdered(2);
        brand.setDescription("好吃不贵！！");
        brand.setStatus(3);
        mapper.updateBrand(brand);
        System.out.println(brand);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void deleteBrand() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        mapper.deleteBrandById(4);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void queryBrandByCondition1() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        Brand brand = new Brand();
        brand.setBrandName("华为");
        brand.setCompanyName("华为");
        brand.setStatus(1);
        List<Brand> brands = mapper.queryByCondition1(brand);
        brands.forEach(s -> System.out.println(s));
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void queryBrandByCondition2() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        Map<String, Object> brandMap = new HashMap();
        brandMap.put("status", 1);
        brandMap.put("companyName", "华为");
        brandMap.put("brandName", "华为");
        // 但是要注意，能查询成功，必须设置的key的值与sql中传入的属性值的名称一致才能正确匹配、查询成功
        List<Brand> brands = mapper.queryByCondition2(brandMap);
        brands.forEach(System.out::println);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void queryBrandByCondition3() throws IOException {
        /*
            如果不添加参数注解，则会报如下错误：
            ### Error querying database.  Cause: org.apache.ibatis.binding.BindingException: Parameter 'status' not found.
            Available parameters are [arg2, arg1, arg0, param3, param1, param2]

            底层分析：
            当mybatis执行CRUD操作，如果参数有多个，那么mybatis底层会将这些参数存储到一个map集合中，key分别叫arg0/param1、arg1/param2
            例如：
            map.put(""arg0",status);
            map.put("param1",status);
            map.put("arg1",companyName);
            map.put("param2",companyName);
            map.put("arg2",BrandName);
            map.put（"param3",BrandName);
            上述名称阅读性很差，所以mybatis提供了一个aParam注解来给参数取名字
         */
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        List<Brand> brands = mapper.queryByCondition3(1, "华为", "华为");
        brands.forEach(System.out::println);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void queryBrandByCondition4() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        Brand brand = new Brand();
        brand.setStatus(1);
        List<Brand> brands = mapper.queryByCondition4(brand);
        brands.forEach(System.out::println);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void queryBrandByCondition5() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        Brand brand = new Brand();
        brand.setStatus(1);
        List<Brand> brands = mapper.queryByCondition5(brand);
        brands.forEach(System.out::println);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void updateBrandByCondition() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        Brand brand = new Brand();
        brand.setBrandName("鸿星尔克");
        brand.setId(1);
        brand.setDescription("to be no1!");
        mapper.updatePartCondition(brand);
        // 关闭资源
        sqlSession.close();
    }

    @Test
    public void deleteBrandByCondition() throws IOException {
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsStream("mybatis-config.xml")).openSession(true);
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        /*
            如果参数是数组类型，底层会将数组保存到map集合。
            map.put("arg0",ids);
            map.put("array",ids);

            可以使用@Param注解取名称：@Param("ids"） int[] ids
            map.put("ids",ids);

            如果参数是集合类型ist，底层会将数组保存到map集合。--了解
            map.put("argo",ids);
            map.put("collection",ids);
            map.put("list",ids);
         */
        mapper.deleteBatch(new int[]{0});
        // 关闭资源
        sqlSession.close();
    }
}
