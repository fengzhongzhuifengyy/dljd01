package com.feima.learning.mapper;

import com.feima.learning.pojo.User;

import java.util.List;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2024-01-20-14:09
 */
public interface UserMapper {
    /*
        在mybatis中执行CRUD操作我们不需要写java类，需要定义一个mapper接口，在接口中定义CRUD方法
        并且给CRUD方法定义sql语句；mybatis底层会通过动态代理方式给当前接口创建实现类对象。
     */
    // @Select("select * from tb_user")
    List<User> selectAll();

    // 根据id获取用户信息， 如果参数是基本类型或者是包装类型，那么占位符的名称可以任意写
    // #{名称} 表示mybatis中参数占位符，在程序运行的时候会被编译成？
    // @Select("select * from tb_user where id=#{id}")
    User selectById(int id);

    // #{对象的属性名} 表示mybatis中参数占位符，如果参数是对象类型，占位符的名称就是对象对应的属性名
    // 针对增删改查的返回值要么是void，要么就是int类型，int类型将会返回影响的行数
    // @Insert("INSERT INTO tb_user values(id, #{username}, #{password}, #{gender}, #{addr})")
    int addUser(User user);

    // @Update("update tb_user set username=#{username}, password=#{password}, gender=#{gender}, addr=#{addr} where id=#{id}")
    int updateUser(User user);

    // @Delete("delete from tb_user where id=#{id}")
    int deleteById(int id);
}