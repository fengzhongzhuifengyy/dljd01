package com.feima.learning.mapper;

import com.feima.learning.pojo.Brand;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2024-02-04-22:21
 */
public interface BrandMapper {

    List<Brand> selectAllBrand();

    Brand selBrandById(int id);

    // 注解方式返回并传递主键参数
    // @Insert("insert into mybatis.tb_brand values (null, #{brandName}, #{companyName}, #{ordered}, #{description}, #{status})")
    // @Options(useGeneratedKeys = true, keyProperty = "id")
    void addBrand(Brand brand);

    void updateBrand(Brand brand);

    void deleteBrandById(int id);

    /*
        多条件查询
        方式一： 传参实例对象， 封装了查询条件（status、companyName、brandName）
     */
    List<Brand> queryByCondition1(Brand brand);

    /*
       多条件查询
       方式二： 传参map
    */
    List<Brand> queryByCondition2(Map map);

    /*
       多条件查询
       方式二： 传参多个值
       需要使用@Param("SQL中的参数名称")
    */
    List<Brand> queryByCondition3(@Param("status") int status,@Param("companyName") String companyName, @Param("brandName")String brandName);

    /*
      多条件查询
      方式四：动态sql
      实际用户不会全部输出查询参数，所以我们需要使用动态参数实现用户查询
   */
    List<Brand> queryByCondition4(Brand brand);

    /*
     单条件查询：从多个条件中选择一个
     方式五：动态sql
    */
    List<Brand> queryByCondition5(Brand brand);

    /*
        修改部分参数
     */
    void updatePartCondition(Brand brand);

    /*
        批量删除
     */
    void deleteBatch(@Param("ids") int[] ids);
}
