package example02_udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * 功能说明: 模拟UDP服务端
 *
 * @author 虞渊
 * @since 2023-10-07-22:19
 */
public class UDPServer {
    public static void main(String[] args) throws IOException {

        DatagramSocket socket = new DatagramSocket(8888);

        byte[] bytes = new byte[1024];
        DatagramPacket packet = new DatagramPacket(bytes, bytes.length);

        socket.receive(packet);
        // 打印出数组每轮的长度的数据
        String str = new String(bytes, 0, packet.getLength());
        System.out.println(str);

        socket.close();
    }
}
