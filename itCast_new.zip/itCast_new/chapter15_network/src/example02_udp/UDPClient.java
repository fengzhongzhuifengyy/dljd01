package example02_udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * 功能说明:模拟Udp客户端, 注意:UDP协议, 收发数据的时候没有明显的客户端和服务端
 *
 * @author 虞渊
 * @since 2023-10-07-22:19
 */
public class UDPClient {
    public static void main(String[] args) throws IOException {

        // 创建码头对象DatagramSocket
        DatagramSocket socket = new DatagramSocket();
        // 创建包裹对象DatagramPackage
        String content = "你好啊~~~";
        byte[] bytes = content.getBytes();
        DatagramPacket packet = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("127.0.0.1"), 8888);
        // 调用码头对象的发送方法.将包裹对象发送出去
        socket.send(packet);
        // 关闭流
        socket.close();
    }
}
