package example02_udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-11-26-23:52
 */
public class UDPClient02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try  {
            DatagramSocket socket = new DatagramSocket();

            while (true){
                String input = scanner.nextLine();
                if (!"886".equals(input)){
                    byte[] bytes = input.getBytes();
                    DatagramPacket packet = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("192.168.1.2"), 8888);
                    socket.send(packet);
                }else {
                    break;
                }
            }
            socket.close();
        } catch (SocketException e) {
            throw new RuntimeException(e);
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
