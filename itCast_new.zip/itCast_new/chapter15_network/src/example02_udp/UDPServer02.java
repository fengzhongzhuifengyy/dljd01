package example02_udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-11-26-23:52
 */
public class UDPServer02 {
    public static void main(String[] args) {
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket(8888);
        } catch (SocketException e) {
            throw new RuntimeException(e);
        }
        while (true) {
            byte[] bytes = new byte[1024];
            DatagramPacket packet = new DatagramPacket(bytes, bytes.length);
            try {
                socket.receive(packet);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            String s = new String(bytes, 0, packet.getLength());
            System.out.println(s);
        }
    }
}
