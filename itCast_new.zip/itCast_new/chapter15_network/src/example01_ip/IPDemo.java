package example01_ip;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 功能说明: IP类--InetAddress
 *
 *
 * @author 虞渊
 * @since 2023-09-26-0:20
 */
public class IPDemo {
    /*
         getByName ：确定主机名称的IP地址。主机名称可以是机器名称，也可以是IP地址
         getHostName：获取主机名
         getHostAddress ：获取IP
     */
    public static void main(String[] args) throws UnknownHostException {

        //1.获取一个IP地址(在网络中计算机的对象)
        InetAddress address = InetAddress.getByName("192.168.1.2");
        System.out.println(address);

        //3.获取IP
        String hostIP = address.getHostAddress();
        System.out.println(hostIP);

        //2.获取主机名获取ip地址
        //细节：如果能获取到主机名返回的就是主机名
        //但是如果有的情况下，获取不到，返回的就是ip地址
        String hostName = address.getHostName();
        System.out.println(hostName);
    }
}
