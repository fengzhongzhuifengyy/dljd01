package example03_tcp;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

/**
 * 功能说明: TCP客户端
 *
 * @author 虞渊
 * @since 2023-10-08-21:00
 */
public class TCPClient1 {
    public static void main(String[] args) throws IOException {
        // 1. 创建Socket对象, 连接服务端
        Socket socket = new Socket("127.0.0.1", 8888);

        // 2. 获取网络流对象, 进行数据传输
        OutputStream outputStream = socket.getOutputStream();

        // 3. 写出数据到服务端
        outputStream.write("喂喂喂喂, 服务器~~~~".getBytes());

        // 4. 关闭流
        socket.close();
    }
}
