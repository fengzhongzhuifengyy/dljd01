package example03_tcp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 * 功能说明:
 * 1. 向服务端发送一个字符串
 * 2.
 *
 * @author 虞渊
 * @since 2023-11-29-21:07
 */
public class TCPClient2 {
    public static void main(String[] args) {
        try {
            // 创建对象
            Socket socket = new Socket("127.0.0.1", 8889);
            // 获取流
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            // 发送消息
            bw.write("你好啊啊啊啊啊啊啊啊~~~~");
            bw.newLine();
            // 写出数据
            bw.flush();

            String s = br.readLine();
            System.out.println(s);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}
