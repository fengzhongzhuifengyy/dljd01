package example03_tcp;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 功能说明: TCP服务端
 *
 * @author 虞渊
 * @since 2023-10-08-21:00
 */
public class TCPServer1 {
    public static void main(String[] args) throws IOException {
        // 1. 创建ServerSocket对象
        ServerSocket serverSocket = new ServerSocket(8888);

        System.out.println("服务端已开启");

        // 2. 响应客户端发送过来的请求
        Socket socket = serverSocket.accept();

        System.out.println("服务端接收到了数据");

        // 3. 获取网络输入流(读取客服端发送的数据)
        BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        // 获取客户端发送的数据
        String str = br.readLine();
        System.out.println(str);

        // 4. 关闭流
        socket.close();
        serverSocket.close();
    }
}
