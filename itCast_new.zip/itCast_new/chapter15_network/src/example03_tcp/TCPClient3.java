package example03_tcp;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * 功能说明: 实现文件上传
 *
 * @author 虞渊
 * @since 2023-11-29-21:59
 */
public class TCPClient3 {
    public static void main(String[] args) {
        try {
            // 创建对象
            Socket socket = new Socket("127.0.0.1", 8890);
            String s = new Scanner(System.in).nextLine();
            // 输出流用来向服务器发送数据
            OutputStream os = socket.getOutputStream();
            // 传输本地的输入流
            FileInputStream fs = new FileInputStream("D:\\test\\win.png");
            // 操作数据
            byte[] bytes = new byte[8096];
            int len;
            while ((len = fs.read(bytes)) != -1){
                os.write(bytes, 0, len);
            }
            // 输出完就关闭
            socket.shutdownOutput();
            // 关闭流
            fs.close();
            socket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
