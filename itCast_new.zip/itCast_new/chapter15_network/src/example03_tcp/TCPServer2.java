package example03_tcp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-11-29-21:08
 */
public class TCPServer2 {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(8889);
            Socket socket = serverSocket.accept();

            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            // 读取客户端消息
            String s = br.readLine();
            System.out.println("读取到客户端发送的消息:" + s);

            // 回写给客户端
            bw.write("你好啊, 客户端~~~");
            bw.newLine();
            // 写出数据
            bw.flush();


            socket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
