package example03_tcp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 功能说明:实现文件上传,想要跟多个客户端进行通讯,-- 使用多线程
 *
 * @author 虞渊
 * @since 2023-11-29-21:59
 */
public class TCPServer3 {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(8890);

            ThreadPoolExecutor pool = new ThreadPoolExecutor(
                    2,
                    5,
                    60,
                    TimeUnit.SECONDS,
                    new ArrayBlockingQueue<>(10),
                    Executors.defaultThreadFactory(),
                    new ThreadPoolExecutor.AbortPolicy()
            );


            while (true) {
                Socket so = serverSocket.accept();
                pool.submit(new Fileupload(so));

            }
            // so.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
