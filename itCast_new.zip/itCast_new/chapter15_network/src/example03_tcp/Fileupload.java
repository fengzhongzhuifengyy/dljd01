package example03_tcp;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.UUID;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-11-29-23:54
 */
public class Fileupload implements Runnable {
    private Socket so;

    public Fileupload(Socket so) {
        this.so = so;
    }

    @Override
    public void run() {
        try {
            InputStream is = so.getInputStream();
            FileOutputStream fos = new FileOutputStream( "D:\\test\\" + UUID.randomUUID().toString()+"copy.png");
            // 操作数据
            byte[] bytes = new byte[8096];
            int len;
            while ((len = is.read(bytes)) != -1){
                fos.write(bytes, 0, len);
            }
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
