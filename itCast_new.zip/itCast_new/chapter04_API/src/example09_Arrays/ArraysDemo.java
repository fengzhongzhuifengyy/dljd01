package example09_Arrays;

import java.util.Arrays;
import java.util.Comparator;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月06日 23:55
 */
public class ArraysDemo {
    /*
        public static String toString(类型[] a)	将数组元素拼接为带有格式的字符串
        public static void sort (类型[] a)	对数组进行默认升序排序
        public static <T> void sort (类型[] a, Comparator<? super T> c)	使用比较器对象自定义排序
        public static int binarySearch (int[] a, int key)	二分搜索数组中的数据，存在返回索引，不存在返回-1
     */
    public static void main(String[] args) {
        int[] arr = {11, 22, 44, 33, 5};
        System.out.println(Arrays.toString(arr));

        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));

        // 指定比较器进行比较(hashSet加强讲)
        Integer[] arr2 = {55, 11, 33, 22, 44};
        Arrays.sort(arr2, new Comparator<Integer>(){

            @Override
            public int compare(Integer o1, Integer o2) {
                return o2-o1;
            }
        });
        System.out.println(Arrays.toString(arr2));

        // 二分法查找 必须升序才能查找
        System.out.println(Arrays.binarySearch(arr, 22));
    }
}
