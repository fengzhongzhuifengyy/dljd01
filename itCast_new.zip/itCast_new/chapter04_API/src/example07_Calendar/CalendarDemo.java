package example07_Calendar;

import java.util.Calendar;

/**
 * Calendar:
 * Calendar代表了系统此刻日期对应的日历对象。
 * Calendar是一个抽象类，不能直接创建对象。
 *
 * @author 虞渊
 * @since 2022年12月03日 22:26
 */
public class CalendarDemo {
    /*
        1.public int get(int field):取日期中的某个字段信息。推荐传入Calendar里面的静态常量:Calendar.YEAR
        2.public void set(int field,int value):修改日历的某个字段信息。参数1: 指定修改的字段(年月日);参数2: 要修改的具体值;
        3.public void add(int field,int amount):为某个字段增加/减少指定的值。参数1: 指定修改的字段(年月日);参数2: 指定偏移量(+ -)
        4.public final Date getTime():拿到此刻日期对象。
        5.public long getTimeInMillis():拿到此刻时间毫秒值

        calendar是可变日期对象，一旦修改后其对象本身表示的时间将产生变化。
     */
    public static void main(String[] args) {

        // Calendar c: 抽象类
        // Calendar.getInstance(): 获取Calendar类的子类对象
        Calendar ca = Calendar.getInstance();
        System.out.println(ca);
        /*
        java.util.GregorianCalendar[time=1680411918529,areFieldsSet=true,areAllFieldsSet=true,lenient=true,
        zone=sun.util.calendar.ZoneInfo[id="Asia/Shanghai",offset=28800000,dstSavings=0,useDaylight=false,
        transitions=19,lastRule=null],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=1,YEAR=2023,MONTH=3,
        WEEK_OF_YEAR=14,WEEK_OF_MONTH=2,DAY_OF_MONTH=2,DAY_OF_YEAR=92,DAY_OF_WEEK=1,DAY_OF_WEEK_IN_MONTH=1,
        AM_PM=1,HOUR=1,HOUR_OF_DAY=13,MINUTE=5,SECOND=18,MILLISECOND=529,ZONE_OFFSET=28800000,DST_OFFSET=0]
         */

        System.out.println(ca.get(Calendar.YEAR) + "年");
        System.out.println(ca.get(Calendar.MONTH) + 1 + "月"); // 需要+1操作
        System.out.println(ca.get(Calendar.DAY_OF_MONTH) + "日");

        String[] weeks = {"", "日", "一", "二", "三", "四", "五", "六"};
        System.out.println("星期" + weeks[ca.get(Calendar.DAY_OF_WEEK)]); // 这个星期怎么表示呢? ---> 通过查表法

        // 需求: 判断当前年份,是否为闰年
        // 思路: 将Calendar对象,设置为当前年份的3月1日,再将日期向前一天进行判断
        ca.set(Calendar.YEAR, Calendar.MARCH, 1); // set(year,mouth,day): 可以直接设置年月日
        ca.add(Calendar.DAY_OF_MONTH, -1);
        int day = ca.get(Calendar.DAY_OF_MONTH);
        if (day == 29) {
            System.out.println("是闰年");
        } else {
            System.out.println("不是闰年");
        }

    }
}
