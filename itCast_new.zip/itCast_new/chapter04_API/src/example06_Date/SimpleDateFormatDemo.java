package example06_Date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *  SimpleDateFormat: 日期格式化类
 *  可以对Date对象或时间毫秒值格式化成我们喜欢的时间形式。
 *  也可以把字符串的时间形式解析成日期对象。
 *
 * @author 虞渊
 * @since 2022年11月29日 7:50
 */
public class SimpleDateFormatDemo {
    /*
        构造方法:
        public SimpleDateFormat(): 构造一个SimpleDateFormat，使用默认格式
        public SimpleDateFormat(String pattern): 构造一个SimpleDateFormat，使用指定的格式

        成员方法:
        public final String format(Date date): 将日期对象格式化成日期/时间字符串
        public final Date parse(String source): 将字符串解析为日期类型
     */
    public static void main(String[] args) throws ParseException {
        // 日期格式化对象
        SimpleDateFormat sdf = new SimpleDateFormat();
        // 当前时间对象
        Date date = new Date();
        //调用日期格式化对象中的:格式化方法
        String result = sdf.format(date);
        System.out.println(result); // 22-12-3 下午4:51

        // 指定格式格式化
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        String result1 = sdf1.format(date);
        System.out.println(result1); // 2022年12月03日 22:10:21

        // string --> Date
        String str = "2022年12月03日 22:10:21";
        Date date1 = sdf1.parse(str);
    }
}
