package example06_Date;

import java.util.Date;

/**
 * Date类--时间
 *
 * @author 虞渊
 * @since 2022年11月29日 7:31
 */
public class DateDemo {
    /*
        构造方法:
        public Date(): 表示当前时间
        public Date(long date): 根据传入的毫秒值,创建日期对象

        成员方法:
        public void setTime(long time): 根据传入的毫秒值,设置日期对象
        public long getTime(): 根据[日期对象],获取毫秒值
     */
    public static void main(String[] args) {
        Date d1 = new Date();
        System.out.println(d1); //Tue Nov 29 07:32:51 CST 2022
        System.out.println(d1.toLocaleString());// 2022-11-29 7:33:56

        Date d2 = new Date(System.currentTimeMillis());
        Date d3 = new Date(0L);
        System.out.println(d2.toLocaleString());// 当前时间
        System.out.println(d3.toLocaleString());// 1970-1-1 8:00:00 -原因是有时区的概念

        //用途:计算往后一小时的时间
        long time = System.currentTimeMillis() + (1000 * 60 * 60);
        Date d4 = new Date(time);
        System.out.println(d4.toLocaleString()); // 2022-11-29 8:46:09

        Date d5 = new Date();
        d5.setTime(0L); // 设置时间
        System.out.println(d5.toLocaleString()); // 1970-1-1 8:00:00

        Date d6 = new Date();
        Date d7 = new Date(1000);
        System.out.println(d6.getTime()); //获取毫秒值1669679258512
        System.out.println(d7.getTime()); //获取毫秒值1000
    }
}
