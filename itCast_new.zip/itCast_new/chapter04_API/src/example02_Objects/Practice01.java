package example02_Objects;

import com.itCast.study.chapter04_API.domain.Book;

import java.util.ArrayList;
import java.util.Objects;

/**
 * 需求: 创建一个ArrayList集合, 内部存储5个图书对象
 * ("b001","三国",88)
 * ("b001","三国",88)
 * ("b001","三国",88)
 * ("b002","故事会",5)
 * ("b003","水浒",88)
 * 要求: 删除集合中重复的对象(编号, 书名, 价格, 完全一致)
 * 删除之后, 遍历打印集合信息(要求, 直接打印对象名, 就能看到内容)
 *
 * @author 虞渊
 * @since 2022年11月19日 10:09
 */
public class Practice01 {
    public static void main(String[] args) {
        Book book1 = new Book("b001", "三国", 88);
        Book book2 = new Book("b001", "三国", 88);
        Book book3 = new Book("b001", "三国", 88);
        Book book4 = new Book("b002", "故事会", 5);
        Book book5 = new Book("b003", "水浒", 88);

        ArrayList<Book> books = new ArrayList<>();
        books.add(book1);
        books.add(book2);
        books.add(book3);
        books.add(book4);
        books.add(book5);

        // 1.暴力枚举
        // for (int i = 0; i < books.size(); i++) {
        //     for (int j = i+1; j < books.size(); j++) {
        //         if (Objects.equals(books.get(i), books.get(j))){
        //             books.remove(j);
        //             i--;
        //             break;
        //         }
        //     }
        // }

        // 2.借助getCount()方法算出重复书的数目
        for (int i = 0; i < books.size(); i++) {
            //把每一个对象都交给getCount(),统计次数
            //统计出来的次数不是1, 代表出现了多次
            if (getCount(books, books.get(i)) != 1){
                //删除
                books.remove(i);
                //索引回0
                i--;
            }
        }
        System.out.println(books);
    }

    /**
     * 判断Book对象在BookList中重复的个数
     * @param list
     * @param book
     * @return
     * @author 虞渊
     * @Date 2022-11-19 11:16
     */
    public static int getCount(ArrayList<Book> list, Book book) {
        int count = 0;
        for (int i = 0; i < list.size(); i++) {
            //比较两个对象是否相等
            if (Objects.equals(list.get(i), book)) {
                //相同的话,计数器自增
                count++;
            }
        }
        return count;
    }
}
