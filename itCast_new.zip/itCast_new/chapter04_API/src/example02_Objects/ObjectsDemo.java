package example02_Objects;

import com.itCast.study.chapter04_API.domain.Student;

import java.util.Objects;

/**
 * Objects类的介绍
 * @author: 虞渊
 * @date: 2023/6/13
 */
public class ObjectsDemo {
    public static void main(String[] args) {
        Student s1 = new Student("张三", 18);
        Student s2 = new Student("张三", 18);
        System.out.println(Objects.equals(s1, s2));
        /*
            查看Objects的equals()源码:
            public static boolean equals(Object a, Object b) {
                return (a == b) || (a != null && a.equals(b));
            }
            1.性能判断:如果两个对象地址是相同的, 没有比较的对象
            2.健壮性判断: 判断对象不是null的情况下,再调用方法,避免空指针异常
            3.最终比较的时候还是String.equals();
         */
    }
}
