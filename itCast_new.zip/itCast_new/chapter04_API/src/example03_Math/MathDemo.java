package example03_Math;

/**
 * Math类介绍
 *
 * @author 虞渊
 * @since 2022年11月19日 17:05
 */
public class MathDemo {
    public static void main(String[] args) {
        // 取绝对值
        System.out.println(Math.abs(-10));// 10
        // 向上取整
        System.out.println(Math.ceil(12.3));// 13.0
        // 向下取整
        System.out.println(Math.floor(12.3));// 12.0
        // 四舍五入
        System.out.println(Math.round(12.478));// 12
        // 获取最值
        System.out.println(Math.max(10, 20));// 20
        System.out.println(Math.min(10, 20));// 10
        // 获取n的m次幂
        System.out.println(Math.pow(2, 3));// 8.0
        // 获取随机数
        System.out.println(Math.random());// 返回double的随机数[0.0, 1.0)
    }
}
