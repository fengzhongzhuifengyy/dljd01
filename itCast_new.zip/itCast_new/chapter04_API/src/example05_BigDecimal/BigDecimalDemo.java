package example05_BigDecimal;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * BigDecimal类:解决小数运算不精确的问题
 *
 * @author 虞渊
 * @since 2022年11月28日 23:14
 */
public class BigDecimalDemo {
    public static void main(String[] args) {

        //注意当遇到除不尽时,会有异常
        BigDecimal num1 = BigDecimal.valueOf(10.0);
        BigDecimal num2 = BigDecimal.valueOf(3.0);
        // System.out.println(num1.divide(num2).doubleValue());//Exception in thread "main" java.lang.ArithmeticException
        double result1 = num1.divide(num2, RoundingMode.UP).doubleValue(); //向上取整
        double result2 = num1.divide(num2, RoundingMode.DOWN).doubleValue(); //向下取整
        double result3 = num1.divide(num2, 4, RoundingMode.HALF_UP).doubleValue(); //四舍五入, scale: 精度(取4位小数)
        System.out.println(result1);// 3.4
        System.out.println(result2);// 3.3
        System.out.println(result3);// 3.3333

    }

    // 快捷键:ctrl + alt + m --> 代码快速抽取到方法
    private static void method() {
        BigDecimal num1 = BigDecimal.valueOf(10.0);
        BigDecimal num2 = BigDecimal.valueOf(2.0);
        System.out.println(num1);
        System.out.println(num2);

        // System.out.println(num1 + num2); // 报错, 类与类之间不能相加
        // doubleValue()将这个BigDecimal转换为double
        System.out.println(num1.add(num2).doubleValue());
        System.out.println(num1.subtract(num2).doubleValue());
        System.out.println(num1.multiply(num2).doubleValue());
        System.out.println(num1.divide(num2).doubleValue());
    }
}
