package example08_Date8Version.num02_Instant;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月04日 19:04
 */
public class InstantDemo {
    public static void main(String[] args) {

        // 得到一个时间戳对象,默认获取的是0时区的时间
        Instant instant = Instant.now();
        System.out.println("当前时间戳是" + instant); // 时间戳是2022-12-04T11:07:56.788Z

        // Instant -> Date: from()
        Date data = Date.from(instant);
        System.out.println("转换后当前的时间戳是"+data); //转换后当前的时间戳是Sun Dec 04 19:10:05 CST 2022

        // Date -> Instant: toInstant()
        Instant instant1 = data.toInstant();
        System.out.println(instant1);// 2022-12-04T11:11:20.893Z

        // Zone 时区
        Instant instant2 = Instant.now();
        ZonedDateTime zonedDateTime = instant2.atZone(ZoneId.systemDefault());// 可以获取当前系统的默认时间
        System.out.println(zonedDateTime); // 2022-12-04T19:14:31.655+08:00[Asia/Shanghai]

        // instant -> LocalDateTime: ofInstant()
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant2, ZoneId.of("Asia/Shanghai"));
        System.out.println(localDateTime.getDayOfMonth());

    }
}
