package example08_Date8Version.num03_DateTimeFormatter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月04日 19:23
 */
public class DateTimeFormatterDemo {

    public static void main(String[] args) {
        // 获取本地此刻日期时间对象
        LocalDateTime nowTime = LocalDateTime.now();
        System.out.println(nowTime);

        // 创建解析/格式化对象
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss E a"); // 2022-12-04 19:30:32 星期日 下午
        // 可以使用解析器对象调用format方法进行格式化
        String result = dtf.format(nowTime);
        System.out.println(result); // 2022-12-04 19:34:40 星期日 下午
        // 也可以使用时间对象调用format方法进行格式化
        System.out.println(nowTime.format(dtf)); // 2022-12-04 19:34:40 星期日 下午
        // 两种方式效果一致

        // 解析字符串时间
        DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        TemporalAccessor parse = dtf2.parse("2020-10-20 17:59:59"); // {},ISO resolved to 2020-10-20T17:59:59
        System.out.println(parse);
        // 解析当前字符串时间 转换为 本地时间对象
        LocalDateTime ldt = LocalDateTime.parse("2020-10-20 17:59:59", dtf2);
        System.out.println(ldt); // 2020-10-20T17:59:59
    }
}
