package example08_Date8Version.num06_chronoUnit;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * 功能说明:ChronoUnit完整的日期时间计算差值
 *
 * @author 虞渊
 * @since 2022年12月04日 20:12
 */
public class ChronoUnitDemo {
    public static void main(String[] args) {

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime of = LocalDateTime.of(2030, 10, 1, 15, 59, 59);

        System.out.println(ChronoUnit.YEARS.between(now, of)); // 相差的年数
        System.out.println(ChronoUnit.MONTHS.between(now, of)); // 相差的月数
        System.out.println(ChronoUnit.WEEKS.between(now, of)); // 相差的周数
        System.out.println(ChronoUnit.DAYS.between(now, of)); // 相差的天数
        System.out.println(ChronoUnit.HOURS.between(now, of)); // 相差的时数
        System.out.println(ChronoUnit.MINUTES.between(now, of)); // 相差的分数
        System.out.println(ChronoUnit.SECONDS.between(now, of)); // 相差的秒数
        System.out.println(ChronoUnit.MILLIS.between(now, of)); // 相差的毫秒数
        System.out.println(ChronoUnit.MICROS.between(now, of)); // 相差的毫秒数
        System.out.println(ChronoUnit.NANOS.between(now, of)); // 相差的毫秒数
        System.out.println(ChronoUnit.HALF_DAYS.between(now, of)); // 相差的半天数
        System.out.println(ChronoUnit.DECADES.between(now, of)); // 相差的十年数
        System.out.println(ChronoUnit.CENTURIES.between(now, of)); // 相差的世纪(百年)数
        System.out.println(ChronoUnit.MILLENNIA.between(now, of)); // 相差的千年数
        System.out.println(ChronoUnit.ERAS.between(now, of)); // 相差的纪元数
    }
}
