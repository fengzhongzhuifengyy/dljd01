package example08_Date8Version.num04_Period;

import java.time.LocalDate;
import java.time.Period;

/**
 * 功能说明 Period: 计算日期(年月日)的差异
 *
 * @author 虞渊
 * @since 2022年12月04日 19:55
 */
public class PeriodDemo {
    public static void main(String[] args) {
        LocalDate nowTime = LocalDate.now();
        LocalDate ofTime = LocalDate.of(2023, 12, 4);

        // Period: 对象表示两个日期对象(年月日)时间的间隔对象
        Period periodTime = Period.between(nowTime, ofTime);// 第二个参数减去第一个参数

        System.out.println(periodTime.getYears()); // 间隔的年数
        System.out.println(periodTime.getMonths()); // 间隔的月数
        System.out.println(periodTime.getDays()); // 间隔的天数
        System.out.println(periodTime.toTotalMonths()); // 间隔的总月数
    }
}
