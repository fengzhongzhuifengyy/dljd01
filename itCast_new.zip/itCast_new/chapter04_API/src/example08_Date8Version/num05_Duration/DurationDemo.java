package example08_Date8Version.num05_Duration;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 * 功能说明:Duration计算日期间隔,用于LocalDateTime, Instant之间的比较
 *
 * @author 虞渊
 * @since 2022年12月04日 20:03
 */
public class DurationDemo {
    public static void main(String[] args) {
        // 本地时间对象与设定时间对象
        LocalDateTime nowTime = LocalDateTime.now();
        LocalDateTime ofTime = LocalDateTime.of(2023, 10, 1, 13, 59, 59);

        Duration betweenTime = Duration.between(nowTime, ofTime); // 第二个参数 - 第一个参数

        System.out.println(betweenTime.toDays()); // 两个时间差的天数
        System.out.println(betweenTime.toHours()); // 两个时间差的小时数
        System.out.println(betweenTime.toMinutes()); // 两个时间差的分钟数
        System.out.println(betweenTime.toMillis()); // 两个时间差的毫秒数
        System.out.println(betweenTime.toNanos()); // 两个时间差的纳秒数
    }
}
