package example08_Date8Version.num01_LocalDateTime;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.MonthDay;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月04日 17:12
 */
public class LocalDateTimeUpdateDemo {
    public static void main(String[] args) {

        LocalDateTime time = LocalDateTime.now();
        System.out.println(time);

        // minus : 减法
        System.out.println(time.minusHours(1));
        System.out.println(time.minusMinutes(1));
        System.out.println(time.minusSeconds(1));
        System.out.println(time.minusNanos(1));
        System.out.println(time); // 每次对象的修改不会修改原对象,都会衍生出新的对象,即日期对象是不可变的对象
        System.out.println("-------------------");

        // plus: 加
        System.out.println(time.plusHours(1));
        System.out.println(time.plusMinutes(1));
        System.out.println(time.plusSeconds(1));
        System.out.println(time.plusNanos(1));
        System.out.println(time); // 每次对象的修改不会修改原对象,都会衍生出新的对象,即日期对象是不可变的对象(((_
        System.out.println("-------------------");

        // with: 设置,修改
        System.out.println(time.withYear(2008));
        System.out.println(time.withMonth(1));
        System.out.println(time.withDayOfMonth(1));
        System.out.println(time.withHour(12));
        System.out.println(time.withMinute(59));
        System.out.println(time.withSecond(59));
        System.out.println(time); // 每次对象的修改不会修改原对象,都会衍生出新的对象,即日期对象是不可变的对象
        System.out.println("-------------------");

        LocalDate myDate = LocalDate.of(2008, 8, 8);
        LocalDate nowTime = LocalDate.now();
        // 2008-08-08是否在当前之前
        System.out.println(nowTime.isBefore(myDate));
        // 2008-08-08是否在当前之后
        System.out.println(nowTime.isAfter(myDate));

        // 判断今天是否是你的生日
        LocalDate birthTime = LocalDate.of(2008, 8, 8);
        LocalDate nowTime1 = LocalDate.now();
        // 提取你的月日对象封装成月日对象
        MonthDay birthMonthDay = MonthDay.of(birthTime.getMonthValue(), birthTime.getDayOfMonth());
        // 根据当前的时间转换为月日对象
        MonthDay nowMonthDay = MonthDay.from(nowTime1);
        MonthDay birMonthDay = MonthDay.from(birthTime);
        System.out.println(birthMonthDay.equals(nowMonthDay));
        System.out.println(birMonthDay.equals(nowMonthDay));
    }
}
