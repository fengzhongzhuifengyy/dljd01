package example08_Date8Version.num01_LocalDateTime;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * LocalDate、LocalTime、LocalDateTime
 * 他们 分别表示日期，时间，日期时间对象，他们的类的实例是不可变的对象。
 * 他们三者构建对象和API都是通用的
 *
 * @author 虞渊
 * @since 2022年12月04日 16:24
 */
public class LocalDateTimeDemo {
    /*
        其类的实例是不可变的实例, 即每个时间都是一个对象
        LocalDate, LocalTime, LocalDateTime
        对象创建方式:
        1. now(): 当前时间
        2. of(...): 设置时间

        localDateTime 转换为LocalDate, LocalTime
        1. toLocalDate()
        2. toLocalTime()
     */
    public static void main(String[] args) {
        // 对象创建方式一: 获取当前年月日时间对象
        LocalDateTime nowTime = LocalDateTime.now();
        System.out.println(nowTime);    // 2022-12-04T16:53:27.314

        // 分别获取年, 月, 日, 时, 分, 秒
        System.out.println(nowTime.getYear()); // 2022
        System.out.println(nowTime.getMonth()); // DECEMBER
        System.out.println(nowTime.getMonthValue()); // 12
        System.out.println(nowTime.getDayOfMonth()); // 4
        System.out.println(nowTime.getHour()); // 17
        System.out.println(nowTime.getMinute()); // 6
        System.out.println(nowTime.getSecond()); // 12
        // 获取星期
        System.out.println(nowTime.getDayOfWeek());
        System.out.println(nowTime.getDayOfWeek().getValue());
        // 获取月份对象
        System.out.println(nowTime.getMonth());
        System.out.println(nowTime.getMonth().getValue());

        // 对象创建方式二: 获取指定年月日时分秒创建对象
        LocalDateTime ofTime = LocalDateTime.of(2008, 10, 1, 10, 59, 59);
        System.out.println(ofTime);

        // LocalDateTime -> LocalDate/localtime
        LocalDate nowLocalDate = nowTime.toLocalDate();
        LocalTime nowLocalTime = nowTime.toLocalTime();
        System.out.println(nowLocalDate);
        System.out.println(nowLocalTime);
    }
}
