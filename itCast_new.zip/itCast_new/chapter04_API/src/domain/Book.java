package domain;

import java.util.Objects;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年11月19日 10:10
 */
public class Book {
    private String bookNumber;
    private String bookName;
    private int bookPrice;

    public Book(String bookNumber, String bookName, int bookPrice) {
        this.bookNumber = bookNumber;
        this.bookName = bookName;
        this.bookPrice = bookPrice;
    }

    public String getBookNumber() {
        return bookNumber;
    }

    public void setBookNumber(String bookNumber) {
        this.bookNumber = bookNumber;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public int getBookPrice() {
        return bookPrice;
    }

    public void setBookPrice(int bookPrice) {
        this.bookPrice = bookPrice;
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookNumber='" + bookNumber + '\'' +
                ", bookName='" + bookName + '\'' +
                ", bookPrice=" + bookPrice +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book)) return false;
        Book book = (Book) o;
        return getBookPrice() == book.getBookPrice() && Objects.equals(getBookNumber(), book.getBookNumber()) && Objects.equals(getBookName(), book.getBookName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getBookNumber(), getBookName(), getBookPrice());
    }
}
