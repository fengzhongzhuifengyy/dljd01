package domain;

import java.util.Objects;

/**
 * Student类
 *
 * @author 虞渊
 * @since 2022年11月19日 9:15
 */
public class Student {

    private String name;
    private int age;

    /*
        Object的toString()源码:
        public String toString() {
        return getClass().getName() + "@" + Integer.toHexString(hashCode());
        getClass().getName(): 全类名(包名 + 类名)
        hashCode(): 是根据对象的内存地址,结合哈希算法,计算出的哈希值
        Integer.toHexString(): 将哈希值转换为16进制
    }
     */
    @Override
    public String toString(){
        return "name = " + name + "age = " + age;
    }

    @Override
    public boolean equals(Object obj){
        // 比较两者地址是否相同,地址如果相同,代表内容肯定一样
        if (this == obj){
            return true;
        }
        // 程序判断走到obj == null这里this.equals()说明必然不是null,
        //      否则会报空指针,代表肯定不一样
        // 比较两个对象的字节码对象是否相同(字节码不一样,代表类型肯定不一样)
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
        // 程序走到这里,说明是同一个类型,那么就进行向下转型
        Student stu = (Student) obj;
        // 比较对象的属性是不是相等
        return age == stu.age && Objects.equals(name, stu.name);
    }


    // @Override
    // public boolean equals(Object o) {
    //     if (this == o) return true;
    //     if (!(o instanceof Student)) return false;
    //     Student student = (Student) o;
    //     return getAge() == student.getAge() && Objects.equals(getName(), student.getName());
    // }


    // @Override
    // public int hashCode() {
    //     return Objects.hash(getName(), getAge());
    // }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


}
