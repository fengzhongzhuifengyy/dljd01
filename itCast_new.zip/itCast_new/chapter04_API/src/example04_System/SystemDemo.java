package example04_System;

/**
 * System类介绍
 *
 * @author 虞渊
 * @since 2022年11月19日 18:59
 */
public class SystemDemo {
    public static void main(String[] args) {

        int[] arr1 = new int[]{22, 33, 44, 55};
        int[] arr2 = new int[3];

        // 1.数组拷贝(源数组, 拷贝的起始索引位置, 目标数组, 拷贝到目标数组的哪一个索引位置, 拷贝的长度)
        // public static native void arraycopy(Object src,  int  srcPos,Object dest, int destPos,int length);
        System.arraycopy(arr1, 1, arr2, 0, 3);

        for (int i = 0; i < arr2.length; i++) {
            System.out.println(arr2[i] + " ");
        }

        // 2.终止运行的虚拟机程序
        // System.exit(0);

        // 3.获取从1970-1-1,0:0:0当前系统的时间毫秒值
        // public static native long currentTimeMillis();
        System.out.println(System.currentTimeMillis());

    }
}
