package example01_Object;

import com.itCast.study.chapter04_API.domain.Student;

/**
 * Object: 基类，包括数组都可以使用其方法
 *
 * @author: 虞渊
 * @date: 2023/6/13
 */
public class ObjectDemo {
    /*
        1.Object.toString()
            public String toString():默认是返回当前对象在堆内存中的地址信息:类的全限名@内存地址
        2.Object.equals()
            public boolean equals(Object o):默认是比较当前对象与另一个对象的地址是否相同,相同返回true，不同返回false
     */

    public static void main(String[] args) {
        // Student类重写了toString()
        Student s1 = new Student("张三", 18);
        // 这里查看println()的源码发现是调用的Object的toString();
        System.out.println(s1.toString());

        // Student类重写了equals()
        Student s2 = new Student("张三", 18);
        System.out.println(s1.equals(s2));
    }
}
