package example01_HashMap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;

/**
 * @author: 虞渊
 * @date: 2023/6/17
 */
public class PokerTest {

    public static void main(String[] args) {
        // 准备数据
        String[] colors = new String[]{"红桃", "黑桃", "方块", "梅花"};
        String[] numbers = new String[]{"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

        // 定义map存储这些牌, 因为需要洗牌, 排序所以使用treeMap
        // 这里的key 代表每张牌的标号, 方便后续排序 --- 索引排序法
        TreeMap<Integer, String> treeMap = new TreeMap<>();

        ArrayList<Integer> list = new ArrayList<>();

        // 大王小王插入treeMap中
        int index = 0;
        treeMap.put(index, "大王");
        list.add(index++);
        treeMap.put(index, "小王");
        list.add(index++);
        // 存入其他的牌
        for (String number : numbers) {
            for (String color : colors) {
                treeMap.put(index,  color + number );
                list.add(index++);
            }
        }
        System.out.println(list);
        // 因为需要洗牌调用Collections.shuffle()只能使用list,因此创建list保存每张牌的标号
        // 再假如map的时候就可以一并加入,提升效率
        Collections.shuffle(list);

        // 通过list标号进行发牌
        // 定义个存储发牌容器, 为了保证发牌后的顺序使用treeMap
        TreeMap<Integer, String> box = new TreeMap<>();
        TreeMap<Integer, String> player1 = new TreeMap<>();
        TreeMap<Integer, String> player2 = new TreeMap<>();
        TreeMap<Integer, String> player3 = new TreeMap<>();

        // 取前三张放入盒中
        // 因为list有索引,所以可以进行%3操作
        for (int i = 0; i < list.size(); i++) {

            if (i <= 2) {
                box.put(list.get(i), treeMap.get(list.get(i)));
            } else if (i % 3 == 0) {
                player1.put(list.get(i), treeMap.get(list.get(i)));
            } else if (i % 3 == 1) {
                player2.put(list.get(i), treeMap.get(list.get(i)));
            } else {
                player3.put(list.get(i), treeMap.get(list.get(i)));
            }
        }
        System.out.println("player1: ");
        player1.forEach((n, s) -> System.out.print(s + "\t"));
        System.out.println();
        System.out.println("player2: ");
        player2.forEach((n, s) -> System.out.print(s + "\t"));
        System.out.println();
        System.out.println("player3: ");
        player3.forEach((n, s) -> System.out.print(s + "\t"));
        System.out.println();
    }

}
