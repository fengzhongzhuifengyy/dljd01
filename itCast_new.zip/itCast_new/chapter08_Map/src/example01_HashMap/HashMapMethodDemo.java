package example01_HashMap;

import java.util.HashMap;

/**
 * 功能说明: map的常用api
 * 
 * V put(K key,V value)	添加元素
 * V remove(Object key)	根据键删除键值对元素
 * void clear()	移除所有的键值对元素
 * boolean containsKey(Object key)	判断集合是否包含指定的键
 * boolean containsValue(Object value)	判断集合是否包含指定的值
 * boolean isEmpty()	判断集合是否为空
 * int size()	集合的长度，也就是集合中键值对的个数
 *
 * @author 虞渊
 * @since 2022年12月26日 22:13
 */
public class HashMapMethodDemo {
    /*
        Map集合常用的API
     */
    public static void main(String[] args) {

        HashMap<String, String> hashMap = new HashMap<>();

        String s1 = hashMap.put("张三", "北京");
        String s2 = hashMap.put("李四", "上海");
        String s3 = hashMap.put("张三", "广州");

        System.out.println(hashMap); // {李四=上海, 张三=广州}
        // put()方法返回的是原先 被覆盖的值, 第一次添加的时候集合之前没有元素,所以返回null
        System.out.println(s1); // null
        System.out.println(s2); // null
        System.out.println(s3); // 北京

        // containsKey():判断集合是否包含指定的键
        System.out.println(hashMap.containsKey("张三")); // true

        // containsValue():判断集合是否包含指定的值
        System.out.println(hashMap.containsValue("黑龙江"));// false

        //remove():根据键删除集合的元素,返回的是删除的那个值
        hashMap.remove("张三");
        System.out.println(hashMap); // {李四=上海}

        // clear():移除所有的键值对元素
        hashMap.clear();
        System.out.println(hashMap); // {}

        // isEmpty():判断集合是否为空
        System.out.println(hashMap.isEmpty()); // true

        // size():集合的长度，也就是集合中键值对的个数
        System.out.println(hashMap.size()); // 0


    }
}
