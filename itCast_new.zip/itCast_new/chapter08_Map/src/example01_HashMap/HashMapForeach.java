package example01_HashMap;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Map集合的遍历方式有：3种。
 * 方式一：键找值的方式遍历：先获取Map集合全部的键，再根据遍历键找值。
 * 方式二：键值对的方式遍历，把“键值对“看成一个整体，难度较大。
 * 方式三：JDK 1.8开始之后的新技术：Lambda表达式。*
 *
 * @author 虞渊
 * @since 2022年12月26日 22:41
 */
public class HashMapForeach {

    public static void main(String[] args) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("张三", "北京");
        hashMap.put("李四", "上海");
        hashMap.put("王五", "广州");

        extracted1(hashMap);
        extracted2(hashMap);
        extracted3(hashMap);
    }

    /*
     Map集合的遍历方式1:
     思路:根据键找值:
     public Set<K> keySet(): 获取到Map集合中所有的键的集合
     public V get(Object key): 根据键找值
     */
    private static void extracted1(HashMap<String, String> hashMap) {
        Set<String> keySet = hashMap.keySet();
        for (String key : keySet) {
            System.out.println(key + "==" + hashMap.get(key));
        }
    }

    /*
     Map集合的遍历方式2:
     思路:根据键-值遍历:
     Set<Map.Entry<K,V>> entrySet(): 获取所有键值对对象的集合
     K  getKey()	获得键
     V  getValue()	获取值
     */
    private static void extracted2(HashMap<String, String> hashMap) {
        Set<Map.Entry<String, String>> entrySet = hashMap.entrySet();
        for (Map.Entry<String, String> entry : entrySet) {
            System.out.println(entry.getKey() + "==" + entry.getValue());
        }
    }

    /*
    JDK 8开始的新技术Lambda表达式，提供了一种更简单、更直接的遍历集合的方式。
    default void forEach(BiConsumer<? super K, ? super V> action): 结合lambda遍历Map集合
     */
    private static void extracted3(HashMap<String, String> hashMap) {
        hashMap.forEach((k, v) -> System.out.println(k + "=" + v));
    }
}
