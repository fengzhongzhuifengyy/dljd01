package example01_HashMap;

import java.util.HashMap;

/**
 * @author 虞渊
 * @since 2023-08-17-23:33
 */
public class Statistics02Test {
    /*
    需求：字符串 "aababcabcdabcde"
         请统计字符串中每一个字符出现的次数，并按照以下格式输出
         输出结果：
          a（5）b（4）c（3）d（2）e（1）
     */
    public static void main(String[] args) {
        char[] ch = "aababcabcdabcde".toCharArray();
        HashMap<Character, Integer> hashMap = new HashMap<>();
        for (char c : ch) {
            hashMap.put(c, hashMap.getOrDefault(c, 0) + 1);
        }
        StringBuilder sb = new StringBuilder();
        hashMap.forEach((k,v) -> sb.append(k).append('(').append(v).append(')'));
        System.out.println(sb);
    }
}
