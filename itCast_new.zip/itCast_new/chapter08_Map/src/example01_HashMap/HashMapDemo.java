package example01_HashMap;

import java.util.HashMap;
import java.util.Map;

/**
 * Map集合是一种双列集合，每个元素包含两个数据。
 * Map集合的每个元素的格式：key=value(键值对元素)。
 * Map集合也被称为“键值对集合”。
 *
 * Map集合体系特点
 * Map集合的特点都是由键决定的。
 * Map集合的键是无序,不重复的，无索引的，值不做要求（可以重复）。
 * Map集合后面重复的键对应的值会覆盖前面重复键的值。
 * Map集合的键值对都可以为null。
 *
 * Map集合实现类特点
 * HashMap:元素按照键是无序，不重复，无索引，值不做要求。（与Map体系一致）
 *      由键决定：无序、不重复、无索引。HashMap底层是哈希表结构的。
 *      依赖hashCode方法和equals方法保证键的唯一。
 *      如果键要存储的是自定义对象，需要重写hashCode和equals方法。
 *      基于哈希表。增删改查的性能都较好。
 *
 * LinkedHashMap:元素按照键是有序，不重复，无索引，值不做要求。
 *      由键决定：有序、不重复、无索引。
 *      这里的有序指的是保证存储和取出的元素顺序一致
 *      原理：底层数据结构是依然哈希表，只是每个键值对元素又额外的多了一个双链表的机制记录存储的顺序。
 *
 * TreeMap：元素按照建是排序，不重复，无索引的，值不做要求。
 *      由键决定特性：不重复、无索引、可排序
 *      可排序：按照键数据的大小默认升序（有小到大）排序。只能对键排序。
 *      注意：TreeMap集合是一定要排序的，可以默认排序，也可以将键按照指定的规则进行排序
 *      TreeMap跟TreeSet一样底层原理是一样的。
 *      TreeMap集合自定义排序规则有2种:类实现Comparable接口，重写比较规则;集合自定义Comparator比较器对象，重写比较规则。
 * @author 虞渊
 * @since 2022年12月26日 22:04
 */
public class HashMapDemo {
    /*
        Map: 双列集合,键值对

        特点:
            Map集合,所有的数据结构都只针对键有效,跟值没有关系
                - 键 : 唯一
                - 值 : 可以重复
            每个键只能对应一个值
     */
    public static void main(String[] args) {
        Map<String, String> map = new HashMap<>();
        // Map集合的键是无序,不重复的，无索引的，值不做要求（可以重复）。
        map.put("张三", "北京");
        map.put("李四", "上海");
        map.put("王五", "广州");
        // Map集合后面重复的键对应的值会覆盖前面重复键的值。--等价于修改
        map.put("王五", "黑龙江");
        // Map集合的键值对都可以为null。
        map.put(null, null);

        System.out.println(map); // {null=null, 李四=上海, 张三=北京, 王五=黑龙江}
    }
}
