package example01_HashMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/**
 * @author 虞渊
 * @since 2023-08-17-23:19
 */
public class Statistics01Test {
    /*
    需求
        某个班级80名学生，现在需要组成秋游活动，班长提供了四个景点依次是（A、B、C、D）,
        每个学生只能选择一个景点，请统计出最终哪个景点想去的人数最多。
    分析
        将80个学生选择的数据拿到程序中去。
        定义Map集合用于存储最终统计的结果。
        遍历80个学生选择的数据，看Map集合中是否存在，不存在存入“数据=1“，存在则其对应值+1,

     */
    public static void main(String[] args) {
        // 4个景点的数据
        String[] arr = new String[]{"A", "B", "C", "D"};

        // 构造80个学生选择
        ArrayList<String> chooseList = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 80; i++) {
            // 构造一个随机产生的索引, 大小在长度范围内
            int index = random.nextInt(arr.length);
            chooseList.add(arr[index]);
        }

        // 进行统计
        HashMap<String, Integer> hashMap = new HashMap<>();
        for (String s : chooseList) {
            hashMap.put(s, hashMap.getOrDefault(s, 0) +1);
        }

        hashMap.forEach((k,v) -> System.out.println(k + "-" + v));
    }
}
