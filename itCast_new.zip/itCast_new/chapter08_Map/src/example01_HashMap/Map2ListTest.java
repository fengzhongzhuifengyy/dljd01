package example01_HashMap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 * @author 虞渊
 * @since 2023-08-17-23:49
 */
public class Map2ListTest {

    /*
        需求
        定义一个Map集合，键用表示省份名称，值表示市，但是市会有多个。

        添加完毕后，遍历结果：
        格式如下：
        江苏省 = 南京市，扬州市，苏州市，无锡市，常州市
        湖北省 = 武汉市，孝感市，十堰市，宜昌市，鄂州市
        河北省 = 石家庄市，唐山市，邢台市，保定市，张家口市
     */
    public static void main(String[] args) {
        HashMap<String, ArrayList<String>> listHashMap = new HashMap<>();
        ArrayList<String> list1 = new ArrayList<String>();
        Collections.addAll(list1, "南京市", "扬州市", "苏州市", "无锡市", "常州市");

        ArrayList<String> list2 = new ArrayList<String>();
        Collections.addAll(list2, "武汉市", "孝感市", "十堰市", "宜昌市", "鄂州市");

        ArrayList<String> list3 = new ArrayList<String>();
        Collections.addAll(list3, "石家庄市", "唐山市", "邢台市", "保定市", "张家口市");

        listHashMap.put("江苏省", list1);
        listHashMap.put("湖北省", list2);
        listHashMap.put("河北省", list3);

        for (String key : listHashMap.keySet()) {
            StringBuilder sb = new StringBuilder();
            sb.append(key).append("=");
            ArrayList<String> list = listHashMap.get(key);

            for (int i = 0; i < list.size(); i++) {
                if (i == list.size() - 1){
                    sb.append(list.get(i));
                }else{
                    sb.append(list.get(i)).append(",");
                }
            }
            System.out.println(sb);
        }
    }
}
