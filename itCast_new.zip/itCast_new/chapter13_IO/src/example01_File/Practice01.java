package example01_File;

import java.io.File;
import java.util.Scanner;

/**
 * 定义一个方法,  从键盘录入一个文件夹路径,  如果输入错误, 给出提示并继续录入 !
 *
 * @author: 虞渊
 * @date: 2023/6/20
 */
public class Practice01 {
    public static void main(String[] args) {
        getDir();
    }

    public static File getDir(){
        Scanner sc = new Scanner(System.in);
        while (true) {
            String inputDir = sc.nextLine();
            File file = new File(inputDir); // 根据键盘录入的路径创建File对象
            if (!file.exists()){ // 不存在
                System.out.println("输入错误, 重新输入");
            }else if (file.isFile()){ // 存在判断是不是文件
                System.out.println("是文件不是文件夹路径");
            }else {
                return file;
            }
        }
    }
}
