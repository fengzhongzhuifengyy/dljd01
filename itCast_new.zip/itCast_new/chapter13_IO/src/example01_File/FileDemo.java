package example01_File;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * File类代表操作系统的文件对象（文件、文件夹），在java.io.File包下。
 * File类提供了诸如：定位文件，获取文件信息（大小、修改时间）、删除文件、创建文件（文件夹）等功能。但是不能读写
 *
 * File类创建对象的构造方法:
 * public File (String pathname): 根据文件路径创建文件对象
 * public File (String parent, String child): 根据父路径名字符串和子路径名字符串创建文件对象
 * public File (File  parent, String child): 根据父路径对应文件对象和子路径名字符串创建文件对象
 *
 * 注意:
 * File对象可以定位文件和文件夹
 * File封装的对象仅仅是一个路径名，这个路径可以是存在的，也可以是不存在的。
 *
 * 绝对路径和相对路径是什么样的？
 * 绝对路径是带盘符的。
 * 相对路径是不带盘符的，默认创建文件到当前工程项目下寻找文件。但是如果是单元测试里面就在当前模块下
 * 今后相对路径会使用很多,一般不在项目的平级路径下操作,一般在项目的模块下使用相对路径"itCast\\char..."
 *
 * @author: 虞渊
 * @date: 2023/6/19
 */
public class FileDemo {
    public static void main(String[] args) throws IOException {
        FileMethod1();
        // FileMethod2();
        // FileMethod3();
    }

    /**
     *  File类的判断和获取方法
     */
    public static void FileMethod1() throws IOException {
        // 根据传入的字符串路径,创建File对象(其他两种就是拆分路径)
        File file1 = new File("E:\\test\\a.txt");
        // 创建文件,这里有一个编译性异常的预处理
        boolean b = file1.createNewFile();
        // 判断是否是文件夹
        System.out.println(file1.isDirectory()); // false
        // 判断是否是文件
        System.out.println(file1.isFile()); // true
        // 判断当前文件或者文件夹是否存在
        System.out.println(file1.exists()); // true
        // 返回文件的大小(字节个数)
        long length = file1.length();
        System.out.println(length); // 0
        // 返回文件的绝对路径
        String path = file1.getAbsolutePath();
        System.out.println(path);
        // 获取文件名称,文件名带后缀
        String name = file1.getName();
        System.out.println(name);
        // 获取文件最后一次的修改时间
        long time = file1.lastModified();
        System.out.println(new Date(time).toLocaleString());
        LocalDateTime localDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(time), ZoneId.systemDefault());
        System.out.println(localDateTime);
    }

    /**
     * File类的创建和删除方法
     */
    public static void FileMethod2() throws IOException {
        File file1 = new File("E:\\test\\b.txt");
        // 创建文件
        boolean b = file1.createNewFile();
        System.out.println(b);

        // 创建文件夹
        File file2 = new File("E:\\test\\b");
        boolean b1 = file2.mkdir();
        System.out.println(b1);

        // 创建多个文件夹
        File file3 = new File("E:\\test\\c\\d\\e\\");
        boolean b2 = file3.mkdirs();
        System.out.println(b2);

        // 删除文件
        boolean b3 = file1.delete();
        System.out.println(b3);

        // 删除文件夹
        boolean b4 = file2.delete();
        System.out.println(b4);

        // 但是删除文件夹,只能删除空文件夹
        System.out.println(file3.delete());
    }

    /**
     * File类的遍历功能
     *         public File[] listFiles(): 获取当前目录下所有的"一级文件对象"到一个文件对象数组中去返回（重点）
     *         listFiles方法注意事项：
     *             当调用者File表示的路径不存在时，返回null
     *             当调用者File表示的路径是文件时，返回null
     *             当调用者File表示的路径是一个空文件夹时，返回一个长度为0的数组
     *             当调用者File表示的路径是一个有内容的文件夹时，将里面所有文件和文件夹的路径放在File数组中返回
     *             当调用者File表示的路径是一个有隐藏文件的文件夹时，将里面所有文件和文件夹的路径放在File数组中返回，包含隐藏文件
     *             当调用者File表示的路径是需要权限才能访问的文件夹时，返回null
     *             可以看出 核心是!=nul
     */
    public static void FileMethod3() {
        File file = new File("E:\\");
        // 获取文件夹下所有的[文件][文件夹]的对象
        File[] files = file.listFiles();
        // 遍历前,进行非空判断,因为有很多的情形返回的File对象是null
        if (files != null){
            // va 代表每一个文件和文件夹的对象
            for (File va : files) {
                System.out.println(va);
            }
        }

        // 文件过滤器FileFilter(接口)
        // 原理就是先进行过滤, 把过滤后的file对象存进数组
        File[] filesFilter = file.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                return file.isDirectory() && file.getName().endsWith("test");
            }
        });
        for (File vo : filesFilter) {
            System.out.println(vo);
        }
    }
}
