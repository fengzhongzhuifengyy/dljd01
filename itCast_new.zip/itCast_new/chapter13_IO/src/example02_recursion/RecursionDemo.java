package example02_recursion;

import java.io.File;
import java.util.HashMap;

/**
 * 什么是方法递归?
 * 方法直接调用自己或者间接调用自己的形式称为方法递归（ recursion）。
 * 递归的形式
 * 直接递归：方法自己调用自己。
 * 间接递归：方法调用其他方法，其他方法又回调方法自己。
 * 方法递归存在的问题？
 * 递归如果没有控制好终止，会出现递归死循环，导致栈内存溢出现象。
 *
 * @author: 虞渊
 * @date: 2023/6/21
 */
public class RecursionDemo {
    public static void main(String[] args) {
        // System.out.println(fun1(5));
        // System.out.println(fun2(2));

        File file = new File("E:\\test"); // 限定给的路径是个文件夹路径
        // fun4(file);
        // fun5(file);

        HashMap<String, Integer> hashMap = new HashMap<>();
        HashMap<String, Integer> hashMap1 = fun6(file, hashMap);
        System.out.println(hashMap1);
    }

    /**
     * 求N的阶乘
     * 思想: 将大问题,拆解出一个一个小问题
     * 5! = 5 * 4!
     * 4! = 4 * 3!
     * 3! = 3 * 2!
     * 2! = 2 * 1!
     * 1! = 1
     *
     * @param n
     */
    public static int fun1(int n) {
        if (n == 1) {
            return 1;
        }
        return n * fun1(n - 1);
    }

    /**
     * 计算1-n的和的结果，使用递归思想解决
     *
     * @param n
     * @return
     */
    public static int fun2(int n) {
        if (n == 1 || n== 0) {
            return n;
        }
        return n + fun2(n - 1);
    }

    /**
     * 不死神兔 (斐波那契数列)
     * 有一对兔子，从出生后第3个月起每个月都生一对兔子，
     * 小兔子长到第三个月后每个月又生一对兔子，
     * 假如兔子都不死，问第二十个月的兔子对数为多少？
     *
     * @param mouth
     */
    public static int fun3(int mouth) {
        if (mouth == 1 || mouth == 2) {
            return 1;
        }
        return fun3(mouth - 1) + fun3(mouth - 2);
    }

    /**
     * 设计一个方法, 打印出某文件夹下所有的文件名称(包括子文件夹)
     * @param file
     */
    public static void fun4(File file) {
        // 获取每一个file对象
        // 这里因为是数组, 所以不需要有出口, 数组总会遍历完
        File[] files = file.listFiles();
        for (File va : files) {
            // 是文件夹就递归下一层
            if (va.isDirectory()) {
                // 但是这里发现有bug, 因为files数组会存在为null的场景
                // 所以表示当前文件夹下有值再遍历
                 if (va.listFiles() != null) {
                fun4(va);
                 }
            }
            System.out.println(va.getName());
        }
    }

    /**
     * 需求 : 设计一个方法, 删除某一个文件夹下的所有内容
     * 注意 : delete() 只能删除空文件夹
     *
     * @param file
     */
    public static void fun5(File file) {
        // 获取所有文件和文件夹的数组
        File[] files = file.listFiles();
        for (File fi : files) {
            // 判断是不是文件
            if (fi.isFile()) {
                // 是文件直接删除
                fi.delete();
            } else {  // 是目录,进行递归调用,删除里面的文件
                fun5(fi);
            }
        }
        // 这一步需要注意, for循环里面删除只能删除文件, 不能删除文件夹
        // \\a\\123.txt -->
        // 123.txt被for循环删除
        // 这里的a就是传参的file
        // 代码走到这里,说明file里面肯定是个空文件了,里面的每一层的文件被删除了,这时删除空文件夹
        file.delete();
    }

    /**
     * 需求 : 设计一个方法,  统计一个文件夹中, 所有文件类型出现的次数
     * .txt 2
     * .docx 1
     * .png 3
     *
     * @param file
     * @return
     */
    public static HashMap<String, Integer> fun6(File file, HashMap<String, Integer> hashMap) {

        File[] files = file.listFiles();
        for (File fil : files) {
            if (fil.isFile()) {
                // 这里也有bug,如果文件不带有后缀名就会报错
                // String key = fil.getName().substring(fil.getName().lastIndexOf("."));
                // 所以采用分割的方式进行(a.b.c.txt)
                String[] strings = fil.getName().split("\\.");
                String key = strings[strings.length -1]; // 取最后一段,但是就是少了一个点
                hashMap.put(key, hashMap.getOrDefault(key, 0) + 1);
                // 如果是文件夹, 就递归累计
            }else if (fil.isDirectory()){
                // 注意为null的情况
                if (fil.listFiles() != null){
                    fun6(fil, hashMap);
                }
            }
        }
        return hashMap;
    }
}
