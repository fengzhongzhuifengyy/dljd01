package example09_printStream;

import java.io.FileNotFoundException;
import java.io.PrintStream;

/**
 * 功能说明:打印流 ---没啥用
 * 作用：打印流可以实现方便、高效的打印数据到文件中去。打印流一般是指：PrintStream，PrintWriter两个类。
 * 可以实现打印什么数据就是什么数据，例如打印整数97写出去就是97，打印boolean的true，写出去就是true。
 * 字节打印流:
 * public PrintStream(OutputStream os)	打印流直接通向字节输出流管道
 * public PrintStream(File  f)	打印流直接通向文件对象
 * public PrintStream(String filepath)	打印流直接通向文件路径
 *
 * public void print(Xxx xx)	打印任意类型的数据出去
 *
 * 字符打印流:
 * public PrintWriter(OutputStream os)	打印流直接通向字节输出流管道
 * public PrintWriter (Writer w)	打印流直接通向字符输出流管道
 * public PrintWriter (File  f)	打印流直接通向文件对象
 * public PrintWriter (String filepath)	打印流直接通向文件路径
 *
 * public void print(Xxx xx)	打印任意类型的数据出去
 *
 * PrintWriter : 需要在构造方法里面开启自动刷新, 否则在flush()/close()关流的情况下才可以输出到文件
 *
 * @author 虞渊
 * @since 2023-09-04-0:06
 */
public class PrintStreamDemo {
    public static void main(String[] args) throws FileNotFoundException {
        PrintStream out = System.out;
        out.println("abc");

        // 当然你可以直接打印到文件
        PrintStream ps = new PrintStream("E:\\test\\a.txt");
        ps.println(97);
        ps.close();
    }
}
