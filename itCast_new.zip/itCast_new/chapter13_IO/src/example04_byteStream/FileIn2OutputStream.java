package example04_byteStream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * IO流
 * 按流向分:
 *  输入流 : InputStream Reader 两个抽象父类
 *  输出流: OutputStream Writer 两个抽象父类
 *
 * 按数据类型分:
 *  字节流 : 万能流,包括音频视频图片等
 *  字符流: 只能传输纯文本
 *
 * @author: 虞渊
 * @date: 2023/6/27
 */
public class FileIn2OutputStream {
    public static void main(String[] args) throws IOException {
        // fun1();
        // fun2();
        fun3();
    }

    /**
     * 文件字节输出流 FileOutputStream
     * <p>
     * 构造器:
     * public FileOutputStream(File file) : 创建一个字节输出流 , 向指定File对象的文件中写入内容
     * public FileOutputStream(File file, boolean append) : 创建一个字节输出流 , 向指定File对象的文件中写入内容
     * public FileOutputStream(String name) : 创建一个字节输出流 , 向指定名称的文件中写入内容
     * public FileOutputStream(String name,  boolean append) : 第二个参数为true, 表示追加写数据
     *
     * 成员方法:
     * public void write(int b ) : 将指定字节写入到文件中
     * public void write(byte[] b) : 将字节数组中的字节写入到文件中
     * public void write(byte[] b,  int off, int len) : 将字节数组的一部分写到文件中 , b代表的是字节数组, off代表开始索引, len代表个数
     * public void close() : 释放资源 , 断开流与文件之间的联系
     * 字节输出流是否可以写一个字符串 ? ----> String类 : public byte[] getBytes();
     *
     * 输出换行:
     * windows : \r\n   举例 : 输出流对对象.write("\r\n".getBytes())
     * mac :  \r
     * linux : \n
     */
    public static void fun1() throws IOException {
        // 创建字节输出流对象, 关联文本文件
        FileOutputStream fos = new FileOutputStream("E:\\test\\123.txt");
        // 写单个字节
        fos.write(97);
        // 写字节数组的全部
        byte[] bytes = {97, 98, 99, 100};
        fos.write(bytes);
        // 换行
        fos.write("\r\n".getBytes());
        // 写字节数组的一部分
        fos.write(bytes, 0, 2);
        // 写字符串(字节数组)
        fos.write("sss".getBytes());
        // 关闭流,释放资源
        fos.close();
    }

    /**
     * 文件字节输入流 FileInputStream
     * 构造方法:
     * public FileInputStream(File file) : 创建一个字节输入流对象, 从指定File对象的文件中读取数据
     * public FileInputStream(String name) : 创建一个字节输入流对象, 从指定名称的文件中读取数据
     *
     * 成员方法:
     * public int read() : 读取一个字节数据并返回 , 读到完毕末位返回-1
     * public int read(byte[] b) : 把数据读取字节数组中, 并返读到数据的有效个数返回, 读到完毕末位返回-1
     */
    public static void fun2() throws IOException {
        // 创建流对象
        FileInputStream fis = new FileInputStream("E:\\test\\123.txt");
        byte[] bytes = new byte [1024];
        int len;
        while ((len = fis.read(bytes)) != -1){
            String str = new String(bytes, 0, len);
            System.out.println(str);
        }
        fis.close();
    }

    /**
     * 字节流文件的复制
     */
    public static void fun3() throws IOException {
        // 创建流对象
        FileInputStream fis = new FileInputStream("E:\\test\\123.txt");
        FileOutputStream fos = new FileOutputStream("E:\\test\\234.txt");
        byte[] bytes = new byte[1024];
        int len;
        while ((len = fis.read(bytes)) != -1){
            fos.write(bytes, 0, len);
        }
        fis.close();
    }
}
