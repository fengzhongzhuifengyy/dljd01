package example04_byteStream;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 功能说明:针对异常jdk7之后的关闭流:
 * try(需要关闭流的对象){
 * 相关处理语句;
 * }catch(相关异常表对象){
 * 捕获异常信息
 * }
 *
 * @author 虞渊
 * @since 2023-08-20-18:36
 */
public class FileOutputStreamDemo02 {
    public static void main(String[] args) {

    }

    /**
     * JDK 7 之前的关闭流写法
     */
    public static void fun1() {
        FileOutputStream fos = null;
        try {
            // int num = 10 / 0;  // 这里就会出现空指针
            fos = new FileOutputStream("E:\\test\\22.txt");
            fos.write("hello".getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            // 此时 这里会出现空指针的情况
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    /**
     * JDK 7 之后的关闭流写法:
     * 格式:
     *  try(需要调用cLose方法的对象）{
     *      逻辑代码
     *  }catch（抓捕异常）{
     *      异常的处理方案．
     *  }
     *
     *  ()中包裹的对象, 会自动的调用close()
     *
     *  细节: 只要一个类, 实现了AutoCloseAble接口, 将该类放在try()里面, 就会自动调用close();
     *  public class FileOutputStream extends OutputStream
     *  public abstract class OutputStream implements Closeable, Flushable
     *  public interface Closeable extends AutoCloseable
     */
    public static void fun12() {
        // 需要关流的对象放入try的()中
        try (FileOutputStream fos = new FileOutputStream("E:\\test\\22.txt");) {
            fos.write("hello".getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


