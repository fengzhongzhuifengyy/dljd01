package example10_properties;

import java.util.Hashtable;

/**
 * 功能说明: HashMap 与 Hashtable
 *
 * @author 虞渊
 * @since 2023-09-04-0:15
 */
public class PropertiesDemo01 {
    /*
        java.util.Properties 继承于 Hashtable来表示一个持久的属性集。
        它使用键值结构存储数据，每个键及其对应值都是一个字符串。

        HashMap 和 Hashtable 的区别
            1. HashMap允许存储 null 键 null 值,  Hashtable不行
            2. HashMap线程不安全,  Hashtable 线程安全 --以后也不用,会有其他安全方法代替(Collections.syncxxx())
     */
    public static void main(String[] args) {
        fun();
    }

    public static void fun() {
        Hashtable<String, String> hashtable = new Hashtable<>();
        // Hashtable不允许存储null
        // hashtable.put(null, null); // java.lang.NullPointerException
    }
}
