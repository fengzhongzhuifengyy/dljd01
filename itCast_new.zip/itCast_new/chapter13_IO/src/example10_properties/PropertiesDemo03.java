package example10_properties;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;

/**
 * 功能说明: Properties集合数据写出到文件
 *
 * @author 虞渊
 * @since 2023-09-13-23:41
 */
public class PropertiesDemo03 {
    /*
        Properties和文件相关的方法
        void load (InputStream inStream): 从输入字节流读取属性列表(键和元素对)
        void load (Reader reader): 从输入字符流读取属性列表(键和元素对)
        void store (OutputStream out，String comments): 将此属性列表(键和元素对) 写入此 Properties表中，以适合于使用load(Inputstream)方法的格式写入输出字节流
        void store (Writer writer, String comments): 将此属性列表(键和元素对)写入此 Properties表中，以适合使用load(Reader)方法的格式写入输出字符流
        public Object setProperty(String key，String value): 保存键值对 (put)
        public String getProperty(String key): 使用此属性列表中指定的键搜索属性值(get)
        public Set<String> stringPropertyNames(): 所有键的名称的集合(keySet())
     */
    public static void main(String[] args) throws IOException {
        Properties properties = new Properties();
        properties.setProperty("1", "1");
        properties.setProperty("2", "2");
        // 将相关配置信息存入配置文件中--store()
        FileOutputStream fos = new FileOutputStream("itCast\\config.properties");
        properties.store(fos, "这是配置文件");
        fos.close();

        // 从配置文件中读取配置---load()
        properties.load(new FileInputStream("itCast\\config.properties"));
        Set<String> ketSet = properties.stringPropertyNames();
        for (String key : ketSet) {
            System.out.println(key +"---" + properties.getProperty(key));
        }

    }
}