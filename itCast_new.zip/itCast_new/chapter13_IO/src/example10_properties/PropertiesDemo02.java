package example10_properties;

import java.util.Properties;
import java.util.Set;

/**
 * 功能说明: Properties作为集合的使用
 *
 * @author 虞渊
 * @since 2023-09-04-0:22
 */
public class PropertiesDemo02 {
    /*
        Properties是Hashtable的子类, 意味着先是一个集合

        从演示来看, Properties没有泛型,可以添加任意类型, 但是一般都建议是String
     */
    public static void main(String[] args) {
        Properties properties = new Properties();

        // // 通过之前集合的方式实现 -- 弊端就是没有泛型,比较麻烦
        // properties.put("username", "zhansgan");
        // properties.put("passwd", "123456");
        // // 通过之前的方法实现遍历
        // properties.forEach((k,v) -> System.out.println(k+" "+v));


        // 通过独有的方式进行设置键值对
        properties.setProperty("username", "zhansgan");
        properties.setProperty("passwd", "123456");
        // stringPropertyNames(): 拿到所有键的集合
        Set<String> keySet = properties.stringPropertyNames();
        for (String key : keySet) {
            // getProperty(): 通过键获取值
            System.out.println(properties.getProperty(key));
        }
    }


}
