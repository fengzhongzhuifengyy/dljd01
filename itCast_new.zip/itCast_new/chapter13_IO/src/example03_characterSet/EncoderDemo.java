package example03_characterSet;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

/**
 * 字符集(编码表)
 * ASCII：ASCII使用1个字节存储一个字符，一个字节是8位，总共可以表示128个字符信息
 * GBK: GBK是中国的码表, GBK要兼容ASCII编码，但其中文字符一般以两个字节的形式存储。
 * Unicode字符集：UTF-8编码后一个中文一般以三个字节的形式存储，同时也要兼容ASCII编码表。
 *
 * 编码前的字符集和解码时的字符集有什么要求？
 * 必须一致，否则会出现字符乱码
 * 英文和数字不会乱码
 *
 * 编码（加密）: 将看的懂的字符转换为看不懂的字节
 * 解码（解密）: 将看不懂的字符转换为看的懂的字符
 *
 * String 编码:
 * byte[] getBytes()	使用平台的默认字符集将该 String编码为一系列字节，将结果存储到新的字节数组中
 * byte[] getBytes(String charsetName)	使用指定的字符集将该 String编码为一系列字节，将结果存储到新的字节数组中
 *
 * String解码
 * String(byte[] bytes)	通过使用平台的默认字符集解码指定的字节数组来构造新的 String
 * String(byte[] bytes, String charsetName)	通过指定的字符集解码指定的字节数组来构造新的 String
 *
 * @author: 虞渊
 * @date: 2023/6/26
 */
public class EncoderDemo {
    public static void main(String[] args) throws UnsupportedEncodingException {
        /*
            编码细节:
            1. 英文 数字 标点占用的都是一个字节
            2. 中文字符在字节体现的时候,开头肯定是负数,后面有可能是正数
         */
        String s1 = "你好";
        byte[] bytes1 = s1.getBytes();
        System.out.println(Arrays.toString(bytes1)); // [-28, -67, -96, -27, -91, -67]
        // 编码构造器携带编码集
        String s3 = "你好";
        byte[] bytes3 = s3.getBytes("GBk");
        System.out.println(Arrays.toString(bytes3)); // [-60, -29, -70, -61]
        /*
            解码细节:
            1. 编码解码的字符集必须一致
            2. 平台默认指定的字符集是utf-8
         */
        byte[] bytes2 = {97, 98, 99};
        String s2 = new String(bytes2);
        System.out.println(s2);
        // 解码构造器携带编码集
        String s4 = new String(bytes3, "GBK");
        System.out.println(s4);
    }
}
