package example06_bufferStream;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 功能说明: BufferedReader
 * 字符缓冲输入流: public BufferedReader(Reader r)	可以把低级的字符输入流包装成一个高级的缓冲字符输入流管道，从而提高字符输入流读数据的性能
 * 新增能力: public String readLine()	读取一行数据返回，如果读取没有完毕，无行可读返回null
 *
 * 字符缓冲输出流：BufferedWriter: public BufferedWriter(Writer w)	可以把低级的字符输出流包装成一个高级的缓冲字符输出流管道，从而提高字符输出流写数据的性能
 * 新增能力: public void newLine()	换行操作
 *
 * 如果想要内容追加, 还是需要在原流中进行true传参
 *
 * @author 虞渊
 * @since 2023-09-03-22:07
 */
public class BufferReader2Writer {
    public static void main(String[] args) throws IOException {
        fun();
    }

    public static void fun() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("E:\\test\\123.txt"));
        BufferedWriter bw = new BufferedWriter(new FileWriter("E:\\test\\123co.txt"));
        // readline() : 无数据返回null
        String s = br.readLine();
        System.out.println(s);
        String len;
        while ((len = br.readLine()) != null){
            bw.write(len);
            // 换行
            bw.newLine();
        }
        br.close();
        bw.close();
    }
}
