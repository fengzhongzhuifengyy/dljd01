package example06_bufferStream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 功能说明:缓冲流也称为高效流、或者高级流。之前学习的字节流可以称为原始流。
 * 作用：缓冲流自带缓冲区、可以提高原始字节流、字符流读写数据的性能
 * 分类:
 * 字节输入缓冲流:public BufferedInputStream(InputStream is) 可以把低级的字节输入流包装成一个高级的缓冲字节输入流管道，从而提高字节输入流读数据的性能
 * 字符输入缓冲流:public BufferedOutputStream(OutputStream os) 可以把低级的字节输出流包装成一个高级的缓冲字节输出流，从而提高写数据的性能
 *
 * @author 虞渊
 * @since 2023-09-03-21:40
 */
public class BufferedIn2outputStream {
    public static void main(String[] args) {

    }

    /**
     * 字节缓冲流细节说明:
     * 1.缓冲流只是对普通流对象进行增强(包装),真正跟文件建立关系的,还是普通流对象
     * 2.关闭了缓冲流,就不需要单独再关闭普通流了---源码的close()就已经调用普通流的close()
     * 3.缓冲流的读写效率是怎么提高的? -在流对象中, 内置了8k数组
     *     普通流+ 自定义数组 ---最高效
     */
    public static void fun1() throws IOException {
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream("E:\\test\\123.txt"));
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("E:\\test\\123.txt"));
        int i;
        // 这里虽然只有read(),但是是一次性读取8192个字节
        // 但是中间环节的转换还是比较慢,这里就算指定自己的数组, 还是会先填写缓冲的8k数组
        while ((i = bis.read()) != -1){
            // 同理这个写也是一次性写出8192
            bos.write(i);
        }
        bos.close();
        bis.close();
    }

    // 通过缓存字节数组来增加效率
    public static void fun2() throws IOException {
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream("E:\\test\\123.txt"));
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("E:\\test\\123.txt"));
        byte[] bytes = new byte[8192];
        int len;
        while ((len = bis.read(bytes)) != -1){
            bos.write(bytes, 0, len);
        }
        bos.close();
        bis.close();
    }
}
