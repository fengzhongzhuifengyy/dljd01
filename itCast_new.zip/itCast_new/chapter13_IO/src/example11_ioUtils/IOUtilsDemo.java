package example11_ioUtils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

/**
 * 功能说明: IO 工具类
 *
 * @author 虞渊
 * @since 2023-09-13-23:41
 */
public class IOUtilsDemo {
    /*
        String readFileToString(File file, String encoding)	读取文件中的数据, 返回字符串
        void copyFile(File srcFile, File destFile)	复制文件。
        void copyDirectoryToDirectory(File srcDir, File destDir)	复制文件夹。
     */
    public static void main(String[] args) throws IOException {
        String str = FileUtils.readFileToString(new File("E:\\test\\123.txt"), "UTF-8");
        System.out.println(str);

        FileUtils.copyFile(new File("E:\\test\\123.txt"), new File("E:\\test\\123co.txt"));

        FileUtils.copyDirectoryToDirectory(new File("E:\\test\\新建文件夹"), new File("E:\\test\\新建文件夹copy"));
    }
}
