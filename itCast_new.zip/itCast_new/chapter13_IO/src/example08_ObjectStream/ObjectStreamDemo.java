package example08_ObjectStream;

import com.itCast.study.chapter11_exception.domain.Student;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * 对象流(序列化流)
 *  特点:
 *      可以把对象以字节的形式写到本地文件, 直接打开文件，是读不懂的,需要再次用对象操作流读到内存中
 *  分类:
 *      对象操作输出流 ObjectOutputStream : 就是将对象写到本地文件中,
 *      writeObject();
 *      对象操作输入流 ObjectInputStream: 把写到本地文件中的对象读到内存中
 *      readObject();
 *
 *  注意事项:
 *      1 修改了对象所属的Javabean类 , 会抛出InvalidClassException异常
 *      解决 : 给对象所属的类加一个 serialVersionUID
 *      private static final long serialVersionUID = ?L
 *      2 给该成员变量加 transient 关键字修饰，该关键字标记的成员变量不参与序列化过程
 *
 * @author 虞渊
 * @since 2023-09-03-23:34
 */
public class ObjectStreamDemo {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Student stu = new Student("zhangsan", 18);
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("E:\\test\\obj.txt"));
        oos.writeObject(stu);
        /*
            发现报错:java.io.NotSerializableException
            说明类需要实现Serializable接口, 仅是一个标记接口
         */
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("E:\\test\\obj.txt"));
        Object o = ois.readObject();
        System.out.println(o); // Student{name='zhangsan', age=18}
        ois.close();

        /*
            思考: 如果我们有多个对象, 一个一个读写吗?
            通过测试发现,如果读到最后就会抛异常, 所以一般我们都会将多个对象存入集合中
            比如创建三个对象存入list对象, 然后进行读写
         */
    }
}
