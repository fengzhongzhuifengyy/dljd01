package example05_charStream;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 字符流
 * 1.字符流的应用: 字节流虽然可以操作任意类型的文件,但是读中文时,可能会出现乱码,字符流就可以解决读写过程中出现乱码的问题
 * 2.字符流组成 : 字节流 + 编码表
 *      当我们调用read方法读取字符的时候, 实际上，底层会先读取到(一个字节),判断这个字节是否是负数（中文字符，字节的第一个，肯定是负数)
 *      假设:-74 -73 -72, 第一次读取到的是-74，就可以判断，读取的内容是中文了,是中文的话，再结合平台的默认编码表，决定继续读取多少个字节
 *      UTF-8，读取3个字节—-->转换为中文的汉字,如果读取到的字节，是正数，就直接读取一个字节，然后转换.
 * 3.字符流方法 :
 *  写数据方法:
 *      public void write(int c) : 写一个字符
 *      public void write(char[] cbuf) : 写一个字符数组
 *      public void write(char[] cbuf,int off,int len) : 写一个字符数组的一部分
 *      public void write(String str) : 写一个字符串
 *      public void write(String str,int off,int len) : 写一个字符串的一部分
 *  读数据方法:
 *      public int read():一次读取一个字符
 *      public int read(char[] cbuf):一次读取一个字符数组
 *  其他方法;
 *      public void flush() : 刷新该流的缓冲 , 刷新之后可以继续写数据
 *      public void close() : 关闭此流，先会执行刷新 , 刷新之后无法进行写数据
 *
 * 4.分类:
 * FileWriter(字符输出流)  :
 *      概述 : 用来写入字符文件的便捷类
 *      体系 : public class FileWriter extends OutputStreamWriter
 *      构造方法 : public FileWriter(String fileName) : 据给定的文件名构造一个 FileWriter 对象
 * FileReader(字符输出流) :
 *      概述 : 用来读取字符文件的便捷类
 *      体系 : public class FileReader extends InputStreamReader
 *      构造方法：public FileReader(String fileName) : 据给定的文件名构造一个FileReader对象
 *
 * 5.字节流与字符流不一样的细节:
 *      1.创建的数组类型不一致, char[]
 *      2.字节流写出数据,就算没有关闭流,数据也会正常写出到文件,字符流不行,为什么不行, 因为字符输出流底层是有一层buff数组缓存区,源码如下:
 *             public abstract class Writer implements Appendable, Closeable, Flushable {
 *             private char[] writeBuffer;
 *             ...}
 *      字符流写出数据,必须调用
 *          flush()[将缓存区的数据,刷出到文件,刷出后,可以继续调用writer写出数据]
 *          close()[主要作用是关闭释放流资源,如果关闭的是字符流,还会将缓冲区的数据刷出, 但是一旦调用完close之后, 就无法继续写数据]
 *      3.字符流写出数据,可以直接写出来字符串
 *
 * @author: 虞渊
 * @date: 2023/6/29
 */
public class FileReader2FileWriter {
    public static void main(String[] args) throws IOException {
        fun1();
        fun3();
    }
    /**
     * 字符输入流:
     */
    public static void fun1() throws IOException {
        FileReader fr = new FileReader("E:\\test\\123.txt");
        int i;
        while ((i = fr.read()) != -1){
            System.out.print((char)i);
        }
        fr.close();
    }

    /**
     * 字符流文件的复制
     */
    public static void fun3() throws IOException {
        // 创建流对象
        FileReader fr = new FileReader("E:\\test\\123.txt");
        FileWriter fw = new FileWriter("E:\\test\\234.txt");
        char[] chars = new char[1024];
        int len;
        while ((len = fr.read(chars)) != -1){
            fw.write(chars, 0, len);
        }
        fw.close();
        fr.close();
    }
}
