package example07_inputReader2outputWriter;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 * 功能说明:
 * 字符输入流 : InputStreamReader类
 *      public InputStreamReader(InputStream in) : 使用平台默认编码进行解析数据
 *      public InputStreamReader(InputStream in,String charsetName) : 用指定的编码进行解析数据
 *
 * 字符输出流 : OutputStreamWriter类
 *      public OutputStreamWriter(OutputStream out) : 根据默认编码把字节流的转换为字符流对象
 *      public OutputStreamWriter(OutputStream out,String charsetName) : 根据指定编码把字节流对象转换为字符流对象
 *
 *
 * @author 虞渊
 * @since 2023-09-03-22:44
 */
public class ZhuanHuanLiu {
    /*
        为什么需要转换流呢?
        因为有些流对象, 不是自己直接创建的, 而是通过接收方法返回值
        手里的流是一个字节流但是是一个纯文本,这个时候就可以使用字符流来实现转换提升效率

        流程:
        1. 真正根文件产生关联的还是字节流
        2. 根据读取的字节,配合指定的编码表,进行转换操作
     */
    public static void main(String[] args) {

    }

    public static void fun() throws IOException {
        // 使用指定编码表创建转换输入流对象, 关联文件(真正跟文件关联的, 还是普通流对象)
        InputStreamReader isr = new InputStreamReader(new FileInputStream("E:\\test\\123.txt"), "utf-8");

        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("E:\\test\\123cp1.txt"), "utf-8");
        int i;
        while ((i= isr.read()) != -1) {
            osw.write(i);
        }
        osw.close();
        isr.close();
    }
}
