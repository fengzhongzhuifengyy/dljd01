# select * from hm_stu;
-- 1.给指定列添加数据
# INSERT INTO 表名(列名1,列名2,…) VALUES(值1,值2,…);
# insert into hm_stu(id, name, gender, birthday) values (001, '张三', '男', date'1990-12-12');
/*
针对data类型:
如果没有时间部分,可用这个
insert into table_name(begin_date) values (date'2010-01-01');

如果有时间部分to_date函数将字符型转换为日期型，用这个
insert into table_name(begin_date) values
　　　　(to_date('2010-01-01 20:23:00','yyyy-mm-dd hh24:mi:ss'));

如果要插入当前时间，可以使用sysdate直接取数据库系统时间
insert into table_name(begin_date) values (sysdate);
 */

-- 2.给所有列添加数据，列名的列表可以省略的
# insert into 表名 values(值1, 值2, 值3,...);
# insert into hm_stu values ('002', '李四', '男', date '1991-12-12', 95.5, '12233435@qq.com', '13655515777', 1);
-- 3.批量添加数据
# insert into 表名(列名1, 列名2...) values (值1, 值2...), (值1, 值2)...
# insert into  表名 values  (值1, 值2...), (值1, 值2)...

# insert into hm_stu values ('003', '王五', '男', date '1991-12-12', 96.5, '12333435@qq.com', '13655515778', 2),
#                           ('004', '李六', '男', date '1991-12-12', 97.5, '12433435@qq.com', '13655515779', 3);


-- 修改数据: 修改语句中如果不加条件,则将所有的数据都修改
-- UPDATE 表名 SET 列名1=值1,列名2=值2,… [WHERE 条件] ;
# update hm_stu set name='小张三' where id=1;

-- 4.将张三的性别改为女
# update hm_stu set gender='女' where name='小张三';
-- 5、将张三的生日改为 1999-02-12 分数改为99.99
# update hm_stu set birthday='1999-02-12', score=99.99 where name='小张三';

-- 6、将王五的分数在原有的基础上-10分
# update hm_stu set score=score-10 where name='王五'

-- 7.删除张三记录: 如果不加条件删除所有
-- 删除  DELETE FROM 表名 [WHERE 条件] ;
# delete from hm_stu where name='李六'