-- DDL 操作数据库:

-- 1.查看所有数据库
# show databases;
-- 2.创建db1数据库
# create database db1;
-- 3.创建db2数据库，如果不存在的话就创建
# create database if not exists db2;
-- 4.删除db2数据库
# drop database db1;
-- 5.删除db2数据库，如果存在的话就删除
# drop database if exists db2;
-- 6.使用db1数据库
# use database db1;
-- 7.查看当前使用的数据库
# select database();
-- --------------------------------------------------------

-- DDL 操作表:

-- 1.查询当前数据库下的所有表
# show tables;
-- 2.查询表结构
# desc score;

-- 3.创建表
/*
	CREATE TABLE 表名 (
		字段名1  数据类型1,
		字段名2  数据类型2,
		…
		字段名n  数据类型n
	);

	3.需求：创建tb_user表
		id int,
		username varchar(20),
		password varchar(20)
*/
# create table tb_user(
#     id int,
#     username varchar(20),
#     password varchar(20)
# );

/*
    Mysql支持多种数据类型: 可以分为三类 数值 日期 字符串
    分类	数据类型	大小	描述
数值类型
    TINYINT	1 byte	极小整数值
	SMALLINT	2 bytes	小整数值
	MEDIUMINT	3 bytes	中等整数值
	INT或INTEGER	4 bytes	大整数值	语法:字段名 int  或者  字段名 int(长度)。长度不写默认是11。例如 id int
	BIGINT	8 bytes	极大整数值
	FLOAT	4 bytes	单精度浮点数值	语法:字段名 float(总长度,小数位数)  。例如  score float(5,2)
	DOUBLE	8 bytes	双精度浮点数值	语法:字段名 double(总长度,小数位数)  。例如  score float(5,2)
	DECIMAL		小数值
日期和时间类型
    DATE	3	日期值
	TIME	3	时间值或持续时间
	YEAR	1	年份值
	DATETIME	8	混合日期和时间值	年月日时分秒，如果不添加值，默认值就是null。
	TIMESTAMP	4	混合日期和时间值，时间戳	年月日时分秒，如果不添加数据或者添加的数据是null，该列数据默认取系统当前时间。
字符串类型
    CHAR	0-255 bytes	定长字符串	语法:字段名 char(8)  表示将来存的字符串长度固定是8，如果不足8个字符，用空格字符站位。
	VARCHAR	0-65535 bytes	变长字符串	语法:字段名 varchar(8)  表示将来存的字符串长度小于或者等于8，实际字符串的长度是几就占几个字符的空间。
	TINYBLOB	0-255 bytes	不超过 255 个字符的二进制字符串
	TINYTEXT	0-255 bytes	短文本字符串
	BLOB	0-65 535 bytes	二进制形式的长文本数据
	TEXT	0-65 535 bytes	长文本数据
	MEDIUMBLOB	0-16 777 215 bytes	二进制形式的中等长度文本数据
	MEDIUMTEXT	0-16 777 215 bytes	中等长度文本数据
	LONGBLOB	0-4 294 967 295 bytes	二进制形式的极大文本数据
	LONGTEXT	0-4 294 967 295 bytes	极大文本数据
*/
/*
	4.需求：设计一张学生表(student)，请注重数据类型、长度的合理性
		编号(id)
		姓名(name)，姓名最长不超过10个汉字
		性别(gender)，因为取值只有两种可能，因此最多一个汉字
		生日(birthday)，取值为年月日
		入学成绩(score)，小数点后保留两位
		邮件地址(email)，最大长度不超过 64
		家庭联系电话(tel)，不一定是手机号码，可能会出现 - 等字符
		学生状态(status)（用数字表示，正常、休学、毕业...）
*/
# create table hm_student(
#     id int,
#     name varchar(10),
#     gender char(1),
#     birthday date,
#     score double(5, 2),
#     email varchar(64),
#     tel varchar(12),
#     status tinyint
# )

-- 5.删除tb_user表
# drop table 表名
# drop table hm_user;

-- 6.删除tb_user表,判断表是否存在。
# drop table if exists 表名
# drop table if exists hm_user

-- 7.修改hm_student表名称为hm_stu
# alter table 表名 rename to 新的名称
# alter table hm_student rename to hm_stu;
# alter table tb_user rename to hm_user

-- 8.给hm_stu表添加一列address，类型为varchar类型
# alter table 表名 add 列名 列名的数据类型
# alter table  hm_stu add address varchar(20);

-- 9.修改address列的类型为char类型
# alter table 表名 modify 列名 列名的数据类型
# alter table hm_stu modify address char(8);

-- 10.修改address列为addr并且修改为varchar类型
# alter table 表名 change 原列名 新列名 新列名数据类型
# alter table hm_stu change address addr varchar(20);

-- 11.删除addr列
# alter table 表名 drop 列名
# alter table hm_stu drop addr