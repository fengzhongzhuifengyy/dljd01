/*
	分页查询:

			SELECT 字段列表 FROM 表名 LIMIT  起始索引 , 查询条目数
				* 起始索引：从0开始

    上述语句中的起始索引是从0开始

*/
select * from t_hm_student;
-- 1. 查询第1页3条数据
select *
from t_hm_student limit 0, 3; # 第一页已经0 1 2
-- 2. 查询第2页3条数据
select *
from t_hm_student limit 3, 3; # 第二页从索引3开始
-- 3. 查询第3页3条数据
select *
from t_hm_student limit 6, 3;

