/*
	排序查询：
		* 语法：SELECT 字段列表 FROM 表名  ORDER BY 排序字段名1 [排序方式1],排序字段名2 [排序方式2] …;
		* 排序方式：
				* ASC：升序排列（默认值）
				* DESC：降序排列

	如果有多个排序条件，当前边的条件值一样时，才会根据第二条件进行排序
*/

select * from t_hm_student;
-- 1.查询学生信息，按照年龄升序排列
select *
from t_hm_student order by age;
-- 2.查询学生信息，按照数学成绩降序排列
select *
from t_hm_student order by math desc ;
-- 3.查询学生信息，按照数学成绩降序排列，如果数学成绩一样，再按照英语成绩升序排列
select *
from t_hm_student order by math desc, english;
