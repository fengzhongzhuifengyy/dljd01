/*
    将一列数据作为一个整体，进行纵向计算。
	count(列名):统计数量（一般选用不为null的列）
	max(列名):最大值
	min(列名):最小值
	sum(列名):求和
	avg(列名):平均值
    null 值不参与所有聚合函数运算
*/
select * from t_hm_student;
-- 1.统计班级一共有多少个学生
select count(*)
from t_hm_student;
-- 2.查询数学成绩的最高分
select max(math)
from t_hm_student;
-- 3.查询数学成绩的最低分
select min(math)
from t_hm_student;
-- 4.查询数学成绩的总分
select sum(math)
from t_hm_student;
-- 5.查询数学成绩的平均分
select avg(math)
from t_hm_student;
-- 6.查询英语成绩的最低分
-- 为什么65? 因为null不参与聚合运算
select min(english)
from t_hm_student;