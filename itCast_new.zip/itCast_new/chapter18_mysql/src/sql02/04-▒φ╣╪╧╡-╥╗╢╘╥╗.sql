/*
	一对一：
		如：用户 和 用户详情
		一对一关系多用于表拆分，将一个实体中经常使用的字段放一张表，不经常使用的字段放另一张表，用于提升查询性能

	
	实现方式：在任意一方加入外键，关联另一方主键，并且设置外键为唯一(UNIQUE)

	
*/
-- 删除表
DROP TABLE IF EXISTS t_hm_user;
DROP TABLE IF EXISTS t_hm_user_desc;

-- 用户详情表
CREATE TABLE t_hm_user_desc(
	id int primary key auto_increment,
	city varchar(100),
	edu varchar(10),
	income double(10,2),
	status varchar(10),
	descInfo varchar(200)
);

-- 用户表
CREATE TABLE t_hm_user(
	id int primary key auto_increment,
	phone varchar(100),
	nickname varchar(20),
	age int,
	gender char(1),
	# 这里作为外键必须设置 unique
	desc_id int unique ,
	constraint fk_t_hm_user_desc foreign key(desc_id) references t_hm_user_desc(id)
);
-- 建完表后，添加外键