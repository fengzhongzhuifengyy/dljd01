/*
开启事务:
start transaction;
begin;
提交事务
commit;
回滚事务
rollback;
  */


DROP TABLE IF EXISTS account;

-- 创建账户表
CREATE TABLE t_hm_account(
	id int PRIMARY KEY auto_increment,
	name varchar(10),
	money double(10,2)
);

-- 添加数据
INSERT INTO t_hm_account(name,money) values('张三',1000),('李四',1000);

UPDATE t_hm_account set money = 1000;

select * from t_hm_account;

-- 演示事务操作



-- 查看事务的默认提交方式
SELECT @@autocommit;
-- 1 自动提交  0 手动提交
-- 修改事务提交方式
set @@autocommit = 0;