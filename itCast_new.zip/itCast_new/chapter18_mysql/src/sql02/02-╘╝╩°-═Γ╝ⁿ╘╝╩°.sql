/*
	外键约束:
		* 外键用来让两个表的数据之间建立链接，保证数据的一致性和完整性

	
	-- 创建表时添加外键约束
	CREATE TABLE 表名(
		 列名 数据类型,
		 …
		 [CONSTRAINT] [外键名称] FOREIGN KEY(外键列名) REFERENCES 主表(主表列名) 
	); 


	-- 建完表后添加外键约束
	ALTER TABLE 表名 ADD CONSTRAINT 外键名称 FOREIGN KEY (外键字段名称) REFERENCES 主表名称(主表列名称);


	-- 删除约束
	ALTER TABLE 表名 DROP FOREIGN KEY 外键名称;
	
	
*/
-- 删除表
DROP TABLE IF EXISTS t_hm_employ;
DROP TABLE IF EXISTS t_hm_dept;


-- 部门表
CREATE TABLE t_hm_dept(
	id int primary key auto_increment,
	dep_name varchar(20),
	addr varchar(20)
);
-- 员工表 
CREATE TABLE t_hm_employ(
	id int primary key auto_increment,
	name varchar(20),
	age int,
	dep_id int,
	constraint fk_emp_dept	foreign key(dep_id) references t_hm_dept(id)
);
-- 添加 2 个部门
insert into t_hm_dept(dep_name,addr) values
('研发部','广州'),('销售部', '深圳');

-- 添加员工,dep_id 表示员工所在的部门
INSERT INTO t_hm_employ (NAME, age, dep_id) VALUES
('张三', 20, 1),
('李四', 20, 1),
('王五', 20, 1),
('赵六', 20, 2),
('孙七', 22, 2),
('周八', 18, 2);
-- ------------------
select * from t_hm_employ;
-- 演示外键约束 :  Cannot add or update a child row:
-- a foreign key constraint fails (`test_project`.`t_hm_employ`,
-- CONSTRAINT `fk_emp_dept` FOREIGN KEY (`dep_id`) REFERENCES `t_hm_dept` (`id`))
INSERT INTO t_hm_employ (NAME, age, dep_id) VALUE('张恒久', 20, 3);

-- 删除外键
# alter table t_hm_employ drop foreign key fk_emp_dept

-- 建完表后，添加外键
alter table t_hm_employ add constraint fk_01 foreign key(dep_id) references t_hm_dept(id);

