/*
-- 左外连接
SELECT 字段列表 FROM 表1 LEFT [OUTER] JOIN 表2 ON 条件 LEFT [OUTER] JOIN 表3 ON 条件…;

-- 右外连接
SELECT 字段列表 FROM 表1 RIGHT [OUTER] JOIN 表2 ON 条件 RIGHT [OUTER] JOIN 表3 ON 条件…;

*/
-- 需求：查询所有员工的和员工的部门信息
-- 左外连接
select *
from t_hm_emp e left outer join t_hm_department d on e.dep_id=d.did;
-- 从展示的结果看区别: 小白龙为null 也展示出来了 满足所有员工


-- 右外连接
select *
from t_hm_department d right outer join t_hm_emp e on d.did = e.dep_id;
-- 右链接一般只是掉个表顺序






