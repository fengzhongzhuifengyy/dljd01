
DROP TABLE IF EXISTS t_hm_employ;

-- 员工表
-- 创建约束方式一:
CREATE TABLE t_hm_employ (
  id INT primary key auto_increment, -- 员工id，主键且自增长
  ename VARCHAR(50) not null unique, -- 员工姓名，非空并且唯一
  joindate DATE not null , -- 入职日期，非空
  salary DOUBLE(7,2) not null , -- 工资，非空
  bonus DOUBLE(7,2) default 0-- 奖金，如果没有奖金默认为0
);
# 创建约束二:
CREATE TABLE t_hm_employ (
                             id INT auto_increment, -- 员工id，主键且自增长
                             ename VARCHAR(50) not null unique, -- 员工姓名，非空并且唯一
                             joindate DATE not null , -- 入职日期，非空
                             salary DOUBLE(7,2) not null , -- 工资，非空
                             bonus DOUBLE(7,2) default 0,-- 奖金，如果没有奖金默认为0
                             primary key (id)
);


# Duplicate entry '1' for key 'PRIMARY'
INSERT INTO t_hm_employ(id,ename,joindate,salary,bonus) values(1,'张三','1999-11-11',8800,5000);

-- 演示主键约束：非空且唯一, 自增长之后可以设置为null
INSERT INTO t_hm_employ(id,ename,joindate,salary,bonus) values(null,'李四','1999-11-11',8800,5000);

-- 演示非空约束: Column 'ename' cannot be null
INSERT INTO t_hm_employ(id,ename,joindate,salary,bonus) values(3,null,'1999-11-11',8800,5000);

-- 演示唯一约束: Duplicate entry '李四' for key 'ename'
INSERT INTO t_hm_employ(id,ename,joindate,salary,bonus) values(4,'李四','1999-11-11',8800,5000);

-- 演示默认约束:  Column count doesn't match value count at row 1
INSERT INTO t_hm_employ(id,ename,joindate,salary,bonus) values(4,'王五','1999-11-11',8800);
INSERT INTO t_hm_employ(id,ename,joindate,salary) values(5,'周六','1999-11-11',8800);

# 记住不设置值,才是null值--这里存的是null
INSERT INTO t_hm_employ(id,ename,joindate,salary,bonus) values(4,'王五','1999-11-11',8800,null);

-- 演示自动增长：auto_increment：当列是数字类型并且 唯一约束
SELECT * from t_hm_employ;