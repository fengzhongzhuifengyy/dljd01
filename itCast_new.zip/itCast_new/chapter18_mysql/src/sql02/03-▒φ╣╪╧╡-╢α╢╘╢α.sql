/*
	多对多：
		* 如：订单 和 商品
		* 一个商品对应多个订单，一个订单包含多个商品

	实现方式：建立第三张中间表，中间表至少包含两个外键，分别关联两方主键
*/
-- 删除表
DROP TABLE IF EXISTS t_hm_order_goods;
DROP TABLE IF EXISTS t_hm_order;
DROP TABLE IF EXISTS t_hm_goods;


-- 订单表
CREATE TABLE t_hm_order(
	id int primary key auto_increment,
	payment double(10,2),
	payment_type TINYINT,
	status TINYINT
);

-- 商品表
CREATE TABLE t_hm_goods(
	id int primary key auto_increment,
	title varchar(100),
	price double(10,2)
);

-- 订单商品中间表
CREATE TABLE t_hm_order_goods(
	id int primary key auto_increment,
	order_id int,
	goods_id int,
	count int,
	constraint fk_t_hm_order foreign key(order_id) references t_hm_order(id),
	constraint fk_t_hm_goods foreign key (goods_id) references t_hm_goods(id)
);

-- 建完表后，添加外键


