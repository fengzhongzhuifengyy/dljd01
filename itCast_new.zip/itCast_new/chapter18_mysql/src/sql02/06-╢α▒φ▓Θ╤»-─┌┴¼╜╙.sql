/*
-- 隐式内连接
SELECT 字段列表 FROM 表1,表2… WHERE 条件;

-- 显示内连接
SELECT 字段列表 FROM 表1 [INNER] JOIN 表2 ON 条件 [INNER] JOIN 表3 ON 条件 …;

*/
-- 需求：查询员工的姓名、性别和部门名称
-- 隐式内连接
select *
from t_hm_emp e,
     t_hm_department d
where e.dep_id = d.did;
-- 显式内连接
select *
from t_hm_emp e  inner join t_hm_department d on e.dep_id = d.did where e.salary>4500;
-- inner 可以省略



