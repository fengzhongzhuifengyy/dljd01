/*
	单行单列：作为条件值，使用 = != > <等进行条件判断
		SELECT 字段列表 FROM 表 WHERE 字段名 = (子查询);
	多行单列：作为条件值，使用 in 等关键字进行条件判断
		SELECT 字段列表 FROM 表 WHERE 字段名 in (子查询);
	多行多列：作为虚拟表
		SELECT 字段列表 FROM (子查询) WHERE 条件;
*/

-- 需求1：查询工资高于猪八戒的员工信息
select *
from t_hm_emp
where salary > (select salary from t_hm_emp where NAME = '猪八戒');
-- 需求2：查询 '财务部' 和 '市场部' 所有的员工信息
# 1.查询'财务部'和'市场部'的所有员工信息
# 2.查询dep_id等于2或3的员工信息
select *
from t_hm_emp e
where dep_id in (select did
                 from t_hm_department d1
                 where d1.did in (3, 2));
-- 需求3：查询入职日期是 '2011-11-11' 之后的员工信息和部门信息
select *
from t_hm_emp e
where e.join_date > '2011-11-11';

select *
from (select *
      from t_hm_emp e
      where e.join_date > '2011-11-11') e2
         left join t_hm_department d on e2.dep_id = d.did;
