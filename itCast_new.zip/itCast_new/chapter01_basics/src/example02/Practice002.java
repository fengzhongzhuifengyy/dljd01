package example02;

import java.util.Scanner;

/**
 * 手机号码屏蔽
 * 需求
 * 键盘录入一个手机号，将中间四位号码屏蔽，最终效果为：158****7499
 *
 * @author 虞渊
 * @since 2022年10月25日 16:21
 */
public class Practice002 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入手机号: ");
        String phoneNumber = sc.next();
        //方法一:
        // String subPhoneNum = phoneNumber.substring(3, 7);
        // phoneNumber = phoneNumber.replace(subPhoneNum, "****");

        //方法二:
        //1.取出前3位
        String start = phoneNumber.substring(0, 3);
        //2.取出后4位
        String end = phoneNumber.substring(phoneNumber.length() - 4);
        //3.进行拼接
        phoneNumber = start + "****" + end;
        System.out.println(phoneNumber);

    }
}
