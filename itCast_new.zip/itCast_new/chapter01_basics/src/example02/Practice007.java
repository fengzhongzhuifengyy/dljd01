package example02;

import java.util.ArrayList;

/**
 * 添加用户对象并判断是否存在
 * 需求：
 * 1，main方法中定义一个集合，存入三个用户对象。
 *       用户属性为：id，username，password
 * 2，要求：定义一个方法，根据id查找对应的学生信息。
 *       如果存在，返回true
 *       如果不存在，返回false
 *
 * @author 虞渊
 * @since 2022年10月27日 22:43
 */
public class Practice007 {
    public static void main(String[] args) {

        ArrayList<Student> studentArrayList = new ArrayList<>();
        Student student1 = new Student("张三", 23, "123456",100);
        Student student2 = new Student("李四", 24, "123456",200);
        Student student3 = new Student("王五", 25, "123456",300);
        studentArrayList.add(student1);
        studentArrayList.add(student2);
        studentArrayList.add(student3);
        if (getStudent(400, studentArrayList)) {
            System.out.println("存在");
        }else {
            System.out.println("不存在");
        }
    }

    public static boolean getStudent(int id, ArrayList<Student> arrayList){
        for (Student values : arrayList){
            if (id == values.getId()){
                return true;
            }
        }
        return false;
    }
}
