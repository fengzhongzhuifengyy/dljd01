package example02;

/**
 * 定义方法按照要求拼接数组
 * 需求：
 * 定义一个方法，将数组拼接成如下格式并返回
 * 1、如果传递的参数为空，返回null
 * 2、如果传递的数组元素个数为0，返回[]
 * 3、如果数组为int[] arr = {1,2,3}; ，执行方法后的输出结果为：[1, 2, 3]
 *
 * @author 虞渊
 * @since 2022年10月24日 16:20
 */
public class Practice001 {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3};
        System.out.println(arrayConcat(arr));
    }

    public static String arrayConcat(int[] arr) {
        if (arr == null) {
            return null;
        }
        if (arr.length == 0) {
            return "[]";
        }
        String result = "[";
        for (int i = 0; i < arr.length; i++) {
            if (i == arr.length -1){
                result = result + arr[i] +"]";
            }else {
                result = result.concat(arr[i] + ", ");
            }
        }
        //这是第一种方法,还可以在循环中加入判断,最后的值不进行拼接", "
        // result = result.trim().substring(0, result.length() - 2).concat("]");
        return result;
    }
}


