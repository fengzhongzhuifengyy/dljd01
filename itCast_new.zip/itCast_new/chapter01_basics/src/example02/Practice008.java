package example02;

import java.util.ArrayList;

/**
 * 删除元素
 * 需求：
 * 1，main方法中定义一个集合，存入以下字符串。
 *       “a”  “b”  “b”  “c”  “d”
 * 2，要求：删除所有的“b”
 *
 * @author 虞渊
 * @since 2022年10月28日 0:08
 */
public class Practice008 {
    public static void main(String[] args) {
        ArrayList<String> strings = new ArrayList<>();
        strings.add("a");
        strings.add("b");
        strings.add("b");
        strings.add("c");
        strings.add("d");

        // //遍历删除
        // for (int i = 0; i < strings.size(); i++) {
        //     //如果相同就删除(两种方式都可以)
        //     if ("b".equals(strings.get(i))){
        //         // strings.remove("b");
        //         strings.remove(i);
        //     }
        // }
        // //思考,此时代码就结束了吗?--> 打印结果发现 a b c d
        // for (int i = 0; i < strings.size(); i++) {
        //     System.out.println(strings.get(i));
        // }

        //为什么会是这样呢? 因为集合是可以弹性伸缩的,当我们把第一个b删除之后,后面的"b"立马补齐,i++导致直接到"c"
        //处理方式: 我们在获取到第一个"b"时,删除后将索引回退一位(i--)
        //说明针对连续的值进行删除会存在一定的坑,需要理解remove()的方式。

        for (int i = 0; i < strings.size(); i++) {
            //如果相同就删除(两种方式都可以)
            if ("b".equals(strings.get(i))){
                // strings.remove("b");
                strings.remove(i);
                i--;
            }
        }
        //打印结果 a c d
        for (int i = 0; i < strings.size(); i++) {
            System.out.println(strings.get(i));
        }
    }
}
