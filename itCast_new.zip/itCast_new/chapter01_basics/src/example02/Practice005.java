package example02;

/**
 * 拼接字符串
 * 需求：定义一个方法，把 int 数组中的数据按照指定的格式拼接成一个字符串返回。
 * 调用该方法，并在控制台输出结果。
 * 例如：数组为int[] arr = {1,2,3};
 * 执行方法后的输出结果为：[1, 2, 3]
 *
 * @author 虞渊
 * @since 2022年10月26日 21:32
 */
public class Practice005 {
    public static void main(String[] args) {
        int[] arr = {1,2,3};
        System.out.println(getConcat(arr));
    }

    public static String getConcat(int[] arr){
        String str = "[";
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        for (int i = 0; i < arr.length; i++) {
            if (i == arr.length-1){
                sb.append(arr[i]);
            }else {
                sb.append(arr[i] + ", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
