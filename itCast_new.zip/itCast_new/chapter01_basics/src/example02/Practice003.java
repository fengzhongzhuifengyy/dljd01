package example02;

import java.util.Scanner;

/**
 * 脏话屏蔽（敏感词过滤）
 *
 * @author 虞渊
 * @since 2022年10月25日 16:53
 */
public class Practice003 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入你的话术: ");
        String input = scanner.next();
        System.out.println(getValue(input));
    }

    public static String getValue(String str){
        //定义一个敏感词库
        String[] sensitives = new String[]{"你妈", "尼玛"};

        for (String sensitive : sensitives) {
            if (str.contains(sensitive)) {
                str = str.replace(sensitive, "***");
            }
        }
        return str;
    }
}
