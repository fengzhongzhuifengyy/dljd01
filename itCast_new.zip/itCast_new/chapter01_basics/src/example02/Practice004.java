package example02;

/**
 * 验证字符串
 * 请定义一个方法用于判断一个字符串是否是对称的字符串，
 * 并在主方法中测试方法。
 * 例如："abcba"、"上海自来水来自海上"均为对称字符串。
 *
 * @author 虞渊
 * @since 2022年10月25日 22:51
 */
public class Practice004 {
    public static void main(String[] args) {
        String input = "123421";
        //方法一
        if (relativeString(input)) {
            System.out.println("是对称字符串");
        } else {
            System.out.println("不是对称字符串");

        }

        //方法二
        //1.获取方法反转返回的字符串
        String result = reverse(input);
        //2.反转前与翻转后的字符串进行比较
        if (input.equals(result)) {
            System.out.println("是对称字符串");
        } else {
            System.out.println("不是对称字符串");
        }

    }

    //方法1: 返回boolean去判断
    public static boolean relativeString(String str) {
        char[] chars = str.toCharArray();
        int count = 0;
        for (int i = 0, j = chars.length - 1; i < j; i++, j--) {
            if (chars[i] == chars[j]) {
                count++;
            }
        }
        if (count == chars.length / 2) {
            return true;
        }
        return false;
    }

    //方法2: 返回String去判断是否相等
    private static String reverse(String input) {
        //1.初始化字符串进行拼接使用
        String res = "";
        //2.abc -> cba 逆向取出字符并进行字符串拼接
        for (int i = input.length() - 1; i >= 0; i--) {
            res = res + input.charAt(i);
        }
        System.out.println(res);
        return res;
    }

}
