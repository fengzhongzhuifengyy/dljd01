package example02;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * 添加学生对象并遍历
 * 需求：定义一个集合，添加一些学生对象，并进行遍历
 *       学生类的属性为：姓名，年龄。
 * 要求：对象的数据来自键盘录入
 *
 * @author 虞渊
 * @since 2022年10月27日 22:31
 */
public class Practice006 {
    public static void main(String[] args) {
        ArrayList<Student> studentArrayList = new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        //注意这里有个重点:如果直接使用studentArrayList.size(),因为默认长度是0,循环是无法进入的
        for (int i = 0; i < 3; i++ ) {
            Student student = new Student();
            System.out.println("请输入学生姓名: ");
            String username = sc.next();
            student.setUsername(username);
            System.out.println("请输入学生年龄: ");
            int age = sc.nextInt();
            student.setAge(age);
            studentArrayList.add(student);
        }
        //遍历集合
        for (Student values : studentArrayList) {
            System.out.println(values.getUsername() + " " + values.getAge());
        }

    }
}
