package example02;

/**
 * 学生bean
 *
 * @author 虞渊
 * @since 2022年10月27日 22:32
 */
public class Student {
    private String username;
    private int age;
    private String password;

    private int id;

    public Student() {
    }

    public Student(String username, int age, String password, int id) {
        this.username = username;
        this.age = age;
        this.password = password;
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
