package example01;

import java.util.Random;

/**
 * @author by 虞渊
 * @Classname Practice009
 * @Description 一个大V直播抽奖，奖品是现金红包，分别有{2, 588 , 888, 1000, 10000}五个奖金。
 * 请使用代码模拟抽奖，打印出每个奖项，奖项的出现顺序要随机且不重复。打印效果如下：（随机顺序，不一定是下面的顺序）
 * @Date 2022-10-13 0:19
 */
public class Practice009 {
    public static void main(String[] args) {
        int[] numbers = {2, 588, 888, 1000, 10000};

        //打乱数组可以通过随机索引实现,这样效率较高
        Random random = new Random();
        for (int i = 0; i < numbers.length; i++) {
            int index = random.nextInt(5);
            int temp = numbers[i];
            numbers[i] = numbers[index];
            numbers[index] = temp;
        }
        // 遍历打乱后的数组 --此时就是每次打印不同的顺序,且不会出现各种重复打印的数值
        for (int number : numbers) {
            System.out.println(number);
        }
    }
}
