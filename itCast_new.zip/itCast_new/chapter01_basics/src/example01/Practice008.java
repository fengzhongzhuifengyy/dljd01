package example01;

/**
 * @author by 虞渊
 * @Classname Practice008
 * @Description 打印等腰三角形
 * @Date 2022-10-12 23:32
 */
public class Practice008 {
    public static void main(String[] args) {

        for (int i = 1; i <= 5; i++) {
            // 打印空格
            for (int j = i; j <= 5; j++) {
                System.out.print(" ");
            }
            // 打印左边*三角
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            // 打印右边*三角,注意这里需要每行少打印一个,因此只需要-1即可
            for (int j = 1; j <= i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
