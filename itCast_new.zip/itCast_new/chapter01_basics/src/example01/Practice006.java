package example01;

/**
 * @author by 虞渊
 * @Classname Practice006
 * @Description 需求：
 * 	定义一个方法copyOfRange(int[] arr,int from, int to)
 * 功能：
 * 	将数组arr中从索引from（包含from）开始。
 * 	到索引to结束（不包含to）的元素复制到新数组中，
 * 	将新数组返回。
 * @Date 2022-09-27 23:16
 */
public class Practice006 {
    public static void main(String[] args) {

    }
}
