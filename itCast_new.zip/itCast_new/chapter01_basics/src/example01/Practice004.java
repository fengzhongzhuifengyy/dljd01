package example01;

/**
 * @author by 虞渊
 * @Classname Practice004
 * @Description 需求：定义一个数组，存入1,2,3,4,5。按照要求交换索引对应的元素。
                交换前：1,2,3,4,5
                交换后：5,2,3,4,1
 * @Date 2022-09-26 22:29
 */
public class Practice004 {
}
