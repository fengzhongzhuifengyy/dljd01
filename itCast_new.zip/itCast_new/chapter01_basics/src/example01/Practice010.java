package example01;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * @author by 虞渊
 * @Classname Practice010
 * @Description 彩票小项目:投注号码由6个红色球号码和1个蓝色球号码组成。红色球号码从1-33中选择;蓝色球号码从1-16中选择。
 * 奖等	中奖条件		中奖说明		单注奖金分配
 * 红球  蓝球
 * 一等奖				6中1		1000万
 * 二等奖				6中0		500万
 * 三等奖				5中1		3000元
 * 四等奖				5中0		200元
 *                      4中1
 * 五等奖				4中0		10元
 *                      3中1
 * 六等奖				2中1		5元
 *                      1中1
 *                      0中1
 * @Date 2022-10-16 22:41
 */
public class Practice010 {
    public static void main(String[] args) {
        //1.随机生成中奖号码
        //红球:1-33 6个
        //蓝球:1-16 1个
        int[] randomNumbers = createNumber();

        //2.用户输入中奖号码
        int[] userNumbers = inputNumber();

        //3.两个号码进行比较,查看是否中奖
        System.out.println(compareResult(userNumbers, randomNumbers));
    }

    /**
     * 随机生成中奖号码
     *
     * @return int[]
     * @author 虞渊
     * @date 2022-10-18 22:21
     */
    public static int[] createNumber() {

        //1.定义一个数组,存放篮球和红球的号码(6+1)
        int[] arr = new int[7];
        //2.因为存放蓝球,长度为（length-1），同时可以判断出：蓝球存放的时候不能重复（多次存放）--因此增加判重的方法
        Random random = new Random();
        for (int i = 0; i < arr.length - 1; ) {
            // 范围1-33
            int blueNumber = random.nextInt(33) + 1;
            System.out.println("第" + (i + 1) + "次添加红球的个数为：");
            // 号码未重复即加入数组中
            if (!(isDistinct(arr, blueNumber))) {
                arr[i] = blueNumber;
                // 只有添加成功，才可以索引+1
                i++;
            } else {
                System.out.println("蓝球号码重复！");
            }
        }
        //3.添加红球
        arr[arr.length - 1] = random.nextInt(16) + 1;
        System.out.println(Arrays.toString(arr));
        return arr;
    }

    /**
     * 判断号码在存贮的数组中是否已经存在
     *
     * @param arr
     * @param number
     * @return boolean
     * @author 虞渊
     * @date 2022-10-18 22:23
     */
    public static boolean isDistinct(int[] arr, int number) {

        for (int i = 0; i < arr.length; i++) {
            if (number == arr[i]) {
                return true;
            }
        }
        return false;
    }

    /**
     * 生成用户输入号码
     *
     * @return int[]
     * @author 虞渊
     * @date 2022-10-18 22:59
     */
    public static int[] inputNumber() {
        //1.定义一个数组存储用户输入的数字
        int[] arr = new int[7];
        Scanner scanner = new Scanner(System.in);
        //新增蓝球数据
        for (int i = 0; i < arr.length - 1; ) {
            System.out.println("请输入第" + (i + 1) + "蓝球中奖号码：");
            int userBlueNumbers = scanner.nextInt();
            if (userBlueNumbers >= 1 && userBlueNumbers <= 33) {
                if (!(isDistinct(arr, userBlueNumbers))) {
                    arr[i] = userBlueNumbers;
                    i++;
                } else {
                    System.out.println("您输入的号码重复,请重新输入!");
                }
            } else {
                System.out.println("您输入的号码有误,请重新输入");
            }
        }
        //新增红球数据
        while (true) {
            System.out.println("请输入红球的号码: ");
            int userRedNumbers = scanner.nextInt();
            if (userRedNumbers >= 1 && userRedNumbers <= 16) {
                arr[arr.length - 1] = userRedNumbers;
                break;
            } else {
                System.out.println("您输入的号码有误,请重新输入");
            }

        }
        System.out.println(Arrays.toString(arr));
        return arr;
    }

    /**
     * 比较是否中奖
     *
     * @author 虞渊
     * @date 2022-10-18 23:22
     * @param arr1
     * @param arr2
     * @return java.lang.String
     */
    private static String compareResult(int[] arr1, int[] arr2) {
        //定义两个计数器,分别为蓝球和红球相同的个数
        int count1 = 0;
        int count2 = 0;
        //先判断蓝球相同的个数
        for (int i = 0; i < arr1.length - 1; i++) {
            if (isDistinct(arr2, arr1[i])) {
                count1++;
            }
        }
        //再判断红球相同的个数
        if (arr1[arr1.length - 1] == arr2[arr2.length - 1]) {
            count2++;
        }
        System.out.println("count1=" + count1 + "count2=" + count2);
        if (count1 == 6 && count2 == 1) {
            return "一等奖,奖金1000万";
        } else if (count1 == 6 && count2 == 0) {
            return "二等奖,奖金500万";
        } else if (count1 == 5 && count2 == 1) {
            return "三等奖,奖金3000元";
        } else if ((count1 == 5 && count2 == 0) || (count1 == 4 && count2 == 1)) {
            return "四等奖,奖金200元";
        } else if ((count1 == 4 && count2 == 0) || (count1 == 3 && count2 == 1)) {
            return "五等奖,奖金10元";
        } else if ((count1 == 2 && count2 == 1) || (count1 == 1 && count2 == 1) || (count1 == 0 && count2 == 1)) {
            return "六等奖,奖金5元";
        } else {
            return "未中奖";
        }
    }
}
