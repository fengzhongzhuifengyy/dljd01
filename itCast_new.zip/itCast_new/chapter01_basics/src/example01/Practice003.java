package example01;

import java.util.Random;

/**
 * @author by 虞渊
 * @Classname Practice003
 * @Description 需求：生成10个1~100之间的随机数存入数组。
                          1）求出所有数据的和
                          2）求所有数据的平均数
                          3）统计有多少个数据比平均值小
 * @Date 2022-09-25 22:56
 */
public class Practice003 {
    public static void main(String[] args) {
        int[] numbers = new int[10];
        // 求和的值
        int sum = 0;
        // 平均值
        int avg = 0;
        // 随机数并存入数组
        Random random = new Random();
        for (int i = 0; i < numbers.length; i++) {
            int randomNumber = (random.nextInt(100) + 1);
            numbers[i] = randomNumber;
            sum += randomNumber;
        }
        avg = sum / numbers.length;
        System.out.println("平均分" + avg);
        // 次数
        int count = 0;
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
            if (numbers[i] < avg) {
                count++;
            }
        }
        System.out.println();
        System.out.println("统计有" + count + "个数据比平均值小");
    }
}
