package example01;

import java.util.Random;
import java.util.Scanner;

/**
 * @author by 虞渊
 * @Description 程序自动生成一个1-100之间的随机数字，使用程序实现猜出这个数字是多少？
 * @Date 2022-09-25 14:33
 */
public class Practice002 {

    public static void main(String[] args) {
        //创建对象
        Random random = new Random();
        //nextInt()生成一个随机数
        //可以指定生成的范围，我们可以在小括号中如果写10，表示会生成0-9之间生成一个随机数。
        /*
            随机数的小技巧：
            例如生成7-15
            a.头尾都减去同一个值，让这个范围从0开始    -7  [0 8]
            b.尾巴+1                     nextInt(8+1)   [0 9]
            c.最终的结果再加上a步骤减去的数                [7 16]
         */
        int randomNumber = random.nextInt(100) + 1;
        System.out.println("随机数为：" + randomNumber);

        //2.猜
        Scanner scanner = new Scanner(System.in);
        //两数比较，三种情况
        while (true) {
            System.out.println("请输入你猜测的数：");
            int guessNumber = scanner.nextInt();
            if (guessNumber < randomNumber) {
                System.out.println("您猜的数字偏小，再来一次！");
            } else if (guessNumber > randomNumber) {
                System.out.println("您猜的数字偏大，再来一次！");
            } else {
                System.out.println("猜对了");
                break;
            }
        }
    }
}
