package example01;

import java.util.Random;
import java.util.Scanner;

/**
 * @author by 虞渊
 * @Classname Practice007
 * @Description 键盘录入班级人数,  根据班级人数录入班级学员姓名；从录入的学员姓名中, 随机取出一个, 并打印在控制台
 * @Date 2022-09-29 23:26
 */
public class Practice007 {
    public static void main(String[] args) {
        // 1.键盘录入班级的人数
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入班级人数：");
        int studentNumber = sc.nextInt();
        // 2.根据人数
        String[] studentInfos = new String[studentNumber];
        // 3.录入学生信息
        for (int i = 0; i < studentInfos.length; i++) {
            System.out.println("请输入第" + (i + 1)+"位学员的信息（姓名、年龄、性别）：");
            String inputInfo = sc.next();
            studentInfos[i] = inputInfo;
        }

        for (int i = 0; i < studentInfos.length; i++) {
            System.out.println(studentInfos[i]);
        }
        // 4.随机抽取
        Random random = new Random();
        for (int i = 0; i < 5; i++) {
            // random.nextInt：范围是0 - studentNumber-1
            int index = random.nextInt(studentNumber);
            System.out.println(index);
            System.out.println(studentInfos[index]);
        }

    }
}
