package example01;

/**
 * @author by 虞渊
 * @Classname Demo01
 * @Description 需求：键盘录入一个大于等于2的整数 x ，计算并返回 x 的 平方根 。结果只保留整数部分 ，小数部分将被舍去。
 * @Date 2022-09-24 1:07
 */
public class Practice001 {
    public static void main(String[] args) {
    }
}
