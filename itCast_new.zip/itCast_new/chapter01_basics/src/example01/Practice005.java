package example01;

/**
 * @author by 虞渊
 * @Classname Practice005
 * @Description 需求：定义一个数组，存入1~5。要求打乱数组中所有数据的顺序。
 * @Date 2022-09-26 22:36
 */

public class Practice005 {
	public static void main(String[] args) {
		// 1.从0索引开始遍历
		// 2.生成随机索引
		// 3.此时将i与随机索引index对应的值进行交换，i++
	}
}
