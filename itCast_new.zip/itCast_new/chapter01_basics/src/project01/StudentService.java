package project01;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年10月28日 23:46
 */
public class StudentService {

    Scanner sc = new Scanner(System.in);

    /**
     * 添加学生信息
     *
     * @param arrayList
     * @return java.lang.String
     * @author 虞渊
     * @date 2022-10-29 17:30
     */
    public String add(ArrayList<Student> arrayList) {
        System.out.println("请输入学生学号: ");
        String stuNum = sc.next();
        while (true) {
            if (contains(arrayList, stuNum)) {//添加学生的学号不能重复
                System.out.println("学生信息已存在,请重新输入!");
            } else {
                // 学号不重复,开始添加
                break;
            }
        }
        System.out.println("请输入学生姓名: ");
        String stuName = sc.next();
        System.out.println("请输入学生年龄: ");
        int stuAge = sc.nextInt();
        System.out.println("请输入学生居住地: ");
        String stuAddress = sc.next();
        arrayList.add(new Student(stuNum, stuName, stuAge, stuAddress));
        return "添加学生成功";
    }

    /**
     * 查询学生信息
     *
     * @param arrayList
     * @return java.lang.String
     * @author 虞渊
     * @date 2022-10-29 17:31
     */
    public String query(ArrayList<Student> arrayList) {
        String str = "学号" + "\t姓名" + "\t年龄" + "\t居住地\n";
        for (int i = 0; i < arrayList.size(); i++) {
            str += arrayList.get(i).getSid() + "\t" + arrayList.get(i).getName() + "\t" + arrayList.get(i).getAge() + "\t" + arrayList.get(i).getAddress() + "\n";
        }
        return str;
    }

    /**
     * 删除学生信息
     *
     * @param arrayList
     * @return java.lang.String
     * @author 虞渊
     * @date 2022-10-29 17:32
     */
    public String delete(ArrayList<Student> arrayList) {
        String sid;
        while (true) { // 为了输入错误可以再次重新输入
            System.out.println("请输入你要删除的学生的学号: ");
            sid = sc.next();
            if (contains(arrayList, sid)) { //判断sid是否存在-------->注意这里就不需要对-1进行判断

                // 为了提高代码效率,删除操作在循环外进行
                // int index = findIndex(arrayList, sid);//得到sid的索引
                // arrayList.remove(index);
                // return "删除学生信息成功";

                // 存在进行删除,跳出循环删除
                break;
            } else {
                System.out.println("您删除的id不存在,请重新输入!");
            }
        }
        int index = findIndex(arrayList, sid);//得到sid的索引
        arrayList.remove(index);
        return "删除学生信息成功";
    }

    /**
     * 修改学生信息
     *
     * @param arrayList
     * @return java.lang.String
     * @author 虞渊
     * @date 2022-10-29 17:37
     */
    public String update(ArrayList<Student> arrayList) {
        String sid;
        while (true) {
            System.out.println("请输入你要修改的学生的学号: ");
            sid = sc.next();
            if (contains(arrayList, sid)) {
                //修改学生对象操作
                break;
            } else {
                System.out.println("该学号不存在,请重新输入!");
            }
        }
        System.out.println("请输入学生的新姓名: ");
        String stuNum = sc.next();
        System.out.println("请输入学生的新年龄: ");
        int stuAge = sc.nextInt();
        System.out.println("请输入学生的新住址: ");
        String stuAddress = sc.next();
        //获取sid对应的索引
        int index = findIndex(arrayList, sid);
        arrayList.get(index).setName(stuNum);
        arrayList.get(index).setAge(stuAge);
        arrayList.get(index).setAddress(stuAddress);
        return "修改学生成功";
    }

    /**
     * 退出系统
     *
     * @return boolean
     * @author 虞渊
     * @date 2022-10-29 17:37
     */
    public boolean exit() {
        System.out.println("请确认是否退出Y/N?");
        char choose = sc.next().charAt(0);
        if ("Y".equals(String.valueOf(choose).toUpperCase())) {
            return true;
        }
        System.out.println("放弃退出学生管理系统!");
        return false;
    }

    /**
     * 判断id是否存在集合中
     *
     * @param list 学生集合
     * @param sid  用户id
     * @return boolean true:存在; false:不存在
     * @author 虞渊
     * @date 2022-10-29 16:48
     */
    public boolean contains(ArrayList<Student> list, String sid) {

        // for (int i = 0; i < list.size(); i++) {
        //     if (sid == null) {
        //         return false;
        //
        //     }
        //     if (sid.equals(list.get(i).getSid())) {
        //         return true;
        //     }
        // }
        // return false;

        // 与findIndex()方法合并即可以判断是否存在
        return findIndex(list, sid) >= 0;
    }

    /**
     * 通过sid查询在集合中的索引位置
     *
     * @param list
     * @param sid
     * @return int
     * @author 虞渊
     * @date 2022-10-29 16:56
     */
    public int findIndex(ArrayList<Student> list, String sid) {

        if (sid == null) {
            return -1;
        }
        for (int i = 0; i < list.size(); i++) {
            if (sid.equals(list.get(i).getSid())) {
                return i;
            }
        }
        return -1;
    }
}
