package project01;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * 页面类
 *
 * @author 虞渊
 * @since 2022年10月28日 23:35
 */
public class StudentSystem {
    public static void main(String[] args) {
        boolean isFlag = true;
        Scanner scanner = new Scanner(System.in);
        StudentService studentService = new StudentService();
        ArrayList<Student> myStudent = new ArrayList<>();

        do {
            System.out.println("------欢迎来到学生管理系统------");
            System.out.println("1.添加学生");
            System.out.println("2.删除学生");
            System.out.println("3.修改学生");
            System.out.println("4.查看所有学生");
            System.out.println("5.退出");
            System.out.print("请输入你的选择(1-5): ");
            String choose = scanner.next();

            switch (choose){
                case "1" :
                    System.out.println("添加学生详情");
                    System.out.println(studentService.add(myStudent));
                    break;
                case "2" :
                    System.out.println("删除学生");
                    System.out.println(studentService.delete(myStudent));
                    break;
                case "3" :
                    System.out.println("修改学生");
                    System.out.println(studentService.update(myStudent));
                    break;
                case "4" :
                    System.out.println("查看所有学生");
                    System.out.println(studentService.query(myStudent));
                    break;
                case "5" :
                    System.out.println("退出");
                    if (studentService.exit()){
                        isFlag = false;
                        System.out.println("退出学生管理系统");
                    }
                    break;
                default:
                    System.out.println("您输入的不合法,请重新输入!");
            }
        }while (isFlag);
    }
}
