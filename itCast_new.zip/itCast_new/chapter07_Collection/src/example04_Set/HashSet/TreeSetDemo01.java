package example04_Set.HashSet;

import com.itCast.study.chapter07_Collection.domain.Movie;

import java.util.TreeSet;

/**
 * TreeSet:
 * 不重复、无索引、可排序
 * 可排序：按照元素的大小默认升序（有小到大）排序。
 * TreeSet集合底层是基于红黑树的数据结构实现排序的，增删改查性能都较好。
 * 注意：TreeSet集合是一定要排序的，可以将元素按照指定的规则进行排序。
 *
 * @author 虞渊
 * @since 2022年12月25日 20:40
 */
public class TreeSetDemo01 {
    public static void main(String[] args) {
        // 数字大小排序
        TreeSet<Integer> ts = new TreeSet<>();
        ts.add(10);
        ts.add(20);
        ts.add(30);
        ts.add(40);
        ts.add(40);

        System.out.println(ts);

        //字典排序
        TreeSet<String> ts1 = new TreeSet<>();
        ts1.add("c");
        ts1.add("e");
        ts1.add("f");
        ts1.add("g");
        ts1.add("v");
        ts1.add("张三");
        ts1.add("李四");

        System.out.println(ts1);

        // 存储:自定义对象, 怎么排序呢?
        TreeSet<Movie> ts2 = new TreeSet<>();
        /*
            如果直接创建bean, 然后放入TreeSet里面会发生异常:Movie cannot be cast to java.lang.Comparable
            可以看出,当自定义类没有实现Comparable接口,自定义类是不具备可比性的,就无法进行排序,运行就会异常

            compareTo:
                正数: 数据往右边走(红黑树)
                负数: 数据往左边走(红黑树)
                0: 不存,首次树根还是需要存储的
         */
        ts2.add(new Movie("张三1", 0.751, "王五"));
        ts2.add(new Movie("张三2", 0.752, "李四"));
        ts2.add(new Movie("张三3", 0.753, "周三"));
        System.out.println(ts2);
        /*
        比较规则如下:
        public int compareTo(Movie o) {
        //1.优先按照总分数做比较
        int result = (int)(this.getScore() - o.getScore());
        //2.年龄相同在按照名字进行比较
        return   result = result == 0? this.name.compareTo(o.name): result;
    }
         */
    }
}
