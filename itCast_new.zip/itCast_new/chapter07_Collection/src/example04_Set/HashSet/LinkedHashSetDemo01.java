package example04_Set.HashSet;

import java.util.LinkedHashSet;

/**
 * LinkedHashSet: HashSet的子类,可以保证元素的唯一,并且还能保证存取的顺序
 *
 * @author 虞渊
 * @since 2022年12月25日 20:33
 */
public class LinkedHashSetDemo01 {

    public static void main(String[] args) {
        LinkedHashSet<String> lhs = new LinkedHashSet<String>();
        /*
            底层的数据结构依然是哈希表,只是每个元素又额外多了一个双链表的机制记录存储的顺序
         */
        lhs.add("d");
        lhs.add("s");
        lhs.add("g");
        lhs.add("g");
        lhs.add("n");
        System.out.println(lhs);
    }
}
