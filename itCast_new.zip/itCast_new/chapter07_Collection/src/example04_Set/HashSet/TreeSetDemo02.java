package example04_Set.HashSet;

import java.util.Comparator;
import java.util.TreeSet;

/**
 * @author 虞渊
 * @since 2023-08-16-7:31
 */
public class TreeSetDemo02 {
    /*
        需求: 向集合中添加元素(abc，aaa，aaaa，cccccc，eeeeeee)
            对集合中存储的元素，进行排序操作，要求根据字符串的长度，来进行排序
        情况: 要排序的数据，是java已经写好的类，这些类重写过compareTo方法，内部有自己的排序方式
            但是它的排序方式，跟我想要的不一样，这时候怎么办?
        解决方案:要搞一个新的排序器，覆盖掉，他原有的排序方式

        自然排序:
            类 impLements Comparable 接口，重写 compareTo 方法，
        比较器排序:
            在TreeSet集合的构造方法里，传入 Comparator接口的实现类对象
        注意: 如果一个类,同时指定了自然排序,还指定了比较器排序,优先按照长度进行排序
     */
    public static void main(String[] args) {

        TreeSet<String> treeSet = new TreeSet<>(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                // 按照长度进行降序排
                int res = o2.length() - o1.length();
                // 再按照名称是进行排序
                res = res == 0 ? o2.compareTo(o1) : res;
                return res;
            }
        });
        treeSet.add("abc");
        treeSet.add("aaa");
        treeSet.add("aaaa");
        treeSet.add("cccccc");
        treeSet.add("eeeeeee");

        // 遍历结果
        for (String va : treeSet) {
            System.out.println(va);
        }


    }
}
