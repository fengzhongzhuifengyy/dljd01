package example04_Set.HashSet;

import java.util.Comparator;
import java.util.TreeSet;

/**
 * 向集合中添加元素(abc, aaa, aaaa, cccccc, eeeeeeeee),按照字符串的长度进行排序
 *
 * @author 虞渊
 * @since 2022年12月25日 22:40
 */
public class Practice01 {
    /*
        需要排序的数据,是java中已经写好的类,这种类重写过compareTo方法,内部有自己的排序方式,
        但是并不满足我当前的排序需求
        解决方法:自定义排序--比较器排序

        1. 自然排序:
            类实现Comparable接口,重写compareTo()方法

        2. 比较器排序:
            在集合的构造方法中,传入Comparator接口的实现类对象


         注意: 一个类有一个自然排序的方式,又有了比较器排序,优先按照比较器排序进行操作
     */
    public static void main(String[] args) {

        TreeSet<String> st = new TreeSet<>(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                //1.优先按照长度进行排序
                int length = o1.length() - o2.length();
                //2. 再根据内容进行排序
                length = length == 0 ? o1.compareTo(o2) : length;
                return length;
            }
        });
        st.add("abc");
        st.add("aaa");
        st.add("aaaa");
        st.add("cccccc");
        st.add("eeeeeeeee");

        System.out.println(st); // [aaa, aaaa, abc, cccccc, eeeeeeeee] -- 自然排序明显做不到  // [aaa, abc, aaaa, cccccc, eeeeeeeee] -- 比较器排序可以

    }
}
