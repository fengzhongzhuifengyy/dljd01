package example04_Set.HashSet;

import com.itCast.study.chapter07_Collection.domain.Student;

import java.util.TreeSet;

/**
 * 键盘录入3个学生信息(姓名,语文成绩,数学成绩,英语成绩),按照总分从高到低输出到控制台
 *
 * @author 虞渊
 * @since 2022年12月25日 23:04
 */
public class Practice02 {
    public static void main(String[] args) {

        TreeSet<Student> students = new TreeSet<>();

        students.add(new Student("张三", 18.2, 49.6, 75.3));
        students.add(new Student("李四", 23.2, 68.6, 175.3));
        students.add(new Student("王二", 56.2, 90.6, 90.3));

        System.out.println(students);
    }
}
