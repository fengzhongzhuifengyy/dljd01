package example04_Set.HashSet;

import com.itCast.study.chapter07_Collection.domain.Movie;

import java.util.HashSet;

/**
 * Set: 存取无序,无索引,不可以有重复数据(去重)
 * 哈希表的详细流程
 *      创建一个默认长度16，默认加载因为0.75的数组，数组名table
 *      根据元素的哈希值跟数组的长度计算出应存入的位置
 *      判断当前位置是否为null，如果是null直接存入，如果位置不为null，表示有元素，
 *      则调用equals方法比较属性值，如果一样，则不存，如果不一样，则存入数组。
 *      当数组存满到16*0.75=12时，就自动扩容，每次扩容原先的两倍
 *
 * @author 虞渊
 * @since 2022年12月15日 22:56
 */
public class HashSetDemo01 {
    /*
        hashSet存储自定义对象
        当只重写了equals方法,并没有去重
        但同时重写了equals方法和hashCode方法,才有去重的效果

        hashSet去重的原理:
        hash表:数组 + 链表 + 红黑树
        1.当我们调用集合的添加方法时,首先会调用该对象的hashCode(),计算出一个hash值
        2.拿着这个hash值,去数组中查找,是否有相同的(已有值)
               没有相同的,直接存
               有相同的,进入第三步
         3.调用对象的equals()进行比较是否相同
                如果是相同(true)的,不存 --代表hash值相同,内容也相同
                如果不同(false),存 --链表形式

        通过举例我们也看出了,如果hashcode的返回值是固定的,就会调用很多次的equals方法,影响效率
        目标:对象的内容不相同,尽量减少equals方法的调用

     */
    public static void main(String[] args) {

        Movie m1 = new Movie("张三", 4.2, "成龙");
        Movie m2 = new Movie("李四", 5.2, "小龙");
        Movie m3 = new Movie("张三", 4.2, "成龙");
        Movie m4 = new Movie("王五", 6.2, "成小");

        HashSet<Movie> movies = new HashSet<>();
        /*
            HashSet 1.7版本原理解析: 数组 + 链表 + (结合哈希算法)
                1.创建一个默认长度为16,加载因子为0.75的数组table; 加载因子就是当数组满足16*0.75时,就会自动扩容,扩容为原数组长度的2倍
                2.根据元素的哈希值跟数组的长度求余计算出应入的索引位置(哈希算法)
                3.判断当前索引位置是否为null,如果是null直接存入
                4.如果索引位置不为null,表示有元素,则调用equals方法比较
                5.如果一样,则不存,如果不一样,则存入数组
                    JDK7新元素占用老元素位置,指向老元素
                    JDK8新元素挂在老元素下面,如果某一个索引的位置,挂载的节点达到了8个,会将链表转换为红黑树

            JDK1.8版本开始HashSet原理解析
                1.底层结构：哈希表（数组、链表、红黑树的结合体）
                2.当挂在元素下面的数据过多时，查询性能降低，从JDK8开始后，当链表长度超过8的时候，自动转换为红黑树。
         */
        movies.add(m1);
        movies.add(m2);
        movies.add(m3);
        movies.add(m4);

        for (Movie value : movies) {
            System.out.println(value);
        }
        /*
        调用equals了吗???
        调用equals了吗???
        调用equals了吗???
        调用equals了吗???
        Movie{name='张三', score=4.2, actor='成龙'}
        Movie{name='李四', score=5.2, actor='小龙'}
        Movie{name='王五', score=6.2, actor='成小'}
         */
        // 为什么equals调4次呢?--因为当前设置hashCode方法的返回值一致 == 1,添加时需要从头到尾进行比较
        // 因为是链表,equals添加到一条链表上会从上到下依次比较,导致equals方法次数较多
    }
}
