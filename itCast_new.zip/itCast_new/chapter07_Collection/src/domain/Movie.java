package domain;

import java.util.Objects;

/**
 * 功能说明:电影类
 *
 * @author 虞渊
 * @since 2022年12月11日 21:07
 */
public class Movie  implements Comparable<Movie>{

    private String name;
    private double score;
    private String actor;

    public Movie() {
    }

    public Movie(String name, double score, String actor) {
        this.name = name;
        this.score = score;
        this.actor = actor;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    @Override
    public String toString() {
        return "Movie{" +
                "name='" + name + '\'' +
                ", score=" + score +
                ", actor='" + actor + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        System.out.println("调用equals了吗???");
        if (this == o) return true;
        if (!(o instanceof Movie)) return false;
        Movie movie = (Movie) o;
        return Double.compare(movie.getScore(), getScore()) == 0 && Objects.equals(getName(), movie.getName()) && Objects.equals(getActor(), movie.getActor());
    }

    // @Override
    // public int hashCode() {
    //     return Objects.hash(getName(), getScore(), getActor());
    // }

    @Override
    public int hashCode() {
        return Objects.hash(name, score, actor);
    }


    // @Override
    // public int hashCode() {
    //     return 1;
    // }

    @Override
    /*
        compareTo() 默认就是在存入TreeSet对象的时候,
        对象与树上的对象进行比较(存在树旋转的情况)---> this.age.compareTo(o.age)
     */
    public int compareTo(Movie o) {
        //1.优先按照总分数做比较
        int result = (int)(this.getScore() - o.getScore());
        //2.年龄相同在按照名字进行比较
        return   result = result == 0? this.name.compareTo(o.name): result;
        //// 假如属性都相同,我也想添加 -- 固定写死一个值
        // result = result == 0? 1: result;
    }
}
