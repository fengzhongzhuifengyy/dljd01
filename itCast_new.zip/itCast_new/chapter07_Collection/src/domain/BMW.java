package domain;

/**
 * @author 虞渊
 * @since 2023-08-13-21:46
 */
public class BMW extends Car{

    public BMW() {
    }

    public BMW(String name) {
        super(name);
    }

    @Override
    public void run() {
        System.out.println(getName() + "run...");
    }
}
