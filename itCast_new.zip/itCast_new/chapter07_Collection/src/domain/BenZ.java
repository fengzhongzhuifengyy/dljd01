package domain;

/**
 * @author 虞渊
 * @since 2023-08-13-21:47
 */
public class BenZ extends Car{
    @Override
    public void run() {
        System.out.println(getName() + "run...");
    }

    public BenZ() {
    }

    public BenZ(String name) {
        super(name);
    }

}
