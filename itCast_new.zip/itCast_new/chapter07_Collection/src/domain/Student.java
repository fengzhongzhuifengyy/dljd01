package domain;

import java.util.Objects;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月25日 23:06
 */
public class Student implements Comparable<Student> {

    private String name;
    private double yuwen;
    private double shuxue;
    private double english;

    public Student() {
    }

    public Student(String name, double yuwen, double shuxue, double english) {
        this.name = name;
        this.yuwen = yuwen;
        this.shuxue = shuxue;
        this.english = english;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getYuwen() {
        return yuwen;
    }

    public void setYuwen(double yuwen) {
        this.yuwen = yuwen;
    }

    public double getShuxue() {
        return shuxue;
    }

    public void setShuxue(double shuxue) {
        this.shuxue = shuxue;
    }

    public double getEnglish() {
        return english;
    }

    public void setEnglish(double english) {
        this.english = english;
    }

    @Override
    public String toString() {
        return "Practice02{" +
                "name='" + name + '\'' +
                ", yuwen=" + yuwen +
                ", shuxue=" + shuxue +
                ", english=" + english +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student student = (Student) o;
        return Double.compare(student.getYuwen(), getYuwen()) == 0 && Double.compare(student.getShuxue(), getShuxue()) == 0 && Double.compare(student.getEnglish(), getEnglish()) == 0 && Objects.equals(getName(), student.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getYuwen(), getShuxue(), getEnglish());
    }

    @Override
    public int compareTo(Student s) {
        //1.根据总成绩进行降序排序
        int res = s.getResult() - this.getResult();
        //2,根据语文成绩排列
        res = res == 0 ? (int) (s.getYuwen() - this.getYuwen()) : res;
        //3.根据数学成绩排列
        res = res == 0 ? (int) (s.getShuxue() - this.getYuwen()) : res;
        //4.根据英语成绩排列
        res = res == 0 ? (int) (s.getEnglish() - this.getEnglish()) : res;

        return res;
    }

    public int getResult() {
        return (int) (getEnglish() + getYuwen() + getShuxue());
    }
}
