package domain;

/**
 * Car类
 *
 * @author 虞渊
 * @since 2023-08-13-21:44
 */
public abstract class Car {
    private String name;

    public abstract void  run();

    public Car() {
    }

    public Car(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Car{" +
                "name='" + name + '\'' +
                '}';
    }
}
