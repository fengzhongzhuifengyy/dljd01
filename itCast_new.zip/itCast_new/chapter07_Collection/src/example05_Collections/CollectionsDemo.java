package example05_Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

/**
 * Collections并不属于集合，是用来操作集合的工具类。
 *
 * @author 虞渊
 * @since 2022年12月26日 21:11
 */
public class CollectionsDemo {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        // 批量加所有的数至集合中--可用于集合的复制
        Collections.addAll(list,"a","bc", "def", "eeee", "qqqqq");
        System.out.println(list);

        // 集合自带的addAll():将集合加到新集合中
        HashSet<String> hs = new HashSet<>();
        hs.addAll(list);
        System.out.println(hs);

        // 将集合list中元素随机打乱
        Collections.shuffle(list);
        System.out.println(list);

        // 对list集合进行排序 ---只能用于List集合
        Collections.sort(list); // 默认自然排序
        System.out.println(list);

        // 根据长度进行降序排序
        Collections.sort(list, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {

                return o2.length() - o1.length() == 0? o2.compareTo(o1) : o2.length() - o1.length();
            }
        });
        System.out.println(list);
    }
}
