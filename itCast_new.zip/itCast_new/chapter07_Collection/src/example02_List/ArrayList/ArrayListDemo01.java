package example02_List.ArrayList;

import java.util.ArrayList;
import java.util.List;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月11日 22:19
 */
public class ArrayListDemo01 {
    public static void main(String[] args) {
        /*
            1、List系列集合特点
                ArrayList、LinekdList ：有序，可重复，有索引。
            2、List的实现类的底层原理
                ArrayList底层是基于数组实现的，根据查询元素快，增删相对慢。
                LinkedList底层基于双链表实现的，查询元素慢，增删首尾元素是非常快的。

            void add(int index,E element)	在此集合中的指定位置插入指定的元素
            E remove(int index)	删除指定索引处的元素，返回被删除的元素
            E set(int index,E element)	修改指定索引处的元素，返回被修改的元素
            E get(int index)	返回指定索引处的元素
         */
        List<String> list = new ArrayList<>();
        list.add("张三1");
        list.add("张三2");
        list.add("张三3");
        list.add("张三4");
        System.out.println(list);

        list.add(4, "张三5");
        System.out.println(list);

        list.remove(1);
        System.out.println(list);

        list.set(1, "张三6");
        System.out.println(list);

        String s = list.get(1);
        System.out.println(s);
    }
}
