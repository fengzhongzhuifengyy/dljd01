package example02_List.ArrayList;

import java.util.ArrayList;
import java.util.List;

/**
 * 功能说明:因为有索引所以新增了一个遍历方式
 * arraylist的底层原理
 * 第一次创建集合并添加第一个元素的时候，在底层创建一个默认长度为10的数组。
 * 容量不够就扩容1.5倍容量
 *
 * @author 虞渊
 * @since 2022年12月11日 22:27
 */
public class ArrayListDemo02 {
    public static void main(String[] args) {

        List<String> list = new ArrayList<>();
        list.add("张三1");
        list.add("张三2");
        list.add("张三3");
        list.add("张三4");

        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }
}
