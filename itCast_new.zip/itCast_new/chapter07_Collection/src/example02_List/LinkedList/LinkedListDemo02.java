package example02_List.LinkedList;

import java.util.LinkedList;

/**
 * 链表的底层原理
 *
 * @author 虞渊
 * @since 2022年12月11日 22:37
 */
public class LinkedListDemo02 {
    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("1");
        list.addFirst("2");
        list.addFirst("3");
        list.addFirst("4");

        String s = list.get(1);
        System.out.println(s); // 3

        // list.get(1): 这是根据索引获取元素,底层是双向链表,双向链表也没有索引,拿着索引查找为什么慢呢?
        /*
        根据源码可以看出:
            对索引进行判断,判断离头近一点还是离尾部近一点
            如果是离头部近一点,正序遍历
            如果是离尾部近一点,倒序遍历
            ---这也看出是双向链表

            Node<E> node(int index) {
        // assert isElementIndex(index);
        // 二分查找
        if (index < (size >> 1)) {
            Node<E> x = first;
            for (int i = 0; i < index; i++)
                x = x.next;
            return x;
        } else {
            Node<E> x = last;
            for (int i = size - 1; i > index; i--)
                x = x.prev;
            return x;
        }
    }
         */
    }
}
