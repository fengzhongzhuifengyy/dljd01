package example02_List.LinkedList;

import java.util.LinkedList;

/**
 * LinkedList独有的方法
 *
 * @author 虞渊
 * @since 2022年12月11日 22:33
 */
public class LinkedListDemo01 {
    /*
        public void addFirst(E e)	在该列表开头插入指定的元素
        public void addLast(E e)	将指定的元素追加到此列表的末尾
        public E getFirst()	返回此列表中的第一个元素
        public E getLast()	返回此列表中的最后一个元素
        public E removeFirst()	从此列表中删除并返回第一个元素
        public E removeLast()	从此列表中删除并返回最后一个元素
     */
    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("1");
        list.addFirst("2");
        list.addFirst("3");
        list.addFirst("4");
        System.out.println(list); // [4, 3, 2, 1]

        list.addLast("5");
        list.addLast("6");
        list.addLast("7");
        System.out.println(list); // [4, 3, 2, 1, 5, 6, 7]

        list.removeFirst();

        list.removeLast();
        System.out.println(list); // [3, 2, 1, 5, 6]

        System.out.println(list.getFirst()); // 3
        System.out.println(list.getLast()); // 6
    }
}
