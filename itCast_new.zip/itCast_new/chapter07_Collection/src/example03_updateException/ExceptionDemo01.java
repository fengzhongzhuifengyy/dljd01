package example03_updateException;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

/**
 * 功能说明:并发修改异常
 *
 * @author 虞渊
 * @since 2022年12月11日 22:48
 */
public class ExceptionDemo01 {
    /*
        ConcurrentModificationException:并发修改异常
        原因:迭代器在遍历集合的时候,使用集合的[添加和删除],对集合做操作,就会出现并发异常

        解决方案:
            不要使用集合的添加和删除,使用迭代器自身的添加和删除

            问题2: 迭代器没有add方法怎么办?
            方案使用List集合中, 特有的迭代器ListIterator:

        有趣现象:
            当使用迭代器遍历集合,使用集合的删除操作倒数第二个元素时,不会发生异常
            ----原因就是: 当遍历到倒数第二个时, 最后一个前进一位,那么size就会-1,这样hasNext()==false,不会再循环了,就不会有next()里面抛出异常了
            ----这个算是源码中的bug
     */
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("李四");
        list.add("张三");
        list.add("李四");
        list.add("张三");

        // remove()可以直接使用
        // Iterator<String> it = list.iterator();
        // while (it.hasNext()){
        //     String s = it.next();
        //     if (s.contains("张三")){
        //         // list.remove("张三"); // add()元素也不行
        //         it.remove(); //使用迭代器自己的remove方法
        //     }
        // }
        // System.out.println(list);

        // add()可以使用数组本身的迭代器listIterator
        ListIterator<String> lit = list.listIterator();
        while (lit.hasNext()){
            String next = lit.next();
            if (next.contains("张三")){
                lit.add("李四2"); // 使用List集合自身的迭代器
            }
        }
        System.out.println(list);// [李四, 张三, 李四2, 李四, 张三, 李四2]
    }
}
