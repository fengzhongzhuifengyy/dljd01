package example01_collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月11日 16:17
 */
public class IteratorDemo {
    public static void main(String[] args) {
        Collection<String> st = new ArrayList<>();
        st.add("aaa");
        st.add("bbb");
        st.add("ccc");
        st.add("ddd");


        Iterator<String> it = st.iterator(); // 获取迭代器对象

        while (it.hasNext()){ // 判断集合是否有值
            String s = it.next(); //// 获取值,并且将cursor(光标)+1
            System.out.println(s);
        }

        System.out.println("------------");
        // 如果测试,能否继续遍历获取? --- 不能获取,上次的指针已经走到集合的最后
        // 那么应该怎么处理呢? ---重新获取迭代器对象,进行重新迭代器遍历
        while (it.hasNext()){ // 判断集合是否有值
            String s = it.next(); //// 获取值,并且将cursor(光标)+1
            System.out.println(s);
        }

        // 查看迭代器内部源码发现 指针已经走到最后一位
        // 迭代器如果遍历完的话,需要重新创建迭代器对象进行遍历
        Iterator<String> it2 = st.iterator();
        while (it2.hasNext()){
            String s = it2.next();
            System.out.println(s);
        }
    }
}
