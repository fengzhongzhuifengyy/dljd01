package example01_collection;

import com.itCast.study.chapter07_Collection.domain.Movie;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.Consumer;

/**
 * 需求
 * 某影院系统需要在后台存储上述三部电影，然后依次展示出来。
 *      属性：电影名name  评分score  主演actor
 * 分析
 * 1：定义一个电影类，定义一个集合存储电影对象。
 * 2：创建3个电影对象，封装相关数据，把3个对象存入到集合中去。
 * 3：遍历集合中的3个对象，输出相关信息。
 * 4.打印评分超过8分的元素
 *
 * @author 虞渊
 * @since 2022年12月11日 20:440
 */
public class Practice01 {
    public static void main(String[] args) {

        Collection<Movie> movies = new ArrayList<>();

        movies.add(new Movie("电影1", 9.5, "周星驰"));
        movies.add(new Movie("电影2", 7.5, "李小龙"));
        movies.add(new Movie("电影3", 8.5, "成龙"));

        Iterator<Movie> it = movies.iterator();
        while (it.hasNext()){
            Movie movie = it.next();
            if (movie.getScore() > 8){
                System.out.println(movie);
            }
        }
        System.out.println("--------------");

        for (Movie movie : movies) {
            if (movie.getScore() > 8){
                System.out.println(movie);
            }

        }
        System.out.println("--------------");

        movies.forEach(new Consumer<Movie>() {
            @Override
            public void accept(Movie movie) {
                if (movie.getScore() > 8){
                    System.out.println(movie);
                }
            }
        });
        System.out.println("--------------");

        movies.forEach(movie -> {
                if (movie.getScore() > 8){
                    System.out.println(movie);
                }
        });
    }
}
