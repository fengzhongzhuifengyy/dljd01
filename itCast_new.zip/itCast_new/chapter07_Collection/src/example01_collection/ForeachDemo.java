package example01_collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Consumer;

/**
 * 功能说明:调用集合的foreach方法
 *
 * @author 虞渊
 * @since 2022年12月11日 20:49
 */
public class ForeachDemo {
    public static void main(String[] args) {
        Collection<String> st = new ArrayList<>();
        st.add("aaa");
        st.add("bbb");
        st.add("ccc");
        st.add("ddd");

        st.forEach(new Consumer<String>() {
            @Override
            public void accept(String s) {
                System.out.println(s);
            }
        });

        st.forEach(s->System.out.println(s));
    }
}
