package example01_collection;

import java.util.ArrayList;
import java.util.Collection;

/**
 * 功能说明:增强for,底层也是迭代器
 *
 * @author 虞渊
 * @since 2022年12月11日 18:23
 */
public class ForForDemo {
    /*
        格式:
            for(数据类型 变量名: 集合或者数组){
            }
        实现Iterable接口的类才可以使用迭代器和增强for，Collection接口已经继承了Iterable接口。
     */
    public static void main(String[] args) {
        Collection<String> st = new ArrayList<>();
        st.add("aaa");
        st.add("bbb");
        st.add("ccc");
        st.add("ddd");
        for (String s :st) {
            System.out.println(s);
        }
    }
}
