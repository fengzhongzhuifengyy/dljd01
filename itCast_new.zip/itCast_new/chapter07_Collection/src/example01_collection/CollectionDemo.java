package example01_collection;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Collection是单列集合的祖宗接口，它的功能是全部单列集合都可以继承使用的。
 *
 * @author : 虞渊
 * @date : 2023/6/15
 */
public class CollectionDemo {
    /*
        public boolean add(E e)	把给定的对象添加到当前集合中
        public void clear() 	清空集合中所有的元素
        public boolean remove(E e)	把给定的对象在当前集合中删除
        public boolean contains(Object obj)	判断当前集合中是否包含给定的对象
        public boolean isEmpty()	判断当前集合是否为空
        public int size()	返回集合中元素的个数。
     */
    public static void main(String[] args) {
        // 创建集合对象
        Collection<String> c = new ArrayList<>();
        // 添加
        c.add("abc");
        c.add("def");
        c.add("qqq");

        System.out.println(c);

        // 删除
        c.remove("zzz");

        System.out.println(c);

        // contains : 判断集合中, 是否包含传入的元素
        // 底层是调用equals判断是否相等,针对传入的对象,需要判定是否重写了equals();
        System.out.println(c.contains("abc"));
        System.out.println(c.contains("zzz"));

        System.out.println("---------------------");

        // isEmpty : 判断集合是否为空
        System.out.println(c.isEmpty()); // 如果c=null. 就会出现空指针异常
        // 清空集合元素
        c.clear();
        System.out.println(c.isEmpty());
    }
}
