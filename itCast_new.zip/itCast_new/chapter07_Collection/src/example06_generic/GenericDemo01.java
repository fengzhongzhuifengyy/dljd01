package example06_generic;

/**
 * 泛型
 *
 * @author 虞渊
 * @since 2023-08-13-16:51
 */
public class GenericDemo01 {
    /*
        泛型的好处:
            1. 统一了数据类型
            2. 将运行期的错误,提升到了编译器,避免了强转可能出现的异常
     */
    public static void main(String[] args) {
        Person<String> p1 = new Person<>();
        p1.setE("abc");

        Person<Integer> p2 = new Person<>();
        p2.setE(123);
    }
}

/*
    泛型类:定义类时同时定义了泛型的类就是泛型类。
    泛型类的格式：修饰符 class 类名<泛型变量>{  }, 例如: public class MyArrayList<T> {  }
        此处泛型变量T可以随便写为任意标识，常见的如E、T、K、V等。
        作用：编译阶段可以指定数据类型，类似于集合的作用。
    泛型类中的泛型,在创建对象的时候,确定具体的类型
 */
class Person<E> {
    private E e;

    public E getE() {
        return e;
    }

    public void setE(E e) {
        this.e = e;
    }
}

/*
    泛型方法: 定义方法时同时定义了泛型的方法就是泛型方法。
    泛型方法的格式：修饰符 <泛型变量> 方法返回值 方法名称(形参列表){}, 例如: public <T> void show(T t) {  }
    作用：方法中可以使用泛型接收一切实际类型的参数，方法更具备通用性。
    泛型类中的泛型,在方法调用的时候,确定具体的类型
 */
class Tools {
    // 给你任何一个类型的数组，都能返回它的内容。也就是实现Arrays.toString(数组)的功能
    public static <T> void printArray(T[] arr) {
        for (T t : arr) {
            System.out.println(t);
        }
    }
}

/*
    泛型接口: 使用了泛型定义的接口就是泛型接口。
    泛型接口的格式：修饰符 interface 接口名称<泛型变量>{}, 例如: public interface Data<E>{}
    作用：泛型接口可以让实现类选择当前功能需要操作的数据类型

    接口中的泛型,在
    1. 实现接口的时候确定具体的类型; class InterImpl implements Inter<Student>{}
    2. 实现接口的时候,不指定具体的类型; class InterImpl<E> implements Inter<E>{}
    将泛型传递到自己的类中---比较好
 */
interface Inter<E>{
    void add(E e);
    void delete(E e);
}
