package example06_generic;

import com.itCast.study.chapter07_Collection.domain.BMW;
import com.itCast.study.chapter07_Collection.domain.BenZ;
import com.itCast.study.chapter07_Collection.domain.Car;

import java.util.ArrayList;

/**
 * 泛型通配符:?
 *
 * @author 虞渊
 * @since 2023-08-13-21:43
 */
public class GenericDemo02 {
    /*
        ? 可以在“使用泛型”的时候代表一切类型。
        E T K V 是在定义泛型的时候使用的。
        泛型的上下限：
            ? extends Car: ?必须是Car或者其子类   泛型上限
            ? super Car ： ?必须是Car或者其父类   泛型下限

     */
    public static void main(String[] args) {
        ArrayList<BMW> list1 = new ArrayList<>();
        list1.add(new BMW("宝马1号"));
        list1.add(new BMW("宝马2号"));
        list1.add(new BMW("宝马3号"));

        ArrayList<BenZ> list2 = new ArrayList<>();
        list2.add(new BenZ("奔驰1号"));
        list2.add(new BenZ("奔驰2号"));
        list2.add(new BenZ("奔驰3号"));

        method(list1);
        method(list2);

    }

    // 但是我们发现, 虽然可以用,但是还是Object---鸡肋
    // public static void  method(ArrayList<?> list){
    //
    // }

    // 使用上下限解决 : Car和 Car的自理
    public static void method(ArrayList<? extends Car> list){
        for (Car car : list) {
            car.run();
        }
    }
}
