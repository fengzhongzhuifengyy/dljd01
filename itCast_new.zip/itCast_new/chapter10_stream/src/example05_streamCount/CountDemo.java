package example05_streamCount;

import java.util.ArrayList;

/**
 * 功能说明:终结方法-调用完成后流就无法继续使用了，原因是不会返回Stream了。
 *
 * @author 虞渊
 * @since 2022年12月28日 23:04
 */
public class CountDemo {
    public static void main(String[] args) {
        /*
          void forEach (Consumer action)	对此流的每个元素执行遍历操作
          long count ()	返回此流中的元素数
         */
        ArrayList<String> list = new ArrayList<String>();

        list.add("林青霞");
        list.add("张曼玉");
        list.add("王祖贤");
        list.add("柳岩");
        list.add("张敏");
        list.add("张无忌");

        // 统计集合中张开头的元素个数
        // count()是个终结方法,返回值是long
        long number = list.stream().filter(s -> s.startsWith("张")).count();
        System.out.println(number);
        // 注意事项: 如果一路流对象,已经进行了终结操作就不能再次操作了
    }
}
