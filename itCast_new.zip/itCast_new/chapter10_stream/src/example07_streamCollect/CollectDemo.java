package example07_streamCollect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * 功能说明: 对数据进行Stream流的方式操作完毕后,可以把流中的数据收集到集合中
 * <p>
 * Stream流的收集方法
 * R collect (Collector collector)	开始收集Stream流，指定收集器
 * Collectors工具类提供了具体的收集方式
 * public static <T> Collector toList ()	把元素收集到List集合中
 * public static <T> Collector toSet ()	把元素收集到Set集合中
 * public static  Collector toMap (Function keyMapper , Function valueMapper)	把元素收集到Map集合中
 *
 * @author 虞渊
 * @since 2022年12月28日 23:16
 */
public class CollectDemo {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();

        list.add("林青霞");
        list.add("张曼玉");
        list.add("王祖贤");
        list.add("柳岩");
        list.add("张敏");
        list.add("张无忌");

        // 转成List
        List<String> list1 = list.stream().filter(s -> !s.startsWith("张")).collect(Collectors.toList());
        System.out.println("list1 = " + list1);

        // 转成Set
        Set<String> set = list.stream().filter(s -> s.startsWith("张")).collect(Collectors.toSet());
        System.out.println("set = " + set);

        // 转成Map
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("张三,23");
        arrayList.add("李四,24");
        arrayList.add("王五,25");
        // 保留年龄大于等于24的人,并将结果收集到map集合中,姓名为键年龄为值
        Map<String, Integer> collectMap = arrayList.stream().filter(s -> Integer.parseInt(s.split(",")[1]) >= 24)
                .collect(Collectors.toMap(s -> s.split(",")[0],
                        s -> Integer.parseInt(s.split(",")[1])));
        System.out.println("collectMap = " + collectMap);

        // 保留年龄大于24的人,并将结果收集到map集合中,姓名为键年龄为值 --- 使用匿名内部类实现, 方便理解上面的
        Map<String, Integer> map = arrayList.stream().filter(new Predicate<String>() {
            @Override
            public boolean test(String s) {
                return Integer.parseInt(s.split(",")[1]) > 24;
            }
        }).collect(Collectors.toMap(new Function<String, String>() { // 这里的形参参数含义: 入参是String, 返回值就是String
            @Override
            public String apply(String s) {
                return s.split(",")[0];
            }
        }, new Function<String, Integer>() { // 这里的形参参数含义: 入参是String, 返回值就是Integer
            @Override
            public Integer apply(String s) {
                return Integer.parseInt(s.split(",")[1]);
            }
        }));
        System.out.println("map = " + map);

        // Stream流转换arr数组, 使用 Stream.toArray()的静态方法实现 打印偶数
        int[] arr = new int[]{1, 2, 3, 4, 5, 6, 7, 8};
        int[] streamArr = Arrays.stream(arr).filter(s -> s % 2 == 0).toArray();
        System.out.println("streamArr = " + Arrays.toString(streamArr));
    }
}
