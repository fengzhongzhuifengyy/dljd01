package example02_streamFilter;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * 功能说明:中间操作方法-filter
 * Stream<T> filter(Predicate<? super T> predicate) : 用于对流中的数据进行过滤。
 *
 * @author 虞渊
 * @since 2022年12月28日 21:34
 */
public class FilterDemo {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("张三丰");
        list.add("张无忌");
        list.add("张翠山");
        list.add("王二麻子");
        list.add("张良");
        list.add("谢广坤");
        // 将数据都放入s1这条流水线中
        Stream<String> s1 = list.stream();
        // 将每一个数据都调用test方法
        Stream<String> s2 = s1.filter(new Predicate<String>() {
            @Override
            public boolean test(String s) { // s指流水线中的每一个数据
                return s.startsWith("张");
            }
        });
        // 遍历s2流
        s2.forEach(new Consumer<String>() {
            @Override
            public void accept(String s) {
                System.out.println(s);
            }
        });

        //使用lambda进行简化
        list.stream().filter(s -> s.startsWith("张")).forEach(s -> System.out.println(s));
    }
}
