package example04_streamConcat;

import java.util.ArrayList;
import java.util.stream.Stream;

/**功能说明:中间操作方法:distinct/ concat
 * Stream<T> distinct()	去除流中重复的元素。依赖(hashCode和equals方法)
 * static <T> Stream<T> concat(Stream a, Stream b)	合并a和b两个流为一个流
 *
 * @author 虞渊
 * @since 2022年12月28日 22:55
 */
public class ConcatDemo {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();

        list.add("林青霞");
        list.add("张曼玉");
        list.add("王祖贤");
        list.add("柳岩");
        list.add("张敏");
        list.add("张无忌");

        // 需求1：取前4个数据组成一个流
        Stream<String> s1 = list.stream().limit(4);
        // 需求2：跳过2个数据组成一个流
        Stream<String> s2 = list.stream().skip(2);
        // 需求3：合并需求1和需求2得到的流，并把结果在控制台输出
        // Stream.concat(s1, s2).forEach(s -> System.out.println(s)); // 注意事项: 如果一路流对象,已经进行了终结操作就不能再次操作了
        System.out.println("===================");
        // 需求4：合并需求1和需求2得到的流，并把结果在控制台输出，要求字符串元素不能重复
        Stream.concat(s1, s2).distinct().forEach(s -> System.out.println(s));
        // 注意distinct是依赖于重写equals判断是否重复
    }
}
