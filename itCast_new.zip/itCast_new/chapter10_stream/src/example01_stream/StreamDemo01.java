package example01_stream;

import java.util.ArrayList;
import java.util.List;

/**
 * Stream流:
 * 用于简化集合和数组操作的API。
 * 1.先得到集合或者数组的Stream流（就是一根传送带）。
 * 2.把元素放上去。
 * 3.然后就用这个Stream流简化的API来方便的操作元素。
 *
 * 需求：按照下面的要求完成集合的创建和遍历
 * 创建一个集合，存储多个字符串元素
 * 把集合中所有以 "张" 开头的元素存储到一个新的集合
 * 把 "张" 开头的集合中的长度为 3 的元素存储到一个新的集合
 * 遍历上一步得到的集合
 *
 * @author 虞渊
 * @since 2022年12月27日 22:31
 */
public class StreamDemo01 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("张三丰");
        list.add("张无忌");
        list.add("张翠山");
        list.add("王二麻子");
        list.add("张良");
        list.add("谢广坤");

        // 把集合中所有以 "张" 开头的元素存储到一个新的集合
        ArrayList<String> list1 = new ArrayList<>();

        for (String s : list) {
            if (s.startsWith("张")) {
                list1.add(s);
            }
        }
        System.out.println(list1);

        // 把 "张" 开头的集合中的长度为 3 的元素存储到一个新的集合
        ArrayList<String> list2 = new ArrayList<>();
        for (String s : list1) {
            if (s.length() == 3) {
                list2.add(s);
            }
        }
        System.out.println(list2);


        // 使用Stream流来解决
       list.stream().filter(s -> s.startsWith("张"))
                    .filter(s -> s.length() ==3)
               .forEach(s -> System.out.println(s));
    }

}
