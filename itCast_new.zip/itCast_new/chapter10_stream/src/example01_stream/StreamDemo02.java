package example01_stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * 功能说明:获取Stream流的几种方式
 *
 * @author 虞渊
 * @since 2022年12月28日 20:27
 */
public class StreamDemo02 {
    /*
        获取Stream流:
            Collection集合:
                List:/Set使用默认的stream()生成流, default Stream<E> stream()

            Map集合:把Map转成Set集合,间接的生成流
                HashMap<String, Integer> hm = new HashMap<String, String>();
                Stream<String> keyStream = hm.ketSet().stream;
                Stream<Integer> valueStream = hm.values().stream;
                Stream<Map.Entry<String, Integer>> entryStream = hm.entrySet().stream;

            数组获取stream:
            数组没有stream(),必须使用数组的工具类Arrays.stream(数组名)

            有同种数据类型的多个数据
            Stream里面的of方法: 获取一堆数据的stream流
     */
    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        list.add("张三丰");
        list.add("张无忌");
        list.add("张翠山");
        list.add("王二麻子");
        list.add("张良");
        list.add("谢广坤");
        // list集合获取流对象
        Stream<String> listStream = list.stream();

        Set<String> set = new HashSet<>();
        set.add("张三丰");
        set.add("张无忌");
        set.add("张翠山");
        set.add("王二麻子");
        set.add("张良");
        set.add("谢广坤");
        // Set集合获取流对象
        Stream<String> setStream = set.stream();

        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("张三丰",100);
        map.put("张无忌",35);
        map.put("张翠山",55);
        map.put("王二麻子",22);
        map.put("张良",30);
        map.put("谢广坤",55);
        // Map集合获取流对象
        Stream<String> keyStream = map.keySet().stream();
        Stream<Integer> valuesStream = map.values().stream();
        Stream<Map.Entry<String, Integer>> entryStream = map.entrySet().stream();

        // 数组获取流对象
        String[] s = {"张三", "李四", "王五"};
        Stream<String> arrStream = Arrays.stream(s); // 数组没有stream(),必须使用数组的工具类Arrays

        // Stream类中有静态方法of(),存入同种数据类型的多个数据
        Stream<String> stringStream = Stream.of("张三", "李四", "王五");
        Stream<Integer> integerStream = Stream.of(10, 20, 30);
    }
}
