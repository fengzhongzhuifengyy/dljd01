package example06_streamAttention;

import java.util.ArrayList;

/**
 * 功能说明:Stream流无法直接操作数据源数据
 *
 * @author 虞渊
 * @since 2022年12月28日 23:11
 */
public class StreamAttentionDemo {
    /*
        Stream流的操作,无法对集合,数组,其他数据源直接修改
     */
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();

        list.add("林青霞");
        list.add("张曼玉");
        list.add("王祖贤");
        list.add("柳岩");
        list.add("张敏");
        list.add("张无忌");

        list.stream().filter(s -> s.startsWith("张")).forEach(s -> System.out.println(s));
        // 不改变源数据详情
        System.out.println(list); // [林青霞, 张曼玉, 王祖贤, 柳岩, 张敏, 张无忌]
    }
}
