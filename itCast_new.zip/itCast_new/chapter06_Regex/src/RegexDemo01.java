import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 正则表达式:正则表达式本质还是一个字符串,用这些规定的字符来制定规则，并用来校验数据(其他字符串)格式的合法性。
 *
 * @author 虞渊
 * @since 2022年12月04日 22:48
 */
public class RegexDemo01 {
    /*
        字符类(默认匹配一个字符)
            [abc]	       只能是a, b, 或c
            [^abc]	       除了a, b, c之外的任何字符
            [a-zA-Z]       a到z A到Z，包括（范围）
            [a-d[m-p]]	   a到d，或m通过p：（[a-dm-p]联合）
            [a-z&&[def]]   d, e, 或f(交集)
            [a-z&&[^bc]]   a到z，除了b和c：（[ad-z]减法）
            [a-z&&[^m-p]]  a到z，除了m到p：（[a-lq-z]减法）

        预定义的字符类(默认匹配一个字符)
            .	任何字符
            \d	一个数字： [0-9]
            \D	非数字： [^0-9]
            \s	一个空白字符： [ \t\n\x0B\f\r]
            \S	非空白字符： [^\s]
            \w	[a-zA-Z_0-9] 英文、数字、下划线
            \W	[^\w] 一个非单词字符

        贪婪的量词（配合匹配多个字符）
            X?	X , 一次或根本不
            X*	X，零次或多次, 一次不行
            X+	X , 一次或多次
            X {n}	X，正好n次
            X {n, }	X，至少n次
            X {n,m}	X，至少n但不超过m次
     */
    public static void main(String[] args) {
        // QQ号规则 :
        // 不能以0开头
        // 5~12位
        // 全部都是数字
        String regex = "[1-9]\\d{4,11}";
        System.out.println("1234567".matches(regex));

        // 手机号规则 :
        // 必须是1开头
        // 第二位 :  3 4 5 6 7 8 9
        // 全都是数字,  必须是11位
        String regex1 = "[1][3-9]\\d{9}";
        System.out.println("13876786556".matches(regex1));

        // 邮箱规则:
        // zhangsan@itcast.cn
        // zhangsan@163.com
        // 123456@qq.com
        // zhangsan@sina.com
        // zhangsan@wanleyun.qq.com
        // zhangsan@xxx.edu
        // zhangsan@xxx.org
        String regex2 = "\\w+@[\\w&&[^_]]{2,8}(\\.[a-z]{2,3})+"; // 小括号是正则组的概念,表示(.xx)出现1到多次
        System.out.println("zhangsan@wanleyun.qq.com".matches(regex2));


        String rs = "来黑马程序学习Java,电话020-43422424,或者联系邮箱" + "itcast@itcast.cn,电话18762832633,0203232323" + "邮箱bozai@itcast.cn,400-100-3233,4001003232";

        /*
            字符串中使用正则的方法:
             public boolean matches (String regex): 判断是否匹配正则表达式，匹配返回true，不匹配返回false。
             public String replaceAll(String regex,String newStr):按照正则表达式匹配的内容进行替换
         */

        /*
            正则表达式支持爬取信息
            String rs = "来黑马程序学习Java,电话020-43422424，或者联系邮箱"
            + "itcast@itcast.cn,电话18762832633，0203232323"
            + "邮箱bozai@itcast.cn，400-100-3233 ，4001003232";
            // 需求：从上面的内容中爬取出 电话号码和邮箱。
            // 1.定义爬取规则
            String regex = "(\\w{1,}@\\w{2,10}(\\.\\w{2,10}){1,2})|"
            +"(1[3-9]\\d{9})|(0\\d{2,5}-?\\d{5,15})|400-?\\d{3,8}-?\\d{3,8}";
            // 2.编译正则表达式成为一个匹配规则对象
            Pattern pattern = Pattern.compile(regex);
            // 3.通过匹配规则对象得到一个匹配数据内容的匹配器对象
            Matcher matcher = pattern.matcher(rs);
            // 4.通过匹配器去内容中爬取出信息
            while(matcher.find()){
            System.out.println(matcher.group());}
         */
        // 1.根据正则表达式,获取预编译对象(正则对象)
        Pattern pattern = Pattern.compile(regex2);
        // 2.匹配器对象
        Matcher matcher = pattern.matcher(rs);
        while (matcher.find()) {
            System.out.println(matcher.group()); // itcast@itcast.cn bozai@itcast.cn
        }

    }
}
