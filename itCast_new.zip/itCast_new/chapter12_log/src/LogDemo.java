import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2023年01月07日 21:09
 */
public class LogDemo {
    public static void main(String[] args) {
        // 形参指的是：logger对象的名称
        Logger logger = LoggerFactory.getLogger("test");
        logger.debug("测试一下debug日志");
        logger.info("测试一下info日志");
        logger.error("测试一下error日志");
    }
}
