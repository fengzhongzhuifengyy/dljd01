import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2024-01-10-0:16
 */
public class JdbcDemo5 {
    /*
        ResultSet(结果集对象)作用：封装了DQL查询语句的结果，获取查询结果
        ResultSet    ps.executeQuery()：执行DQL 语句，返回 ResultSet 对象

        获取查询结果
        boolean   next()：(1) 将光标从当前位置向前移动一行 （2）判断当前行是否为有效行
        返回值：
        true：有效行，当前行有数据
        false：无效行，当前行没有数据

        xxx    getXxx(参数)：获取数据
        xxx：数据类型；如：int getInt(参数) ; String getString(参数)
        参数：
        int：列的编号，从1开始
        String：列的名称

        //循环判断游标是否是最后一行末尾
        while(resultSet.next()){
            //获取数据
            resultSet.getXxx(参数);
        }
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // 1.注册驱动,告诉程序是什么数据库
        Class.forName("com.mysql.jdbc.Driver");
        // 2.获取链接
        String url = "jdbc:mysql://192.168.171.130:3306/test_project";
        String username = "root";
        String password = "123456";
        Connection connection = DriverManager.getConnection(url, username, password);
        //3.获取执行sql的对象
        PreparedStatement preparedStatement = connection.prepareStatement("select * from  test_project.t_hm_dept");
        //4.执行操作,获取结果
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            String str = resultSet.getString(1); // 获取第一列的值，不建议
            String str1 = resultSet.getString("id"); // 获取列名为id的列
            System.out.println(str);
            System.out.println(str1);
        }
        //6.释放资源
        resultSet.close();
        preparedStatement.close();
        connection.close();
    }
}
