package test;

import dao.BrandDao;
import org.junit.Test;
import pojo.Brand;

import java.util.List;

public class BrandTest {

    @Test
    public void testSelectAll() throws Exception {
        // 1 创建BrandDao对象
        BrandDao brandDao = new BrandDao();
        // 2 调用方法，获取结果
        List<Brand> brands = brandDao.selectAll();
        // 3 打印结果
        System.out.println(brands);
    }

    @Test
    public void testAdd() throws Exception {
        // 1 创建BrandDao对象
        BrandDao brandDao = new BrandDao();
        // 2 调用方法，获取结果
        boolean flag = brandDao.add(new Brand(4, "荣耀", "荣耀控股", 3, "荣耀加油", 1));
        // 3 打印结果
        System.out.println(flag?"添加成功":"添加失败");
    }

    @Test
    public void testUpdate() throws Exception {
        // 1 创建BrandDao对象
        BrandDao brandDao = new BrandDao();
        // 2 调用方法，获取结果
        boolean flag = brandDao.update(new Brand(4, "荣耀手机", "荣耀", 5, "荣耀牛逼", 0));
        // 3 打印结果
        System.out.println(flag?"修改成功":"修改失败");
    }

    @Test
    public void testDelete() throws Exception {
        // 1 创建BrandDao对象
        BrandDao brandDao = new BrandDao();
        // 2 调用方法，获取结果
        boolean flag = brandDao.delete(4);
        // 3 打印结果
        System.out.println(flag?"删除成功":"删除失败");
    }
}
