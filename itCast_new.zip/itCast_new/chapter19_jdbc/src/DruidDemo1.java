import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.alibaba.druid.pool.DruidPooledConnection;

import java.io.InputStream;
import java.util.Properties;

/**
 * 功能说明:Druid连接池介绍
 *
 * @author 虞渊
 * @since 2024-01-18-23:15
 */
public class DruidDemo1 {
    public static void main(String[] args) throws Exception {
        // 1.导入jar包
        // 2.定义配置文件
        // 3.加载配置文件
        Properties properties = new Properties();
        InputStream inputStream = DruidDemo1.class.getClassLoader().getResourceAsStream("druid.properties");
        properties.load(inputStream);
        // 获取连接池对象
        DruidDataSource dataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(properties);
        // 获取数据库连接
        DruidPooledConnection connection = dataSource.getConnection();
        String sql = "";
        connection.prepareStatement(sql);
        // ...
    }
}
