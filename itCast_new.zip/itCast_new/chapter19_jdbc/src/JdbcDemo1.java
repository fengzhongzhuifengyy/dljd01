import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * 功能说明: 演示JDBC入门
 *
 * @author 虞渊
 * @since 2023-12-27-21:53
 */
public class JdbcDemo1 {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // 1.注册驱动,告诉程序是什么数据库
        Class.forName("com.mysql.jdbc.Driver");
        // 2.获取链接
        String url = "jdbc:mysql://192.168.171.130:3306/test_project";
        String username = "root";
        String password = "123456";
        Connection connection = DriverManager.getConnection(url, username, password);
        //3.获取执行sql的对象
        PreparedStatement preparedStatement = connection.prepareStatement("update test_project.t_hm_dept set addr= '台湾' where id=1");
        //4.执行操作,获取结果
        int line = preparedStatement.executeUpdate();
        //5.打印结果
        System.out.println("影响了" + line +"行数据");
        //6.释放资源
        preparedStatement.close();
        connection.close();
    }
}
