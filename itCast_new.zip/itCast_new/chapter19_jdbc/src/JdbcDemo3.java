import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * 功能说明: JDBC API Connection
 *
 * @author 虞渊
 * @since 2024-01-09-23:54
 */
public class JdbcDemo3 {
    /*
     Connection：
        1. 获取执行sql的对象：
            预编译SQL功能的执行SQL对象：解决了Statement对象执行SQL的漏洞
            PreparedStatement prepareStatement (sql)
            执行存储过程的对象：
            CallableStatement   prepareCall (sql)
        2. 事务管理：
            JDBC 事务管理：Connection接口中定义了3个对应的方法
            开启事务：setAutoCommit(boolean autoCommit)：true为自动提交事务；false为手动提交事务，即为开启事务
            提交事务：commit()
            回滚事务：rollback()
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");

        String url = "jdbc:mysql://192.168.171.130:3306";
        String user = "root";
        String passwd = "123456";

        Connection connection = DriverManager.getConnection(url, user, passwd);

        try {
            // 开启事务
            connection.setAutoCommit(false);
            PreparedStatement statement = connection.prepareStatement("update account set money=money+500 where name = '张三'");
            statement.executeUpdate();
            // 提交事务
            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
            // 回滚事务
            connection.rollback();
        }
    }
}
