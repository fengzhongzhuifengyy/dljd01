package dao;


import pojo.Brand;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * 操作数据库，执行CRUD
 */
public class BrandDao {

    /**
     * 查询所有品牌信息并封装
     *
     * @return
     */
    public List<Brand> selectAll() throws Exception {
        // 1 注册驱动，获取连接对象 Connection
        Class.forName("com.mysql.jdbc.Driver");
        // 连接路径，表示连接哪个数据库
        String url = "jdbc:mysql://192.168.171.130:3306/brand_demo?useSSL=false";
        String user = "root";
        String password = "123456";
        Connection connection = DriverManager.getConnection(url, user, password);

        // 2 定义SQL：select *  from tb_brand;
        // 3 获取 PreparedStatement对象，传递SQL并且预编译SQL
        PreparedStatement statement = connection.prepareStatement("SELECT * from brand_demo.tb_brand");
        // 4 设置参数：不需要
        // 5 执行SQL，不需要传递SQL
        ResultSet resultSet = statement.executeQuery();
        // 6 处理结果：封装成List<Brand>
        ArrayList<Brand> brands = new ArrayList<>();
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String brand_name = resultSet.getString("brand_name");
            String company_name = resultSet.getString("company_name");
            int ordered = resultSet.getInt("ordered");
            String description = resultSet.getString("description");
            int status = resultSet.getInt("status");
            Brand brand = new Brand(id, brand_name, company_name, ordered, description, status);
            brands.add(brand);
        }
        // 7 释放资源,返回结果
        statement.close();
        connection.close();
        return brands;
    }

    /**
     * 添加品牌信息
     *
     * @param brand
     * @return
     * @throws Exception
     */
    public boolean add(Brand brand) throws Exception {
        // 1 注册驱动，获取连接对象 Connection
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://192.168.171.130:3306/brand_demo?useSSL=false";   // 连接路径，表示连接哪个数据库
        String username = "root";
        String password = "123456";
        Connection conn = DriverManager.getConnection(url, username, password);

        // 2 定义SQL
        String sql = "insert into brand_demo.tb_brand(brand_name, company_name, ordered, description, status) VALUES (?,?,?,?,?)";
        // 3 获取 PreparedStatement对象，传递SQL并且预编译SQL
        PreparedStatement pstmt = conn.prepareStatement(sql);
        // 4 设置参数：
        pstmt.setString(1, brand.getBrand_name());
        pstmt.setString(2, brand.getCompany_name());
        pstmt.setInt(3, brand.getOrdered());
        pstmt.setString(4, brand.getDescription());
        pstmt.setInt(5, brand.getStatus());
        // 5 执行SQL，不需要传递SQL
        int count = pstmt.executeUpdate();
        // 6 释放资源,返回结果
        pstmt.close();
        conn.close();
        return count > 0;
    }

    /**
     * 根据id修改品牌信息
     *
     * @param brand
     * @return
     * @throws Exception
     */
    public boolean update(Brand brand) throws Exception {
        // 1 注册驱动，获取连接对象 Connection
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://192.168.171.130:3306/brand_demo?useSSL=false";   // 连接路径，表示连接哪个数据库
        String username = "root";
        String password = "123456";
        Connection conn = DriverManager.getConnection(url, username, password);

        // 2 定义SQL
        String sql = "update brand_demo.tb_brand set brand_name= ? where id = ?";
        // 3 获取 PreparedStatement对象，传递SQL并且预编译SQL
        PreparedStatement pstmt = conn.prepareStatement(sql);
        // 4 设置参数：
        pstmt.setString(1, brand.getBrand_name());
        pstmt.setInt(2, brand.getId());
        // 5 执行SQL，不需要传递SQL
        int count = pstmt.executeUpdate();
        // 6 释放资源,返回结果
        pstmt.close();
        conn.close();
        return count > 0;
    }

    /**
     * 根据id删除品牌信息
     *
     * @param id
     * @return
     * @throws Exception
     */
    public boolean delete(int id) throws Exception {
        // 1 注册驱动，获取连接对象 Connection
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://192.168.171.130:3306/brand_demo?useSSL=false";   // 连接路径，表示连接哪个数据库
        String username = "root";
        String password = "123456";
        Connection conn = DriverManager.getConnection(url, username, password);

        // 2 定义SQL
        String sql = "delete from brand_demo.tb_brand where id = ?";
        // 3 获取 PreparedStatement对象，传递SQL并且预编译SQL
        PreparedStatement pstmt = conn.prepareStatement(sql);
        // 4 设置参数：
        pstmt.setInt(1, id);
        // 5 执行SQL，不需要传递SQL
        int count = pstmt.executeUpdate();

        // 6 释放资源,返回结果
        pstmt.close();
        conn.close();
        // 6 处理结果
        return count > 0;
    }
}
