import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2024-01-10-0:06
 */
public class JdbcDemo4 {
    /*
        PreparedStatement(执行者对象)作用：
        动态设置参数：
            1.1、获取 PreparedStatement 对象
            // SQL语句中的参数值，使用？占位符替代
            String sql = "update account set money=? where id = ?";
            // 通过Connection对象获取，并传入对应的sql语句
            PreparedStatement ps= conn.prepareStatement(sql);

            1.2、设置参数值
            PreparedStatement对象：setXxx(参数1，参数2)：给 ? 赋值
            Xxx：数据类型 ； 如 setInt (参数1，参数2)
            参数：
            参数1： 第几个?，从1 开始。参数2： ?的值。
            例如： ps.setDouble(1,3000.0); ps.setInt(2,1)

            1.3、执行增删改查操作
            int executeUpdate()：执行DML、DDL语句，不需要再传递sql
            返回值：(1) DML语句影响的行数 (2) DDL语句执行后，执行成功也可能返回 0
            ResultSet    executeQuery()：执行DQL 语句，不需要再传递sql
            返回值： ResultSet 结果集对象
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // 1.注册驱动,告诉程序是什么数据库
        Class.forName("com.mysql.jdbc.Driver");
        // 2.获取链接
        String url = "jdbc:mysql://192.168.171.130:3306/test_project";
        String username = "root";
        String password = "123456";
        Connection connection = DriverManager.getConnection(url, username, password);
        //3.获取执行sql的对象
        PreparedStatement preparedStatement = connection.prepareStatement("update test_project.t_hm_dept set addr= '台湾' where id=?");
        // 设置动态参数
        preparedStatement.setInt(1,1);
        //4.执行操作,获取结果
        int line = preparedStatement.executeUpdate();
        //5.打印结果
        System.out.println("影响了" + line +"行数据");
        //6.释放资源
        preparedStatement.close();
        connection.close();
    }
}
