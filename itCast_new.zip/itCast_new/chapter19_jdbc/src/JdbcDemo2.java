import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * 功能说明: JDBC APi-DriverManager
 *
 * @author 虞渊
 * @since 2023-12-28-0:05
 */
public class JdbcDemo2 {
    /*
        DriverManager:
        作用1. 注册驱动
         Class.forName("com.mysql.jdbc.Driver");
         查看Driver类.发现有静态代码块:
         static {
         try {
            DriverManager.registerDriver(new Driver());
         } catch (SQLException var1) {
            throw new RuntimeException("Can't register driver!");
            }
         }
         DriverManager.registerDriver(new Driver()); -- 导致驱动注册两次
         那为什么不直接使用呢? 因为会导致注册两次(本身1次 + new Driver() 1次)

         作用2. 获取连接
         getConnection(url, user, passwd)
         1.  url：连接路径
            语法：jdbc:mysql://ip地址(域名):端口号/数据库名称?参数键值对1&参数键值对2…
            示例：jdbc:mysql://127.0.0.1:3306/db1   或者 jdbc:mysql://localhost:3306/db1
            细节：
            如果连接的是本机mysql服务器，并且mysql服务默认端口是3306，则url可以简写为：jdbc:mysql:///数据库名称?参数键值对
            配置 useSSL=false 参数，禁用安全连接方式，解决警告提示
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // 注册驱动， 告诉程序用的是MySQL数据库
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://192.168.171.130:3306";
        String user = "root";
        String passwd = "123456";
        // 获取连接
        Connection connection = DriverManager.getConnection(url, user, passwd);
        // 获取执行sql的执行者对象
        PreparedStatement statement = connection.prepareStatement("update test_project.t_hm_emp set salary=100 where id=1");
        // 执行操作，获取结果
        statement.executeUpdate();
        // 释放资源
        statement.close();
        connection.close();
    }
}
