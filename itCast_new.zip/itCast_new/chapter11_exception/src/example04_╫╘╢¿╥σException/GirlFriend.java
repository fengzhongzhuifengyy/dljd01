package example04_自定义Exception;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月31日 22:19
 */
public class GirlFriend {

    public GirlFriend(){
        throw new GirlFriendNotFoundException();
    }

}
