package example04_自定义Exception;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月31日 22:22
 */
public class GirlFriendTest {

    public static void main(String[] args) {

        GirlFriend girlFriend = new GirlFriend();
        /*
        Exception in thread "main" com.itCast.study.chapter11_exception.example04_自定义Exception.GirlFriendNotFoundException
	    at com.itCast.study.chapter11_exception.example04_自定义Exception.GirlFriend.<init>(GirlFriend.java:12)
	    at com.itCast.study.chapter11_exception.example04_自定义Exception.GirlFriendTest.main(GirlFriendTest.java:13)
         */
    }
}
