package example02_tryCatch;

/**
 * 功能说明: 捕获异常
 *
 * @author 虞渊
 * @since 2022年12月30日 21:17
 */
public class TryCatchDemo {
    /*
        异常的处理方式1:
        try ... catch
        好处: 可以将异常捕获,不影响后面代码的执行

        格式:
        try {
            可能会出现问题的代码
        }catch (要捕获的异常){
            异常的处理方式
        }

        执行步骤:
        1.执行try{}里面包裹的代码
            A:如果代码没有异常,不会执行catch的代码
            B:有问题产生
        2.catch捕获这个异常,执行catch当中的代码,执行完毕后,程序继续执行下去
     */
    public static void main(String[] args) {
        System.out.println("开始");
        try {
            int[] arr = new int[3];
            System.out.println(arr[10]); // throw new ArrayIndexOutOfBoundsException()

        } catch (ArrayIndexOutOfBoundsException e) { // ArrayIndexOutOfBoundsException e = new ArrayIndexOutOfBoundsException(); 捕获异常
            System.out.println("哈哈,问题被我抓到了,你看不到错误了");
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        System.out.println("结束");
    }
}
