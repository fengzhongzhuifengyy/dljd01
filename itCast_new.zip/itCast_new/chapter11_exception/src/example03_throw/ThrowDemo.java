package example03_throw;

import com.itCast.study.chapter11_exception.domain.Student;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2022年12月31日 19:16
 */
public class ThrowDemo {
    public static void main(String[] args) throws Exception {

        Student stu = new Student();
        stu.setAge(-10);
        System.out.println(stu.getAge());

        // 明显有问题,这个时候我希望的是终止程序,并给出相应的提示
        // 1.throw new Exception(""); 构造异常对象抛出
            // 针对这一步,如果抛出运行时异常 throw new RuntimeException(""),此时就不需要方法添加throws进行声明
        // 2.方法必须声明此方法有异常场景,添加throws进行异常声明
        // 3.调用此存在异常场景的方法,就必须经过处理(try catch/ throws)

        // throw 和 throws有什么区别呢?
        // 1.throw是用来抛出异常,真正干活的
        // 2.throws是用来声明方法里面存在异常场景

        // 子类继承重写父类方法?
        // 子类不能抛出父类不存在的异常: 一句话:父亲坏了,儿子不能比父亲更坏
        // 如果父类的方法没有抛出异常,子类重写父类的方法,有异常产生只能try catch,不能throw
    }
}
