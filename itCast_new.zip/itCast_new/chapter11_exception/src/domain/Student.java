package domain;

import java.io.Serializable;

/**
 * 功能说明: Student实体类
 *
 * @author 虞渊
 * @since 2022年12月31日 19:52
 */
public class Student implements Serializable {

    private String name;
    private int age;

    public Student() {
    }

    public Student(String name, int age) {
        this.name = name;
        if (age > 0 && age < 120){
            this.age = age;
        }else {
            // 抛出 异常对象 ---如果抛出运行时异常 throw new RuntimeException(""),此时就不需要方法添加throws进行声明
            throw new RuntimeException("您的年龄输入的不合法,请检查是否0-120之间!");
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    // 方法添加throws关键字
    public void setAge(int age) throws Exception{
        if (age > 0 && age < 120){
            this.age = age;
        }else {
            // 抛出 异常对象
            throw new Exception("您的年龄输入的不合法,请检查是否0-120之间!");
        }

    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
