package homework;

/**
 * 编写一个学生类,  每一个学生( Student ) 都有学号,姓名和分数,分数永远不能为为负数
 * 创建3个学生对象, 并打印学生信息
 * 如果试图给学生赋值一个负数,抛出一个自定异常  ( NoScoreException )
 * ps : 年龄不用加自定义异常
 *
 * @author 虞渊
 * @since 2023年01月01日 16:18
 */
public class Homework03 {
    public static void main(String[] args) {

        Student s1 = null;
        Student s2 = null;
        Student s3 = null;
        try {
            s1 = new Student("001", "张三", 92.0);
            s2 = new Student("002", "李四", -92.0);
            s3 = new Student("003", "王二", 93.0);
        } catch (NoScoreException e) {
            System.out.println(e.getMessage());
        }

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
    }
}

class Student {

    private String stuNumber;
    private String stuName;
    private double stuScore;

    public Student() {
    }

    public Student(String stuNumber, String stuName, double stuScore) {
        this.stuNumber = stuNumber;
        this.stuName = stuName;
        setStuScore(stuScore);
    }

    public String getStuNumber() {
        return stuNumber;
    }

    public void setStuNumber(String stuNumber) {
        this.stuNumber = stuNumber;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public double getStuScore() {
        return stuScore;
    }

    public void setStuScore(double stuScore) {
        if (stuScore > 0){
            this.stuScore = stuScore;
        }else {
            throw new NoScoreException("分数不能为负数");
        }
    }

    @Override
    public String toString() {
        return "Student{" +
                "stuNumber='" + stuNumber + '\'' +
                ", stuName='" + stuName + '\'' +
                ", stuScore=" + stuScore +
                '}';
    }
}