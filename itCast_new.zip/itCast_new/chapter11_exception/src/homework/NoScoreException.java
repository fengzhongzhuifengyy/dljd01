package homework;

/**
 * 功能说明
 *
 * @author 虞渊
 * @since 2023年01月01日 16:29
 */
public class NoScoreException extends RuntimeException {
    public NoScoreException(String message) {
        super(message);
    }
}
