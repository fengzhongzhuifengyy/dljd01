package homework;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * 现在有两个`ArrayList`集合存储队伍当中的多个成员姓名，要求使用Stream流依次进行以下若干操作步骤：
 * 1. 第一个队伍只要名字为3个字的成员姓名；
 * 2. 第一个队伍筛选之后只要前3个人；
 * 3. 第二个队伍只要姓张的成员姓名；
 * 4. 第二个队伍筛选之后不要前2个人；
 * 5. 将两个队伍合并为一个队伍；
 * 6. 根据姓名创建`Person`对象；
 * 7. 打印整个队伍的Person对象信息。
 *
 * @author 虞渊
 * @since 2023年01月01日 14:51
 */
public class HomeWork01 {
    public static void main(String[] args) {

        List<String> one = new ArrayList<>();
        one.add("陈玄风");
        one.add("梅超风");
        one.add("陆乘风");
        one.add("曲灵风");
        one.add("武眠风");
        one.add("冯默风");
        one.add("罗玉风");
        List<String> two = new ArrayList<>();
        two.add("宋远桥");
        two.add("张三丰");
        two.add("俞岱岩");
        two.add("张松溪");
        two.add("张翠山");
        two.add("殷梨亭");
        two.add("莫声谷");

        // 第一个队伍只要名字为3个字的成员姓名;第一个队伍筛选之后只要前3个人
        Stream<String> s1 = one.stream().filter(s -> s.length() == 3).limit(3);
        // 第二个队伍只要姓张的成员姓名;第二个队伍筛选之后不要前2个人
        Stream<String> s2 = two.stream().filter(s -> s.startsWith("张")).skip(2);
        // 将两个队伍合并为一个队伍；
        Stream.concat(s1, s2).forEach(s -> {
            Person person = new Person(s);
            System.out.println(person);
        });
    }
}

class Person {

    private String name;

    public Person() {}

    public Person(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Person{name='" + name + "'}";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
