package homework;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 目标 : 练习toMap方法
 * 需求 : 现有字符串数组, 内部元素为如下，请使用所学习的Stream流技术，将内部数据转换为Map集合
 * Map<String, String> 要求集合的键存储的是姓名，值存储的是居住地
 * 随后遍历打印Map集合
 *
 * @author 虞渊
 * @since 2023年01月01日 14:58
 */
public class HomeWork02 {
    public static void main(String[] args) {
        String[] sArr = {"张三,北京", "李四,上海", "王五,深圳", "赵六,广州", "周七,黑龙江"};

        Map<String, String> map = Arrays.stream(sArr).collect(Collectors.toMap(s -> s.split(",")[0], s -> s.split(",")[1]));
        map.forEach((s1, s2) -> System.out.println(s1 + "="+ s2));
    }
}
