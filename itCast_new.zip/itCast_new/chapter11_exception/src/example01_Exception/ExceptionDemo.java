package example01_Exception;

/**
 * 功能说明: 异常默认的处理方式
 *
 * @author 虞渊
 * @since 2022年12月30日 21:05
 */
public class ExceptionDemo {
    /*
        Java默认对异常的处理方式:抛出异常,抛给上级[调用者]
     */
    public static void main(String[] args) {
        System.out.println("开始");
        // 第二步: new ArithmeticException("by zero")  ---> main() ---> jvm虚拟机 ---> 抛出信息
        calc(10, 0);
        System.out.println("结束");
    }

    public static int calc(int a, int b) {
        // 这里出现问题,java底层会创建一个对象:ArithmeticException--->throw new ArithmeticException("by zero")
        // 在这里会将java程序会结束
        return a / b;
    }
}
