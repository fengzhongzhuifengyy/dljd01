/**
 * 功能说明: 测试自定义注解的执行顺序类
 *
 * @author 虞渊
 * @since 2023-12-03-19:56
 */
//表示Test这个注解的存活时间
public class UserTest {

    public void show(){
        System.out.println("show.....");
    }

    @MyTest
    public void print(){
        System.out.println("print.....");
    }

    @MyTest
    public void method(){
        System.out.println("method.....");
    }
}
