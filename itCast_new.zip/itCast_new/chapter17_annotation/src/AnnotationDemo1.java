/**
 * 功能说明: 注解
 *
 * @author 虞渊
 * @since 2023-12-03-19:25
 */
@SuppressWarnings("all")
public class AnnotationDemo1 {
    /*
        Annotation表示注解，是JDK1.5的新特性。
        注解的主要作用：对我们的程序进行标注。注解是给编译器或JVM看的，编译器或JVM可以根据注解来完成对应的功能。
     */
    public static void main(String[] args) {

    }

    @Deprecated
    @AnnotationDemo2()
    public static void method1() {
        int a = 1;
        int b = 2;
    }

    @AnnotationDemo3("张三")
    public static void method2() {
        int a = 1;
        int b = 2;
    }
}
