import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-12-03-19:59
 */
public class AnnotationDemo4 {
    /*
        当运行UserTest类时,只允许加MyTest注解的方法
        思路: 让程序知道哪些是加了注解, 哪些是没有加注解
        1.获取要执行类的字节码对象
        2.获取内部所有的Method对象
        3.遍历数组获取每一个Method对象
        4.判断这个Method对象,有没有挂上注解
     */
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Class clazz = UserTest.class;

        Constructor constructor = clazz.getConstructor();
        Object o = constructor.newInstance();

        Method[] methods = clazz.getMethods();
        for (Method method : methods) {
            // 此方法传参一个注解类型对应的 Class 对象
            if (method.isAnnotationPresent(MyTest.class)){
                method.invoke(o);
                /*
                这里发现什么都没有打印, 原来是因为注解在运行时就已经结束生命周期
                需要在注解类上面增加时效的注解@Retention(RetentionPolicy.RUNTIME)
                 */
            }
        }
    }
}
