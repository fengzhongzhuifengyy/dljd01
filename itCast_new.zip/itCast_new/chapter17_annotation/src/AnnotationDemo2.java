/**
 * 功能说明: 自定义注解
 *
 * @author 虞渊
 * @since 2023-12-03-19:32
 */
public @interface AnnotationDemo2 {
    /*
    属性类型 :
    * 基本数据类型
    * String
    * Class
    * 注解
    * 枚举
    * 以上类型的一维数组
     */
    int num = 10;
    // 等价于 public static final int num = 10;

    int num1 = 100;
    String num2 = "abc";
    Class num4 = String.class;
    int[] num5 = {};

    String show1() default "123";

    int show2() default 132;

    Class show4() default String.class;

    int[] show5() default {1, 2, 3};

}
