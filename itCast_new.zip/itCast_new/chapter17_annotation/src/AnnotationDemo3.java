/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-12-03-19:48
 */
public @interface AnnotationDemo3 {
    // 一个特殊的属性value, 不需要写属性value=, 直接写值
    String value();
}
