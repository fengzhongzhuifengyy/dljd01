package example01_NochangeCollection;

/**
 * 不可变集合 ---jdk 9才能使用
 * 在List、Set、Map接口中，都存在of方法，可以创建一个不可变的集合。
 * static <E>  List<E>  of(E…elements)	创建一个具有不可变的List集合
 * static <E>  Set<E>  of(E…elements)	创建一个具有不可变的Set集合
 * static <K , V>   Map<K，V>  of(E…elements)	创建一个具有不可变的Map集合
 * 这个集合不能添加，不能删除，不能修改。
 *
 * @author 虞渊
 * @since 2022年12月27日 22:08
 */
public class ListOfDemo {
    /*
        List.of(...) 不可改变的
                (添加,删除,修改)
        Set.of(...)
        Map.of():不是可变参数,最多存储10个
        Map.ofEntries():是可变参数

        应用场景:
        jdk 1.9 才可以运行
        配合集合对象的构造方法,进行批量添加集合
     */
    public static void main(String[] args) {

        // List<String> list =  List.of("abc", "bbb", "vvv");
        // System.out.println(list.add("vbg"));
        // System.out.println(list.set(0, "vbg"));
        // System.out.println(list.get(0));

        // 配合构造器
        // ArrayList<String> myList = new ArrayList<>(list);
        // System.out.println(myList); // 此时myList就可以进行增删改除


        // Map.ofEntries(
        //         Map.entry(1, 1),
        //         Map.entry(2, 2)
        // );

    }
}
