import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 功能说明: 反射的应用
 *
 * @author 虞渊
 * @since 2023-12-03-15:58
 */
public class ReflectDemo8 {
    public static void main(String[] args) throws IOException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {

        // 创建一个定时器对象(线程池)
        ScheduledExecutorService pool = Executors.newScheduledThreadPool(10);
        // 添加定时任务
        // 目标: 不希望每一次变更任务,都要修改源代码
        // 解决: 通过设置配置项
        Properties properties = new Properties();
        properties.load(Files.newInputStream(Paths.get("D:\\gitee\\itpath\\itCast\\src\\com\\itCast\\study\\chapter16_clazz\\config.properties")));
        String classname = properties.getProperty("classname");
        // 通过反射拿配置的任务类的字节码对象
        Class<?> clazz = Class.forName(classname);
        Constructor<?> constructor = clazz.getConstructor();
        Runnable string = (Runnable) constructor.newInstance(); // 强转

        pool.scheduleAtFixedRate(
                string, // 任务处理
                1, // 延迟时间
                2, // 间隔时间
                TimeUnit.SECONDS // 时间单位
        );
    }
}
