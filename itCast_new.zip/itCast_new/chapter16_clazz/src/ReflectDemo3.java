import java.lang.reflect.Field;

/**
 * 功能说明: 通过反射获取类中成员变量的对象
 *
 * @author 虞渊
 * @since 2023-12-03-14:05
 */
public class ReflectDemo3 {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchFieldException {
        // 获取字节码对象
        Class<?> clazz = Class.forName("com.itCast.study.chapter16_clazz.domain.MyStudent");

        // 解剖成员变量的对象
        // 只能获取所有public修饰的成员变量的对象, default protect private 都不可以获取
        Field[] fields = clazz.getFields();
        for (Field field : fields) {
            /*
            public java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.num
             */
            System.out.println(field);
        }
        System.out.println("------------------------");
        // 获取所有的成员变量的对象
        Field[] fields1 = clazz.getDeclaredFields();
        for (Field field : fields1) {
            /*
            private java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.name
            private int com.itCast.study.chapter16_clazz.domain.MyStudent.age
            public java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.num
            protected int com.itCast.study.chapter16_clazz.domain.MyStudent.sex
            int com.itCast.study.chapter16_clazz.domain.MyStudent.height
             */
            System.out.println(field);
        }

        // 获取单个的公共的成员变量的对象(只能public)
        Field numField = clazz.getField("num");
        System.out.println(numField); // public java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.num


        Field nameFiled = clazz.getDeclaredField("name");
        System.out.println(nameFiled); // private java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.name
    }
}
