import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 功能说明: 通过反射技术调用方法
 *
 * @author 虞渊
 * @since 2023-12-03-15:09
 */
public class ReflectDemo6 {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException {
        Class<?> clazz = Class.forName("com.itCast.study.chapter16_clazz.domain.MyStudent");
        Method getNameMethod = clazz.getMethod("getName");
        Method setNameMethod = clazz.getMethod("setName", String.class);

        // 调用这些方法
        // Object invoke(Object obj, Object... args)
        // 参数一: 用obj对象调用该方法
        // 参数二: 调用方法的传递的参数(如果没有就不写)
        // 返回值: 方法的返回值(如果没有就不写)
        // 1.创建对象
        Constructor<?> constructor = clazz.getConstructor();
        Object student = constructor.newInstance();
        // 2.方法调用
        Object getName = getNameMethod.invoke(student);
        setNameMethod.invoke(student, "张三");
        System.out.println(student); // MyStudent{name='张三', age=0}

    }
}
