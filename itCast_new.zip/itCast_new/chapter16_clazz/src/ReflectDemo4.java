import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

/**
 * 功能说明: 通过反射拿到成员变量对象,并完成赋值和获取操作
 *
 * @author 虞渊
 * @since 2023-12-03-14:38
 */
public class ReflectDemo4 {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchFieldException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Class<?> clazz = Class.forName("com.itCast.study.chapter16_clazz.domain.MyStudent");
        Field nameField = clazz.getDeclaredField("name");

        // 进行赋值
        // void set(Object obj, Object value)
        // 参数一: 你这个成员变量,归属于哪一个对象
        // 参数二: 该成员变量所记录的值
        // 因此需要创建对象
        Constructor<?> constructor = clazz.getConstructor();
        Object student = constructor.newInstance();

        // nameField.set(student, "张三");
        // System.out.println(student); // java.lang.IllegalAccessException ---代表您访问权限不足

        // 那么怎么办? --进行擦除私有权限
        nameField.setAccessible(true);
        nameField.set(student, "张三");
        System.out.println(student); // 重写了toString(), 打印查看set是否生效

        // 获取成员变量的值
        // get(Object obj): 这里也是需要说明是哪一个对象
        Object age = nameField.get(student);
        System.out.println(age);
    }

}
