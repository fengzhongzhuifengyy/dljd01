package domain;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-12-03-16:01
 */
public class TuesdayTask implements Runnable{
    @Override
    public void run() {
        System.out.println("今天星期二");
    }
}
