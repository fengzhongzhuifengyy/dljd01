package domain;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-11-30-23:53
 */
public class MyStudent {
    private String name;
    private int age;
    public String num;
    protected int sex;
    int height;

    public MyStudent(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public MyStudent() {
    }

    // 演示私有的构造方法
    private MyStudent(String name, int age, double score){

    }

    private MyStudent(String name, int age, double score, double number){

    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "MyStudent{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
