package domain;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-12-03-16:03
 */
public class WednesdayTask implements Runnable{
    @Override
    public void run() {
        System.out.println("今天星期三");
    }
}
