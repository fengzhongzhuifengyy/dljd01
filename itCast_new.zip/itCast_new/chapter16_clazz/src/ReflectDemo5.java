import java.lang.reflect.Method;

/**
 * 功能说明: 通过反射获取成员方法的对象
 *
 * @author 虞渊
 * @since 2023-12-03-14:55
 */
public class ReflectDemo5 {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException {
        Class<?> clazz = Class.forName("com.itCast.study.chapter16_clazz.domain.MyStudent");
        // 解剖成员方法对象,包括私有的 -- 一般不推荐
        Method[] declaredMethods = clazz.getDeclaredMethods();
        for (Method method : declaredMethods) {
            /*
            public java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.toString()
            public java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.getName()
            public void com.itCast.study.chapter16_clazz.domain.MyStudent.setName(java.lang.String)
            public void com.itCast.study.chapter16_clazz.domain.MyStudent.setAge(int)
            public int com.itCast.study.chapter16_clazz.domain.MyStudent.getAge()
             */
            System.out.println(method);
        }
        System.out.println("----------------------");
        // 获取所有公共的方法,父类(继承)的公共方法也有
        Method[] methods = clazz.getMethods();
        for (Method method : methods) {
            /*
            public java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.toString()
            public java.lang.String com.itCast.study.chapter16_clazz.domain.MyStudent.getName()
            public void com.itCast.study.chapter16_clazz.domain.MyStudent.setName(java.lang.String)
            public int com.itCast.study.chapter16_clazz.domain.MyStudent.getAge()
            public void com.itCast.study.chapter16_clazz.domain.MyStudent.setAge(int)
            public final void java.lang.Object.wait() throws java.lang.InterruptedException
            public final void java.lang.Object.wait(long,int) throws java.lang.InterruptedException
            public final native void java.lang.Object.wait(long) throws java.lang.InterruptedException
            public boolean java.lang.Object.equals(java.lang.Object)
            public native int java.lang.Object.hashCode()
            public final native java.lang.Class java.lang.Object.getClass()
            public final native void java.lang.Object.notify()
            public final native void java.lang.Object.notifyAll()
             */
            System.out.println(method);
        }

        System.out.println("---------------");
        // 参数1: 方法名
        // 参数2: 识别性的参数, 比如方法中传参的个数
        Method getNameMethod = clazz.getMethod("getName");
        Method setNameMethod = clazz.getMethod("setName", String.class);
    }
}
