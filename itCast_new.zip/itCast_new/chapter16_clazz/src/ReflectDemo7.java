import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

/**
 * 功能说明:  请向一个泛型为 Integer 的集合,  添加一个 String 字符串
 *
 * @author 虞渊
 * @since 2023-12-03-15:28
 */
public class ReflectDemo7 {
    /*
        普及: Java中的泛型是假的, 只在编译期间有效, 运行的时候, 就没有泛型了.
             运行的时候: 肯定过了编译阶段, 肯定有字节码对象.
             结论 : Java中的泛型, 到运行期间, 就会被擦除掉.
     */
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        ArrayList<Integer> list = new ArrayList<>();

        // 获取集合的字节码对象
        Class<? extends ArrayList> listClazz = list.getClass();
        // 获取方法对象
        Method addMethod = listClazz.getMethod("add", Object.class);
        // 调用add()进行调用,添加字符串
        addMethod.invoke(list, "abc");
        System.out.println(list); // [abc]
    }
}
