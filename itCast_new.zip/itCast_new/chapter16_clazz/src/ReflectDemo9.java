import domain.MyStudent;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

/**
 * 功能说明:
 *
 * @author 虞渊
 * @since 2023-12-03-17:05
 */
public class ReflectDemo9 {
    /*
    框架: 给我一个javabean.class字节码文件, 将数据库中的信息,封装为一个个的Javabean对象,并存入集合并返回
    问题一: 反射的是成员变量吗?
    不是成员变量,成员变量普遍是private私有的,不推荐暴力反射进行操作
    问题二:到底该反射谁呢?
    反射方法
     */
    public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException, IntrospectionException, InvocationTargetException {
        // 获取JavaBean字节码对象
        Class clazz = MyStudent.class;

        // 读取本地文件
        ArrayList<String> infos = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader("day14-code001入门\\img001入门\\imgstuInfo.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            infos.add(line);
        }
        br.close();

        // 从集合中取出对象信息
        for (String info : infos) {

            String name = info.split(",")[0];
            int age = Integer.parseInt(info.split(",")[1]);
            // 创建对象
            Object o = clazz.newInstance();

            // 反射setName方法
            PropertyDescriptor pdName = new PropertyDescriptor("name", clazz);
            Method setName = pdName.getWriteMethod();
            setName.invoke(o, name);

            // 反射setAge方法
            PropertyDescriptor pdAge = new PropertyDescriptor("age", clazz);
            Method setAge = pdAge.getWriteMethod();
            setAge.invoke(o, age);

            System.out.println(o);
        }
    }
}
