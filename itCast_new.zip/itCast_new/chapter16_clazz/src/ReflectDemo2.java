import domain.MyStudent;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * 功能说明: 通过反射获取类中构造防范的对象
 *
 * @author 虞渊
 * @since 2023-12-02-1:28
 */
public class ReflectDemo2 {
    /*
        已经拿到一个字节码对象,就代表已经拿到了
        -字节码对象: 成员变量 成员方法 构造方法
        目标: 通过反射的形式, 创建该类的对象
     */
    public static void main(String[] args) {
        try {
            // 拿到学生的字节码对象
            Class<?> clazz = Class.forName("com.itCast.study.chapter16_clazz.domain.MyStudent");

            // 这是一个过时创建对象的方法,一般我们不使用,推荐使用通过构造方法进行创建对象
            // Object o = clazz.newInstance();

            // 获取该类的构造方法的对象 数组
            Constructor<?>[] constructors = clazz.getConstructors();
            for (Constructor<?> constructor : constructors) {
                /*
                public com.itCast.study.chapter16_clazz.domain.MyStudent(java.lang.String,int)
                public com.itCast.study.chapter16_clazz.domain.MyStudent()
                 */
                System.out.println(constructor);
            }

            // 获取该类,指定的 [构造方法] 对象
            Constructor<?> cons1 = clazz.getConstructor();
            System.out.println(cons1); // public com.itCast.study.chapter16_clazz.domain.MyStudent()

            // 参数区分带参的构造方法 对象
            Constructor<?> cons2 = clazz.getConstructor(String.class, int.class);
            System.out.println(cons2); // public com.itCast.study.chapter16_clazz.domain.MyStudent(java.lang.String,int)

            // 此时发现,我们无法获取私有的构造方法
            // 使用爆破反射
            Constructor<?>[] declaredConstructors = clazz.getDeclaredConstructors();
            for (Constructor<?> declaredConstructor : declaredConstructors) {
                /*
                public com.itCast.study.chapter16_clazz.domain.MyStudent()
                public com.itCast.study.chapter16_clazz.domain.MyStudent(java.lang.String,int)
                private com.itCast.study.chapter16_clazz.domain.MyStudent(java.lang.String,int,double,double)
                private com.itCast.study.chapter16_clazz.domain.MyStudent(java.lang.String,int,double)
                 */
                System.out.println(declaredConstructor);
            }

            // 此时我们就可以创建MyStudent对象啦
            MyStudent myStudent = (MyStudent)cons2.newInstance("张三", 50);
            System.out.println(myStudent.getName());
            System.out.println(myStudent.getAge());


        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
