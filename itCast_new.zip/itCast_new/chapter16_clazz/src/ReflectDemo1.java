import domain.MyStudent;

/**
 * 功能说明:通过反射创建字节码对象
 *
 * @author 虞渊
 * @since 2023-11-30-23:52
 */
public class ReflectDemo1 {
    /*
        通过反射技术获取MyStudent类的字节码对象
        方式1:
            通过 类目.class
                所有的类:都有默认的静态属性, .class ---> 获取该类的字节码对象
                场景: 一般用于锁对象进行使用

        方式2: 通过 对象名.getClass()
                前提: 对象已经创建好了
                细节: getClass()来自于Object类

        方式3: 通过Class类的静态方法: Class.forName("包名+类目")

        通过上述代码: 三种方式,获取到的字节码对象,都是同一份,类的字节码对象,在内存中只有一份
     */
    public static void main(String[] args) {
        Class clazz1 = MyStudent.class;
        System.out.println(clazz1);

        MyStudent myStudent = new MyStudent();
        Class clazz2 = myStudent.getClass();
        System.out.println(clazz2);

        try {
            Class clazz3 = Class.forName("com.itCast.study.chapter16_clazz.domain.MyStudent");
            System.out.println(clazz3);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
