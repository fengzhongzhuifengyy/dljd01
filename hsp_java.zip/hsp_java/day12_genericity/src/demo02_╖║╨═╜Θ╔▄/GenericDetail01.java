package com.hspedu.java.day12_泛型.demo02_泛型介绍;

import java.util.ArrayList;
import java.util.List;

/**
 * 泛型使用细节
 */
public class GenericDetail01 {
    public static void main(String[] args) {
        //1.T E 只能是引用类型
        //2.在指定泛型具体类型后,可以传入该类型或者其子类类型
        //因为E指向了A类型,构造器需要传入A类型
        Pig<A> pig1 = new Pig<A>(new A());
        pig1.f1();//class com.hspjava.day12_泛型.demo02_泛型介绍.A
        Pig<A> pig2 = new Pig<A>(new B());//此时会报错怎么办呢? --->让B继承A
        pig2.f1();//class com.hspjava.day12_泛型.demo02_泛型介绍.B

        //3.泛型的使用形式
        //3.1 使用接口引用来接收;
        List<Integer> list1 = new ArrayList<Integer>();
        ArrayList<Integer> arrayList1 = new ArrayList<Integer>();
        //3.2在实际开发中,我们往往简写:
        List<Integer> list2 = new ArrayList<>();
        ArrayList<Integer> arrayList2 = new ArrayList<>();
        //为什么可以这样写?  编译器会进行类型推断,而且是推荐这样的写法
        //idea也会自动去除
        ArrayList<Pig> pigs = new ArrayList<>();


        //4.如果我们这样写 List list3 = new ArrayList(); 默认给他的泛型就是<E>, E是Object
        //之前我们都是这样写:
        ArrayList arrayList = new ArrayList();
        //等价于
        ArrayList<Object> objects = new ArrayList<>();
    }
}

class A {
}

class B extends A {
}

class Pig<E> {

    E e;

    public Pig(E e) {
        this.e = e;
    }

    public void f1(){
        System.out.println(e.getClass());
    }
}