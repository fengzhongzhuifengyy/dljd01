package com.hspedu.java.day12_泛型.demo02_泛型介绍;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 1.创建3个学生对象
 * 2.放入到HashSet中
 * 2.放入到HashMap中,要求Key是String name,Value是学生对象
 * 3.使用2中方式遍历
 */
public class GenericExercise01 {
    private static Student student3;

    public static void main(String[] args) {
        HashMap<String, Student> hashMap = new HashMap<>();
        Student student1 = new Student("1", 1);
        Student student2 = new Student("2", 2);
        Student student3 = new Student("3", 3);
        hashMap.put(student1.name, student1);
        hashMap.put(student2.name, student2);
        hashMap.put(student3.name, student3);
        System.out.println(hashMap);//{1=Student{name='1', age=1}, 2=Student{name='2', age=2}, 3=Student{name='3', age=3}}
        // 迭代器
        System.out.println("iterator迭代器HashMap");
        Set<Map.Entry<String, Student>> entries = hashMap.entrySet();
        Iterator<Map.Entry<String, Student>> iterator = entries.iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Student> next = iterator.next();
            System.out.println(next.getKey() + next.getValue());
        }

        //for循环
        System.out.println("for循环HashMap");
        Set<String> strings = hashMap.keySet();
        for (String s : strings) {
            System.out.println(s + hashMap.get(s));
        }

        HashSet<Student> hashSet = new HashSet<>();
        hashSet.add(student1);
        hashSet.add(student2);
        hashSet.add(student3);
        System.out.println(hashSet);//[Student{name='2', age=2}, Student{name='1', age=1}, Student{name='3', age=3}]
        //for
        System.out.println("for循环HashSet");
        for (Student student : hashSet) {
            System.out.println(student);
        }
        System.out.println("iterator迭代器HashSet");
        //iterator
        Iterator<Student> iterator1 = hashSet.iterator();
        while (iterator1.hasNext()) {
            Student next = iterator1.next();
            System.out.println(next);
        }

    }
}


class Student {

    public String name;
    public int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}