package com.hspedu.java.day12_泛型.demo02_泛型介绍;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * 定义 Employee 类
 * 1) 该类包含：private 成员变量 name,sal,birthday，其中 birthday 为 MyDate 类的对象；
 * 2) 为每一个属性定义 getter, setter 方法；
 * 3) 重写 toString 方法输出 name, sal, birthday
 * 4) MyDate 类包含: private 成员变量 month,day,year；并为每一个属性定义 getter, setter 方法；
 * 5) 创建该类的 3 个对象，并把这些对象放入 ArrayList 集合中（ArrayList 需使用泛型来定义），对集合中的元素进行排序，并遍历输出：
 * <p>
 * 排序方式： 调用 ArrayList 的 sort 方法 ,
 * 传入 Comparator 对象[使用泛型]，先按照 name 排序，如果 name 相同，则按生日日期的先后排序。【即：定制排序】
 */
public class GenericExercise02 {
    public static void main(String[] args) {

        Employee employee1 = new Employee("tom", 2000, new MyDate(6, 1, 2022));
        Employee employee2 = new Employee("yack", 3000, new MyDate(5, 1, 2022));
        Employee employee3 = new Employee("tom", 4000, new MyDate(4, 1, 2022));

        ArrayList<Employee> employees = new ArrayList<>();
        employees.add(employee1);
        employees.add(employee2);
        employees.add(employee3);
        System.out.println("排序前" + employees);

        employees.sort(new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                //先对参入的参数进行验证
                if (!(o1 instanceof Employee && o2 instanceof Employee)) {
                    System.out.println("类型不正确");
                    return 0;
                }
                //比较name
                int i = o1.getName().compareTo(o2.getName());
                //如果名字相同(i=0):
                //这里对年月日的比较,在MyDate类里面进行比较 会更好
                if (i == 0) {
                    return o1.getMyDate().compareTo(o2.getMyDate());
                }
                //如果名字不同,直接返回之前字符串的比较
                return i;
            }
        });

        System.out.println("排序后" + employees);
    }
}

class Employee {
    private String name;
    private double sal;
    private MyDate myDate;

    public Employee(String name, double sal, MyDate myDate) {
        this.name = name;
        this.sal = sal;
        this.myDate = myDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSal() {
        return sal;
    }

    public void setSal(double sal) {
        this.sal = sal;
    }

    public MyDate getMyDate() {
        return myDate;
    }

    public void setMyDate(MyDate myDate) {
        this.myDate = myDate;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", sal=" + sal +
                ", myDate=" + myDate +
                '}';
    }
}

class MyDate implements Comparable<MyDate> {
    private int mouth;
    private int day;
    private int year;

    public MyDate(int mouth, int day, int year) {
        this.mouth = mouth;
        this.day = day;
        this.year = year;
    }

    public int getMouth() {
        return mouth;
    }

    public void setMouth(int mouth) {
        this.mouth = mouth;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return year + "年" + mouth + "月" +
                day + "日";
    }


    @Override
    public int compareTo(MyDate myDate) {
        int yearMinus = year - myDate.year;
        //年份不相同
        if (yearMinus != 0){
            return yearMinus;
        }
        //月份不相同,走到这里说明 年份相同
        int mouthMinus = mouth - myDate.mouth;
        if (mouthMinus != 0){
            return mouthMinus;
        }
        //日不相同,走到这里说明 年份月份相同
        return day - myDate.day;
    }
}