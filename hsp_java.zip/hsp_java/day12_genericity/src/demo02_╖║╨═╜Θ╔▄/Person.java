package com.hspedu.java.day12_泛型.demo02_泛型介绍;

/**
 *  泛型的作用
 */
// 泛型的作用是:可以在类声明时通过一个标识 标识类中某个属性的类型,或者某个方法的返回值类型,或者是参数类型
public class Person<E> {
    E s; // E 表示s的数据类型,该数据类型是在定义Person对象的时候指定,即在编译期间,就确定E是什么类型了

    public Person(E s) {// E也可以是参数类型
        this.s = s;
    }

    public E  f1(){//E也可以是返回类型
        return s;
    }

    //显示E的运行类型
    public void show (){
        System.out.println(s.getClass());
    }
}
