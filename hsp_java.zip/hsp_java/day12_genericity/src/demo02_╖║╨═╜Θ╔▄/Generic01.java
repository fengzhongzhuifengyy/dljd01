package com.hspedu.java.day12_泛型.demo02_泛型介绍;

/**
 *  泛型介绍
 *  E 表示s的数据类型,该数据类型是在定义Person对象的时候指定,即在编译期间,就确定E是什么类型
 *
 */
public class Generic01 {
    public static void main(String[] args) {
        Person<String> person1 = new Person<String>("韩顺平教育");
        person1.show();//class java.lang.String
        /*
            理解泛型:
            Person类的E -> String
            public class Person {
               String s; // E 表示s的数据类型,该数据类型是在定义Person对象的时候指定,即在编译期间,就确定E是什么类型了

                public Person(String s) {// E也可以是参数类型
                    this.s = s;
                }

                public String f1(){//E也可以是返回类型
                    return s;
                }
         */
        Person<Integer> person2= new Person<Integer>(100);
        /*
            理解泛型:
            Person类的E -> Integer
            public class Person {
               Integer s; // E 表示s的数据类型,该数据类型是在定义Person对象的时候指定,即在编译期间,就确定E是什么类型了

                public Person(Integer s) {// E也可以是参数类型
                    this.s = s;
                }

                public Integer f1(){//E也可以是返回类型
                    return s;
                }
         */
        person2.show();//class java.lang.Integer

    }
}
