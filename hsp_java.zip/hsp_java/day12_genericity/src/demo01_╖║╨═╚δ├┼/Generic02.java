package demo01_泛型入门;

import java.util.ArrayList;

/**
 *  用泛型来解决前面的问题
 */
public class Generic02 {
    public static void main(String[] args) {
        ArrayList<Dog> dogs = new ArrayList<>();
        dogs.add(new Dog("1", 10));
        dogs.add(new Dog("2", 20));
        //如果编译器发现添加的类型不满足,就会报错
        //在遍历的时候,可以直接取出Dog类型而不是Object
        // dogs.add(new Cat("3", 13));
        System.out.println(dogs);
        for (Dog o : dogs) {
            System.out.println(o.getName());
        }

    }
}
