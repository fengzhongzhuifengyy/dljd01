package demo01_泛型入门;

import java.util.ArrayList;

/**
 *  泛型的理解和引入
 *  使用穿透方法的问题分析:
 *  1)不能对加入集合ArrayList的数据类型进行约束
 *  2)遍历的时候,需要进行类型转换,如果集合的数据量较大,对效率有影响
 */
public class Generic01 {
    public static void main(String[] args) {
        //请编写程序，在 ArrayList 中，添加 3 个 Dog 对象
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Dog("小花", 10));
        arrayList.add(new Dog("小前", 11));

        //此时,加入不小心加入了一个猫
        arrayList.add(new Cat("小猫", 12));

        //那么此时就会异常: java.lang.ClassCastException
        for (Object o : arrayList) {
            // 向下转型Object -> Dog
            System.out.println(((Dog)o).getName() + "-" + ((Dog)o).getAge());
        }

    }
}
