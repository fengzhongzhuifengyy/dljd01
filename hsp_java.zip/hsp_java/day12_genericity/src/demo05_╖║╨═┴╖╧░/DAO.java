package demo05_泛型练习;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*
 *  定义一个泛型类DAO<T>,在其中定义一个Map成员变量,Map的键为String类型,值为T类型
 *  分别创建以下方法:
 *  1.public void save(String id, T entity): 保存T类型的对象到Map成员变量中
 *  2.public T get(String id): 从Map中获取id对应的对象
 *  3.public void update(String id, T entity):替换map中key为id的内容,改为entity对象
 *  4.public List<T> list(): 返回Map中的所有对象
 *  5.public void delete(String id): 删除指定的id对象
 */
public class DAO<T> {


    private Map<String, T> map = new HashMap<>();


    public void save(String id, T entity) {
        map.put(id, entity);
    }

    public T get(String id) {
        return map.get(id);
    }

    public void update(String id, T entity) {
        if (map.keySet().contains(id)) {
            map.put(id, entity);
        } else {
            System.out.println("id不存在");
        }
    }

    public List<T> list() {
        List<T> list = new ArrayList<>();
        Set<String> keySet = map.keySet();
        for (String key : keySet) {

            list.add(get(key));//此处的get()方法是本类28行的自定义get(); 使用map.get(key)也是可以的
        }
        return list;
    }

    public void delete(String id) {
        map.remove(id);
    }

    @Override
    public String toString() {
        return "DAO{map=" + map +
                '}';
    }
}
