package demo05_泛型练习;


import org.junit.Test;

/**
 *  编程题:
 *  定义一个泛型类DAO<T>,在其中定义一个Map成员变量,Map的键为String类型,值为T类型
 *  分别创建以下方法:
 *  1.public void save(String id, T entity): 保存T类型的对象到Map成员变量中
 *  2.public T get(String id): 从Map中获取id对应的对象
 *  3.public void update(String id, T entity):替换map中key为id的内容,改为entity对象
 *  4.public List<T> list(): 返回Map中的所有对象
 *  5.public void delete(String id): 删除指定的id对象
 *
 *  定义一个User类: private成员变量(int类型) id age ; (String 类型) name
 *  创建DAO类的对象,分别调用其save get update list delete方法鳄梨操作User对象,使用Junit单元测试类进行测试
 */
public class GenericExercise01 {
    public static void main(String[] args) {
        // DAO<User> userDAO = new DAO<>();
        // userDAO.save("111", new User(1,1,"张三"));
        // userDAO.save("222", new User(2,2,"李四"));
        // System.out.println(userDAO);
        // userDAO.get("111");
        // userDAO.update("222", new User(2,2,"王五"));
        // userDAO.list();
        // userDAO.delete("111");
    }

    @Test
    public void testDao(){
        DAO<User> userDAO = new DAO<>();
        userDAO.save("111", new User(1,1,"张三"));
        userDAO.save("222", new User(2,2,"李四"));
        System.out.println(userDAO);
        System.out.println(userDAO.get("111"));

        userDAO.update("222", new User(2,2,"王五"));
        System.out.println(userDAO);
        System.out.println(userDAO.list());

        userDAO.delete("111");
        System.out.println(userDAO);
    }
}
