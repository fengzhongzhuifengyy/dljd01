package demo03_自定义泛型;

/**
 *  自定义泛型类
 */
public class CustomerGeneric01 {
    public static void main(String[] args) {

    }
}

/*
    分析:
    1.Tiger后面泛型,所以称为自定义泛型
    2.T R M 称为泛型的标识符,一般是字母大写
    3.泛型的标识符可以有多个

    细节:
    1.普通成员可以使用泛型(属性,方法)
    2.使用泛型的数组,不能初始化
    3.静态方法中不能使用类的泛型
 */
class Tiger<T, R, M>{
    String name;
    T t;//属性使用了泛型
    R r;
    M m;
    //因为数组在new 时无法确定T的类型就无法在内存中开辟空间
    // T[] ts = new T[8];//类型形参 'T' 不能直接实例化

    public Tiger(String name, T t, R r, M m) { //方法使用了泛型
        this.name = name;
        this.t = t;
        this.r = r;
        this.m = m;
    }

    //因为静态是和类相关的,在类加载时,对象还没有创建
    //所有静态方法和静态属性使用了泛型,JVM就无法完成初始化
    // static R r1;
    // public static void m1(M m){ }//无法从 static 上下文引用 'com.hspjava.day12_泛型.demo03_自定义泛型.Tiger.this

}
