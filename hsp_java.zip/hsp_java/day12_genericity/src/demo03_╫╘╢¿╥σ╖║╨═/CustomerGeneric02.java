package demo03_自定义泛型;

/**
 * 自定义泛型接口
 */
public class CustomerGeneric02 {
    public static void main(String[] args) {

    }
}

/*
    分析:
    1.接口中,静态成员也不能使用泛型(这个和泛型类规定一致)
    2.泛型接口的类型, 在"继承接口" 或者 "实现接口" 时确定
    3.没有指定类型,默认为Object
 */
interface IUsb<U, R> {
    int INT = 10;
    // U name = 10;//静态成员也不能使用泛型

    //普通方法可以使用泛型(都是抽象方法)
    R get(U u);

    void hi(R r);

    void run(R r1, R r2, U u1, U u2);

    //默认方法也是可以使用泛型的
    default R DefaultMethod(U u) {
        return null;
    }
}

interface IA extends IUsb<String, Double> {

}
/*
    当我们去实现IA接口时,因为IA继承IUsb接口,指定了U为String; R为Double
    因此,在实现IUsb接口的方法时,使用String替换U, Double替换R
 */
class AA implements IA{


    @Override
    public Double get(String s) {
        return null;
    }

    @Override
    public void hi(Double aDouble) {

    }

    @Override
    public void run(Double r1, Double r2, String u1, String u2) {

    }

    @Override
    public Double DefaultMethod(String s) {
        return IA.super.DefaultMethod(s);
    }
}

// 实现接口时,直接指定泛型接口的类型
//给U指定了String ,给R指定了Integer
class BB implements IUsb<String, Integer>{

    @Override
    public Integer get(String s) {
        return null;
    }

    @Override
    public void hi(Integer integer) {

    }

    @Override
    public void run(Integer r1, Integer r2, String u1, String u2) {

    }
}
//没有指定类型,默认都是Object --不推荐
class CC implements IUsb{

    @Override
    public Object get(Object o) {
        return null;
    }

    @Override
    public void hi(Object o) {

    }

    @Override
    public void run(Object r1, Object r2, Object u1, Object u2) {

    }
}