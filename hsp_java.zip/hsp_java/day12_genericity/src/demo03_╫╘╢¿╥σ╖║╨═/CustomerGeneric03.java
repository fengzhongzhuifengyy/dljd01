package demo03_自定义泛型;

import java.util.ArrayList;

/**
 * 自定义泛型方法
 */
public class CustomerGeneric03 {
    public static void main(String[] args) {
        Car car = new Car();
        car.f1("王三", 12.5);//当调用方法时,传入参数,编译器会确定类型

        //测试:泛型方法,可以使用类声明的泛型
        Animal<String, ArrayList<String>> animal = new Animal<>();

        animal.f3(new ArrayList<>(), "gogo");
    }
}

/*
    分析:
    1.泛型方法可以定义在普通类中也可以定义在泛型类中
    2.当泛型方法被调用时,类型会确定
 */
class Car {//普通类

    //泛型方法
    /*
        分析:
        1.<T, R> 就是泛型(标识符)
        2.是提供给fly()使用的
     */
    public <T, R> void f1(T t, R r) {
        System.out.println(t.getClass().getSimpleName());//String
        System.out.println(r.getClass().getSimpleName());//Double
    }
}

class Animal<R, T> {//泛型类
    R r;
    T t;

    public <U, M> void f2(U u, M m) {
        System.out.println("泛型方法");
    }

    /*
        1.下面hi()不是泛型方法
        2.是hi()使用类声明的泛型
     */
    public void hi(T t){

    }
    //泛型方法,可以使用类声明的泛型, 也可以使用自己声明的泛型
    public <K, k> void f3(T t, K k){
        System.out.println(t.getClass());//class java.util.ArrayList
        System.out.println(k.getClass());//class java.lang.String
    }
}
