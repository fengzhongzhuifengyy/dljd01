package demo03_自定义泛型;

/**
 *  自定义泛型类练习
 */
public class CustomerGenericExercise01 {
    public static void main(String[] args) {
        MyGeneric<Double, String, Integer> g = new MyGeneric<>("john");
        g.setT(10.9);
        // g.setT("yy");//错误类型不对
        System.out.println(g);

        MyGeneric g2 = new MyGeneric("john~~");
        g2.setT("yy");//此时就是Object
        System.out.println("g2=" + g2);
    }
}

class MyGeneric<T, R, M>{
    String name;
    T t;

    public T getT() {
        return t;
    }

    public void setT(T t) {
        this.t = t;
    }

    public MyGeneric(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "MyGeneric{" +
                "name='" + name + '\'' +
                ", t=" + t +
                '}';
    }
}