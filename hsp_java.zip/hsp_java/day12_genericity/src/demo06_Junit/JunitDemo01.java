package demo06_Junit;


import org.junit.Test;

/**
 *  Junit单元测试
 */
public class JunitDemo01 {
    public static void main(String[] args) {
        // 传统方式
        new JunitDemo01().m1();
        new JunitDemo01().m2();


    }

    @Test
    public void m1(){
        System.out.println("m1方法被调用");
    }

    @Test
    public void m2(){
        System.out.println("m2方法被调用");
    }
}
