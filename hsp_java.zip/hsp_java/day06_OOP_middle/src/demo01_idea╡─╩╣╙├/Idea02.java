package demo01_idea的使用;

// 自定义模板(template)
public class Idea02 {
    public static void main(String[] args) { // main 就是一个快捷模板

        System.out.println(); // sout

        for (int i = 0; i < 1; i++) {  // fori

        }

    }
}
