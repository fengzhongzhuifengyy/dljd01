package demo01_idea的使用;

// 创建一个类 MyTools,编写一个方法,可以完成对 int 数组冒泡排序的功能
public class Idea01 {
    public static void main(String[] args) {
        int[] arrs = {1, 4, 5, 3, 7};
        MyTools myTools = new MyTools();
        myTools.bubbleSort(arrs);


        // 输出排序后的arrs,是引用传递,值会改变
        // 遍历数组
        System.out.println("排序后的arrs数组: ");
        for (int i = 0; i < arrs.length; i++) {
            System.out.print(arrs[i] + "\t");
        }


    }
}

class MyTools {

    public void bubbleSort(int[] arrs) {
        int temp = 0;
        for (int i = 0; i < arrs.length - 1; i++) {

            for (int j = 0; j < arrs.length - 1 - i; j++) {
                if (arrs[j] > arrs[j + 1]) {

                    temp = arrs[j];
                    arrs[j] = arrs[j + 1];
                    arrs[j + 1] = temp;
                }
            }
        }

    }
}
