package demo05_继承.improve;

/**
 * @ Pupil and Graduate's  super
 */
public class Student {
    // 共有的属性
    public String name;
    public int age;
    private double score;

    // 共有的方法
    // 成绩
    public void setScore(double score) {
        this.score = score;
    }
    // 输出学生信息
    public void showInfo(){
        System.out.println("姓名: " + name + " 年龄: " + age + " 分数: " + score);
    }

}
