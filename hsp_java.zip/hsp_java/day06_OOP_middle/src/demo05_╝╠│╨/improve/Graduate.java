package demo05_继承.improve;

public class Graduate extends Student{
    // 私有的方法
    public void testing(){
        System.out.println(name + "大学生正在考试");
    }
}
