package demo05_继承.improve;

import com.hspjava.day06_面向对象中级.demo05_继承.introduce.Graduate;
import com.hspjava.day06_面向对象中级.demo05_继承.introduce.Pupil;

/**
 * @ 测试类
 */
public class Extends01 {
    public static void main(String[] args) {
        Pupil pupil = new Pupil();
        pupil.name = "金角大王";
        pupil.age = 20;
        pupil.testing();
        pupil.setScore(70);
        pupil.showInfo();
        System.out.println("----------------------");
        Graduate graduate = new Graduate();
        graduate.name = "银角大王";
        graduate.age = 200;
        graduate.testing();
        graduate.setScore(80);
        graduate.showInfo();
    }
}
