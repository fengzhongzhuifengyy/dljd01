package demo05_继承.improve;

/**
 * Pupil继承Student
 */
public class Pupil extends Student{
    // 私有的方法
    public void testing(){
        System.out.println(name + "小学生正在考试");
    }
}
