package demo05_继承.details;

/**
 * 继承细节的父类
 */
public class Base extends TopBase {
    /**
     * 4个属性
     * 4个属性
     */
    public int n1 = 100;
    protected int n2 = 200;
    int n3 = 300;
    private int n4 = 400;

    /**
     *  构造器
     */
    public Base() {
        System.out.println("父类的构造器Base()...被调用");
    }

    public Base(String name) {
        System.out.println("父类的有参构造器Base(String name)...被调用");
    }

    public Base(String name, int age){
        System.out.println("父类的有参构造器Base(String name, int age)...被调用");
    }


    // 父类提供一个public的方法,获得n4
    public int getN4(){
        return n4;
    }

    /**
     * 4个方法
     */
    public void test100() {
        System.out.println("test100");
    }

    protected void test200() {
        System.out.println("test200");
    }

    void test300() {
        System.out.println("test300");
    }

    private void test400() {
        System.out.println("test400");
    }

    // 公共的方法 获得test400()
    public void callTest400(){
        test400();
    }



    public int age = 80;

    public void cal(){
        System.out.println("爷爷Base类的cal()方法");
    }

    public void sum(){
        System.out.println("爷爷Base类的sum()方法");
    }

    public void hi(){
        System.out.println("爷爷Base类的hi()方法");
    }

    public void ok2(){
        System.out.println("爷爷Base类的ok2()方法");
    }

}
