package demo05_继承.details;

/**
 *  Base类的父类
 */
public class TopBase {

    public TopBase(){

        System.out.println("超级父类 topBase");
    }

}
