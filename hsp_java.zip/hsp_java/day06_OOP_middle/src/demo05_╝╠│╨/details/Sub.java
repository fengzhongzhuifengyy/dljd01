package demo05_继承.details;

/**
 * @继承细节的子类
 */
public class Sub extends Base {

    /*
        细节二:
        1.子类必须调用父类的构造器， 完成父类的初始化
        2.当创建子类对象时， 不管使用子类的哪个构造器， 默认情况下总会去调用父类的无参构造器
        3.如果父类没有提供无参构造器， 则必须在子类的构造器中用 super 去指定使用父类的哪个构造器完成对父类的初始化工作， 否则，编译不会通过

     */
    public Sub(){
        // 其实这里默认会调用super();
//        super();
        super("李四",40);
        System.out.println("子类的构造器Sub()...被调用");
    }

    public Sub(String name){
        super("王五",50);
        System.out.println("子类的有参构造器Sub(String name)...被调用");
    }

    /*
        细节三:如果希望指定去调用父类的某个构造器， 则显式的调用一下 : super(参数列表)
        细节四:super 在使用时， 必须放在构造器第一行(super()只能在构造器中使用)
        细节五:super() 和 this() 都只能放在构造器第一行， 因此这两个方法不能共存在一个构造器
     */
    public Sub(String name, int age){
        // 1.如果想调用父类的无参构造器,如下,或者什么也不写,都是调用父类的无参构造器
//        super();

        // 2.要调用父类的单参数构造器
//        super("测试单参数");

        // 3.要调用父类的双参构造器
        super("测试双参",44);
        System.out.println("子类的有参构造器Sub(String name, int age)...被调用");
    }


    public void sayOk(){
        /*
        细节1:子类继承了所有的属性和方法,非私有的属性和方法可以在子类直接访问,
        但是私有属性不能在子类直接访问,要通过(父类提供)公共的方法去访问
         */
        // System.out.println(n1 + " " + n2 + " " + n3 + " " + n4); 此处无法调用n4

        System.out.println(n1 + " " + n2 + " " + n3);

        // 通过父类提供的公共方法getN4()获取n4
        System.out.println(getN4());

        test100();
        test200();
        test300();
       // test400();错误
        callTest400();
    }

    /*
        细节六:java 所有类都是 Object 类的子类, Object 是所有类的基类
     */

    /*
        细节七:父类构造器的调用不限于直接父类！ 将一直往上追溯直到 Object 类(顶级父类)
     */

}
