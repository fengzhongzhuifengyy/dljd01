package demo05_继承.introduce;

/**
 * @ 大学生类: 模拟大学生考试的情况
 */
public class Graduate {

    public String name;
    public int age;
    private double score;

    public void setScore(double score) {
        this.score = score;
    }

    // 考试
    public void testing(){
        System.out.println(name + "正在考试高等数学");
    }

    // 输出学生信息
    public void showInfo(){
        System.out.println("大学生姓名: " + name + " 年龄: " + age + " 分数: " + score);
    }
}
