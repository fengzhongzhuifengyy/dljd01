package demo05_继承.introduce;

/**
 * @ 小学生类:模拟小学生考试
 */
public class Pupil {
    public String name;
    public int age;
    private double score;

    public void setScore(double score) {
        this.score = score;
    }

    // 考试
    public void testing(){
        System.out.println(name + "正在考试小学数学");
    }

    // 输出小学生信息
    public void showInfo(){
        System.out.println("小学生姓名 " + name + " 年龄 " + age + " 分数 " + score);
    }
}
