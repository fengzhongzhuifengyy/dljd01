package demo02_包;


import java.util.Arrays;

//注意:
//老韩建议： 我们需要使用到哪个类， 就导入哪个类即可， 不建议使用 *导入
//import java.util.Scanner; //表示只会引入 java.util 包下的 Scanner
//import java.util.*;//表示将 java.util 包下的所有类都引入(导入)
public class Package01 {

    // 使用系统提供 Arrays 完成 数组排序
    public static void main(String[] args) {

        int [] arrs = {-1, 20, 13, 3};
        // 传统的方法是自己编写(排序)
        Arrays.sort(arrs);

        // 输出
        for (int i = 0; i < arrs.length; i++) {
            System.out.println(arrs[i] + "/t");
        }


    }
}
