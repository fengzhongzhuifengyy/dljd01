package demo13_断点调试;

// 演示debug异常
public class Debug02 {
    public static void main(String[] args) {

        int[] arr = {1, -1, 2};
        for (int i = 0; i <= arr.length; i++) {
            System.out.println(arr[i]);
        }
        System.out.println("程序退出了...");
    }
}
