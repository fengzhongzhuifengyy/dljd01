package demo13_断点调试;

import java.util.Arrays;

public class Debug03 {
    public static void main(String[] args) {

        int[] arr = {8, -1, 199, 20, 100};
        // 我们查看Arrays.sort()方法的底层实现 -->debug F7
        Arrays.sort(arr);

        for (int i =0; i < arr.length; i++){
            System.out.print(arr[i] + "\t");
        }
    }
}
