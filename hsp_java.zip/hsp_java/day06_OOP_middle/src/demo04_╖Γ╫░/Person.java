package demo04_封装;


public class Person {

    private String name;
    private int age;
    private double salary;
    private String job;

    // 然后根据我们的思路,进行条件判断

    public void setName(String name){
        if (name.length() >= 2 && name.length() <=6){
            this.name = name;
        }else {
            System.out.println("名字长度需要2-6字符,默认值admin");
            this.name = "admin";
        }

    }

    public String getName(){
        return name;
    }

    // 自己写太慢 使用快捷键 alt + insert

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        // 限制判断
        if(age >=1 && age <= 120){
            this.age = age;
        }else {
            System.out.println("年龄在1-120,给默认值18");
            this.age = 18;
        }

    }

    public double getSalary() {
        // 这里可以添加对访问者的权限判断
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    // 写一个方法,返回Person信息
    public String info(){
        return "信息为: name = " + name  + "age = " + age + "salary = " + salary;
    }


    /*
        思考:如果此时编写待参数的构造器,那是不是set方法就不行了?
        将构造器与setXxx相结合
     */
    // 构造器

    public Person() {

    }

    public Person(String name, int age, double salary) {
//        this.name = name;
//        this.age = age;
//        this.salary = salary;
        // 明显 验证已经失效.我们将set方法写入构造器中来解决,实现验证
        setName(name);
        setAge(age);
        setSalary(salary);
    }
}
