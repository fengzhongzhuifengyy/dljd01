package demo04_封装;

public class Account {

    private String name;

    private double balance;

    private String password;

    public Account() {

    }

    public Account(String name, double balance, String password) {
        this.setName(name);
        this.setBalance(balance);
        this.setPassword(password);
    }

    public void setName(String name) {
        if (name.length() == 2 || name.length() == 3 || name.length() == 4) {
            this.name = name;
        } else {
            System.out.println("您输入的名字不合法,长度为2位3位或者4位,当前赋予默认值");
            this.name = "李四";
        }
    }

    public String getName() {
        return name;
    }

    public void setBalance(double balance) {
        if (balance > 20) {
            this.balance = balance;
        } else {
            System.out.println("您输入的余额不合法,请大于20");
            this.balance = 20;
        }
    }

    public double getBalance() {
        return balance;
    }

    public void setPassword(String password) {
        if (password.length() == 6) {
            this.password = password;
        } else {
            System.out.println("您输入的密码不合法,给默认值 123456");
            this.password = "123456";
        }
    }

    public String getPassword() {
        return password;
    }

    // 增加一个展示信息的方法
    public void showInfo() {
        // 读取账号信息,这里可以增加校验的权限
        // 校验身份是否合法
        System.out.println("account的name= " + this.getName() +
                "account的balance= " + this.getBalance()
                + "account的password= " + this.getPassword());
    }
}
