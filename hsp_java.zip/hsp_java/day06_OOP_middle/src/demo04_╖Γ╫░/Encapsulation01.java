package demo04_封装;

//  不能随便查看人的年龄,工资等隐私， 并对设置的年龄进行合理的验证。 年龄合理就设置， 否则给默认
//  年龄, 必须在 1-120, 年龄， 工资不能直接查看 ， name 的长度在 2-6 字符 之间
public class Encapsulation01 {
    public static void main(String[] args) {

        Person person = new Person();
//        person.name = "jack";
//        person.age = 10; 无法实现

        person.setName("jack");
        person.setAge(100);
        person.setSalary(10000);
        person.setJob("程序员");

        System.out.println(person.info());


        Person person1 = new Person("smith", 2000, 5000);
        System.out.println("Smith的信息");
        System.out.println(person1.info());
    }
}
