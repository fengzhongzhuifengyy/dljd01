package demo03_访问修饰符;

public class B {

    // 验证在同包下访问: public  protected 默认 修饰的方法和属性; 不能访问 private修饰的方法和属性
    public void m2(){
        A a = new A();
        System.out.println(a.n1 + "\t" + a.n2 + "\t" + a.n3 + "\t");
    }
}
