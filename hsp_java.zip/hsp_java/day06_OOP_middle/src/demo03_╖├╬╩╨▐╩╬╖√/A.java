package demo03_访问修饰符;

public class A {

    // 4个属性,分别用不同的修饰符
    public int n1 = 100;
    protected int n2 = 200;
    int n3 = 300;
    private int n4 = 400;


    // 演示同类下:
    public void m1(){
        // 访问4个属性
        System.out.println("n1 = " + n1 + "n2 = " + n2 + "n3 = " + n3 + "n1 = " + n4);
    }
}
