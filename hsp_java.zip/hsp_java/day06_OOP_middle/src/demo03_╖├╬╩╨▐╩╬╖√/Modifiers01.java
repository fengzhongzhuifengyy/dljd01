package demo03_访问修饰符;

// 类只能用public和默认来访问
public class Modifiers01 {
    public static void main(String[] args) {

        A a = new A();
        a.m1();

        B b = new B();
        b.m2();
    }
}
