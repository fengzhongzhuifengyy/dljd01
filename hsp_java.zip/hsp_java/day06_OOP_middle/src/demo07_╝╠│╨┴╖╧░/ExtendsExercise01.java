package demo07_继承练习;

public class ExtendsExercise01 {
    public static void main(String[] args) {
        B b = new B(); // a  b,name  b 知道默认有个super();
    }
}

class A {

    A() {
        System.out.println("a");
    } // 第二步

    A(String name) {
        System.out.println("a name");
    }
}

class B extends A {

    B() {
        this("abc"); // 先找本类的构造器  第一步(为什么无参没有super()? 因为有this())
        System.out.println("b");
    }

    B(String name) {
        // super();  // 第二步
        System.out.println("b,name"); // 第三步
    }
}
