package demo07_继承练习;

public class ExtendsExercise02 {
    public static void main(String[] args) {
        CC cc = new CC();
    }
}

class AA {//A 类

    public AA() {
        System.out.println("我是 A 类");
    }
}

class BB extends AA { //B 类,继承 A 类 //main 方法中： C c =new C(); 输出么内容? 3min
    public BB() {
        System.out.println("我是 B 类的无参构造");
    }

    public BB(String name) {
        System.out.println(name + "我是 B 类的有参构造");
    }
}

class CC extends BB { //C 类， 继承 B 类

    public CC() {
        this("hello");
        System.out.println("我是 c 类的无参构造");
    }

    public CC(String name) {
        super("hahah");
        System.out.println("我是 c 类的有参构造");
    }
}
