package com.hspedu.java.day06_面向对象中级.demo08_super;

import com.hspedu.java.day06_面向对象中级.demo05_继承.details.Base;

public class Super01 {
    public static void main(String[] args) {

        B b = new B();
        b.sum();
    }
}

class A extends Base {
    //4 个属性
    public int n1 = 100;
    protected int n2 = 200;
    int n3 = 300;
    private int n4 = 400;

    public A() {
    }

    public A(String name) {
    }

    public A(String name, int age) {
    }


    public void test100() {
    }

    protected void test200() {
    }

    void test300() {
    }

    private void test400() {
    }


    // A类的一个计算方法
    public void cal() {
        System.out.println("A类的一个cal()...");
    }
}




class B extends A {

    public int n1 = 200;

    /*
     语法一: super访问父类的属性,但是不能访问父类private的属性; super.属性名
     */
    public void hi() {
//        System.out.println(super.n1 + super.n2 + super.n3 + super.n4);
    }

    /*
        语法二: super访问父类的方法,但是不能访问父类私有的方法; super.getMethod();
     */
    public void ok() {
        super.test100();
        super.test200();
        super.test300();
//        super.test400();
    }
    /*
        语法三:super访问父类的构造器: super(形参列表),只能放在构造器的第一句,只能出现一句
     */
    // 方法不行
//    public void ok1(){
//        super(); // Call to 'super()' must be first statement in constructor body
//    }

    public B() {
//        super();
        super("jack");
    }

    // B类的一个求和方法
    public void sum(){
        System.out.println("B类的一个sum()...");
        // 希望调用父类A的cal()
        // 这时,因为子类B没有cal方法,此时有三种方法
        cal();
        /*
        子类调用方法的规则:
        找cal方法时,顺序是:先找本类,如果有则调用;如果没有,则找父类且父类cal()可以调用就去调用;如果父类也没有cal(),就去找父类的父类
        提示: 如果在查找方法的过程中,找到了,但是不能访问,则报错  cannot access
        如果查找方法的过程中,没有找到,则提示方法不存在 // Cannot resolve method 'cal' in 'B'
        */

        this.cal(); // 与cal()完全等价

        super.cal(); // 找cal()的顺序: 直接查找父类,其他的规则一样


        /* 演示访问属性的规则: */
        // 先找本类,本类有则则调用
        System.out.println(n1);
        System.out.println(this.n1);
        // 如果本类没有,则去父类找
        System.out.println(n2);
        System.out.println(this.n2);
        // 如果整个父类都没有,提示属性不存在
        // 如果属性在父类中无法访问,则也会报错
//        System.out.println(n4); // 'n4' has private access
//        System.out.println(this.n4); // 'n4' has private access

        System.out.println(super.n1); // 直接打印父类的属性n1,即使子类存在也不会访问



    }

    // 演示super.cal()
    // B类的cal()
    public void cal(){
        System.out.println("子类B的cal()...");
    }
}
