package demo06_继承的本质;

/**
 * 继承的本质
 */
public class ExtendsTheory {
    public static void main(String[] args) {

        Son son = new Son();
        // 当我们new对象时,内存的布局到底是怎样的?

        System.out.println(son.name); // 结果: 大头儿子
        // son.name到底该访问谁的属性呢?
        // 这时大家注意,要按照查找关系类返回信息
        /*
            1.首先看看子类是否有该属性
            2.如果子类有这个属性,并且可以访问,则返回信息,
            3.如果子类没有这个属性就看父类有无此属性,如果父类有该属性且可以访问,返回信息,
            4.如果父类没有就按照3的规律接着找上一级,直到object,当然都没有就报错

            5.如果父类中是私有的(age),即使祖父类有公共的(age),也会报错,因为父类是有的只是没有权限
         */


        System.out.println(son.hobby); // 结果: hobby = "旅游"

        // 私有的属性不能直接访问,但是在内存中还是开辟了age这个属性,但是不能直接访问,需要父类提供公共的方法区访问
//        System.out.println(son.age);
        System.out.println(son.getAge());

    }
}
