package demo06_继承的本质;

public class Son extends Father {
    String name = "大头儿子";
}
