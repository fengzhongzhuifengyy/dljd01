package demo06_继承的本质;

public class GrandPa {

    String name = "大头爷爷";

    String hobby = "旅游";
}
