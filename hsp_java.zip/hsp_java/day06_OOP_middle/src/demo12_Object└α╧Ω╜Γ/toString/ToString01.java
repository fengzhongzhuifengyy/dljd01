package demo12_Object类详解.toString;

public class ToString01 {
    public static void main(String[] args) {

        // toString 的源码
//        public String toString() {
        // （1）getClass().getName() 全类名(包名+类名)
        // （2）Integer.toHexString(hashCode())将对象的hashcode值转成16进制的字符串
//            return getClass().getName() + "@" + Integer.toHexString(hashCode());
//        }

        Monster monster = new Monster("小妖怪", "巡山", 1000);
        // 未重写时调用toString方法
        System.out.println(monster.toString());

        // 默认调用toString()
        System.out.println(monster);
    }
}

class Monster{

    private String name;
    private String job;
    private double salary;

    public Monster(String name, String job, double salary) {
        this.name = name;
        this.job = job;
        this.salary = salary;
    }

    // 重写toString(),输出对象的方法
    // 使用快捷键即可alt+insert

    @Override
    public String toString() { // 默认就是重写后把对象的属性输出,当然也可以改
        return "Monster{" +
                "name='" + name + '\'' +
                ", job='" + job + '\'' +
                ", salary=" + salary +
                '}';
    }
}