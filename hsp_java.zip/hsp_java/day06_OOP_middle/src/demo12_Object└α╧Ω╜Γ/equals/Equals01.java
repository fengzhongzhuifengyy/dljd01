package demo12_Object类详解.equals;

public class Equals01 {
    public static void main(String[] args) {

        /*
            1.==: 既可以判断基本数据类型,又可以判断引用数据类型
            2. ==:如果判断基本数据类型,判断的值是否相等
            3.==:如果判断的是引用数据类型,判断的是地址是否相等,即判定的是不是同一个对象
         */
        A a = new A();
        A b = a;
        A c = b;
        System.out.println(a == c);

        // 虽然编译类型是父类，但是还是可以，仅比较两个对象的地址值
        B bObj = a;
        System.out.println(bObj == c);

        /*
            1、equals是Object类中的方法，只能判断引用数据类型
            2、equals默认判断的是地址值是否相等，子类中往往重写该方法，用于判断内容是否相等（Integer 、 String）
         */
        int number1 = 10;
        double number2 = 10.0;
        System.out.println(number1 == number2);
//        System.out.println(number1.equals(number2)); // Cannot resolve method 'equals(double)'

        // equals 方法，源码怎么查看呢？
        "hello".equals("abc");


        // Object的equals源码：Object的equals()默认就是比较对象地址是否相同;也就是判断两个对象是否是同一个对象

//        public boolean equals(Object obj) {
//            return (this == obj);
//        }


        // String 的equals源码: 把Object的equals()重写,变成比较两个字符串是否相同
//        public boolean equals(Object anObject) {
//            if (this == anObject) {  // 如果是同一个对象
//                return true; // 返回 true
//            }
//            if (anObject instanceof String) { // 判断类型
//                String anotherString = (String)anObject; //向下转型
//                int n = value.length;
//                if (n == anotherString.value.length) { //如果长度相同
//                    char v1[] = value;
//                    char v2[] = anotherString.value;
//                    int i = 0;
//                    while (n-- != 0) { //然后一个一个的比较字符
//                        if (v1[i] != v2[i])
//                            return false;
//                        i++;
//                    }
//                    return true; //如果两个字符串的所有字符都相等， 则返回 true
//                }
//            }
//            return false; //如果比较的不是字符串， 则直接返回 false
//        }


        /*
            Integer的equals方法: Integer也重写了Object的equals(),用于判断两个值是否相等
         */
        /*
        public boolean equals(Object obj) {
        if (obj instanceof Integer) {
            return value == ((Integer)obj).intValue();
        }
        return false;
    }
         */

        Integer integer1 = new Integer(1000);
        Integer integer2 = new Integer(1000);
        System.out.println(integer1 == integer2); // false
        System.out.println(integer1.equals(integer2)); // true

        String str1 = new String("txl");
        String str2 = new String("txl");
        System.out.println(str1 ==str2);
        System.out.println(str1.equals(str2));
    }
}

class B{

}

class A extends B{

}




