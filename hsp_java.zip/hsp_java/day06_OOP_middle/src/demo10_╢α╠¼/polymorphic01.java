package demo10_多态;

// 先解决一个多态问题:
// 请编写一个程序,Master类中有一个feed(喂食)方法,可以完成主人给动物喂食
// 提示: Food(类)中包含Fish(类)/Bone(类); Animal(类)中包含Cat/Dog

// 传统的方法: 代码的复用性不高,不利于维护

// 多态:方法和对象有多种形态
public class polymorphic01 {
    public static void main(String[] args) {

        // 1.完成主人给小狗喂食
        Master tom = new Master("汤姆");
        Dog dog = new Dog("小黄瓜");
        Bone bone = new Bone("酱大骨");
        tom.feed(dog,bone);

        // 2.完成主人给小猫喂食
       Cat cat =  new Cat("小花猫");
       Fish fish =  new Fish("小黄鱼");
       tom.feed(cat,fish);

        // 此时,动物种类很多,食物就会很多,不利于维护
        // 提出多态(polymorphic)解决



    }
}

/**
 * 食物
 */
class Food {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Food(String name) {
        this.name = name;
    }
}

/**
 *  鱼
 */
class Fish extends Food {

    public Fish(String name) {
        super(name);
    }
}

/**
 *  骨头
 */
class Bone extends Food {
    public Bone(String name) {
        super(name);
    }

}

/**
 *  动物
 */
class Animal {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Animal(String name) {
        this.name = name;
    }
}

/**
 *  猫
 */
class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }

}

/**
 *  狗
 */
class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }
}

class Master {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Master(String name) {
        this.name = name;
    }

    // 此时会有如下喂食方法
   // // 主人给小狗喂食
   // public void feed(Dog dog, Bone bone) {
   //     System.out.println("主人" + name + " 给 " + dog.getName() + " 吃 " + bone.getName());
   // }
   //
   // // 主人给小猫喂金鱼
   // public void feed(Cat cat, Fish fish) {
   //     System.out.println("主人" + name + " 给 " + cat.getName() + " 吃 " + fish.getName());
   // }

    // 这个时候 如果小狗很多,动物很多
    // feed方法就会很多,不利于维护代码



    // 这时使用多态机制: 父类的引用指向子类
    // animal 编译类型是Animal,可以指向(接收)子类的对象
    // food 编译类型是Food,可以指向(接收)子类的对象
    public void feed(Animal animal, Food food){
        System.out.println("主人" + name + " 给 " + animal.getName() + " 吃 " + food.getName());
    }
}
