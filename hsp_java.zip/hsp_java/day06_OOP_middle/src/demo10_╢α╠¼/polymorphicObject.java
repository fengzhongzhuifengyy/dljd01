package demo10_多态;

// 对象的多态: 父类的引用指向子类的对象
/*  1.一个对象的编译类型和运行类型可以不一致,"可以不一致"潜台词: 可以一致
    2.编译类型在定义对象时,就确定了,不能改变
    3.运行类型是可以变化的
    4.编译类型看定义时"="的左边,运行类型看"="的右边
 */
public class polymorphicObject {
    public static void main(String[] args) {
        // 体验对象多态的特点: Animal是编译类型,运行类型是Dog
        Animals animals = new Dogs();
        // 因为运行到这时,Animal的运行类型是Dog,所以这个cry()就是Dog的cry()
        animals.cry(); // Dog的cry()...

        animals = new Cats();
        animals.cry(); // Cats的cry()...

    }
}

class Animals {

    public void cry() {
        System.out.println("Animals的cry()... ");
    }
}

class Cats extends Animals {

    @Override
    public void cry() {
        System.out.println("Cats的cry()...");
    }
}

class Dogs extends Animals {

    @Override
    public void cry() {
        System.out.println("Dog的cry()...");
    }
}