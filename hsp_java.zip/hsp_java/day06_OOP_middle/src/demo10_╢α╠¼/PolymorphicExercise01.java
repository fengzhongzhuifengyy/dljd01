package demo10_多态;

public class PolymorphicExercise01 {
    public static void main(String[] args) {

        double d = 13.4; // ok
        long l = (long) d; // ok

        int i = 5; //
//        boolean b = (boolean)i; // 不ok  boolean --> int


        Object obj = "hello"; // ok 向上转型
        String objStr = (String)obj; // ok 向下转型

        Object objPri = new Integer(5); // ok 向上转型
        String str = (String)objPri; // 不可以 指向Integer 的父类引用 指向String引用
        Integer str1 = (Integer)objPri; // ok 向下转型
    }
}
