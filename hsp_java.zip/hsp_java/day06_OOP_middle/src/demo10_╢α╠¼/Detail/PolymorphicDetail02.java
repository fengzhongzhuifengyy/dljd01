package demo10_多态.Detail;

public class PolymorphicDetail02 {
    public static void main(String[] args) {

        /*
            属性没有重写的说法,属性的值看编译类型
         */
        Base base = new Sub();
        System.out.println(base.count); // 10

//        System.out.println(base.name); // Cannot resolve symbol 'name'

        Sub sub = new Sub();
        System.out.println(sub.count);
    }
}


class Base{

    int count = 10;

}

class Sub extends Base{

    int count = 20;
    String name = "张三";
}