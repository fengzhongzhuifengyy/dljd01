package demo10_多态.Detail;

public class Dog extends Animal {

}
