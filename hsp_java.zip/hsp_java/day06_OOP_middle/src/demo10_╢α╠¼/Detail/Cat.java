package demo10_多态.Detail;

public class Cat extends Animal{

    @Override
    public void eat() {
        System.out.println("猫吃鱼");
    }

    public void catchMouth(){ // Cat特有的方法catchMouth
        System.out.println("猫捉老鼠");
    }
}
