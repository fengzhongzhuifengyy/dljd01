package demo10_多态.Detail;

public class PolymorphicDetail01 {
    public static void main(String[] args) {

        // 向上转型的本质: 父类型的引用指向子类
        Animal animal = new Cat();

        // 思考 是否可行? -- 可行,Object也是Cat的父类
        Object ob = new Cat();

        /*
         向上转型调用方法的规则如下:
         可以调用父类中的所有成员(需遵守访问权限),
         不能调用子类中的特有成员(方法,属性)
         */

        /* 测试调用子类特有的方法: 因为在编译阶段,能调用哪些成员(属性和方法),是由编译阶类型来决定的*/
//        animal.catchMouth(); // Cannot resolve method 'catchMouth' in 'Animal'

        /*
            最终运行效果看子类的具体实现,即调用方法时,按照从运行类型(子类)开始查找方法进行调用
         */
        animal.eat();  // 子类的方法: 猫吃鱼
        animal.run(); // 跑  发现子类没有run() --> 去父类查找且可以调用
        animal.show(); // hello,你好
        animal.sleep(); // 睡


        // 向下转型: 调用子类独有的方法 catchMouth()
        // 只能强转父类的引用,但是不能强转父类的对象
        // 父类的引用必须指向当前目标类型的对象
        // 当向下转型后,就可以调用子类类型中的所有成员

        // 语法: 子类类型 引用名 =  (子类类型) 父类引用
        /*
            1.父类的引用 --> 子类的引用
            2.那么此时编译类型是什么? 运行类型是什么? : 编译: 左侧 Cat ; 运行类型 右侧 Cat
         */
        Cat cat = (Cat) animal;
        cat.catchMouth(); // 猫捉老鼠

        /*
            3.要求: 父类的引用必须指向当前目标类型的对象  简单说: 要求animal这个引用原来就是指向cat的,之前的animal其实就是cat,所以才能向下转换
            因此 只能指向猫,不能指向狗
         */
            Dog dog = (Dog) animal; // 可以吗?  Exception in thread "main" java.lang.ClassCastException
    }
}
