package demo10_多态.Detail;

//  instance of 比较操作符
public class PolymorphicDetail03 {
    public static void main(String[] args) {

        // 用于判断对象的运行类型是否为XX类型或者XX类型的子类型
        BB bb = new BB();
        System.out.println(bb instanceof BB); // true  BB 是 BB 的类型
        System.out.println(bb instanceof AA); // true  BB 是 AA 的子类型


        // aa 的编译类型是AA 运行类型是BB
        AA aa = new BB();
        System.out.println(aa instanceof AA); // true aa(BB) 是 AA 的子类型
        System.out.println(aa instanceof BB); // true aa(BB) 是 BB 的类型

        /*
            结论 :  aa的"运行类型" BB是否是 BB/AA; 比较的是"运行类型"
         */

        Object object = new Object();
        System.out.println(object instanceof AA); // false

        String  str = "hello";
//        System.out.println(str instanceof AA); 无法比较

        System.out.println(str instanceof Object); // true


    }
}

class AA{

}

class BB extends AA{

}
