package demo10_多态;
// 方法体现多态--多种形态

public class polymorphicMethod {
    public static void main(String[] args) {

        // 方法的重载体现多态:这里我们传入不同的参数,就会调用不同的sum();
        A a = new A();
        System.out.println(a.sum(1,2));
        System.out.println(a.sum(1,2,3));
        /*
            可以看出: 我们传入不同的参数,就会调用不同的方法,就体现了多态
         */


        // 方法的重写体现多态:
        B b = new B();
        a.say();
        b.say();
    }
}


class B { //父类
    public void say() {
        System.out.println("B say() 方法被调用...");
    }
}

class A extends B {//子类

    public int sum(int n1, int n2) {//和下面 sum 构成重载
        return n1 + n2;
    }

    public int sum(int n1, int n2, int n3) {
        return n1 + n2 + n3;
    }

    public void say() {
        System.out.println("A say() 方法被调用...");
    }
}