package demo09_方法重写;

public class Dog extends Animal {
    /*
        老韩解读:
        1.因为Dog是Animal的子类
        2.Dog的cry()和Animal的cry()定义的形式一样(名称,返回值,参数);这就是重写
     */
    public void cry(){
        System.out.println("Dog发声");
    }

    /*
        细节:子类方法的返回类型和父类方法的返回类型一样,或者是父类返回类型的子类
     */
    // public Object m1(){
    //     return null;
    // }

   public String m1(){
       return "null";
   }

    // attempting to use incompatible return type
//    public Object m2(){
//        return null;
//    }

    /*
        细节:子类方法不能缩小父类方法的权限
     */
    //  attempting to assign weaker access privileges ('package-private'); was 'public'
//    Object m1(){
//        return null;
//    }
}
