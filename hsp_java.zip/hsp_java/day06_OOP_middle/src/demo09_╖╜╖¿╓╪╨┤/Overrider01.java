package demo09_方法重写;

public class Overrider01 {
    public static void main(String[] args) {

        // 演示方法重写的情况
        Dog dog = new Dog();

        dog.cry();
    }

}

