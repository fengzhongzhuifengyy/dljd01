package demo09_方法重写;

public class Animal {

    public void cry() {
        System.out.println("动物叫");
    }

    public Object m1() {
        return null;
    }

    public String m2(){
        return "";
    }
}
