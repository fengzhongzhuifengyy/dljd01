package demo09_方法重写;

public class Person {

    private String name;
    private int age;

    public Person(){

    }

    public Person(String name, int age){
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


    // say()
    public String say(){
        return "我的名称: " + getName() + " 我的年龄: " + getAge();
    }
}
