package demo11_多态的应用.多态数组;

// 多态数组:数组的定义类型是父类类型,但是里面实际保存的对象是子类类型

// 要求如下:要求创建一个Person对象,2个Student对象和2个Teacher对象,统一放在一个数组中,并调用每个数组的say()
public class PloymorphicArray {
    public static void main(String[] args) {

        // 创建父类的对象和引用,这里可以存放子类的对象
        Person[] person = new Person[5];
        person[0] = new Person("jack", 18);
        person[1] = new Student("susan", 19, 98.3);
        person[2] = new Student("tom", 20, 89.1);
        person[3] = new Teacher("smith", 45, 5000);
        person[4] = new Teacher("king", 40, 4000);

        // 循环遍历调用say()
        for (int i = 0; i < person.length; i++) {
            // 编译类型是Person, 运行类型是根据实际对象由jvm机调用(运行类型)
            System.out.println(person[i].say()); // 这里就是动态绑定机制
        }

        System.out.println("==========================================");

        // 如何调用子类独有的方法呢? instanceof
        for (int i = 0; i < person.length; i++) {

            if(person[i] instanceof Student){
                Student student = (Student)person[i];
                student.study();

            }else if (person[i] instanceof Teacher){
                Teacher teacher = (Teacher)person[i];
                teacher.teacher();
            } else if (person[i] instanceof  Person){
                // 不做处理
            }else{
                System.out.println("您的数组类型有误");
            }
        }
    }
}


