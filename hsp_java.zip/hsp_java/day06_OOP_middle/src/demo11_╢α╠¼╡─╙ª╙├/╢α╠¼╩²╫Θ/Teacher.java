package demo11_多态的应用.多态数组;

public class Teacher extends Person {

    private double salary;

    public Teacher(String name, int age, double salary){
        super(name,age);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String say(){
        return super.say() + " 薪水:" + salary;
    }

    public void teacher(){
        System.out.println("老师" + getName() + "正在授课java");
    }
}
