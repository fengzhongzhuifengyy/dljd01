package demo11_多态的应用.多态参数;

public class Worker extends Employee {

    public Worker(String name, double salary) {
        super(name, salary);
    }

    public void work(){
        System.out.println("普通员工" + getName() + "正在工作");
    }

    // 因为普通员工没有其他的收入,则直接调用父类的方法
    public double getAnnual(){
        return super.getAnnual();
    }
}
