package demo11_多态的应用.多态参数;

public class Test {
    public static void main(String[] args) {

        Worker worker = new Worker("tom", 2500);
        Manager manager = new Manager("milan", 5000, 20000);

        Test test = new Test();
        test.showEmpAnnual(worker);
        test.showEmpAnnual(manager);
        test.testWork(worker);
        test.testWork(manager);

    }

    // 获取任何员工的年薪
    public void showEmpAnnual(Employee em) {
        System.out.println(em.getAnnual()); // 动态绑定机制
    }

    // 添加一个方法， testWork,如果是普通员工， 则调用 work 方法， 如果是经理， 则调用 manage 方法
    public void testWork(Employee em) {
        if (em instanceof Worker) {
            ((Worker) em).work(); // 向下转型获取子类独有的方法
        } else if (em instanceof Manager) {
            ((Manager) em).manage(); // 向下转型获取子类独有的方法
        } else {
            System.out.println("不做处理");
        }

    }
}
