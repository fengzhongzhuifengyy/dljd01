package homework;

// 现有Person类,里面有方法run eat Student类继承了Person类,并重写了run();自定义study(),
// 试写出对象向上转型和向下转型的代码,并写出各自都可以调用那些方法,并写出方法输出什么
public class Homework10 {
    public static void main(String[] args) {

        Person person = new Student();
        person.run(); // student run
        person.eat(); // person eat

        Student student = (Student)person;
        student.study(); // student study
        student.run(); // student run
    }
}

class Person{
    public void run(){
        System.out.println("person run");
    }

    public void eat(){
        System.out.println("person eat");
    }
}

class Student extends Person{
    public void run(){
        System.out.println("student run");
    }
    public void study(){
        System.out.println("student study");
    }
}