package homework;

// 编写Doctor类{name, age, job, gender, sal}
// 相应的get,set方法,5个参数的构造器,重写父类对象(Object)的equals方法
// public boolean equals(Object obj),并判断测试类中创建的两个对象是否相等
public class Homework09 {
    public static void main(String[] args) {
        Doctor doctor1 = new Doctor("张三", 19, "和尚", "男", 20000);
        Doctor doctor2 = new Doctor("张三", 19, "和尚", "男", 20000);

        if (doctor1.equals(doctor2)) {
            System.out.println("两个对象相等");
        } else {
            System.out.println("两个对象不相等");
        }

    }
}

class Doctor {

    private String name;
    private int age;
    private String job;
    private String gender;
    private double sal;

    public Doctor(String name, int age, String job, String gender, double sal) {
        setName(name);
        setAge(age);
        setJob(job);
        setGender(gender);
        setSal(sal);

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public double getSal() {
        return sal;
    }

    public void setSal(double sal) {
        this.sal = sal;
    }

    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }
        if (obj instanceof Doctor) {
            return name.equals(((Doctor) obj).getName())
                    && age == ((Doctor) obj).getAge()
                    && job.equals(((Doctor) obj).getJob())
                    && gender.equals(((Doctor) obj).getGender())
                    && sal == ((Doctor) obj).getSal();
        }
        return false;
    }
}
