package homework;

// 扩展如下的BankAccount类
// 要求:
// 1)在上面类的基础上扩展新类CheckingAccount,对每次存款和取款都收取1元手续费
// 2)扩展前一个练习的BankAccount类,新类SavingAccount每个月都有利息产生(earnMonthlyInterest方法被调用),并且每月三次免手续费的存款或取款,
// 在earnMonthlyInterest方法中重置交易次数
// 3) 体会重写的好处
public class Homework07 {
    public static void main(String[] args) {

        CheckingAccount checkingAccount = new CheckingAccount(1000);
        checkingAccount.deposit(10);
        System.out.println(checkingAccount.getBalance());
        checkingAccount.withdraw(900);
        System.out.println(checkingAccount.getBalance());

        SavingAccount savingAccount = new SavingAccount(500);
        savingAccount.deposit(100);
        savingAccount.deposit(100);
        savingAccount.deposit(100);
        System.out.println(savingAccount.getBalance()); // 800
        savingAccount.deposit(100);
        System.out.println(savingAccount.getBalance()); // 899

        // 月初,定时器自动调用一下earnMonthlyInterest()
        savingAccount.earnMonthlyInterest();
        System.out.println(savingAccount.getBalance()); // 907.99
        savingAccount.withdraw(100);
        System.out.println(savingAccount.getBalance()); // 807.99
    }
}

class BankAccount {

    private double balance;

    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    // 存款
    public void deposit(double amount) {
        balance += amount;
    }

    // 取款
    public void withdraw(double amount) {
        balance -= amount;
    }

    // set 和getBalance()

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}

class CheckingAccount extends BankAccount {

    public CheckingAccount(double initialBalance) {
        super(initialBalance);
    }

    @Override
    public void deposit(double amount) {
        super.deposit(amount - 1);
    }

    @Override
    public void withdraw(double amount) {
        super.withdraw(amount - 1);
    }
}

class SavingAccount extends BankAccount {

    private double rate = 0.01;

    private int count = 3;

    public SavingAccount(double initialBalance) {
        super(initialBalance);
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getRate() {
        return rate;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    // 利息
    public void earnMonthlyInterest() {
        // 每个月初,我们统计上个月的利息,并且将count置成3
        count = 3;
        super.deposit(getBalance() * getRate());
    }

    @Override
    public void deposit(double amount) {
        if (count > 0) {
            super.deposit(amount);
        } else {
            super.deposit(amount - 1);
        }
        count--;
    }

    @Override
    public void withdraw(double amount) {
        if (count > 0) {
            super.withdraw(amount);
        } else {
            super.withdraw(amount -1);
        }
        count--;
    }


}