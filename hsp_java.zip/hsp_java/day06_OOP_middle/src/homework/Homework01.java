package homework;

// 定义一个Persons类{name, age, job},初始化Person对象数组,有3个person对象,并按照age从大到小进行排序,提示:使用冒泡排序
public class Homework01 {
    public static void main(String[] args) {

        Persons[] persons = new Persons[3];
        persons[0] = new Persons("jack", 15, "student");
        persons[1] = new Persons("rose", 10, "boy");
        persons[2] = new Persons("tom", 30, "teacher");

        System.out.println("排序前的效果");
        for (int i = 0; i <persons.length ; i++) {
            System.out.println(persons[i]); // 当我们直接输出一个对象时，会默认调用toString方法,我们对toSting进行重写
        }

        // age进行排序
        Persons temp = null;
        for (int i = 0; i < persons.length -1 ; i++) {

            for (int j = 0; j < persons.length -1 - i; j++) {
            //要求按照名字的长度从小到大 if(persons[i].getName().length() > persons[i+1].getName().length())
                if (persons[j].getAge() < persons[j+1].getAge()){
                    temp = persons[j];
                    persons[j] = persons[j+1];
                    persons[j+1] = temp;
                }
            }
        }

        System.out.println("排序后的效果");
        for (int i = 0; i <persons.length ; i++) {
            System.out.println(persons[i]); // 当我们直接输出一个对象时，会默认调用toString方法,我们对toSting进行重写
        }


    }
}

class Persons {

    private String name;
    private int age;
    private String job;

    public Persons(String name, int age, String job) {
        this.name = name;
        this.age = age;
        this.job = job;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getJob() {
        return job;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setJob(String job) {
        this.job = job;
    }

    @Override
    public String toString() {
        return "Persons{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", job='" + job + '\'' +
                '}';
    }
}
