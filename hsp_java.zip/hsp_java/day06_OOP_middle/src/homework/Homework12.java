package homework;

// getClass()
public class Homework12 {
    public static void main(String[] args) {
        A a = new B();
        System.out.println("a的运行类型=" + a.getClass());
        a = new C();
        System.out.println("a的运行类型=" + a.getClass());
    }


}

class A{}

class B extends A{}

class C extends B{}