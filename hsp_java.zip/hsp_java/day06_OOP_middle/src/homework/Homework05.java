package homework;

// 假定Grand Father Son在同一个包内,问:父类和子类通过this和super都可以调用那些属性和方法
public class Homework05 {
}

class Grand {

    String name  = "AA";
    private int age = 100;

    public void g1() {
    }

}

class Father extends Grand {

    String id = "001";
    private double score;

    public void f1() {
        // super可以访问那些成员? super.name; super.g1();
        // super.name; super.g1();

        // this可以访问那些成员? 从子类开始找
        // this.id, this.score, this.name, this.g1();
    }
}

class Son extends Father {

    String name = "BB";

    public void g1() {

    }

    private void show(){
        // super可以访问那些成员?
        // super.id; super.f1();super.name; super.g1();

        // this可以访问那些成员?
        // this.name; this.g1(); this.show(); this.id; this.f1();
    }
}