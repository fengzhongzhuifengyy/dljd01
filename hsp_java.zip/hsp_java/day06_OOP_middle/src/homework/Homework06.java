package homework;

public class Homework06 {

    public static void main(String[] args) {
        new Demo().test(); // Test Demo rose jack
        new Demo("john").test(); // john Jack
    }
}

class Test {

    String name = "rose";

    Test() {
        System.out.println("Test");
    }

    Test(String name) {
        this.name = name; // 这里把父类的name 修改为 john
    }
}

class Demo extends Test {

    String name = "Jack";

    Demo() {
        super();
        System.out.println("Demo");

    }

    Demo(String s) {
        super(s);
    }

    public void test() {
        System.out.println(super.name);
        System.out.println(this.name);
    }
}
