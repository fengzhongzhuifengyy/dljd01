package homework;

// 设计父类 - 员工类,子类:工人类(Worker),农民(Peasant), 教师类(Teacher),科学家类(Scientist),服务生类(Waiter)
// 其中工人,农民,服务生只有基本工资 sal
// 教师除基本工资外还有课酬(元/天) classDay, classSal
// 科学家除基本工资外还有年终奖 bonus
// 编写一个测试类,将各个类型的员工的全年工资打印出来
public class HomeWork04 {
    public static void main(String[] args) {

        Employee1[] em = new Employee1[5];

        em[0] = new Worker1("工人", 1000);
        em[1] = new Peasant("农民",500);
        em[2] = new Teacher1("老师",2000,150, 100);
        em[3] = new Scientist("科学家", 5000, 50000);
        em[4] = new Waiter("服务员", 4000);

        for (int i = 0; i < em.length ; i++){

            if (em[i] instanceof Worker1){

                System.out.println("工人的年收入" + ((Worker1)em[i]).printYearSalary()); //考虑代码的健壮还是加上转型,防止后面有自己属性

            }else if(em[i] instanceof Peasant){

                System.out.println("农民的年收入" + ((Peasant)em[i]).printYearSalary());

            }else if (em[i] instanceof Teacher1){

                System.out.println("教师的年收入" + ((Teacher1)em[i]).printYearSalary());

            }else if (em[i] instanceof Scientist){

                System.out.println("科学家的年收入" + ((Scientist)em[i]).printYearSalary());

            }else if(em[i] instanceof Waiter){

                System.out.println("服务员的年收入" + ((Waiter)em[i]).printYearSalary());
            }else {
                System.out.println("您输入的类型不合法");
            }
        }
    }
}

class Employee1{

    private String name;

    private double salary;

    // 带薪的月份,后面可以自己setMouthSal
    private int mouthSal = 12;

    public Employee1(String name, double salary){
        this.name = name;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getMouthSal() {
        return mouthSal;
    }

    public void setMouthSal(int mouthSal) {
        this.mouthSal = mouthSal;
    }

    public double printYearSalary(){
        return getSalary() * getMouthSal();
    }
}

class Worker1 extends Employee1{

    public Worker1(String name, double salary) {
        super(name, salary);
    }


}

class Peasant extends Employee1{

    public Peasant(String name, double salary) {
        super(name, salary);
    }
}

class Waiter extends Employee1{
    public Waiter(String name, double salary) {
        super(name, salary);
    }
}

class Scientist extends Employee1{

    private double bonus;
    public Scientist(String name, double salary,double bonus) {
        super(name, salary);
        this.bonus = bonus;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public double printYearSalary() {
        return super.printYearSalary() + getBonus() * 12;
    }
}

class Teacher1 extends Employee1{

    private int classDay;

    private double classSal;

    public Teacher1(String name, double salary, int classDay, double classSal) {
        super(name, salary);
        this.classDay = classDay;
        this.classSal = classSal;
    }

    public int getClassDay() {
        return classDay;
    }

    public void setClassDay(int classDay) {
        this.classDay = classDay;
    }

    public double getClassSal() {
        return classSal;
    }

    public void setClassSal(double classSal) {
        this.classSal = classSal;
    }

    @Override
    public double printYearSalary() {
        return super.printYearSalary() + getClassDay() * getClassSal();
    }
}