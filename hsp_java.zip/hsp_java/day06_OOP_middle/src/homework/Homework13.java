package homework;
// 打印如下效果:
// 老师的信息:
// 姓名: 张飞
// 年龄: 30
// 性别: 男
// 工龄: 5
// 我承诺我会认真教学
// 张飞爱玩象棋
// ----------------
// 学生的信息:
// 姓名: 小明
// 年龄: 15
// 性别: 男
// 学号: 00023102
// 我承诺我会好好学习
// 小明爱玩足球

// 实现面向对象编程

/**
 * 方法的调用: 同一个类中 静态的调非静态的方法;或者 非静态的调静态的方法都需要new对象
 */
public class Homework13 {
    public static void main(String[] args) {

        Person1 person1 = new Student1("张三", '男', 15, "122456");
        person1.printMessage();
        System.out.println("--------------");
        Person1 person2 = new Teacher2("李四", '男', 35, 15);
        person2.printMessage();
        System.out.println("----------------------------------------------------");

        Person1[] pe = new Person1[4];
        pe[0] = new Student1("学生1", '男', 18, "123");
        pe[1] = new Student1("学生2", '女', 15, "456");
        pe[2] = new Teacher2("老师1", '男', 35, 10);
        pe[3] = new Teacher2("老师2", '女', 25, 5);

        Homework13 homework13 = new Homework13();
        homework13.sort1(pe);
        homework13.show(pe);

    }

    public void sort1(Person1[] pe) {

        for (int i = 0; i < pe.length - 1; i++) {

            for (int j = 0; j < pe.length - 1 - i; j++) {

                if (pe[j].getAge() < pe[j + 1].getAge()) {
                    Person1 temp = pe[j];
                    pe[j] = pe[j + 1];
                    pe[j + 1] = temp;
                }
            }
        }

        for (int i = 0; i < pe.length; i++) {
            System.out.println(pe[i] + " ");
        }

    }



    public void show(Person1[] pe) {
        for (int i = 0; i < pe.length; i++) {

            if (pe[i] instanceof Student1) {
                ((Student1) pe[i]).study();
            } else if (pe[i] instanceof Teacher2) {
                ((Teacher2) pe[i]).teach();
            } else if (pe[i] instanceof Person1) {

            } else {
                System.out.println("您输入的类型不准确");
            }
        }

    }
}


class Person1 {
    private String name;
    private char sex;
    private int age;

    public Person1(String name, char sex, int age) {
        this.name = name;
        this.sex = sex;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String play() {
        return getName() + "爱玩";
    }

    public void printMessage() {
        System.out.println(getName() + "的信息如下: ");
        System.out.println("姓名: " + getName());
        System.out.println("年龄: " + getAge());
        System.out.println("性别: " + getSex());
    }

    @Override
    public String toString() {
        return "Person1{" +
                "name='" + name + '\'' +
                ", sex=" + sex +
                ", age=" + age +
                '}';
    }
}

class Student1 extends Person1 {

    private String stu_id;

    public Student1(String name, char sex, int age, String stu_id) {
        super(name, sex, age);
        this.stu_id = stu_id;
    }

    public String getStu_id() {
        return stu_id;
    }

    public void setStu_id(String stu_id) {
        this.stu_id = stu_id;
    }

    public void study() {
        System.out.println("我承诺,我会好好学习");
    }

    public String play() {
        return super.play() + "游戏";
    }

    public void printMessage() {
        super.printMessage();
        System.out.println("学号: " + getStu_id());
        study();
        System.out.println(play());
    }

    @Override
    public String toString() {
        return "Student1{" +
                "stu_id='" + stu_id + '\'' +
                '}' + super.toString();
    }
}

class Teacher2 extends Person1 {

    private int work_age;

    public Teacher2(String name, char sex, int age, int work_age) {
        super(name, sex, age);
        this.work_age = work_age;
    }

    public int getWork_age() {
        return work_age;
    }

    public void setWork_age(int work_age) {
        this.work_age = work_age;
    }

    public void teach() {
        System.out.println("我承诺,我会好好教学");
    }

    public String play() {
        return super.play() + "象棋";
    }

    public void printMessage() {
        super.printMessage();
        System.out.println("工龄: " + getWork_age());
        teach();
        System.out.println(play());
    }

    @Override
    public String toString() {
        return "Teacher2{" +
                "work_age=" + work_age +
                '}' + super.toString();
    }
}
