package homework;

// 通过继承实现员工工资核算打印功能:
// 父类 : 员工类(Employee)
// 子类 : 部门经理类(Manager), 普通员工类(Worker)
// 1) 部门经理工资 = 1000 + 单日工资 * 天数 * 等级(1.2) ==> 奖金 + 基本工资
// 2) 普通员工工资 = 单日工资 * 天数 * 等级(1.0) ==> 基本工资
// 3) 员工属性: 姓名 ,单日工资, 工作天数
// 4) 员工方法: (打印工资)
// 5) 普通员工及部门经理都是员工子类,需要重写打印工资方法
// 6) 定义初始化普通员工对象,调用打印工资方法输出工资,定义并初始化部门经理对象,调用打印工资方法输出工资
public class Homework03 {
    public static void main(String[] args) {

        Worker worker = new Worker(300, 20, "张三", 1.0);

        System.out.println("普通工人" + worker.getName() + "的工资" + worker.wage());

        Manager manager = new Manager(500, 20, "经理", 1.2);
        manager.setBonus(1000);

        System.out.println("经理" + manager.getName() + "的工资" + manager.wage());

    }
}


class Employee{

    private double salary;

    private int workday;

    private String name;

    private double grade;

    public Employee(double salary, int workday, String name, double grade){

        this.salary = salary;
        this.workday = workday;
        this.name = name;
        this.grade = grade;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getWorkday() {
        return workday;
    }

    public void setWorkday(int workday) {
        this.workday = workday;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }
    // 工资
    public double wage(){
        return getSalary() * getWorkday();
    }
}


class Manager extends Employee{

    private double bonus;

    public Manager(double salary, int workday, String name, double grade) {
        super(salary, workday, name, grade);

    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public double wage(){
        return super.wage() + getBonus();
    }
}

class Worker extends Employee{

    public Worker(double salary, int workday, String name, double grade) {
        super(salary, workday, name, grade);
    }


}