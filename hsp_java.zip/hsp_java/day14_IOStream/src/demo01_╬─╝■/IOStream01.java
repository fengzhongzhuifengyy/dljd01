package demo01_文件;


import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * 演示 文件的创建
 * 请在E盘下,创建文件 news1.txt news2.txt news3.txt,用三种方式创建
 */
public class IOStream01 {
    public static void main(String[] args) {

    }

    //方式1 new File(String pathname) //根据文件路径构建一个File对象
    @Test
    public void createFile1() {
        String filepath = "E:\\news1.txt";
        File file = new File(filepath);//只是在java程序中 内存中开辟文件空间只是java对象而已

        try {
            file.createNewFile();//只有执行的createNewFile才会真正的在磁盘创建该文件
            System.out.println("创建文件1成功");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //方式2: new File(File pathname, String child) //根据父文件目录 + 子路径 构建
    @Test
    public void createFile2() {
        File file = new File("E:\\", "news2.txt");
        try {
            file.createNewFile();
            System.out.println("创建文件成功");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //方式3: new File(String parent, String child)
    @Test
    public void createFile3() {
        String parent = "E:\\";
        String child = "news3.txt";
        File file = new File(parent, child);
        try {
            file.createNewFile();
            System.out.println("创建文件成功");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
