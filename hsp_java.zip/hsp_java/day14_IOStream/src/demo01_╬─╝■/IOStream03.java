package demo01_文件;


import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * 目录的操作和文件的删除
 */
public class IOStream03 {
    public static void main(String[] args) {

    }

    //判断e:\news1.txt是否存在,如果存在就删除
    @Test
    public void m1() {
        String filepath = "e:\\news1.txt";
        File file = new File(filepath);
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (file.exists()) {
            System.out.println("文件存在");
            if (file.delete()) {
                System.out.println("删除成功");
            } else {
                System.out.println("删除失败");
            }
        } else {
            System.out.println("该文件不存在");
        }
    }

    //判断 e:\demo02 是否存在,存在就删除,否则提示不存在
    //目录也被当做文件
    @Test
    public void m2() {
        String filepath = " e:\\demo02";
        File file = new File(filepath);
        // try {
        //     file.createNewFile();
        // } catch (IOException e) {
        //     e.printStackTrace();
        // }
        if (file.exists()) {
            System.out.println("目录存在");
            if (file.delete()) {
                System.out.println("删除成功");
            } else {
                System.out.println("删除失败");
            }
        } else {
            System.out.println("该目录不存在");
        }
    }

    //判断e:\demo\a\b\c 目录是否存在,不存在创建
    @Test
    public void m3() {
        String filepath = "e:\\demo\\a\\b\\c";
        File file = new File(filepath);
        if (file.exists()) {
            System.out.println("目录存在");
        } else {
            System.out.println("该目录不存在");

            if (file.mkdirs()) {//这里要使用 mkdirs() 方法:创建多级目录
                System.out.println("目录创建成功");
            } else {
                System.out.println("目录创建失败");
            }
        }

    }

}

