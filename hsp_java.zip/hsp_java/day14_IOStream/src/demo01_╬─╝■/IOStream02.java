package demo01_文件;


import org.junit.Test;

import java.io.File;

/**
 *  获取文件信息
 */
public class IOStream02 {
    public static void main(String[] args) {

    }

    @Test
    public void info(){

        //先创建文件对象
        File file = new File("e:\\通讯录.txt");
        //这里不创建也可以,从内存获取
        // try {
        //     file.createNewFile();
        // } catch (IOException e) {
        //     e.printStackTrace();
        // }

        //调用相应的方式获取文件信息
        //1.getName():获取文件名称
        String name = file.getName();
        System.out.println("文件名称: " + name); //文件名称: 通讯录.txt

        //2.getAbsolutePath():获取文件绝对路径
        String absolutePath = file.getAbsolutePath();
        System.out.println("文件的绝对路径: " + absolutePath );//文件的绝对路径: e:\通讯录.txt

        //3.getParent(): 获取文件父级路径
        String parent = file.getParent();
        System.out.println("文件父级路径" + parent); //e:\

        //4.length(): 获取文件的大小,按照字节来计算
        long length = file.length();
        System.out.println("文件大小(字节): " + length); //文件长度: 0

        //5.isFile(): 判断是否是文件
        boolean file1 = file.isFile();
        System.out.println("是否是文件: " + file1);//是否是文件: true

        //6.isDirectory() : 判断是否是目录
        boolean directory = file.isDirectory();
        System.out.println("是否是目录: " + directory); //是否是目录: false

        //7.exists(): :判断文件是否存在
        boolean exists = file.exists();
        System.out.println("文件是否存在: " + exists); //文件是否存在: true
    }
}
