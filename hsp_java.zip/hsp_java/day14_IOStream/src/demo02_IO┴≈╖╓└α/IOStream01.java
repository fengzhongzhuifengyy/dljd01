package demo02_IO流分类;


import org.junit.Test;

import java.io.FileInputStream;
import java.io.IOException;

/**
 *  演示 FileInputStream 的使用: 字节输入流 : 文件-> 程序
 *  单个字节的读取,效率低
 *  -> 使用read(byte[] b) 重写读取
 */
public class IOStream01 {
    public static void main(String[] args) {


    }

    //要求:请使用 FileInputStream 读取 hello.txt 文件，并将文件内容显示到控制台
    @Test
    public void readFile01(){
        String filepath = "E:\\hello.txt";
        int readData = 0;
        FileInputStream fileInputStream = null;
        try {
            //创建FileInputStream对象用于读取文件内容
            fileInputStream = new FileInputStream(filepath);
            // read():从该输入流读取一个字节的数据。 如果没有输入可用，此方法将阻止。
            // 数据的下一个字节，如果达到文件的末尾， -1表示读取完毕。
            // 返回一个字节的int值
            while ((readData = fileInputStream.read()) != -1){
                System.out.print((char)readData);//需要转成char来输出
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            //关闭文件流,释放资源
            try {
                fileInputStream.close();
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    //读取文件方式2 效率优化
    @Test
    public void readFile02(){
        String filepath = "E:\\hello.txt";
        int readLength= 0;
        FileInputStream fileInputStream = null;
        byte[] bytes = new byte[5];
        try {
            //创建FileInputStream对象用于读取文件内容
            fileInputStream = new FileInputStream(filepath);
            // read(byte[] b):从该输入流读取最多b.length字节的数据到字节数组。 此方法将阻塞，直到某些输入可用。
            // 读入缓冲区的总字节数，如果没有更多的数据，因为文件的结尾已经到达， -1 。
            // 如果读取正常, 返回实际读取的(一组)字节数 int(一组进行计算)
            while ((readLength = fileInputStream.read(bytes)) != -1){
                //将读取到的字节的 0-readLength 转成String输出
                System.out.print(new String(bytes, 0, readLength));

            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            //关闭文件流,释放资源
            try {
                fileInputStream.close();
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
