package demo02_IO流分类;

import java.io.FileWriter;
import java.io.IOException;

/**
 * 使用 FileWriter 将 “风雨之后，定见彩虹” 写入到 note.txt 文件中, 注意细节.
 */
public class IOStream05 {
    public static void main(String[] args) {

        String content = "风雨之后，定见彩虹";
        String filepath = "e:\\note.txt";
        FileWriter fileWriter = null;

        try {
            fileWriter = new FileWriter(filepath);

            //1.1 writer(String s): 直接写入字符串
            fileWriter.write(content);//风雨之后，定见彩虹

            //1.2 writer(int a): 写入单个字符
            fileWriter.write('H');//风雨之后，定见彩虹H

            //1.3 write(char[] c): 写入char[]
            char[] chars = content.toCharArray();
            fileWriter.write(chars); //风雨之后，定见彩虹H风雨之后，定见彩虹

            //1.4 writer(char[] c, off, len): 写入char[]的指定部分
            fileWriter.write(chars, 0, 4); //风雨之后，定见彩虹H风雨之后，定见彩虹风雨之后

            //1.5 writer(String, off, len) : 写入String的指定部分
            fileWriter.write(content, 4, content.length()-4); //风雨之后，定见彩虹H风雨之后，定见彩虹风雨之后，定见彩虹

        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (fileWriter != null){
                try {
                    // FileWriter使用后,必须要关闭(close) 或 刷新(flush),否则写入不到指定的文件
                    //关闭文件流 =  flush + 关闭
                    fileWriter.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
