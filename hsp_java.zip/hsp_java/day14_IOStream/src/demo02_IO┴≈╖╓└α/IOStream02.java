package demo02_IO流分类;


import org.junit.Test;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 演示 FileOutputStream的使用:
 */
public class IOStream02 {
    public static void main(String[] args) {

    }

    //要求:请使用 FileOutputStream 在 a.txt 文件，中写入 “hello，world”. [老师代码演示], 如果文件不存在，会创建文件(注意：前提是目录已经存在.)
    @Test
    public void writeFile() {
        String filepath = "e:\\1.txt";
        //创建 FileOutputStream 对象
        FileOutputStream fileOutputStream = null;
        try {
            // write(int b) 将指定的字节写入此文件输出流。
            fileOutputStream = new FileOutputStream(filepath);//【H】
            // fileOutputStream = new FileOutputStream(filepath,true);//【H】 这种是追加文件,不是覆盖文件
            fileOutputStream.write('H');//只写一个字节

            //写入一个字符串: write(byte[] b) : 将 b.length个字节从指定的字节数组写入此文件输出流。
            String str = "hello,world";
            fileOutputStream.write(str.getBytes(StandardCharsets.UTF_8)); //getBytes() 把字符串 -> byte[] 【Hhello,world】

            //write(byte[] b, int off, int len): 将 len字节从位于偏移量 off的指定字节数组写入此文件输出流。
            fileOutputStream.write(str.getBytes(), 0, 3); //【Hhello,worldhel】

            /*
                说明:
                针对 new FileOutputStream(String name) 每次运行时时为覆盖
                所以: new FileOutputStream(String name, true) 每次运行为追加
             */
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

