package demo02_IO流分类;


import org.junit.Test;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 综合演示 FileInputStream 和 FileOutputStream
 */
public class IOStream03 {
    public static void main(String[] args) {

    }

    //要求: 编程完成图片/音乐 的拷贝
    /*
        分析:
        1.创建文件的输入流,将文件读入到程序
        2.创建文件的输出流,将得到的程序输出到文件
     */
    @Test
    public void copyFile() {
        FileInputStream fileInputStream = null;
        FileOutputStream fileOutputStream = null;
        String oldFilepath = "E:\\2.png";
        String newFilepath = "E:\\3.png";

        try {
            //核心思想: 边读边写
            byte[] bytes = new byte[10 * 1024];
            fileInputStream = new FileInputStream(oldFilepath);
            fileOutputStream = new FileOutputStream(newFilepath);
            int readLength = 0;
            while ((readLength = fileInputStream.read(bytes)) != -1) {
                fileOutputStream.write(bytes, 0, readLength);
            }
            System.out.println("拷贝ok");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
