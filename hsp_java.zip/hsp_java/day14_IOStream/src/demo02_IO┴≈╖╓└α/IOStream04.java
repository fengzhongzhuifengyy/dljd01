package demo02_IO流分类;

import java.io.FileReader;
import java.io.IOException;

/**
 *  演示 FileReader 和 FileWriter的使用;
 *
 *  使用 FileReader 从 1.txt 读取内容，并显示
 */
public class IOStream04 {
    public static void main(String[] args) {
        String filepath = "e:\\1.txt";
        FileReader fileReader = null;
        int data = 0;
        char[] buf = new char[10];
        int dataLen = 0;
        //1.创建FileReader对象
        try {
            fileReader = new FileReader(filepath);
            //1.1 read():单个字符读取
            // while ((data =  fileReader.read()) != -1){
            //     System.out.print((char)data);
            // }

            //1.2 read(char[] c):使用字符数组来实现,返回为实际读取到的字符数,返回-1表示读取为空文件结束
            // while ((dataLen = fileReader.read(buf)) != -1){
            //     System.out.print(new String(buf,  0, dataLen));
            // }

        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (fileReader != null){
                try {
                    fileReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}
