package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 *  使用ObjectInputStream 读取data.dat 并反序列化恢复数据
 */
public class IOStream07 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {

        String filepath = "e:\\data.dat";
        ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(filepath));
        //反序列化的顺序需要和你保存数据(序列化)的顺序一致,否则异常
        System.out.println(objectInputStream.readInt()); //100
        System.out.println(objectInputStream.readBoolean());//true
        System.out.println(objectInputStream.readChar());//a
        System.out.println(objectInputStream.readDouble());//9.5
        System.out.println(objectInputStream.readUTF());//123456
        Object object = objectInputStream.readObject();//Dog{name='张三', age=10, color='null', nation='null'}
        System.out.println(object);
        System.out.println(object.getClass());//class com.hspjava.day14_IO流.demo03_节点流和处理流.Dog

        /*
            这里有特别的重要的细节---针对readObject():
            如果重写Dog类的toString(), get/set()
            如果我们希望调用Dog类的相关方法,需要向下转型
            例如下面两句
         */
            Dog dog = (Dog)object;
            dog.getName();
        /*
            重点就是 我们需要能够有权限引用此对象包,
            如果重新写对象包放入新的路径,也要注意序列化之前的包和反序列化后的包路径一致, 即需要重新序列化
         */

        // 关闭外层流
        objectInputStream.close();

    }
}
