package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.Serializable;

public class Master implements Serializable {
}
