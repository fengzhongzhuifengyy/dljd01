package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *  使用BufferedWriter将"hello,李焕英"写入到文件中
 */
public class IOStream03 {
    public static void main(String[] args) {
        String content = "hello,李焕英";
        String filepath = "E:\\1.txt";
        BufferedWriter bufferedWriter = null;
        //创建对象
        try {
            bufferedWriter = new BufferedWriter(new FileWriter(filepath));//节点流传入new FileWriter(filepath, true)也可以表示追加
            //写入
            bufferedWriter.write(content);
            bufferedWriter.newLine();//插入一个和系统相关的换行符
            // bufferedWriter.write(content);
            // bufferedWriter.write(content);//此时是向后拼接,一般可以加个换行


        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
