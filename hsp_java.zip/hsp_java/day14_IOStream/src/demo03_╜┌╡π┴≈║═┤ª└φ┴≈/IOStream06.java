package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * 演示 ObjectOutputStream的使用,完成数据的序列化
 */
public class IOStream06 {
    public static void main(String[] args) throws IOException {
        //序列化后保存的文件格式不是纯文本,而是按照规定的格式来保存
        String filepath = "e:\\data.dat";

        ObjectOutputStream objectOutputStream = null;
        objectOutputStream = new ObjectOutputStream(new FileOutputStream(filepath));

        //序列化数据放入
        objectOutputStream.writeInt(100);// int -> Integer -> 实现Serializable
        objectOutputStream.writeBoolean(true);// boolean -> Boolean -> 实现Serializable
        objectOutputStream.writeChar('a');// char -> Character -> 实现Serializable
        objectOutputStream.writeDouble(9.5);
        objectOutputStream.writeUTF("123456");//String
        //保存一个dog对象
        Dog dog = new Dog("张三", 10, "日本", "红色");
        objectOutputStream.writeObject(dog);//java.io.NotSerializableException 这是Dog没有实现Serializable
        objectOutputStream.close();
    }
}

