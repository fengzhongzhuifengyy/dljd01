package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.IOException;
import java.io.PrintStream;

/**
 *   打印流 PrintStream 和 PrintWriter
 *   演示 字节打印流 PrintStream
 */
public class IOStream12 {
    public static void main(String[] args) throws IOException {
        PrintStream out = System.out;
        //在默认情况下, PrintStream输出数据的位置是 标准输出 是显示器
        out.print("hello,world");
        /*
            查看下print()源码:
            public void print(String s) {
                if (s == null) {
                    s = "null";
                }
                write(s); // 底层是它
            }
         */
        //因为print底层使用的是writer,所以我们可以直接调用writer进行打印输出
        out.write("hello,world".getBytes());
        out.close();
        //我们可以修改打印流输出的位置或者设备
        System.setOut(new PrintStream("E:\\5.txt"));
        System.out.println("hello,你好"); //这里就会输出到文件E:\5.txt,因为SetOut的位置已经改变
        /*
            public static void setOut(PrintStream out) {
                checkIO();
                setOut0(out); //native方法,修改了out
            }
         */


    }
}
