package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *  使用BufferedReader 读取文本文件,并显示在控制台
 */
public class IOStream02 {
    public static void main(String[] args) {
        String filepath = "e:\\1.txt";
        BufferedReader bufferedReader = null;
        //创建对象
        try {
            bufferedReader = new BufferedReader(new FileReader(filepath));
            //读取
            String line;
            /*
                说明:
                1. bufferedReader.readline() : 按行读取文件
                2. 如果返回为null时,表示文件读取完毕
             */
            while( (line = bufferedReader.readLine()) != null){
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            //关闭流,只需要关闭包装流,因为底层会自动的关闭节点流
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
