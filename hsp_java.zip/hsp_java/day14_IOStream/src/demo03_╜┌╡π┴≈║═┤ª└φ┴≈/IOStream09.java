package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *  看一个中文乱码问题引出 转换流:字节流转换为字符流 InputStreamReader / OutputStreamWriter
 */
public class IOStream09 {
    public static void main(String[] args) throws IOException {

        String filepath = "e:\\1.txt";
        /*
            思路:
            1.创建字符输入流: BufferedReader
            2.使用BufferedReader对象读取a.txt
            3.默认情况下,读取文件是按照utf-8编码,如果设置的非utf-8,则会乱码
         */
        BufferedReader bufferedReader = new BufferedReader(new FileReader(filepath));
        String s = bufferedReader.readLine();
        System.out.println(s);//hello,���Ӣhello,���Ӣhello,���Ӣ
        bufferedReader.close();
    }
}
