package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 处理流的拷贝
 */
public class IOStream04 {
    public static void main(String[] args) {

        String srcFilepath = "e:\\1.txt";
        String destFilepath2 = "e:\\2.txt";
        BufferedReader bufferedReader = null;
        BufferedWriter bufferedWriter = null;
        String content = "";

        try {
            bufferedReader = new BufferedReader(new FileReader(srcFilepath));
            bufferedWriter = new BufferedWriter(new FileWriter(destFilepath2));

            while ((content = bufferedReader.readLine()) != null) {

                bufferedWriter.write(content);
                bufferedWriter.newLine();//换行一定要注意
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
                //关闭处理流就是关闭节点流
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
