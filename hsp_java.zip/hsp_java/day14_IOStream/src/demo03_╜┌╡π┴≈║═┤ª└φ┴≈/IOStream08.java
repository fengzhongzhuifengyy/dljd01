package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.util.Scanner;

/**
 *  标准输入输出流
 */
public class IOStream08 {
    public static void main(String[] args) {
        //System类的public final static InputStream in = null;
        //System.in编译类型为InputStream, 运行类型是? --> BufferedInputStream
        //表示的是标准输入  键盘
        System.out.println(System.in.getClass());//class java.io.BufferedInputStream


        //System类的public final static PrintStream out = null;
        //System.out的编译类型是PrintStream,运行类型是? --> PrintStream
        //表示的是标准输出  显示器
        System.out.println(System.out.getClass());//class java.io.PrintStream

        //案例:
        System.out.println("你好,李焕英");
        Scanner scanner = new Scanner(System.in);
        System.out.println(scanner.next());

    }
}
