package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.Serializable;

//如果需要序列化某个类的对象,必须实现Serializable
public class Dog implements Serializable {
    String name;
    int age;
    //序列化的版本号,可以提高兼容性
    //当进行类属性的修改,只会当做是类的修改
    private static final long SerialVersionUID = 1l;
    //序列化对象时, 默认将里面所有的属性都进行序列化,但是除了static或者transient修饰的成员
    private static String nation;
    private transient String color;
    //序列化对象时,要求里面属性的类型也需要实现序列化接口
    private Master master = new Master();
    public Dog(String name, int age,String nation, String color) {
        this.name = name;
        this.age = age;
        this.color = color;
        this.nation = nation;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", color='" + color + '\'' +
                ", nation='" + nation +'\''+
                '}';
    }

    public String getName() {
        return name;
    }
}
