package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *  演示 PrintWriter 使用方式
 */
public class IOStream13 {
    public static void main(String[] args) throws IOException {
        // System.out -> printStream --> 调用的构造器是 OutputStream
        //1.演示显示器打印
        // PrintWriter printWriter = new PrintWriter(System.out); //默认是显示器打印
        // printWriter.print("你好上海");

        //2.演示打印至文件
        PrintWriter printWriter = new PrintWriter(new FileWriter("e:\\6.txt"));
        printWriter.print("你好北京");//此时就会输出到指定的文件

        //关闭流,不关闭流是不会刷新的,即不会覆盖内容, close()才是真正写数据
        printWriter.close();
    }
}
