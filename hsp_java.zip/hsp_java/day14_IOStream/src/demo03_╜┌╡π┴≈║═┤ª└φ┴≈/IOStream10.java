package com.hspedu.java.day14_IO流.demo03_节点流和处理流;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *  将字节流FileInputStream包装成字符流InputStreamReader,
 *  对文件进行读取(gbk格式),进而再包装成BufferedReader; 源文件就是gbk格式
 */
public class IOStream10 {
    public static void main(String[] args) throws IOException {
        String filepath  = "e:\\1.txt";
        String charSet = "gbk";

        /*
            解读:
            1.把FileInputStream 转成 InputStreamReader
            2.指定了编码utf-8
         */
        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(filepath), charSet);
        // 把 InputStreamReader 放入 BufferedReader
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        String s = bufferedReader.readLine();
        System.out.println("读取内容= " + s);
        //关闭最外层的流
        inputStreamReader.close();
    }
}
