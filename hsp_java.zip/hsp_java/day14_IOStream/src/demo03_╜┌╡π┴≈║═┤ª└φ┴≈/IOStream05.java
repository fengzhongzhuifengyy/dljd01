package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *  使用Buffered完成图片或者音乐的拷贝
 */
public class IOStream05 {
    public static void main(String[] args) throws IOException {

        String oldFilepath = "E:\\3.png";
        String newFilepath = "E:\\4.png";

        BufferedInputStream bufferedInputStream = null;
        BufferedOutputStream bufferedOutputStream = null;
        byte[] bytes = new byte[1024];
        int data = 0;


        bufferedInputStream = new BufferedInputStream(new FileInputStream(oldFilepath));
        bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(newFilepath));
        while ((data = bufferedInputStream.read(bytes)) != -1){
            bufferedOutputStream.write(bytes, 0, data);
        }
        if (bufferedInputStream != null){
            bufferedInputStream.close();
        }
        if (bufferedOutputStream != null){
            bufferedOutputStream.close();
        }
    }
}
