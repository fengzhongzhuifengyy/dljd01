package com.hspedu.java.day14_IO流.demo03_节点流和处理流;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 *  编程将字节流FileOutputStream 包装成字符流 OutputStreamWriter,对文件进行写入(按照gbk格式,可以指定其他格式)
 */
public class IOStream11 {
    public static void main(String[] args) throws IOException {
        String path = "e:\\3.txt";
        String charSet = "utf-8";

        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(path), charSet);
        outputStreamWriter.write("童绪梁测试");
        outputStreamWriter.close();
    }
}
