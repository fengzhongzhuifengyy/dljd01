package day14_IO流.demo03_节点流和处理流;

/**
 * 修饰器设计模式 模拟
 */
public class IOStream01 {
    public static void main(String[] args) {

        Buffered buffered1 = new Buffered(new FileReader01());
        buffered1.readFile();// 这里有个疑问? 为啥调用抽象的方法
        buffered1.readFiles(10);

        Buffered buffered2 = new Buffered(new FileReader01());
        buffered2.readStrings(10);

    }
}

abstract class Reader01 {
    public void readFile() {
    }

    public void readString() {
    }

    //在抽象类中使用read() 方法统一管理,演示使用一个

}

//节点流1
class FileReader01 extends Reader01 {

    public void readFile() {
        System.out.println("对文件处理");
    }
}

//节点流2
class StringReader01 extends Reader01 {

    public void readString() {
        System.out.println("对String处理");
    }


}

//包装流
class Buffered extends Reader01 {

    private Reader01 reader01; //属性是Reader01

    public Buffered(Reader01 reader01) {
        this.reader01 = reader01;
    }

    // 扩展方法,批量读取文件
    public void readFiles(int num) {
        for (int i = 0; i < num; i++) {
            reader01.readFile();
        }
    }

    // 扩展方法,批量处理String
    public void readStrings(int num) {
        for (int i = 0; i < num; i++) {
            reader01.readString();
        }
    }
}