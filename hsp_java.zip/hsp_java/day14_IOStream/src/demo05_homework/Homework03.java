package demo05_homework;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.Properties;

/**
 *  编程题:
 *  1.要编写一个dog.properties
 *  name=tom
 *  age=5
 *  color=red
 *  2编写Dog类(name, age, color)创建一个dog对象,读取dog.properties用相应的内容完成属性初始化,并输出
 *  3.将创建的dog对象 序列化到文件dog.dat文件
 */
public class Homework03 {
    public static void main(String[] args) throws IOException {
        String filepath = "D:\\Document\\javahsp\\src\\com\\hspjava\\day14_IO流\\demo05_homework\\dog.properties";
        Properties properties = new Properties();
        properties.setProperty("name", "tom");
        properties.setProperty("age", "5");
        properties.setProperty("color", "red");
        properties.store(new OutputStreamWriter(new FileOutputStream(filepath)), "dog.properties");

        String name = (String) properties.get("name");
        Integer age = Integer.parseInt(((String)properties.get("age")));
        String color = (String) properties.get("color");
        Dog dog = new Dog(name, age, color);
        System.out.println(dog);
        String s = "e:\\dog.dat";
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(s));
        objectOutputStream.writeObject(dog);
        objectOutputStream.close();


    }
}
class Dog implements Serializable {
    private String name;
    private int age;
    private String color;

    public Dog(String name, int age, String color) {
        this.name = name;
        this.age = age;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", color='" + color + '\'' +
                '}';
    }
}
