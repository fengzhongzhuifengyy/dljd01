package demo05_homework;

import java.io.File;
import java.io.IOException;

/**
 *  编程题:
 *  1.判断e盘下是否有文件夹mytemp,如果没有就创建
 *  2.在e:\\mytemp目录下,创建hello.txt
 *  3.如果hello.txt已经存在,提示该文件已经存在,就不需要重复创建了
 */
public class HomeWork01 {
    public static void main(String[] args) throws IOException {

        String filepath1 = "e:\\mytemp";
        String filepath2 = filepath1 + "\\hello.txt";

        File file1 = new File(filepath1);
        if (!(file1.exists())){
            if (file1.mkdirs()){
                System.out.println("目录创建成功");
            }
        }else {
            System.out.println("目录已存在");
        }

        File file2 = new File(filepath2);
        if (!(file2.exists())){
            if (file2.createNewFile()){
                System.out.println("文件创建成功");
            }
        }else {
            System.out.println("hello.txt已存在");
        }
    }
}
