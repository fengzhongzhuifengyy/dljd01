package demo05_homework;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *  使用BufferedReader 读取一个文本文件,为每行加上行号,连同内容一并输出到屏幕上
 */
public class Homework02 {
    public static void main(String[] args) throws IOException {

        String filepath = "E:\\1.txt";
        // BufferedReader bufferedReader = new BufferedReader(new FileReader(filepath));
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(filepath), "utf-8"));
        String line = "";
        int number = 0;
        while ((line = bufferedReader.readLine()) != null){
            System.out.println(++number + " " + line);
        }
        bufferedReader.close();
    }
}
