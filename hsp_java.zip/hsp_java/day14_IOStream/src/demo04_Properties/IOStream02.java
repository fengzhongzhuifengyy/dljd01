package demo04_Properties;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

/**
 *  1.使用Properties类完成对mysql.properties的读取
 *  2.使用Properties类添加k-v到新文件 mysql2.properties
 *  3.使用Properties类完成对mysql2.properties 的读取,并修改某个值
 */
public class IOStream02 {
    public static void main(String[] args) throws IOException {
        // 使用Properties类完成对mysql.properties
        //1.创建对象
        Properties properties = new Properties();
        //2.加载指定的配置文件
        properties.load(new FileReader("D:\\Document\\javahsp\\src\\com\\hspjava\\day14_IO流\\demo04_Properties\\mysql.properties"));
        //3.把k-v显示控制台
        properties.list(System.out);
        //4.根据key获取对应的值
        String user = properties.getProperty("user");
        System.out.println("用户名: " + user);
        System.out.println("-------------------------------------------------------------------------");
        // 使用Properties类添加k-v到新文件 mysql2.properties
        //1.创建对象
        Properties properties1 = new Properties();

        //3.添加k-v
        properties1.setProperty("port", "8080");
        properties1.setProperty("schema", "http");
        properties1.setProperty("pwd", "童绪梁");//注意这里存的是unicode码
        //4.完成读取
        properties1.list(System.out);
        //5.修改key
        properties1.setProperty("port", "80");
        properties1.list(System.out);

        //2.存储到指定的配置文件
        properties1.store(new FileWriter("D:\\Document\\javahsp\\src\\com\\hspjava\\day14_IO流\\demo04_Properties\\mysql2.properties"),
                "配置文件2");

    }
}
