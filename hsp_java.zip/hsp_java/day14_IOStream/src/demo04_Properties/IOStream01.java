package demo04_Properties;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *  通过传统的方法读取 ip user pwd
 */
public class IOStream01 {
    public static void main(String[] args) throws IOException {

        BufferedReader bufferedReader = new BufferedReader(new FileReader("D:\\Document\\javahsp\\src\\com\\hspjava\\day14_IO流\\demo04_Properties\\mysql.properties"));
        String line = "";
        //遍历
        while ((line = bufferedReader.readLine()) != null){
            // System.out.println(line);
            //处理获取
            String[] str = line.split("=");
            System.out.println(str[0] + "值是: " + str[1]);
        }
        bufferedReader.close();
    }

}
