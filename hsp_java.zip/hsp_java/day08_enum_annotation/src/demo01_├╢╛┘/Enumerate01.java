package demo01_枚举;

/**
 * 引入枚举类和自定义枚举类
 */
public class Enumerate01 {
    public static void main(String[] args) {
        //传统怎么使用?
        Season spring = new Season("春天", "温暖");
        Season winter = new Season("冬天", "寒冷");
        Season summer = new Season("夏天", "炎热");
        Season autumn = new Season("秋天", "凉爽");
        autumn.setDesc("非常热");
        autumn.setName("小秋");
        //可以看出对于季节而言,它的对象是有具体的值,不会有更多,目前可以随便新增对象还可以随便设置对象属性,不符合要求
        //可以看出这个设计思路,不能体现 季节是固定的四个对象

        // 引出枚举类
        System.out.println(SeasonEnumerate.SPRING);
    }
}

class Season {
    private String name;
    private String desc;

    public Season(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}

/**
 * 1.季节的值是有限的几个值(spring,winter,summer,autumn)
 * 2.只读不需要修改
 * -------------
 * 1.枚举是一组常量的组合
 * 可以这里理解:枚举属于一种特殊的类,里面包含一组有限的特定的对象
 */
// 自定义枚举
class SeasonEnumerate {
    private String name;
    private String desc;
    //定义了四个固定的对象
    public static final SeasonEnumerate SPRING = new SeasonEnumerate("春天", "温暖");
    public static final SeasonEnumerate WINTER = new SeasonEnumerate("冬天", "寒冷");
    public static final SeasonEnumerate SUMMER = new SeasonEnumerate("夏天", "炎热");
    public static final SeasonEnumerate AUTUMN = new SeasonEnumerate("秋天", "凉爽");

    //1.将构造器私有化,防止直接被new出来
    //2.去掉set(),防止属性被修改,保证只读
    //3.在Season内部,直接创建几个固定的对象
    //4.优化,加入final,防止类加载
    private SeasonEnumerate(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

//    public void setName(String name) {
//        this.name = name;
//    }

    public String getDesc() {
        return desc;
    }

//    public void setDesc(String desc) {
//        this.desc = desc;
//    }

    @Override
    public String toString() {
        return "SeasonEnumerate{" +
                "name='" + name + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }
}