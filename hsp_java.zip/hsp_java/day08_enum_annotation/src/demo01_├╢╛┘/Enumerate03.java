package demo01_枚举;

/**
 * 演示Enum类的各种使用方法
 */
public class Enumerate03 {
    public static void main(String[] args) {
        //使用SeasonEnumerate03来演示
        SeasonEnumerate03 autumn = SeasonEnumerate03.AUTUMN;

        //name()返回枚举对象的名称
        System.out.println(autumn.name()); //AUTUMN

        //ordinal()返回的是该枚举对象的编号,默认从0开始编号
        //AUTUMN定义时时第4个,因此输出3
        System.out.println(autumn.ordinal()); //3

        //values()源码没有,从反编译可以看到有个values(),返回SeasonEnumerate03[],将 定义的所有枚举对象 组成数组
        SeasonEnumerate03[] seasonEnumerate03 = SeasonEnumerate03.values();
        for (SeasonEnumerate03 value : seasonEnumerate03) { //增强for循环
            System.out.println(value);//toString()
        }

        //valueOf():将字符串转换成枚举对象，要求字符串必须为已有的常量名，否则报异常！
        //执行流程:
        //1.根据输入的字符串到SeasonEnumerate03的枚举对象进行查找
        //2.如果找到了,就返回,如果没有找到就报错
        SeasonEnumerate03 spring = SeasonEnumerate03.valueOf("SPRING");
        System.out.println("spring=" + spring); //spring=SeasonEnumerate{name='春天', desc='温暖'}

        //compareTo():比较两个枚举常量，比较的就是编号
        //1.就是把SPRING的编号与AUTUMN比较,查看源码:return self.ordinal - other.ordinal-->0-3=-3;
        System.out.println(SeasonEnumerate03.SPRING.compareTo(autumn));// -3

        //演示增强for循环
        new Test().test();
    }
}

enum SeasonEnumerate03 {
    SPRING("春天", "温暖"),
    WINTER("冬天", "寒冷"),
    SUMMER("夏天", "炎热"),
    AUTUMN("秋天", "凉爽");

    private String name;
    private String desc;

    private SeasonEnumerate03(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return "SeasonEnumerate{" +
                "name='" + name + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }

}

class Test {
    int[] nums = {0, 1, 2};

    public void test() {
        //普通for循环
        for (int i = 0; i < nums.length; i++) {
            System.out.print("普通for循环" + nums[i] + " ");
        }
        System.out.println("\n------------------");
        //增强for循环
        for (int values : nums) { // 执行流程 将nums[]的数据逐一赋给values,循环完毕就退出
            System.out.print("增强for循环" + values + " ");
        }
    }

}