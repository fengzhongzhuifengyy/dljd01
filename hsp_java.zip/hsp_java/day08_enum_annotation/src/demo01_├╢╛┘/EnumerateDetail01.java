package demo01_枚举;

/**
 * enum实现接口
 */
public class EnumerateDetail01 {
    public static void main(String[] args) {
        Music.CLASSICALMUSIC.play();
    }
}

class AA{}
//不允许对枚举使用 extends 子句
//enum BB extends AA {
//
//}

enum Music implements Play{
    CLASSICALMUSIC;
    public void play(){
        System.out.println("播放音乐");
    }
}

interface Play{
    void play();
}