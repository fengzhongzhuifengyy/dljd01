package demo03_练习;

/**
 * 有一个Car类,有属性temperature(温度),车内有Air(空调)类,有吹风的功能flow,Air会监视车内的温度变化,如果温度超过40度则吹冷风,如果温度低于0度则吹暖气,如果在这之间关掉空调,
 * 实例化具有不同温度的Car对象,调用空调的flow方法,测试空调吹的风是否正确
 */
public class Exercise07 {
    public static void main(String[] args) {
//        new Cat1(41.0).new Air().flow();
//        new Cat1(-1.0).new Air().flow();
//        new Cat1(10).new Air().flow();

        new Cat1(41.0).getAir().flow();
        new Cat1(-1).getAir().flow();
        new Cat1(10).getAir().flow();
    }
}

class Cat1 {

    private double temperature;

    class Air {

        public void flow() {
            if (temperature > 40) {
                System.out.println("空调吹冷风");
            } else if (temperature < 0) {
                System.out.println("空调吹暖风");
            } else {
                System.out.println("关闭空调");
            }
        }

    }


    public Cat1(double temperature) {
        this.temperature = temperature;
    }
    // 获取Air
    public Air getAir(){
        return new Air();
    }
}
