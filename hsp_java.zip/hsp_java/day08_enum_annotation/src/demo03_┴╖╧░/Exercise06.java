package demo03_练习;

/**
 * 1.有一个交通工具接口类Vehicles,有work接口
 * 2.有Horse类和Boat类分别实现Vehicles
 * 3.创建交通工具工厂类,有两个方法分别获得交通工具Horse和Boat
 * 4.有Person类,有name和Vehicles属性,在构造器中为两个属性赋值
 * 5.实例化Person对象"唐僧",要求一般情况下用Horse作为交通工具,遇到大河时使用Boat作为交通工具
 */
public class Exercise06 {
    public static void main(String[] args) {
        Person tang = new Person("唐僧", new Boat());
        tang.common();
        tang.passRiver();
        /*
            房车可以工作
            房车可以工作
         */
        // 此时如何防止始终使用的是传入的? 通过 instanceOf 优化
        // 下面"再次优化"解决这个问题
    }
}

interface Vehicles { //车辆
    void work();
}

class Horse implements Vehicles {
    @Override
    public void work() {
        System.out.println("房车可以工作");
    }
}

class Boat implements Vehicles {
    public void work() {
        System.out.println("小船可以工作");
    }
}

class VehiclesFactory {
    // 使用static只需要调用其方法即可,不需要new对象
    // 最后思考,在取经过程中,马儿始终是一匹,通过以下编写,可以看出是饿汉式
    private static Horse horse = new Horse();

    // 得到一匹马
    public static Horse getHorse() {
        return horse;
    }

    //得到一艘船
    public static Boat getBoat() {
        return new Boat();
    }

    //VehiclesFactory私有化这样就可以保证,马儿只用一次
    private VehiclesFactory() {
    }
}

class Person {
    private String name;
    private Vehicles vehicles;

    //这里在创建对象时,会给其创建一个交通工具,如果直接使用方法,则就会浪费初始创建的对象
    //此时,思考这个问题,在构建对象时,传入的交通工具对象不浪费呢? --->判断当前vehicles是否已经存在了
    public Person(String name, Vehicles vehicles) {
        this.name = name;
        this.vehicles = vehicles;
    }

    //这里就有编程思想,就是可以把具体的要求封装成方法-->抽取思想
    public void passRiver() {

        //先得到船
//        Boat boat = VehiclesFactory.getBoat();
//        boat.work();
        //优化方案
//        if (vehicles == null) {
//            vehicles = VehiclesFactory.getBoat();
//        }
//            vehicles.work();

        //再次优化
        if (!(vehicles instanceof Boat)) {
            vehicles = VehiclesFactory.getBoat();
        }
        vehicles.work();
    }

    //通常情况下,使用马儿
    public void common() {
//        Horse horse = VehiclesFactory.getHorse();
//        horse.work();

        //优化方案
        //判断当前vehicles是否已经存在了,没有存在,工具就获取
//        if (vehicles == null) {
//            //这里使用的是多态
//            vehicles = VehiclesFactory.getHorse();
//        }
//            vehicles.work();

        //此时如何防止始终使用的是传入的马? --再次优化
        // 1.vehicles=null,vehicles instanceof Horse --> false
        // 2.vehicles=Boat(船对象),vehicles instanceof Horse --> false
        // 3.此时都需要重新生产一个工具
        if (!(vehicles instanceof Horse)) {
            vehicles = VehiclesFactory.getHorse();
        }
        vehicles.work();
    }
}