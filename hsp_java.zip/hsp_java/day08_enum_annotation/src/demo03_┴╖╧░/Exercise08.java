package demo03_练习;


/**
 *  1.创建一个Color枚举类
 * 	2.有RED,BLUE,BLACK,YELLOW,GREEN这5个枚举值/对象
 * 	3.Color有三个属性redValue, greenValue, blueValue
 * 	4.创建构造方法,参数包含这三个属性
 * 	5.每个枚举值都要给这三个属性赋值,三个属性对应的值分别是red: 255,0,0 blue:0,0,255 black:0,0,0 yellow:255,255,0, green:0,255,0
 * 	6.定义接口,里面有show(),要求Color实现该接口
 * 	7.show方法中显示三属性的值
 * 	8.将枚举对象在switch语句中匹配使用
 */
public class Exercise08 {
    public static void main(String[] args) {
        // 直接获取RED对象
        Color color = Color.RED;

        //遍历获取所有的对象
        Color[] colors = Color.values();
        for(Color value: colors){
            switch (value){
                case RED:
                    System.out.println(Color.RED.show());
                   break;
                case BLUE:
                    System.out.println(Color.BLUE.show());
                    break;
                case BLACK:
                    System.out.println(Color.BLACK.show());
                    break;
                case YELLOW:
                    System.out.println(Color.YELLOW.show());
                    break;
                case GREEN:
                    System.out.println(Color.GREEN.show());
                    break;
                default:
                    break;
            }
        }
    }
}

enum Color implements Print{
    RED(255,0,0),
    BLUE(0,0,255),
    BLACK(0,0,0),
    YELLOW(255,255,0),
    GREEN(0,255,0);
    private int redValue;
    private int greenValue;
    private int blueValue;

    private Color(int redValue, int greenValue, int blueValue) {
        this.redValue = redValue;
        this.greenValue = greenValue;
        this.blueValue = blueValue;
    }


    @Override
    public String show() {
        return "Color{" +
                "redValue=" + redValue +
                ", greenValue=" + greenValue +
                ", blueValue=" + blueValue +
                '}';
    }
}

interface Print{
    String show();
}