package demo03_练习;

/**
 * 1.计算接口具有work方法,功能是运算,有一个手机类CellPhone,定义方法testWork,测试计算功能,调用计算接口work方法
 * 2.调用接口CellPhone对象的testWork方法,使用上匿名内部类
 */
public class Exercise04 {
    public static void main(String[] args) {
        CellPhone cellPhone = new CellPhone();
        // 匿名内部类的编译类型是Calc接口,运行类型就是匿名内部类,同时也是个对象
        cellPhone.testWork(new Calc() {
            @Override
            public double work(double n1, double n2) {
                System.out.println("通过匿名内部类计算");
                return n1 + n2;
            }
        }, 10, 8); // 18.0
    }
}

interface Calc {
    // work方法是完成计算,但是题目没有具体要求,自己设计
    double work(double n1, double n2);
}

class CellPhone {
    // 当我们调用testWork()时,直接传入一个实现Calc接口的匿名内部类即可
    public double testWork(Calc calc, double n1, double n2) {
        System.out.println("调用接口实现计算功能");
        return calc.work(n1, n2);
    }
}
