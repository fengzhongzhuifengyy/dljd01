package com.hspedu.java.day01_变量.demo03;

/*
 * float:
 */
public class FloatDetail {
	
	public static void main(String[] args) {
		// cannot convert from double to float
//		float num1 = 1.1l;
		
		float num1 = 1.1F;
		
		double num2 = 1.1;
		
		// 小空间-> 大空间 ok
		double num3 = 1.1f;
		
		// 0.789 -> .789 前面的0可以省略;
		double num4 = .789;
		
		// 科学计数法 5.12e2 = 5.12 * 10^2
		double num5 = 5.12e2;
		
		// 通常情况下,应该使用double型,因为他比float更精确;举例说明
		double num6 = 2.1234567851;
		
		float num7 = 2.1234567851F;
		
		System.out.println(num6); // result: 2.1234567851
		System.out.println(num7); // result: 2.1234567
		
		
		// 浮点数有个陷阱:
		// 看一下代码
		double num8 = 2.7;
		double num9 = 8.1 / 3;
		System.out.println(num8);// result: 2.7
		System.out.println(num9);// result: 2.6999999999999997
		/*
		 * 	因此得到一个重要的使用点: 当我们对运算结果为小数的进行相等判断,要小心!
		 * 
		 * 	应该是以两个数的差值的绝对值,在某个精度范围内判断
		 */
		if (num8 == num9) {
			System.out.println("相等");
		}
		
		// 正确代码
		if(Math.abs(num8 - num9) < 0.0001) {
			
			System.out.println("相等");
		}
		
		System.out.println(Math.abs(num8 - num9));
		/*
		 * 如果是直接查询得到的小数或者直接赋值,是可以直接进行比较的
		 */
		
	}
}
