package com.hspedu.java.day01_变量.demo03;

/*
 * 	char:
 */
public class CharDetail {
	public static void main(String[] args) {
		
		// 在Java中,char的本质是一个整数,在输出时,对应的是unicode码的字符
		char c1 = 97;
		System.out.println(c1);  // result : a
		
		
		char c2 = 'a';
		System.out.println((int)c2);	// result : 97
		
		char c3 = '童';
		System.out.println((int)c3);  //result: 31461
		
		char c4 = 31461;
		System.out.println(c4);
		
		
		// cahr类型是可以进行运算的,相当于一个整数,因为他都有对应的Unicode值
		char c5 = 'a' + 100;
		System.out.println((int)c5);  //result: 197
		
		// 测试:
		
		char c6 = 'b' + 1;
		System.out.println((int)c6); // 99
		System.out.println(c6); // 99对应的字符 --> C
	}
}
