package com.hspedu.java.day01_变量.demo03;

/*
 * 	Int
 * 
 */
public class IntDetail {

	public static void main(String[] args) {
		// Java的整型常量(值)默认为int型,声明为long型需要加"l"+"L";
		int n1 = 1;
		
		// Type mismatch: cannot convert from long to int
//		int n2 = 100L; 
		
		long n2 = 100L;

	}

}
