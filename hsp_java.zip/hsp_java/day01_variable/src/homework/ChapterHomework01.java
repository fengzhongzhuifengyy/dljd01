package homework;

// 使用char类型,范别保存 \n \t \r \\ 1 2
public class ChapterHomework01 {

	public static void main(String[] args) {
		
		char c1 = '\n'; // 换行
		
		char c2 = '\t'; // 制表
		
		char c3 = '\r'; // 回车
		
		char c4 = '\\'; // \
		
		char c5 = '1'; // 1
		
		char c6 = '2'; // 2
		
		
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		System.out.println(c4);
		System.out.println(c5);
		System.out.println(c6);
		
		
		

	}

}
