package com.hspedu.java.day01_变量.demo02;
/*
 *  变量:
 */
public class Variable01 {
	public static void main(String[] args) {
		
		// 声明变量
		int a;		
		a = 100;		
		System.out.println(a);
		
		
		// 还可以这样使用
		int b = 800;
		System.out.println(b);
		
		
		// 记录人的信息
		int age = 20;
		double score = 88.6;
		char gender = '男';
		String name = "King";
		System.out.println("人的信息如下: ");
		System.out.println("年龄: " + age);
		System.out.println("分数: " + score);
		System.out.println("性别: " + gender);
		System.out.println("名字: " + name);
		
	}

}
