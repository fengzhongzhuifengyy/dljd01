package demo01;

/*
  	要求:请使用输出语句,达到如下图形的要求;
  	书名   作者    价格   销量  
  	三国   罗贯中  120    1000 
 */
public class ChangeCharExer {
	public static void main(String[] args) {
		
		System.out.println("书名\t作者\t价格\t销量\n三国\t罗贯中\t120\t1000");
	}

}
