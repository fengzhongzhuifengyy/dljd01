package demo01;

// 演示转义字符的使用
public class ChangeChar {
	
	public static void main(String[] args) {
		
		// \t : 一个制表位,实现对齐的功能
		System.out.println("北京\t天津\t上海");
		
		// \n : 换行符
		System.out.println("jack\nSmith\nmary");
		
		//  \\:一个"\" ; \\\\: 两个\\
		System.out.println("hello\\milan");
		
		// \"
		System.out.println("老韩说\"要好好学习Java,有前途\"");
		
		// \r : 回车
		/*
		 * 解读
		 * 	1.输出:韩顺平教育
		 * 	2.\r(回车)后的字符替换前一句字符: 北京平教育
		 */
		System.out.println("韩顺平教育\r北京");  // 北京平教育
	}

}
