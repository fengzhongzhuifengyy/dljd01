package com.hspedu.java.day01_变量.demo04;

/*
 * 	强制转换细节:
 */
public class ForceConvertDetail {
	public static void main(String[] args) {
		
		/*
		 * 强转符号值针对最近的操作数有效,往往使用()来提升优先级
		 */
//		int x = (int)10 * 1.2; // 错误
		int x = (int)(10 * 1.2); 
		System.out.println(x);
		
		
	}

}
