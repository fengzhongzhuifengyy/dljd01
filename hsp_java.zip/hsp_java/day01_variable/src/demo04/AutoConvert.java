package com.hspedu.java.day01_变量.demo04;

/*
 * 自动转换:
 */
public class AutoConvert {

	public static void main(String[] args) {
		// 演示自动转换
		int num = 'a';
		double d1 = 80;
		System.out.println(num); // 97
		System.out.println(d1);  // 80.0
		

	}

}
