package com.hspedu.java.day01_变量.demo04;
/*
 * 自动类型转换细节:
 * 	
 */
public class AutoConvertDetail {
	public static void main(String[] args) {
		
		/* 有多种类型的数据混合运算时,
		系统首先自动将所有数据转换成大容量最大的那个数据类型,然后再进行计算
		*/
		int i = 10;
		// cannot convert from double to float
//		float f = 10 + 1.1;
		
		double d = 10 + 1.1;
		
		float f = 10 + 1.1f;
		
		/* 当我们把精度达的数据类型赋值给精度小的数据类型时,就会报错
		 */
		// cannot convert from double to int
//		int n1 = 1.12; // 错误
		
		
		/*
		 * byte /short /char 这三者之间不能相互自动转换 
		 */
		// 思考这个为什么是对的呢?
		// 当把这个数赋值给byte时,先判断该数是否在byte范围内,如果范围是ok的,那么就ok的
		byte b1 = 10;
		
		//	思考一下代码:
		int n2 = 10;
		//  cannot convert from int to byte
//		byte b2 = n2; // 错误: 原因:如果变量赋值,判断类型
		
		//	cannot convert from byte to char
//		char c = b1; // 错误 原因 byte 不能自动转换为 char
		
		
		/*
		 * byte / short/ char 三者可以计算,在计算时首先转换为int类型
		 */
		byte b2 = 1;
		
		byte b3 = 2;
		
		short s1 = 1;
		 
//		short s2 = b2 + s1;  // 错误: b2 + s1 --> int
		
//		byte b4 = b2 + b3;  // 错误: b2 + b3 --> int
		
		/*
		 * 	boolean不参与转换
		 */
		boolean pass = true;
		
//		int num1000 = pass;  // boolean 不参与转换
		
		
		// 看一道题:
		byte bb = 1;
		
		short ss = 100;
		
		int ii = 1;
		
		double dd = 1.1;
		
		double ddd = bb + ss + ii + dd;  // 数据自动提升为最大类型
		
	}

}
