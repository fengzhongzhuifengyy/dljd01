package com.hspedu.java.day01_变量.demo04;

/*
 * 	String 类型转基本数据类型:
 */
public class StringToBasic {

	public static void main(String[] args) {
		
		// 基本数据类型 转 String
		int n1 = 100;
		
		float f1 = 1.1f;
		
		double d1 = 4.5;
		
		boolean b1 = true;
		
		// 转换方法: 将基本数据类型的值 + "" 即可
		String s1 = n1 + "";
		String s2 = f1 + "";
		String s3 = d1 + "";
		String s4 = b1 + "";
		
		System.out.println(s1 + " " + s2 + " " + s3 + " " + s4);
		
		
		// 将字符串转换成对应的基本数据类型
		String s5 = "123";
		
		// 面向对象会详细讲述
		// 解读: 使用 基本数据类型对应的包装类 的相应方法,得到基本数据类型
		int num = Integer.parseInt(s5);
		
		double d2 = Double.parseDouble(s5);
		
		float f2 = Float.parseFloat(s5);
		
		Boolean b2 = Boolean.parseBoolean("true");
		
		long l1 = Long.parseLong(s5);
		
		byte b3 = Byte.parseByte(s5);
		
		short sh = Short.parseShort(s5);
		
		System.out.println(num + " " + d2 + " " + f2 + " " + b2 + " " + l1 + " " + b3 + " " + sh);
		
		// 怎么char数据类型不说呢?
		// 把字符串转成char -- > 在计算机含义: 把字符串的第一个字符取到
		System.out.println(s5.charAt(0)); // 得到s5的第一个字符 '1'

	}

}
