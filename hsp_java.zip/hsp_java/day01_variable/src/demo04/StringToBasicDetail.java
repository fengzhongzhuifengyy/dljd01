package com.hspedu.java.day01_变量.demo04;

/*
 * 演示字符串转基本数据类型的细节:
 */
public class StringToBasicDetail {

	public static void main(String[] args) {
		
		String s1 = "hello";
		
		// 转成int
		int n1 = Integer.parseInt(s1);
		
		//java.lang.NumberFormatException
		System.out.println(n1);
	}

}
