package demo13_Properties;

import java.util.Properties;

/**
 *  Properties基本介绍
 */
public class Properties01 {
    public static void main(String[] args) {
        /*
            1.Properties继承了Hashtable
            2.可以通过k-v存放数据,当然key和value不能为null
            3.相同的key也是替换
            4.也是无序的
         */
        Properties properties = new Properties();
        //1.增加
        properties.put("john", 10);
        // properties.put(null, "null");
        // properties.put("null", null);
        properties.put("lic", 100);
        properties.put("lic", 200);
        System.out.println(properties);//{john=10, lic=200}

        //2.获取
        System.out.println(properties.get("lic"));//200

        //3.删除
        properties.remove("lic");
        System.out.println(properties);//{john=10}

        //4.修改就是直接put
        properties.put("john", "约翰");
        System.out.println(properties);//{john=约翰}

        //get
        String john = properties.getProperty("john");
        System.out.println(john);//约翰
        String property = properties.getProperty("john", "燕子李三");
        /*
            public String getProperty(String key, String defaultValue) {
                String val = getProperty(key);
                return (val == null) ? defaultValue : val;
            }
         */
        System.out.println(property);

    }
}
