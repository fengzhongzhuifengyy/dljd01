package demo08_hashSet;

import java.util.HashSet;

/**
 *  HashSet案例1
 */
public class HashSet02 {
    public static void main(String[] args) {
        HashSet set = new HashSet();
        /*
            说明:
            1.在执行add()后,会返回boolean,成功true 失败false
            2.可以通过remove()指定删除某个对象
         */
        System.out.println(set.add("john"));//t
        System.out.println(set.add("lucy"));//t
        System.out.println(set.add("john"));//f
        System.out.println(set.add("jack"));//t
        System.out.println(set.add("Rose"));//t
        set.remove("john");
        System.out.println("set=" + set);//3个,但是顺序不保证

        HashSet set1 = new HashSet();
        set1.add("lucy");//t
        set1.add("lucy");//f
        set1.add(new Dog("tom"));//t
        set1.add(new Dog("tom"));//t
        System.out.println("set = " + set1);

        //再加深一下
        set1.add(new String("txl"));//t
        set1.add(new String("txl"));//f
        System.out.println("set = " + set1);
        /*
            为什么第二个String对象无法加入呢? 需要分析下源码add()到底发生了什么
         */
    }
}

class Dog{
    private String name;

    public Dog(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString(){
        return "名称" + name;
    }
}

