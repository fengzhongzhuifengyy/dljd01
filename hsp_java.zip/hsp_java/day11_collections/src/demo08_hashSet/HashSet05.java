package demo08_hashSet;

import java.util.HashSet;

/**
 *  分析HashSet的扩容和转成红黑树机制
 */
public class HashSet05 {
    public static void main(String[] args) {

        //1.HashSet底层是HashMap,第一次添加时,table数组扩容到16,临界值(threshold)是16*加载因子(loadFactor)是0.75 = 12
        //2.如果table数组使用了临界值12,就会扩容到16x2=32,那么新的临界值就是32x0.75 = 24
        HashSet hashSet = new HashSet();
//        for (int i = 1; i <= 100; i++) {
//            hashSet.add(i);
//        }
//        System.out.println(hashSet);

        //3.在Java8中,如果一条链表的元素个数到达TREEIFY_THRESHOLD(默认是8),并且table的大小 >= MIN_TREEIFY_CAPACITY(默认为64),就会进行树化(红黑树),否则仍然采用数组扩容机制
//        for (int i = 0; i < 12; i++) {
//            hashSet.add(new A(i));
//        }

        //4.当我们像HashSize增加一个元素时, -->Node -->加入table,就算是增加了一个
        for (int i = 1; i < 7; i++) {//在table某一条链表上添加了7个A对象
            hashSet.add(new A(i));
        }

        for (int i = 1; i < 7; i++) {//在table某一条链表上添加了7个B对象
            hashSet.add(new B(i));
        }
    }
}

class A{

    private int n;

    public A(int n) {
        this.n = n;
    }


//返回一个固定的hash值保证在一条链表中
    @Override
    public int hashCode() {
        return 100;
    }
}

class B{

    private int n;

    public B(int n) {
        this.n = n;
    }

    @Override
    public int hashCode() {
        return 200;
    }
}
