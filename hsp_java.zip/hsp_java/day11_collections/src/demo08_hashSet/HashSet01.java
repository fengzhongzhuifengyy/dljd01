package demo08_hashSet;

import java.util.HashSet;
import java.util.Set;

/**
 *  HashSet介绍
 */
public class HashSet01 {
    public static void main(String[] args) {
        Set hashSet = new HashSet();
        hashSet.add(null);
        hashSet.add(null);
        System.out.println("hashSet = " + hashSet);//hashSet = [null]


        /*
            源码分析
            1.构造器走的源码实际是HashMap
                public HashSet() {
                    map = new HashMap<>();
                }
            2.可以存放null值,但是也只能有一个null
         */
    }
}
