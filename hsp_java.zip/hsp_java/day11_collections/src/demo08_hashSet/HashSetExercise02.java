package demo08_hashSet;

import java.util.HashSet;
import java.util.Objects;

/**
 *  定义一个Employ类,该类包含:private成员属性:name, sal, birthday(MyDate类),其中birthday为MyDate类型,属性包括(year mouth day)
 *  要求:
 *  1.创建3个Employ对象放入HashSet中
 *  2.当name和birthday 的值相同时,认为是相同员工,不能添加到HashSet集合中
 */
public class HashSetExercise02 {
    public static void main(String[] args) {
        HashSet hashSet = new HashSet();
        hashSet.add(new Employ("张三", 10.5, new MyDate("2020", "5", "1")));
        hashSet.add(new Employ("李四", 10.5, new MyDate("2020", "5", "1")));
        hashSet.add(new Employ("张三", 10.5, new MyDate("2020", "5", "1")));
        System.out.println(hashSet);
    }
}
class Employ{
    private String name;
    private double salary;
    private MyDate birthday;

    public Employ(String name, double salary, MyDate birthday) {
        this.name = name;
        this.salary = salary;
        this.birthday = birthday;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employ employ = (Employ) o;
        return name.equals(employ.name) && birthday.equals(employ.birthday);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, birthday);
    }

    @Override
    public String toString() {
        return "Employ{" +
                "name='" + name + '\'' +
                ", salary=" + salary +
                ", birthday=" + birthday +
                '}';
    }
}

class MyDate{
    private String year;
    private String mouth;
    private String day;

    public MyDate(String year, String mouth, String day) {
        this.year = year;
        this.mouth = mouth;
        this.day = day;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMouth() {
        return mouth;
    }

    public void setMouth(String mouth) {
        this.mouth = mouth;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MyDate myDate = (MyDate) o;
        return year.equals(myDate.year) && mouth.equals(myDate.mouth) && day.equals(myDate.day);
    }

    @Override
    public int hashCode() {
        return Objects.hash(year, mouth, day);
    }

    @Override
    public String toString() {
        return year + "年" + mouth + "月" + day + "日";
    }
}