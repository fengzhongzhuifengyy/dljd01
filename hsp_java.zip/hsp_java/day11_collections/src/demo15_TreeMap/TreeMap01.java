package demo15_TreeMap;

import java.util.Comparator;
import java.util.TreeMap;

/**
 * TreeMap源码分析
 */
public class TreeMap01 {
    public static void main(String[] args) {
        //1.可以看出,使用默认的构造器创建TreeMap依然是无序的
        TreeMap treeMap = new TreeMap();
        treeMap.put("jack", "杰克");
        treeMap.put("tom", "汤姆");
        treeMap.put("kristina", "克瑞斯提诺");
        treeMap.put("smith", "斯密斯");
        System.out.println(treeMap);//{jack=杰克, kristina=克瑞斯提诺, smith=斯密斯, tom=汤姆}


        //要求按照传入的key(字母表大小)进行排序
        TreeMap treeMap1 = new TreeMap(new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((String)o1).compareTo((String)o2);
            }
        });
        treeMap1.put("jack", "杰克");
        treeMap1.put("tom", "汤姆");
        treeMap1.put("kristina", "克瑞斯提诺");
        treeMap1.put("smith", "斯密斯");
        System.out.println(treeMap1);//{jack=杰克, kristina=克瑞斯提诺, smith=斯密斯, tom=汤姆}

        //要求按照传入的key(长度)进行排序
        TreeMap treeMap2 = new TreeMap(new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((String)o1).length() - ((String)o2).length();
            }
        });
        treeMap2.put("jack", "杰克");
        treeMap2.put("tom", "汤姆");
        treeMap2.put("kristina", "克瑞斯提诺");
        treeMap2.put("smith", "斯密斯");
        treeMap2.put("hsp", "韩顺平");//这个能加进去吗? 不可以,比较的时候发现长度已经存在就直接加不进去了,仅替换了value //{tom=韩顺平, jack=杰克, smith=斯密斯, kristina=克瑞斯提诺}
        System.out.println(treeMap2);//{tom=汤姆, jack=杰克, smith=斯密斯, kristina=克瑞斯提诺}
    }

    /*
        源码分析:
        1. 构造器. 把传入的实现了 Comparator 接口的匿名内部类(对象)，传给给 TreeMap 的 comparator
            public TreeMap(Comparator<? super K> comparator) {
                this.comparator = comparator;
            }
        2. 调用 put 方法
        2.1 第一次添加, 把 k-v 封装到 Entry 对象，放入 root
            Entry<K,V> t = root;
            if (t == null) {
                compare(key, key); // type (and possibly null) check
                root = new Entry<>(key, value, null);
                size = 1;
                modCount++;
                return null;
            }
        2.2 以后添加
        Comparator<? super K> cpr = comparator;
            if (cpr != null) {
            do { //遍历所有的 key , 给当前 key 找到适当位置
                parent = t;
                cmp = cpr.compare(key, t.key);//动态绑定到我们的匿名内部类的 compare
                if (cmp < 0)
                    t = t.left;//这边就是在找位置
                else if (cmp > 0)
                    t = t.right;//这边就是在找位置
                else //如果遍历过程中，发现准备添加 Key 和当前已有的 Key 相等，就不添加
                    return t.setValue(value);
                } while (t != null);
        }
     */
}

