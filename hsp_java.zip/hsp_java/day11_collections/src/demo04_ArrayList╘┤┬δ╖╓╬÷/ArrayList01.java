package demo04_ArrayList源码分析;

import java.util.ArrayList;

/**
 *  ArrayList 的注意事项
 */
public class ArrayList01 {
    public static void main(String[] args) {

        //1.ArrayList 可以加入null,并且多个
        ArrayList arrayList = new ArrayList();
        arrayList.add(null);
        arrayList.add("jack");
        System.out.println("ArrayList = " + arrayList);//ArrayList = [null, jack]
        arrayList.add(null);
        System.out.println("ArrayList = " + arrayList);//ArrayList = [null, jack, null]
    }
}
