package demo04_ArrayList源码分析;

import java.util.ArrayList;

/**
 *  ArrayList 的底层操作机制源码分析(重点，难点.)
 */
public class ArrayList02 {
    @SuppressWarnings("all")
    public static void main(String[] args) {

        //使用无参构造器创建ArrayList对象
//        ArrayList list = new ArrayList();
        ArrayList list = new ArrayList(8);

        //list集合添加1 -10
        for (int i = 1; i <= 10; i++) {
            list.add(i);
        }

        //list集合添加11 -15
        for (int i = 11; i <= 15; i++) {
            list.add(i);
        }
        list.add(100);
        list.add(200);
        list.add(null);
    }
}
