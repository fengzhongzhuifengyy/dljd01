package demo16_Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *  Collections 工具类介绍1
 */
public class Collections01 {
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("tom");
        list.add("jack");
        list.add("milan");
        list.add("king");
        System.out.println(list);//[tom, jack, milan, king]

        //1.reverse(List) : 反转List中元素的顺序
        Collections.reverse(list);
        System.out.println(list);//[king, milan, jack, tom]

        //2.shuffle(List): 对List集合元素进行随机排序
        Collections.shuffle(list);
        System.out.println(list); //每次的输出不一致

        //sort(List): 根据元素的自然顺序对指定List集合元素按照升序排序
        Collections.sort(list);
        System.out.println(list);//[jack, king, milan, tom]

        //sort(List, Comparator): 根据指定的Comparator产生的顺序对List集合元素进行排序
        Collections.sort(list, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((String)o1).length() - ((String)o2).length();
            }
        });
        System.out.println(list);//[tom, jack, king, milan]

        //swap(List, int, int): 将指定的list集合中的i元素与j处的元素进行交换
        Collections.swap(list, 0, 1);
        System.out.println(list);//[jack, tom, king, milan]
    }
}
