package demo16_Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Collections 工具类介绍2
 */
public class Collections02 {
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("tom");
        list.add("jack");
        list.add("milan");
        list.add("king");
        System.out.println(list);//[tom, jack, milan, king]

        //1.Object max(Collection): 根据元素的自然顺序,返回给定集合中的最大元素
        Comparable max = Collections.max(list);
        System.out.println(max);//tom

        //2.Object max(Collection, Comparator): 根据Comparator指定的顺序,返回给定集合中的最大元素
        //返回长度最大的元素
        Object max1 = Collections.max(list, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((String)o1).length() - ((String)o2).length();
            }
        });
        System.out.println(max1);//milan

        //3.Object min(Collection):根据元素的自然顺序,返回给定集合中的最小元素
        //4.Object min(Collection, Comparator): 根据Comparator指定的顺序,返回给定集合中的最小元素

        //5.int frequency(Collection, Object):返回指定集合中元素出现的次数
        //查询tom出现的次数
        int tom = Collections.frequency(list, "tom");
        System.out.println(tom);//1

        //6.void copy(List dest, List src): 将src中的内容复制到dest中
        ArrayList arrayList = new ArrayList();
        // Collections.copy(arrayList, list);
        // System.out.println(arrayList);//IndexOutOfBoundsException
        /*
            if (srcSize > dest.size())
            throw new IndexOutOfBoundsException("Source does not fit in dest");
         */
        //为了完成一个完整的拷贝需要先给dest
        for (int i = 0; i < list.size(); i++) {
            arrayList.add(i);
        }
        Collections.copy(arrayList, list);
        System.out.println(arrayList);//[tom, jack, milan, king]

        //7.boolean replaceAll(List list, Object oldVal, Object newVal): 使用新值替换List对象的旧值
        Collections.replaceAll(list, "tom", "tom1");
        System.out.println(list); //[tom1, jack, milan, king]
    }
}
