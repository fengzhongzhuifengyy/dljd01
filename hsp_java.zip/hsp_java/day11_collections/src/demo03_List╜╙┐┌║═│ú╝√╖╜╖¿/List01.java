package demo03_List接口和常见方法;

import java.util.ArrayList;
import java.util.List;

/**
 *  List接口基本介绍
 */
public class List01 {
    public static void main(String[] args) {
        //1.List集合类中元素有序(即添加顺序和取出顺序一致),且可重复
        List list = new ArrayList();
        list.add("1");
        list.add("2");
        list.add("3");
        list.add("4");
        System.out.println("list = " + list);//list = [1, 2, 3, 4]
        //2.List集合中的每个元素都有其对应的顺序索引,即支持索引
        //索引是从0开始的
        System.out.println(list.get(0));//1
    }
}
