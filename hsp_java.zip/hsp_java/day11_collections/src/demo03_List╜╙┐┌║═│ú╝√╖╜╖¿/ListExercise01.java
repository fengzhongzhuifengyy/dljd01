package demo03_List接口和常见方法;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 添加 10 个以上的元素(比如 String "hello" )，在 2 号位插入一个元素"韩顺平教育"，
 * 获得第 5 个元素，删除第 6 个元素，修改第 7 个元素，在使用迭代器遍历集合，
 * 要求:使用 List 的实现类 ArrayList 完成。
 */
public class ListExercise01 {
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("S");
        list.add("t");
        list.add("r");
        list.add("i");
        list.add("n");
        list.add("g");
        list.add(" ");
        list.add("\"");
        list.add("h");
        list.add("e");
        list.add("l");
        list.add("l");
        list.add("o");
        list.add("\"");
        System.out.println("list = " + list); //list = [S, t, r, i, n, g,  , ", h, e, l, l, o, "]

        list.add(1, "韩顺平教育");
        System.out.println("list = " + list);//list = [S, 韩顺平教育, t, r, i, n, g,  , ", h, e, l, l, o, "]

        System.out.println("第5个元素: " + list.get(5));//n

        list.remove(6);
        System.out.println("list = " + list);//list = [S, 韩顺平教育, t, r, i, n,  , ", h, e, l, l, o, "]

        list.set(7, "韩顺平教育");
        System.out.println("list = " + list);//list = [S, 韩顺平教育, t, r, i, n,  , 韩顺平教育, h, e, l, l, o, "]

        //使用迭代器遍历集合
        Iterator iterator = list.iterator();
        while (iterator.hasNext()){
            System.out.print(iterator.next() + "\t");//S	韩顺平教育	t	r	i	n	 	韩顺平教育	h	e	l	l	o	"
        }
    }
}
