package demo03_List接口和常见方法;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 *  List的三种遍历方式[ArrayList, LinkedList, Vector]
 */
public class List03 {
    public static void main(String[] args) {

        //list子类都可以
        //List list = new ArrayList();
        //List list = new LinkedList();
        List list = new Vector();
        list.add("jack");
        list.add("tom");
        list.add("鱼香肉丝");
        list.add("北京烤鸭");

        //遍历
        //1.迭代器
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            Object obj =  iterator.next();
            System.out.print(obj + "\t");
        }
        System.out.println();
        //2.增强for
        for (Object values : list) {
            System.out.print(values + "\t");
        }
        System.out.println();

        //3.一般for
        for (int i = 0; i < list.size(); i++) {
            Object obj = list.get(i);
            System.out.print(obj + "\t");
        }
    }
}
