package demo14_TreeSet;

import java.util.Comparator;
import java.util.TreeSet;

/**
 *  TreeSet源码解读
 */
public class TreeSet01 {
    public static void main(String[] args) {
        TreeSet treeSet = new TreeSet();
        //添加数据
        treeSet.add("java");
        treeSet.add("python");
        treeSet.add("C");
        treeSet.add("go");
        treeSet.add("go");
        System.out.println(treeSet);//[C, go, java, python]
        /*
            1.当我们使用无参构造器,创建TreeSet时,结果仍然是无序的
         */
        //此时我们需求:首字母按照字母表的顺序排序怎么操作呢?
        //使用TreeSet提供的一个构造器,可以传入一个比较器(匿名内部类)并指定规则
        /*
            public TreeSet(Comparator<? super E> comparator) {
                this(new TreeMap<>(comparator));
            }
         */
        TreeSet treeSet1 = new TreeSet(new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                //调用String的compareTo()进行字符串大小的比较,默认按照每个字符的大小进行比较
                // return ((String)o2).compareTo((String)o1);
                //如果要求按照长度大小来写呢?
                return ((String)o2).length() - ((String)o1).length();
            }
        });
        treeSet1.add("java");
        treeSet1.add("python");
        treeSet1.add("C");
        treeSet1.add("go");
        treeSet1.add("go");
        treeSet1.add("fo");//此时长度相等,也是加不减去的
        System.out.println(treeSet1); //[python, java, go, C]
    }

    /*
        源码分析:
        1.构造器会将传入的匿名比较器对象(Comparator),赋给了TreeSet的底层的TreeMap的属性 this.comparator = comparator;
            public TreeMap(Comparator<? super K> comparator) {
                this.comparator = comparator;
            }
        2.在 调用 treeSet.add("tom"), 在底层会执行到
            if (cpr != null) {//cpr 就是我们的匿名内部类(对象)
            do {
                parent = t;
                //动态绑定到我们的匿名内部类(对象)compare
                cmp = cpr.compare(key, t.key);
                if (cmp < 0)
                    t = t.left;
                else if (cmp > 0)
                    t = t.right;
                else //如果相等，即返回 0,这个 Key 就没有加入
                    return t.setValue(value);
                } while (t != null);
             }
     */
}
