package demo17_Exercise;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *  编程题
 *  使用ArrayList完成对对象Car{name, price}的各种操作
 *  1.add:添加单个元素
 *  2.remove:删除指定元素
 *  3.contains:查找元素是否存在
 *  4.size:获取元素的个数
 *  5.isEmpty:判断是否为空
 *  6.clear:清空
 *  7.addAll:添加多个元素
 *  8.containsAll:查找多个元素是否都存在
 *  9.removeAll:删除多个元素
 *
 *  使用增强for和迭代器来遍历所有的car
 */
public class Exercise02 {
    public static void main(String[] args) {
        ArrayList arrayList = new ArrayList();
        //新增
        arrayList.add(new Car("兰博基尼", 1520000));
        arrayList.add(new Car("雪佛兰", 150000));
        arrayList.add(new Car("temp", 1));
        System.out.println("新增" + arrayList);
        //删除
        arrayList.remove(2);
        System.out.println("删除" + arrayList);

        //查询元素是否存在
        System.out.println("是否存在" + arrayList.contains("兰博基尼"));

        //获取元素的个数
        System.out.println("获取个数" + arrayList.size());

        //判断是否为空
        System.out.println("是否为空" + arrayList.isEmpty());

        //清空
        arrayList.clear();
        System.out.println("清空" + arrayList);

        //添加多个元素
        ArrayList arrayList1 = new ArrayList();
        arrayList1.add(new Car("张三",125));
        arrayList1.add(new Car("李四",125));
        arrayList.addAll(arrayList1);
        System.out.println("添加多个元素" + arrayList);

        //查找多个元素是否都存在
        System.out.println("多个元素是否存在" + arrayList.containsAll(arrayList1));

        //遍历
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            Object obj =  iterator.next();
            System.out.println("迭代器遍历" + obj);
        }

        //删除多个
        arrayList.removeAll(arrayList1);

        for (Object o :arrayList) {
            System.out.println("删除后" + o);
        }


    }
}
