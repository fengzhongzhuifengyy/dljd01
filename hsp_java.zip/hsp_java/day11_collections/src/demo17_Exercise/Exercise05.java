package demo17_Exercise;


import java.util.TreeSet;

/**
 *  代码分析题:
 *  下面的代码会不会出现异常,并从源码进行分析
 */
public class Exercise05 {
    public static void main(String[] args) {

        TreeSet treeSet = new TreeSet();
        // java.lang.ClassCastException : Person cannot be cast to java.lang.Comparable
        //add():因为TreeSet构造器没有传入Comparator接口的匿名内部类
        //所以底层会实现 Comparable<? super K> k = (Comparable<? super K>)key
        //强转把Person转成Comparable类型,就会发生类型转换异常
        treeSet.add(new Person());
    }
}
//那应该怎么解决呢?实现Comparable
//因为默认为0,所以只能添加一个对象,返回的都是0
class Person implements Comparable{

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
