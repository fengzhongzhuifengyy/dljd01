package demo17_Exercise;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *  编程题:
 *  1.使用HashMap类实例化一个Map类型的对象m,键(String)和值(int)分别用于存储员工的姓名和工资,存入数据如下:jack-650元; tom-1200元; smith-2900元
 *  2.将jack的工资改为2600
 *  3.为所有员工工资加薪100元
 *  4.遍历集合中所有的员工
 *  5.遍历集合中所有的工资
 */
public class Exercise03 {
    public static void main(String[] args) {

        Map map = new HashMap();
        map.put("jack", 650);//int -> Integer 自动装箱
        map.put("tom", 1200);
        map.put("smith", 2900);
        System.out.println(map);

        // map.put("jack", 2600);
        map.replace("jack", 2600);
        System.out.println(map);

        //为所有员工工资加薪100元
        Set set = map.keySet();
        for (Object obj : set) {
            //遍历使用map.put进行修改,修改的值通过map.get(key)去获取,但是需要向下转型,得到的是Object
            map.put(obj,(Integer)map.get(obj) + 100);
        }
        System.out.println(map);

        Set set1 = map.entrySet();
        for (Object o :set1) {
            System.out.println(((Map.Entry)o).getKey());
            System.out.println(((Map.Entry)o).getValue());
        }

    }
}
