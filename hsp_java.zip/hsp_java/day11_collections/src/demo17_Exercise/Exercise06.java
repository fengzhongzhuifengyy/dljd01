package demo17_Exercise;

import java.util.HashSet;
import java.util.Objects;

/**
 *  下面的代码输出?
 *  已知Person已经按照name和id重写的hashCode和equals方法
 */
public class Exercise06 {
    public static void main(String[] args) {
        HashSet set = new HashSet();
        Person1 p1 = new Person1(1001, "AA");
        Person1 p2 = new Person1(1002, "BB");
        set.add(p1);
        set.add(p2);
        p1.name = "CC";
        boolean remove = set.remove(p1);
        System.out.println(remove);//false
        System.out.println(set);//[Person1{name='BB', num=1002}, Person1{name='CC', num=1001}]
        set.add(new Person1(1001,"CC"));
        System.out.println(set);//[Person1{name='BB', num=1002}, Person1{name='CC', num=1001}, Person1{name='CC', num=1001}]
        set.add(new Person1(1001,"AA"));
        System.out.println(set);
    }
}

class Person1{
    public String name;
    public int num;

    public Person1(int num,String name) {
        this.name = name;
        this.num = num;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person1 person1 = (Person1) o;
        return num == person1.num && Objects.equals(name, person1.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, num);
    }

    @Override
    public String toString() {
        return "Person1{" +
                "name='" + name + '\'' +
                ", num=" + num +
                '}';
    }
}
