package demo17_Exercise;

/**
 *  新闻类
 */
public class News {
    private String total;
    private String content;

    public News(String total) {
        this.total = total;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String toString(){
        return "新闻: " + getTotal();
    }
}
