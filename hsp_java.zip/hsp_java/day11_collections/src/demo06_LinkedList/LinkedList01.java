package demo06_LinkedList;

/**
 *  LinkedList底层机制 --双向链表的模拟
 */
public class LinkedList01 {
    public static void main(String[] args) {
        //模拟一个简单的双向链表
        Node jack = new Node("jack");
        Node mark = new Node("mark");
        Node tom = new Node("tom");

        //链接三个节点,形成双向链接
        jack.next = mark;
        mark.next = tom;

        tom.prev = mark;
        mark.prev = jack;

        Node first = jack; //让first引用指向jack,就是双向链表的头结点
        Node last = tom;//让last引用指向tom,就是双向链表的尾结点

        //如何实现双向链表的遍历呢?
        //从头到尾进行遍历
        while (true){
            if (first == null){
                break;
            }
            System.out.println("正向遍历 " + first);//输出first引用
            first = first.next;// 引用first的一个节点: jack -> mark -> tom -> null,进入null的时候就直接返回了
        }

        //从尾到头的遍历
        while (true){
            if (last == null){
                break;
            }
            System.out.println("反向遍历 " + last);//输出first引用
            last = last.prev;// 引用last的上个节点: tom -> mark -> jack -> null,进入null的时候就直接返回了
        }

        //演示链表的添加对象,删除对象非常方便
        //需求:在mark -- tom中插入一个smith
        //1.创建Node节点,名称smith
        Node smith = new Node("smith");
        mark.next = smith;
        smith.next = tom;
        tom.prev = smith;
        smith.prev = mark;
        //first last 之前遍历就已经为null了
        Node first1 = jack;
        Node last1 = tom;
        while (true){
            if (first1 == null){
                break;
            }
            System.out.println("新增后遍历 " + first1);
            first1 = first1.next;
        }

    }
}


//定义一个Node类,表示双向链表的节点
class Node{
    public Object item; //真正存放数据的地方
    public Node next; //指向后一个节点
    public Node prev; //指向前一个节点

    public Node(Object name) {
        this.item = name;
    }

    public String toString(){
        return "Node name = " + item;
    }
}