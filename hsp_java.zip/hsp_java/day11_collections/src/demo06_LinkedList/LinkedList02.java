package demo06_LinkedList;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *  LinkedList的底层结构--增删改查案例
 */
public class LinkedList02 {
    public static void main(String[] args) {

        LinkedList linkedList = new LinkedList();
        //新增
        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);
        System.out.println("linkedList = " + linkedList);//linkedList = [1, 2, 3]

        //删除
        linkedList.remove(); //默认删除是第一个
//        linkedList.remove(2); 可以删除指定的node
        System.out.println("linkedList = " + linkedList);//linkedList = [2, 3]

        //修改
        linkedList.set(1, 999);//修改某个节点的对象
        System.out.println("linkedList = " + linkedList);//linkedList = [2, 999]

        //查询,索引从0开始
        Object element = linkedList.get(1);
        System.out.println(element);//999

        //因为LinkedList实现了List接口,遍历方式
        Iterator iterator = linkedList.iterator();
        while (iterator.hasNext()) {
            Object next =  iterator.next();
            System.out.print("迭代器遍历" + next + " ");
        }
        System.out.println();

        for (Object values : linkedList) {
            System.out.print("加强for遍历" + values + " ");
        }


        /*
            //源码阅读 add
            1. LinkedList linkedList = new LinkedList();
                public LinkedList() {}
            2. 这时 linkeList 的属性 first = null last = null
            3. 执行 添加
                public boolean add(E e) {
                    linkLast(e);
                    return true;
                }
            4.将新的结点，加入到双向链表的最后
                void linkLast(E e) {
                    final Node<E> l = last;
                    final Node<E> newNode = new Node<>(l, e, null);
                    last = newNode;
                    if (l == null)
                        first = newNode;
                    else
                        l.next = newNode;
                    size++;
                    modCount++;
                }
         */

        /*
            读源码 linkedList.remove(); // 这里默认删除的是第一个结点
            1. 执行 removeFirst
                public E remove() {
                    return removeFirst();
                }
            2. 执行
                public E removeFirst() {
                    final Node<E> f = first;
                    if (f == null)
                        throw new NoSuchElementException();
                    return unlinkFirst(f);
                }
            3. 执行 unlinkFirst, 将 f 指向的双向链表的第一个结点拿掉
                private E unlinkFirst(Node<E> f) {
                    // assert f == first && f != null;
                    final E element = f.item;
                    final Node<E> next = f.next;
                    f.item = null;
                    f.next = null; // help GC
                    first = next;
                    if (next == null)
                        last = null;
                    else
                        next.prev = null;
                    size--;
                    modCount++;
                    return element;
                }
            */
    }
}
