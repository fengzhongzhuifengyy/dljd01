package com.hspedu.java.day11_集合Collection.demo07_Set接口和常见方法;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 *  Set 接口的常用方法
 */
public class Set01 {
    public static void main(String[] args) {

        //1.以Set接口的实现类HashSet来讲解Set接口方法
        //2.Set接口对象(实现接口类的对象)不能存放重复的元素
        //3.可以添加null,但是因为第二点只能一个null
        //4.Set接口对象存放的数据是无序的(添加和取出的顺序不一样);
        //5.但是注意:取出顺序虽然不是添加的顺序,但是顺序出来之后不会再次变更
        Set set = new HashSet();
        set.add("wxj");
        set.add("xjc");
        set.add("vin");
        set.add("cvb");
        set.add("cvb");
        set.add("null");
        set.add("null");
        set.add("merry");//set =[xjc, null, wxj, vin, cvb, merry]
        System.out.println("set =" + set); //set =[xjc, null, wxj, vin, cvb]


        //遍历方式1 --使用迭代器
        Iterator iterator = set.iterator();
        while (iterator.hasNext()) {
            Object obj =  iterator.next();
            System.out.println("obj = " + obj);
        }
        //遍历方式2 --增强for
        for (Object obj : set) {
            System.out.println("obj = " + obj);
        }
        //传统的for循环可以吗? ---不可以没有get(),Set接口对象不能使用索引来获取
//        for (int i = 0; i < set.size(); i++) {
//            System.out.println(set.get(i));//无法解析 'Set' 中的方法 'get'
//        }

        //删除
        set.remove("null");
        System.out.println("set =" + set);
    }
}
