package demo12_HashTable;

import java.util.Hashtable;

/**
 * Hashtable基本介绍
 */
public class HashTable01 {
    public static void main(String[] args) {

        Hashtable hashtable = new Hashtable();
        hashtable.put("John", 100);//ok
        try {
            hashtable.put(null, 100); //空指针
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        try {
            hashtable.put("John", null);//空指针
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        hashtable.put("Lucy", 100);//ok
        hashtable.put("lic", 100);//ok
        hashtable.put("lic", 80);//替换
        System.out.println("hashtable = " + hashtable);

        /*
            分析HashTable的底层
            1.底层有数组 Hashtable$Entry[] 初始化大小为11
            2.临界值 threshold为8=11* 0.75
            3.扩容:按照自己的扩容机制来进行即可
            4. 执行方法 addEntry(hash, key, value, index);添加k-v 封装到Entry
            5.当if(count >= threshold)满足时,就进行扩容
            6.按照int newCapacity = (oldCapacity<<1) + 1;的大小扩容

         */
    }
}
