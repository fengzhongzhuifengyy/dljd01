package demo01_集合体系图;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *  集合体系图
 */
public class Collection01 {
    public static void main(String[] args) {
        /*
            1.集合分为两组:单列集合和双列集合
            2.Connection接口有两个重要的子接口: List Set,他们的实现类就是单列集合
            3.Map接口的重要子接口:HashMap, HashTable, TreeMap,他们的实现子类都是双列集合,可以理解为存放的为key-value
            4.图需要记下
         */
        //演示单列集合
        ArrayList arrayList = new ArrayList();
        arrayList.add("123");
        arrayList.add("456");

        //演示双列集合
        HashMap hashMap = new HashMap();
        hashMap.put("01", "张三");
        hashMap.put("02", "李四");
    }
}
