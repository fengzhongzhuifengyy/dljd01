package demo10_Map;

import java.util.HashMap;
import java.util.Map;

/**
 *  Map 接口常用方法
 */
public class Map03 {
    public static void main(String[] args) {
        Map map = new HashMap();
        map.put("邓超", new Book("", 100));//ok
        map.put("邓超", "孙俪");//替换
        map.put("王宝强", "马蓉");//ok
        map.put("宋喆", "马蓉");//ok
        map.put("刘令博", null);//ok
        map.put(null, "刘亦菲");//ok
        map.put("鹿晗", "关晓彤");//ok
        System.out.println("map=" + map); //map={邓超=孙俪, 宋喆=马蓉, 刘令博=null, null=刘亦菲, 王宝强=马蓉, 鹿晗=关晓彤}

        map.remove(null);
        System.out.println("map=" + map);//map={邓超=孙俪, 宋喆=马蓉, 刘令博=null, 王宝强=马蓉, 鹿晗=关晓彤}

        Object val = map.get("鹿晗");
        System.out.println(val);//关晓彤

        int size = map.size();
        System.out.println(size);//5

        boolean empty = map.isEmpty();
        System.out.println(empty);//false

        boolean containsKey = map.containsKey("鹿晗");
        System.out.println(containsKey);

        //清空
        map.clear();
        System.out.println("map=" + map);//map={}

    }
}

class Book {
    private String name;
    private int num;
    public Book(String name, int num) {
        this.name = name;
        this.num = num;
    }
}
