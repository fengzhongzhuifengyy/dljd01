package demo10_Map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 *  使用HashMap添加3个员工对象,要求:
 *  键:员工id
 *  值:员工对象
 *  并遍历显示工资>18000的员工(遍历方式最少两种)
 *  员工类:姓名 工资 员工id
 */
public class MapExercise01 {
    public static void main(String[] args) {
        Employ jack = new Employ("jack", 123465789, "001");
        Employ rose = new Employ("rose", 5789, "002");
        Employ smith = new Employ("smith", 123465, "003");

        Map map = new HashMap();
        map.put(jack.getId(), jack);
        map.put(rose.getId(), rose);
        map.put(smith.getId(), smith);

        // 方式1 keySet()
        Set set = map.keySet();
        for (Object obj : set) {
            if (((Employ)map.get(obj)).getSalary() > 18000){
                System.out.println(map.get(obj));
            }
        }

        Iterator iterator1 = set.iterator();
        while (iterator1.hasNext()) {
            Object obj = iterator1.next();
            if (((Employ)map.get(obj)).getSalary() > 18000){
                System.out.println(map.get(obj));
            }
        }
        System.out.println("------------------");
        //方式二 values()
        Collection values = map.values();

        for(Object obj : values){
            if(((Employ)obj).getSalary() > 18000){
                System.out.println(obj);
            }
        }

        Iterator iterator2 = values.iterator();
        while (iterator2.hasNext()) {
            Object obj =  iterator2.next();
            if (((Employ)obj).getSalary() > 18000){
                System.out.println(obj);
            }
        }
        System.out.println("------------------");

        //方式3 entrySet()
        Set set1 = map.entrySet();
        for (Object obj : set1) {
            Map.Entry entry = (Map.Entry)obj;
            if (((Employ)entry.getValue()).getSalary() > 18000){
                System.out.println(entry);
            }
        }

        Iterator iterator3 = set1.iterator();
        while (iterator3.hasNext()) {
            Object obj = iterator3.next();
            Map.Entry entry = (Map.Entry) obj;
            if (((Employ)entry.getValue()).getSalary() > 18000){
                System.out.println(entry);
            }
        }
    }
}
