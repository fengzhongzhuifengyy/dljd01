package demo10_Map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Map接口的遍历
 */
public class Map04 {
    public static void main(String[] args) {
        Map map = new HashMap();
        map.put("邓超", "孙俪");
        map.put("王宝强", "马蓉");
        map.put("宋喆", "马蓉");
        map.put("刘令博", null);
        map.put(null, "刘亦菲");
        map.put("鹿晗", "关晓彤");

        //第一组:先取出所有的key,通过key取出对应的value
        Set keySet = map.keySet();
        // 增强for
        for (Object obj : keySet) {
            System.out.print(obj + "-" + map.get(obj) + " ");//邓超-孙俪 宋喆-马蓉 刘令博-null null-刘亦菲 王宝强-马蓉 鹿晗-关晓彤
        }
        System.out.println("1.1");
        // 迭代器
        Iterator iterator = keySet.iterator();
        while (iterator.hasNext()) {
            Object key = iterator.next();
            System.out.print(key + "-" + map.get(key) + " ");//邓超-孙俪 宋喆-马蓉 刘令博-null null-刘亦菲 王宝强-马蓉 鹿晗-关晓彤
        }
        System.out.println("1.2");

        //第二组,取出所有的values,是个Values(Collection)
        Collection values = map.values();
        //这里也是可以使用所有的遍历方法
        for (Object val : values) {
            System.out.print(val + " ");//孙俪 马蓉 null 刘亦菲 马蓉 关晓彤
        }
        System.out.println("2.1");

        Iterator iterator1 = values.iterator();
        while (iterator1.hasNext()) {
            Object val = iterator1.next();
            System.out.print(val + " ");//孙俪 马蓉 null 刘亦菲 马蓉 关晓彤
        }
        System.out.println("2.2");

        //第三组: 通过EntrySet 来获取k-v
        Set entrySet = map.entrySet(); // EntrySet<Entry<k,v>>  entrySet()的返回值也是返回一个Set集合，此集合的类型为Map.Entry。

        // 增强for
        for (Object node : entrySet) {
//            System.out.println(node.getClass());//class java.util.HashMap$Node
            //node是Object, 需要向下转型为Entry,使用Entry的getKey() / getValue();因为向下转型为Node没有两个实现方法
            Map.Entry entry = (Map.Entry) node;
            System.out.print(entry.getKey() + "-" + entry.getValue() + " ");//邓超-孙俪 宋喆-马蓉 刘令博-null null-刘亦菲 王宝强-马蓉 鹿晗-关晓彤
        }
        System.out.println("3.1");

        //迭代器
        Iterator iterator2 = entrySet.iterator();
        while (iterator2.hasNext()) {
            Object node = iterator2.next();
            Map.Entry entry = (Map.Entry) node;
            System.out.print(entry.getKey() + "-" + entry.getValue() + " ");
        }
        System.out.println("3.2");
    }
}
