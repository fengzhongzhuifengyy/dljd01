package demo10_Map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *  Map接口的特点2
 */
public class Map02 {
    public static void main(String[] args) {

        Map map = new HashMap();
        map.put("no1", "txl");
        map.put("no2", "张无忌");

        /*
            分析:
            1.k-v 最后是 HaspMap$Node = newNode(hash, key, value, null);
            2.k-v 为了方便程序员的遍历,还会在底层创建 EntrySet 集合,该集合存放的元素的类型是 Entry,而一个Entry对象就包含了k,v : EntrySet<Entry<k,v>>;即:transient Set<Map.Entry<K,V>> entrySet;
            3.entrySet中,定义的类型是Map.Entry,但是实际上存放的还是HashMap$Node;为什么能放进去,这是因为 HashMap$Node Implements Map.Entry
            4.这样当把HashMap$Node 对象存放到entrySet就方便我们遍历,因为Map.Entry提供了两个方法(getKey()、getValue())
         */
        Set set = map.entrySet();
        System.out.println(set.getClass());//class java.util.HashMap$EntrySet
        for (Object obj : set) {
//            System.out.println(obj.getClass());//class java.util.HashMap$Node
            //为了从HashMap$Node取出 k-v
            //1.先做向下转型从Entry中取独有的方法
            Map.Entry entry = (Map.Entry)obj;
            System.out.println(entry.getKey() + "-" + entry.getValue());
        }

        Set set1 = map.keySet();
        System.out.println(set1.getClass());//class java.util.HashMap$KeySet
        Collection values = map.values();
        System.out.println(values.getClass());//class java.util.HashMap$Values
    }
}