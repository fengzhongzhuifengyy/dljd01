package demo02_Collection接口和常见方法;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Collection 迭代器遍历
 */
public class Collection02 {
    public static void main(String[] args) {

        Collection col = new ArrayList();

        col.add(new Book("三国演义", "罗贯中", 10.1));
        col.add(new Book("小李飞刀", "古龙", 5.1));
        col.add(new Book("红楼梦", "曹雪芹", 34.6));
        System.out.println("col = " + col);

        //现在想能够遍历col集合
        //1.先得到col对应的迭代器
        Iterator iterator = col.iterator();
        //2.使用while循环遍历
        while (iterator.hasNext()){//iterator.hasNext() 判断集合是否还有元素
            //返回下一个元素,类型是Object,  为什么不是Book,因为集合里面还可以存放其他东西
            Object obj = iterator.next();
            System.out.println(obj);//调用toString()
        }

        //优化--快速生成while循环迭代器: while --> itit
        //显示所有快捷键的快捷键: ctrl + J
//        while (iterator.hasNext()) {
//            Object next =  iterator.next();
//
//        }
        //3.当退出while循环后,这时iterator迭代器指向了最后的元素,如果再取值,就会报错
//        iterator.next(); //java.util.NoSuchElementException

        //4.如果想再次遍历,就需要重置迭代器
        iterator = col.iterator();
        while (iterator.hasNext()) {
            Object next =  iterator.next();
            System.out.println("第二次遍历: " + next);

        }
    }
}

class Book {
    private String name;
    private String author;
    private double price;

    public Book(String name, String author, double price) {
        this.name = name;
        this.author = author;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                '}';
    }
}
