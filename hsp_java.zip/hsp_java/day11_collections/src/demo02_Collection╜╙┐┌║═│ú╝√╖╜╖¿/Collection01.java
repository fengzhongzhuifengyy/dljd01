package demo02_Collection接口和常见方法;

import java.util.ArrayList;
import java.util.List;

/**
 *  Collection的方法
 *  Collection接口的常用方法,因为接口无法实例化我们以实现类ArrayList来演示Collection类的方法
 */
public class Collection01 {
    @SuppressWarnings("all")
    public static void main(String[] args) {
        //创建ArrayList,使用其接口类来接收
        List list = new ArrayList();
        //1.add() 添加指定元素
        list.add("jack");
        list.add(10); // list.add(new Integer(10))
        list.add(true);
        list.add("rose");
        list.add("hsp");
        list.add('A');
        System.out.println("list = " + list);//list = [jack, 10, true, rose, hsp, A]

        //2.remove() 删除指定的元素
        Object remove = list.remove(0);//根据索引删除元素,返回的是这个删除的对象
        System.out.println(remove);//"jack"
        System.out.println("list = " + list);//list = [10, true, rose, hsp, A]
        Boolean remove1 = list.remove(true);//删除指定的元素,返回的布尔类型,是否删除
        System.out.println("list = " + list);//list = [10, rose, hsp, A]
        list.remove(new Integer(10));
        System.out.println("list = " + list);//list = [rose, hsp, A]

        //3.contains() 查找元素是否存在
        System.out.println(list.contains("rose"));//true

        //4.size() 获取元素的个数
        System.out.println(list.size());//3

        //5.isEmpty() 判断集合是否为空
        System.out.println(list.isEmpty());//false

        //6.clear() 清空
        list.clear();
        System.out.println("list = " + list);//list = []

        //7.addAll() 添加多个元素
        ArrayList arrayList = new ArrayList();
        arrayList.add("红楼梦");
        arrayList.add("三国演义");
        list.addAll(arrayList);//传入集合和集合的子类对象
        System.out.println("list = " + list);//list = [红楼梦, 三国演义]

        //8.containsAll() 查找多个元素是否都存在,也是传入集合和集合的子类对象
        System.out.println(list.containsAll(arrayList));//true

        //9.removeAll() 删除多个元素
        list.add("聊斋");
        list.removeAll(arrayList);//传入的也是集合和集合的子类对象
        System.out.println("list = " + list);//list = [聊斋]

    }
}
