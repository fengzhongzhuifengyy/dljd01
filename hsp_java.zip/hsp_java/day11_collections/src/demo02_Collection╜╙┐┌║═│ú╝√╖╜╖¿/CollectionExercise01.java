package demo02_Collection接口和常见方法;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 1.创建 3 个 Dog {name, age} 对象，放入到 ArrayList 中，赋给 List 引用
 * 2.用迭代器和增强 for 循环两种方式来遍历
 * 3.重写 Dog 的 toString 方法， 输出 name 和 age
 */
public class CollectionExercise01 {
    public static void main(String[] args) {
        List list = new ArrayList();

        list.add(new Dog("小花", "10"));
        list.add(new Dog("小白", "10"));
        list.add(new Dog("小蓝", "10"));
        System.out.println(list);

        Iterator iterator = list.iterator();
        //迭代器
        while (iterator.hasNext()) {
            Object next =  iterator.next();
            System.out.println("迭代器: " + next);
        }

        //增强for
        for (Object values : list) {
            System.out.println("增强for: " + values);
        }

    }
}
class Dog{

    private String name;
    private String age;

    public Dog(String name, String age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age='" + age + '\'' +
                '}';
    }
}