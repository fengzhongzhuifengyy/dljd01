package demo02_Collection接口和常见方法;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.Collection;

/**
 *  Collection 接口遍历对象方式 2-for 循环增强
 */
public class Collection03{
    @SuppressWarnings("all")
    public static void main(String[] args) {
        Collection col = new ArrayList();

        col.add(new Book("三国演义", "罗贯中", 10.1));
        col.add(new Book("小李飞刀", "古龙", 5.1));
        col.add(new Book("红楼梦", "曹雪芹", 34.6));
        System.out.println("col = " + col);

        //1.使用增强for,在集合中使用
        for (Object values : col){
            System.out.println("book = " + values);
        }
        //2.增强for也可以直接使用在数组中
        //3.增强for的底层还是迭代器,可以理解成就是简化版的迭代器遍历
        //4 增强for的快捷键: I
//        for (Object o :) {
//
//        }
    }
}
