package demo09LinkedhashSet;


import java.util.LinkedHashSet;

/**
 *     分析LinkedHashSet的底层机制
 */
public class LinkedHashSet01 {
    public static void main(String[] args) {

        LinkedHashSet linkedHashSet = new LinkedHashSet();
        linkedHashSet.add(new String("AAA"));
        linkedHashSet.add(456);
        linkedHashSet.add(456);
        linkedHashSet.add(new Customer("张三"));
        linkedHashSet.add(123);
        linkedHashSet.add("hsp");
        System.out.println(linkedHashSet); //[AAA, 456, Customer{name='张三'}, 123, hsp]

        /*
            分析:
            1.LinkedHashSet 数据加入顺序与取出顺序一致
            2.LinkedHashSet 底层维护的是LinkedHashMap(是HashMap的子类)
            3.LinkedHashSet 底层结构(数组 + 双向链表)
            4.添加第一次时,直接将数组table(节点类型是HashMap$Node)扩容到16, 存放的节点类型是LinkedHashMap$Entry
            5.数组是HashMap$Node[]形式的数组,但是存放的数据/元素/对象是 LinkedHashMap$Entry
                 //继承关系在内部类完成的
                 static class Entry<K,V> extends HashMap.Node<K,V> {
                    Entry<K,V> before, after;
                    Entry(int hash, K key, V value, Node<K,V> next) {
                        super(hash, key, value, next);
                    }
                }
         */


    }
}

class Customer{
    private  String name;

    public Customer(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "name='" + name + '\'' +
                '}';
    }

}