package com.hspedu.java.day15_网络编程.demo03_UDP通信;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 *  1.编写一个接收端A,和一个发送端B
 *  2.接收端A在9999端口等待接收数据
 *  3.发送端B向接收端A发送数据"hello,明天吃火锅"
 *  4.接收端A收到发送端B发送的数据,回复"好的,明天见",再退出
 *  5.发送端接收回复的数据,再退出
 */
public class UDPSendB01 {
    public static void main(String[] args) throws IOException {

        //1.创建DatagramSocket对象,准备发送数据
        DatagramSocket socket = new DatagramSocket(9998);

        //2.将需要发送的数据封装到DatagramPacket
        byte[] bytes = "hello,明天吃火锅".getBytes();
        //说明:封装的DatagramPacket对象data内容字节数组, data.length, 主机(ip), 端口
        DatagramPacket packet = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("192.168.3.3"), 9999);

        //3.发送数据
        socket.send(packet);

        //4.接收从A发来的数据
        byte[] bytes1 = new byte[1024];
        DatagramPacket packet1 = new DatagramPacket(bytes1, bytes1.length);
        socket.receive(packet1);
        //拆包
        int length = packet1.getLength();
        byte[] data = packet1.getData();
        String s = new String(data, 0, length);
        System.out.println(s);

        //5.关闭流
        socket.close();
        System.out.println("发送端B退出...");

    }
}
