package com.hspedu.java.day15_网络编程.demo02_TCP通信;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 演示案例,使用字节流:
 * 1.编写一个服务器端和一个客户端
 * 2.服务器端在9999端口监听
 * 3.客户端连接到服务器端,发送"hello, server",然后退出
 * 4.服务器端接收到信息,输出,退出
 */
public class TCP01_Server {
    public static void main(String[] args) throws IOException {
        //1.服务器端开启"9999"端口
        // 细节: 要求在本机没有其它服务在监听 9999
        ServerSocket serverSocket = new ServerSocket(9999);
        System.out.println("服务端启动9999端口");
        //2.当没有客户端连接 9999 端口时，程序会 阻塞, 等待连接
        // 如果有客户端连接，则会返回 Socket 对象，程序继续
        // 细节：这个 ServerSocket 可以通过 accept() 返回多个 Socket[多个客户端连接服务器的并发]
        Socket socketServer = serverSocket.accept();
        System.out.println("服务端 socket = " + socketServer.getClass());
        //3.通过 socket.getInputStream() 读取客户端写入到数据通道的数据, 显示
        InputStream inputStream = socketServer.getInputStream();
        //4.io 读取
        byte[] data = new byte[1024];
        int length = 0;
        while ((length = inputStream.read(data)) != -1) {
            System.out.println(new String(data, 0 , length));
        }
        //5.关闭流和 socket
        inputStream.close();
        socketServer.close();
        serverSocket.close();
        System.out.println("服务端退出");
    }
}
