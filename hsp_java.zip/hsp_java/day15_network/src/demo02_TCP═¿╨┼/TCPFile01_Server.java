package com.hspedu.java.day15_网络编程.demo02_TCP通信;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *  演示文件上传
 *  1. 编写一个服务器端和一个客户端
 * 2. 服务器端在8888端口监听
 * 3. 客户端连接到服务器端,发送一张图片
 * 4. 服务器端接收到 客户端发送的图片,保存到src下,发送"收到图片",再退出
 * 5. 该程序要求使用StreamUtils.java
 */
public class TCPFile01_Server {
    public static void main(String[] args) throws Exception {
        //1.服务端在本机监听"8888"端口
        ServerSocket serverSocket = new ServerSocket(8888);
        System.out.println("服务端在888端口监听");
        //2.等待客户端的连接
        Socket socketServer = serverSocket.accept();
        //3.读取客户端发送的数据
        //  3.1通过socket得到输入流
        BufferedInputStream bufferedInputStream = new BufferedInputStream(socketServer.getInputStream());
        //  3.2通过工具类将输入变为byte[]
        byte[] bytes = StreamUtils.streamToByteArray(bufferedInputStream);
        //4.将得到的byte数组写入到指定的路径,保存起来
        String filepath = "E:\\6.png";
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(filepath));
        bufferedOutputStream.write(bytes);
        bufferedOutputStream.close();

        //4.向客户端发送"收到图片"
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(socketServer.getOutputStream()));
        bufferedWriter.write("收到图片");
        bufferedWriter.flush();//把内容刷新到数据通道
        socketServer.shutdownOutput();//结束标志
        //5.闭流
        bufferedWriter.close();
        bufferedInputStream.close();
        socketServer.close();
        serverSocket.close();
    }
}
