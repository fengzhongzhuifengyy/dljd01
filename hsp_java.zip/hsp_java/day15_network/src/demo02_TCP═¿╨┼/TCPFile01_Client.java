package com.hspedu.java.day15_网络编程.demo02_TCP通信;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.Socket;

/**
 *  演示文件上传
 *  1. 编写一个服务器端和一个客户端
 * 2. 服务器端在8888端口监听
 * 3. 客户端连接到服务器端,发送一张图片
 * 4. 服务器端接收到 客户端发送的图片,保存到src下,发送"收到图片",再退出
 * 5. 该程序要求使用StreamUtils.java
 */
public class TCPFile01_Client {
    public static void main(String[] args) throws Exception {
        //1.客户端连接服务器,得到Socket对象
        Socket socketClient = new Socket(InetAddress.getLocalHost(),8888);

        //2.创建读取我磁盘文件的输入流(二进制)
        String filepath = "E:\\2.png";
        BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(filepath));

        //3.将文件的输入流保存到字节数组中,引用工具类的方法
        //这里的data就是filepath对应的字节数组
        byte[] data = StreamUtils.streamToByteArray(bufferedInputStream);

        //4.通过socket获取到输出流,将data数据发送给服务器
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(socketClient.getOutputStream());
        bufferedOutputStream.write(data);//将文件对应的字节数组的内容 写入到数据通道
        bufferedOutputStream.flush();
        //5.设置写入结束的标志
        socketClient.shutdownOutput();
        System.out.println("客户端发送图片成功");

        //6.接收从服务端回复的消息
        InputStream inputStream = socketClient.getInputStream();
        //使用工具类将inputStream读取到的内容转成字符串
        String s = StreamUtils.streamToString(inputStream);
        System.out.println(s);

        //7.闭流
        inputStream.close();
        bufferedInputStream.close();
        bufferedOutputStream.close();
        socketClient.close();
    }
}