package com.hspedu.java.day15_网络编程.demo02_TCP通信;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *  应用案例2
 *  1.编写一个服务器端和一个客户端
 *  2.服务器端在9999端口监听
 *  3.客户端连接到服务器端,发送"hello, server",并接收服务端回发的"hello,client",再退出
 *  4.服务器端接收到 客户端发送的消息,输出,并发送"hello client",再退出
 */
public class TCP02_Server {
    public static void main(String[] args) throws IOException {
        //1.开启 9999端口服务
        ServerSocket serverSocket = new ServerSocket(9999);

        //2.监听连接9999的socket
        Socket socketServer = serverSocket.accept();

        //3.接收客户端信息
        InputStream inputStream = socketServer.getInputStream();
        byte[] data = new byte[1024];
        int length = 0;
        while ((length = inputStream.read(data)) != -1){
            System.out.println(new String(data, 0, length));
        }
        System.out.println("服务端接收消息成功");

        //4.服务端发送消息
        OutputStream outputStream = socketServer.getOutputStream();
        outputStream.write("hello,client".getBytes());
        socketServer.shutdownOutput();//保证服务端对服务器端的输入结束
        System.out.println("服务端发送消息成功");

        //5.闭流
        outputStream.close();
        inputStream.close();
        socketServer.close();
        serverSocket.close();

        /*
            这时发现一个问题, 程序不会继续执行下去,在等待客户端是否还会继续输入
            ,为了能让程序继续走下去,我们需要增加判断方法,"已经输入完毕"
         */
    }
}
