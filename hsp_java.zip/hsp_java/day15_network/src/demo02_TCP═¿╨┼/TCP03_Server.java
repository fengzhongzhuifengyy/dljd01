package com.hspedu.java.day15_网络编程.demo02_TCP通信;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 应用案例3 字符流
 * 1.编写一个服务器端和一个客户端
 * 2.服务器端在9999端口监听
 * 3.客户端连接到服务器端,发送"hello, server",并接收服务端回发的"hello,client",再退出
 * 4.服务器端接收到 客户端发送的消息,输出,并发送"hello client",再退出
 */
public class TCP03_Server {
    public static void main(String[] args) throws IOException {

        ServerSocket serverSocket = new ServerSocket(9999);

        Socket socketServer = serverSocket.accept();

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socketServer.getInputStream()));
        String data = bufferedReader.readLine();
        System.out.println(data);
        System.out.println("服务端接收消息完成");

        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(socketServer.getOutputStream()));
        bufferedWriter.write("hello client");
        bufferedWriter.newLine();//插入一个换行符,表示回复内容结束
        bufferedWriter.flush();//如果使用的字符流,需要我们手动刷新,否则数据不会写入数据通道
        // socketServer.shutdownOutput();
        System.out.println("服务端发送消息完成");


        bufferedWriter.close();
        bufferedReader.close();
        socketServer.close();
        serverSocket.close();

        /*
            调式时发现一个问题,不能进行while循环判断是否有bufferedReader.readLine(),否则程序会卡死,原因:

            我们可能下意识地认为readLine()读取到没有数据时就返回null(因为read()方法当读到没有数据时返回-1)，
            而实际上readLine()是一个阻塞函数，当没有数据读取时，就一直会阻塞在那，而不是返回null。
            readLine()只有在数据流发生异常或者另一端被close()掉时，才会返回null值。

            通过查看源码可知，readLine()是调用了read(char[] cbuf, int off, int len) 来读取数据，后面再根据"/r"或"/n"来进行数据处理，所以使用readLine()一定要注意：
            1.读入的数据要注意有/r或/n或/r/n
            2.没有数据时会阻塞，在数据流异常或断开时才会返回null
            3.非必要时（socket之类的数据流），要避免使用readLine()，以免为了等待一个换行/回车符而一直阻塞
         */
    }
}
