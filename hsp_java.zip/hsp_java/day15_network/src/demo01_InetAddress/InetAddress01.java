package com.hspedu.java.day15_网络编程.demo01_InetAddress;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 *  演示 INetAddress
 */
public class InetAddress01 {
    public static void main(String[] args) throws UnknownHostException {

        //1.获取本机InetAdress对象 --InetAddress.getLocalHost()
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println(localHost);//PC-20200514QPHI/192.168.3.3

        //2.根据指定主机名/域名获取ip地址对象 --InetAddress.getByName("PC-20200514QPHI")
        InetAddress hostName1 = InetAddress.getByName("PC-20200514QPHI");
        System.out.println(hostName1);//PC-20200514QPHI/192.168.3.3

        //3.根据指定域名获取ip地址对象 --InetAddress.getByName("www.baidu.com")
        InetAddress hostName2 = InetAddress.getByName("www.baidu.com");
        System.out.println(hostName2);//www.baidu.com/180.101.49.12

        //4.获取InetAdress对象的主机名/域名和地址 --hostName2.getHostName()
        String hostName = hostName2.getHostName();
        System.out.println(hostName);//www.baidu.com

        String hostAddress = hostName2.getHostAddress();
        System.out.println(hostAddress);//180.101.49.12

    }
}
