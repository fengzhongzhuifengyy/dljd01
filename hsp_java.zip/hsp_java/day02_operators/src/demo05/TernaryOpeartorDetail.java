package demo05;

/**
 * 
 * 	三元运算符的细节:
 * 	1.表达式1和表达式2要为可以赋给接收变量的类型(或可以自动类型转换)
 * 	2.三元运算符可以与if else 互换
 *	练习:
 *		实现3个数中的最大值
 */
public class TernaryOpeartorDetail {
	public static void main(String[] args) {
		
		int a = 8;
		int b = 9;
		double c = a > b ? a : b;  // 自动转换
		System.out.println(c);
		
		//cannot convert from double to int
//		int d = a > b? 1.1 :1.2;
		
		
		// 实现3个数中的最大值
		int x = 10;
		int y = 11;
		int z = 12;
		
		int result1 = (x > y)? x : y;
		int result2 = (result1 > z)? result1 : z;
		System.out.println("最大数为:" + result2);
		
		//替换变量(不推荐)
		int max = (((x > y)? x : y) > z)? ((x > y)? x : y) : z;
		System.out.println("最大数为:" + max);
		
	}
}
