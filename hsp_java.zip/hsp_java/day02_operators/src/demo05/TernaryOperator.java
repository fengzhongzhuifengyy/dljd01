package demo05;
/**
 * 
 * 	三元运算符:
 *
 */
public class TernaryOperator {

	public static void main(String[] args) {
		int a = 10;
		int b = 99;
		int result = (a > b) ? a++ : b--;
		System.out.println(result); // 99
		System.out.println(b); // 98

	}

}
