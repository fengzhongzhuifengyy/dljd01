package demo04;

/**
 * 
 * 	赋值运算符的使用:
 * 	运算顺序从右往左;
 *	赋值运算符的左边只能是变量,右边可以是变量/表达式/常量值
 *	复合赋值运算符等价于a+=b --> a = a+b
 *	复合赋值运算符会进行强制类型转换:byte  b = 2; b+=3; b++
 *
 */
public class AssignOperator {
	public static void main(String[] args) {
		
		int n1 = 10;
		n1 += 4;
		System.out.println("n1 = " +  n1); // 14
		
		n1 /= 3;
		System.out.println("n1 = " +  n1); // 4
		
		// 复合赋值运算符会进行强制类型转换,编译不会报错
		byte b = 3;
		b+=2; // 等价于 b = (byte)(b+2);
		b++; // b = (byte)b + 1;
		System.out.println(b);
		
	}
}
