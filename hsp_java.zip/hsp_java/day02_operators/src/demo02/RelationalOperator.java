package demo02;

/**
 * 关系运算符:
 */
public class RelationalOperator {
	public static void main(String[] args) {
		
		int a = 9;
		int b = 8;
		System.out.println(a == b);
		System.out.println(a != b);
		System.out.println(a > b);
		System.out.println(a < b);
		System.out.println(a >= b);
		System.out.println(a <= b);
		boolean flag = a > b;
	}

}
