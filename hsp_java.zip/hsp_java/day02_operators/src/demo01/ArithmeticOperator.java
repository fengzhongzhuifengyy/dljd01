package demo01;

/*
 *  算数运算符
 */
public class ArithmeticOperator {
	
	public static void main(String[] args) {
		
		/** 
		 *  / 的使用
		 */
		System.out.println(10 / 4); // 从数学来看是2.5,但是在java中是2
		System.out.println(10.0 / 4); // 2.5
		double d = 10 / 4;
		System.out.println(d);  // 2.0 
		
		
		/** 	
		 * % 取模 取余
		 * 在java中,取模的本质: 看一个公示: a % b = a - a / b * b
		 */
		System.out.println(10 % 3); // 1
		System.out.println(-10 % 3); // -1
		System.out.println(10 % -3); // 1
		System.out.println(-10 % -3); // -1
		
		
		/**
		 * ++ 作为独立语句使用,++完全等价于i = i + 1;
		 */
		int i = 10;
		i++; // 自增: 等价于 i = i + 1;
		System.out.println(i);
		
		++i; // 自增:等价于 i = i + 1;
		System.out.println(i);
		
		
		/**
		 * 	++ 作为表达式来使用:	
		 *	前++ : 先赋值再自增
		 * 	后++ : 先自增再赋值
		 */
		int j = 100;
		int k = j++; // 等价 k = j; j = j + 1;
		System.out.println("k = " + k ); // 100
		System.out.println("j = " + j ); // 101
		
		int m = ++j; //等价: j =j +1; j = k;
		System.out.println("m = " + m); // 102
		System.out.println("j = " + j); // 102
	}

}
