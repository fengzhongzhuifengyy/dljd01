package demo01;

// 算术运算符面试题
public class ArithmeticOperatorExercise01 {
	public static void main(String[] args) {
		
//		int i = 1;
//		i = i++;
//		System.out.println(i);  // 1
		
		/*
		 *	使用临时变量:  先赋值,再自增
		 *	1.temp = i;
		 *	2.i = i +1; // 2
		 *	3.i = temp;
		 */
		
		int i =1;
		i = ++i;
		System.out.println(i);
		/*
		 * 	规则:
		 * 		1.i = i + 1;
		 * 		2.temp = i;
		 * 		3.i = temp
		 */
	}
}
