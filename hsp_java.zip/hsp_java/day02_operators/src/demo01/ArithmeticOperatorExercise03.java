package demo01;

// 假设还有59天放假,问:合**个星期零**天

// 定义一个变量保存华氏温度,华氏温度转换为摄氏温度的公式为:5/9*(华氏温度-100),请求出华氏温度对应的摄氏温度.[234.5]
public class ArithmeticOperatorExercise03 {
	public static void main(String[] args) {
		
		int num1 = 59 / 7;
		
		int num2 = 59 % 7;
		
		System.out.println("合" + num1 + "个星期零" + num2 + "天");
		
		
		double temp1 = 234.5;
//		double temp2 = ((double)5 / 9) * ((double)(temp1 -100));
		double temp2 = 5.0 / 9 * (temp1 -100);
		System.out.println(temp2);
		
	}
}
