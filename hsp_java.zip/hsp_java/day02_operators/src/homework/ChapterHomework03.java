package homework;

/**
 * 
 * 判断下面的赋值语句是否正确：
 * 	int num1 = (int)"18";
 * 	int num2 = 18.0;
 * 	double num3 = 6d;
 * 	double num4 = 8;
 * 	int i = 48; char ch = i + 1;
 * 	byte b1 = 19; short s = b1 + 2;
 *
 */
public class ChapterHomework03 {

}
