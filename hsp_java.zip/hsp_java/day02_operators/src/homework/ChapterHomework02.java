package homework;

/**
 * 
 *	计算下面代码的值：
 *	int i = 66；
 *	System.out.println(++i+i);
 *
 */
public class ChapterHomework02 {

}
