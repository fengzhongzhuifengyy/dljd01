package homework;

/**
 *	计算下列表达式的结果：
 *	10 / 3 = ?
 *	10 / 5 = ?
 *	10 % 2 = ?
 *	-10.5 % 3 = ? 特别要注意这个：当a % b，a是小数时，公式 = a - （int）a / b * b
 *
 */
public class ChapterHomework01 {

}
