package homework;

/**
 * 	
 * 试写出将String转换成double类型的语句；以及将char类型转换为String类型的语句
 *
 */
public class ChapterHomework04 {

}
