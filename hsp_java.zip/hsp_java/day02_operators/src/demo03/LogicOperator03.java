package com.hspedu.java.day02_运算符.demo03;
/**
 * !和^演示
 */
public class LogicOperator03 {

	public static void main(String[] args) {
		
		// 取反
		System.out.println(60 > 20);
		
		System.out.println(!(20 > 60));
		
		
		// 异或
		boolean b = (10 > 1)^(3 < 5);
		System.out.println(b); // false
	}

}
