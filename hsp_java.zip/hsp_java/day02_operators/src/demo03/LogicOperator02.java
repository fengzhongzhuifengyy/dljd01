package com.hspedu.java.day02_运算符.demo03;

/**
 * || | 的区别
 */
public class LogicOperator02 {

	public static void main(String[] args) {
		
		// ||和|使用及区别
		int age = 50;
		if (age > 20 || ++age < 90) {
			System.out.println("ok100");
		}
		System.out.println("age = " + age); // 50
		
		if (age > 20 | ++age < 90) {
			System.out.println("ok200");
		}
		System.out.println("age = " + age); // 51
	}

}
