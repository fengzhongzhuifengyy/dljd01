package com.hspedu.java.day02_运算符.demo03;

/**
 * && &的区别
 */
public class LogicOperator01 {

	public static void main(String[] args) {
		
		// &&和&的使用
		int age = 50;
		if (age > 20 && age < 90) {
			System.out.println("ok100");
		}
		
		//&的使用
		if (age > 20 && age < 90) {
			System.out.println("ok200");
		}
		
		// &&和&的区别
		/*
		 * 对于&,即使第一个条件为false,后面的条件仍然会判断
		 */
		int a = 4;
		int b = 9;
		if (a < 1 & ++b < 50) {
			System.out.println("ok300");
		}
		System.out.println("a = " + a + "b = " + b); // 4 ; 10
		
		/*
		 * 对于&&,如果第一个条件为false,后面的条件不会执行
		 */
		if (a < 1 && ++b < 50) {
			System.out.println("ok400");
		}
		System.out.println("a = " + a + "b = " + b); // 4 ; 10
	}

}
