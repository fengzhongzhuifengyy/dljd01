package demo03_Class类;

import java.lang.reflect.Field;

/**
 *  演示Class类的常用方法
 */
public class Reflection02 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException {

        String classPath = "com.hspjava.day16_反射.demo03_Class类.Car";
        //1.获取到Car类对应的Class对象
        //Class<?>: 表示不确定的java类型
        Class<?> cls = Class.forName(classPath);

        //2.输出cls
        System.out.println(cls);//显示cls对象,是什么类的Class对象? //class com.hspjava.day16_反射.demo03_Class类.Car
        //输出运行类型
        System.out.println(cls.getClass());//class java.lang.Class --运行类型

        //3.得到包名
        System.out.println(cls.getPackage().getName());//com.hspjava.day16_反射.demo03_Class类

        //4.得到全类名
        System.out.println(cls.getName()); //com.hspjava.day16_反射.demo03_Class类.Car

        //5.通过cls对象(模板)创建实例
        Car car = (Car)cls.newInstance();
        System.out.println(car);//car.toString() --Car{brand='宝马', price=500000, color='白色'}

        //6.通过反射获取属性
        Field brand = cls.getField("brand");
        System.out.println(brand.get(car));//宝马

        //7.通过反射给属性赋值
        brand.set(car, "奔驰");
        System.out.println(brand.get(car));//奔驰

        //8.遍历得到所有的属性
        Field[] fields = cls.getFields();
        for (Field values : fields) {
            System.out.println(values.getName());//brand price color
        }

    }
}
