package demo03_Class类;

/**
 *  Class类分析
 */
public class Reflection01 {
    public static void main(String[] args) throws ClassNotFoundException {
        //1. Class也是类,因此也继承Object类
        //2. Class类对象不是new出来的,而是系统创建的
        //(1)传统的方法
        /*
         Classloader类:
         public Class<?> loadClass(String name) throws ClassNotFoundException {
             return loadClass(name, false);
         }
         */
        // Cat cat = new Cat();

        //(2) 反射方式: 刚才没有 debug 到 ClassLoader 类的 loadClass, 原因是，我没有注销 Cat cat = new Cat();
        /* ClassLoader 类, 仍然是通过 ClassLoader 类加载 Cat 类的 Class 对象
         public Class<?> loadClass(String name) throws ClassNotFoundException {
          return loadClass(name, false);
          }
        */
        Class<?> cls1 = Class.forName("com.hspjava.day16_反射.demo01_引出反射.Cat");

        //3. 对于某个类的 Class 类对象，在内存中只有一份，因为类只加载一次
        //怎么验证? 看两个对象的hashCode是否一致
        Class<?> cls2 = Class.forName("com.hspjava.day16_反射.demo01_引出反射.Cat");
        System.out.println(cls1.hashCode());
        System.out.println(cls2.hashCode());

        //4. 每个类的实例都会记得自己是由哪个Class实例所生成
        //5. 通过Class对象可以完整的得到一个类的完整结构,通过一系列API
        //6. Class对象是存放在堆中的
        //7. 类的字节码二进制数据,是放在方法区的,有的地方称为类的元数据(包括 方法代码, 变量名, 方法名,访问权限等等)
    }
}
