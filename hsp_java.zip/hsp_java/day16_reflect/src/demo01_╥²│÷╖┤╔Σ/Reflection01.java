package demo01_引出反射;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;

/**
 *  反射的引入
 *  根据配置文件re.properties 指定的消息,创建对象并调用方法
 */
public class Reflection01 {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        //根据配置文件re.properties 指定的消息,创建对象并调用方法
        //传统的方式:new对象 -> 调方法
        // Cat cat = new Cat();
        // cat.hi();

        //我们尝试做一下 明白反射的价值
        //1.使用Properties类读取配置文件
        String filepath = "D:\\Document\\javahsp\\src\\com\\hspjava\\day16_反射\\demo01_引出反射\\re.properties";
        Properties properties = new Properties();
        properties.load(new FileInputStream(filepath));
        String classfullpath = properties.get("classfullpath").toString();
        String methodName = properties.get("method").toString();
        System.out.println("classfullpath=" + classfullpath);
        System.out.println("method=" + methodName);
        //目前传统的方法已经不行了,String已经无法转成类

        //2.尝试使用反射来解决
        //2.1 加载类
        Class cls = Class.forName(classfullpath);
        //2.2 通过cls得到你加载的类--即配置的对象实例
        Object o = cls.newInstance();
        System.out.println("运行类型" + o.getClass());
        //2.3通过cls 得到你加载类的Cat的methodName的 方法对象
        //在反射中,可以把方法当做对象
        Method method = cls.getMethod(methodName);
        //2.4 通过method调用方法; 通过方法对象实现调用方法
        method.invoke(o); // hi~招财猫
    }
}
