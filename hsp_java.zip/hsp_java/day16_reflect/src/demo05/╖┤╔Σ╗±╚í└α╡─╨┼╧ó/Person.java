package demo05.反射获取类的信息;

/**
 * 演示类
 */
@Deprecated
public class Person extends Animal implements IA, IB {
    //属性
    public String name;
    protected int age;
    String job;
    private double sal;

    //构造器
    public Person() {

    }

    public Person(String name) {
        this.name = name;
    }

    private Person(int age) {
        this.age = age;
    }

    public Person(String name, int age, String job, double sal) {
        this.name = name;
        this.age = age;
        this.job = job;
        this.sal = sal;
    }

    //方法
    public void m1(String name, int age, double sal) {

    }

    protected void m2() {

    }

    void m4() {

    }

    private void m5() {

    }
}

interface IA {

}

interface IB {

}

