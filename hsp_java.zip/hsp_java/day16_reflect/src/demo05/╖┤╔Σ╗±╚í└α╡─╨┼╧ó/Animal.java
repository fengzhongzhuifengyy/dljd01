package demo05.反射获取类的信息;

/**
 *  演示类
 */
public class Animal {
    public String hobby;

    public Animal(){

    }
    public void hi(){

    }
}
