package demo05.反射获取类的信息;

import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 通过反射获取类的结构信息
 * java.lang.Field类
 */
public class Reflection02 {

    public static void main(String[] args) {

    }

    @Test
    public void api_02() throws ClassNotFoundException {
        //得到Class类的对象
        Class<?> personCls = Class.forName("com.hspjava.day16_反射.demo05.反射获取类的信息.Person");
        //本类的所有属性
        Field[] declaredFields = personCls.getDeclaredFields();
        for (Field field : declaredFields) {
            System.out.println("本类的所有属性" + field.getName());// name age job sal
            System.out.println("本类属性的修饰符值" + field.getModifiers()); // 1, 4, 0, 2
            System.out.println("本类属性的类型为" + field.getType());// class java.lang.String 本类属性的类型为int class java.lang.String  本类属性的类型为double
            //如果修饰符是组合出现即将对应的数相加
        }

    }

    @Test
    public void api_03() throws ClassNotFoundException {
        //得到Class类的对象
        Class<?> personCls = Class.forName("com.hspjava.day16_反射.demo05.反射获取类的信息.Person");
        //得到所有的方法
        Method[] declaredMethods = personCls.getDeclaredMethods();
        for (Method method : declaredMethods) {
            System.out.println("本类中的方法: " + method.getName() +
                                "该方法的修饰符的值" + method.getModifiers() +
                                "该方法返回的类型为" + method.getReturnType());
            //返回该方法的形参类型 按照数组的方式
            Class<?>[] parameterTypes = method.getParameterTypes();
            for (Class aClass :parameterTypes) {
                System.out.println("该方法的形参的类型为" + aClass);
            }

        }
        /*
            本类中的方法: m1该方法的修饰符的值1该方法返回的类型为void
            该方法的形参的类型为class java.lang.String
            该方法的形参的类型为int
            该方法的形参的类型为double
            本类中的方法: m2该方法的修饰符的值4该方法返回的类型为void
            本类中的方法: m4该方法的修饰符的值0该方法返回的类型为void
            本类中的方法: m5该方法的修饰符的值2该方法返回的类型为void
         */
    }

    @Test
    public void api_04() throws ClassNotFoundException {
        //得到Class类的对象
        Class<?> personCls = Class.forName("com.hspjava.day16_反射.demo05.反射获取类的信息.Person");
        //得到所有的构造器
        Constructor<?>[] declaredConstructors = personCls.getDeclaredConstructors();
        for (Constructor constructor :declaredConstructors) {
            System.out.println("本类所有的构造器" + constructor);
            Class[] parameterTypes = constructor.getParameterTypes();
            for (Class aClass :parameterTypes) {
                System.out.println("该构造器对应的形参类型" + aClass.getName());
            }

        }

    }
    /*
    本类所有的构造器public com.hspjava.day16_反射.demo05.反射获取类的信息.Person(java.lang.String,int,java.lang.String,double)
    该构造器对应的形参类型java.lang.String
    该构造器对应的形参类型int
    该构造器对应的形参类型java.lang.String
    该构造器对应的形参类型double
    本类所有的构造器private com.hspjava.day16_反射.demo05.反射获取类的信息.Person(int)
    该构造器对应的形参类型int
    本类所有的构造器public com.hspjava.day16_反射.demo05.反射获取类的信息.Person(java.lang.String)
    该构造器对应的形参类型java.lang.String
    本类所有的构造器public com.hspjava.day16_反射.demo05.反射获取类的信息.Person()
     */

}
