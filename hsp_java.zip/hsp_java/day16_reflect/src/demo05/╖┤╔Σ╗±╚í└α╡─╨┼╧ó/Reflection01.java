package demo05.反射获取类的信息;

import org.junit.jupiter.api.Test;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 通过反射获取类的结构信息
 * java.lang.Class类
 */
public class Reflection01 {
    public static void main(String[] args) {

    }

    @Test
    public void api_01() throws ClassNotFoundException {
        //得到Class类
        Class<?> personCls = Class.forName("com.hspjava.day16_反射.demo05.反射获取类的信息.Person");

        //1.getName() : 获得全类名
        System.out.println(personCls.getName());//com.hspjava.day16_反射.demo05.反射获取类的信息.Person

        //2.getSimpleName() : 获取简单类名
        System.out.println(personCls.getSimpleName());//Person

        // 3. getFields() : 获取所有public修饰的属性,包含本类以及父类
        Field[] fields = personCls.getFields();
        for (Field field : fields) {
            System.out.println("本类及父类的属性: " + field.getName()); //本类及父类的属性: name  本类及父类的属性: hobby
        }

        // 4. getDeclaredFields() : 获取本类中所有的属性
        Field[] declaredFields = personCls.getDeclaredFields();
        for (Field field : declaredFields) {
            System.out.println(field.getName()); //name age job sal 拿不到父类的属性
        }

        // 5. getMethods() : 获取所有public修饰的方法,包含本类以及父类
        Method[] methods = personCls.getMethods();
        for (Method method : methods) {
            System.out.println("本类及父类的方法: " + method.getName());
            /*
            本类及父类的方法: m1
            本类及父类的方法: hi
            本类及父类的方法: wait
            本类及父类的方法: wait
            本类及父类的方法: wait
            本类及父类的方法: equals
            本类及父类的方法: toString
            本类及父类的方法: hashCode
            本类及父类的方法: getClass
            本类及父类的方法: notify
            本类及父类的方法: notifyAll
             */
        }

        // 6. getDeclaredMethods() : 获取本类中的所有方法
        Method[] declaredMethods = personCls.getDeclaredMethods();
        for (Method method : declaredMethods) {
            System.out.println(method.getName());// m1() m2() m3() m4()
        }

        // 7. getConstructors() : 获取所有public修饰的构造器,包含本类以及父类
        Constructor<?>[] constructors = personCls.getConstructors();
        for (Constructor constructor : constructors) {
            System.out.println(constructor);//获取本类和父类
        }
        /*
            public com.hspjava.day16_反射.demo05.反射获取类的信息.Person(java.lang.String,int,java.lang.String,double)
            public com.hspjava.day16_反射.demo05.反射获取类的信息.Person(java.lang.String)
            public com.hspjava.day16_反射.demo05.反射获取类的信息.Person()
         */

        // 8. getDeclaredConstructors() : 获取本类中所有的方法(包含私有)
        Constructor<?>[] declaredConstructors = personCls.getDeclaredConstructors();
        for (Constructor constructor : declaredConstructors) {
            System.out.println(constructor);
        }
        /*
            public com.hspjava.day16_反射.demo05.反射获取类的信息.Person(java.lang.String,int,java.lang.String,double)
            public com.hspjava.day16_反射.demo05.反射获取类的信息.Person(int)
            public com.hspjava.day16_反射.demo05.反射获取类的信息.Person(java.lang.String)
            public com.hspjava.day16_反射.demo05.反射获取类的信息.Person()

         */

        // 9. getPackage() : 以Package的形式返回包信息
        System.out.println(personCls.getPackage());//package com.hspjava.day16_反射.demo05.反射获取类的信息

        // 10. getSuperClass() : 以Class形式返回父类信息

        System.out.println(personCls.getSuperclass());//class com.hspjava.day16_反射.demo05.反射获取类的信息.Animal
        // 11. getInterfaces() : 以Class[]形式返回接口信息
        Class<?>[] interfaces = personCls.getInterfaces();
        for (Class<?> inter : interfaces) {
            System.out.println(inter); //interface com.hspjava.day16_反射.demo05.反射获取类的信息.IA IB
        }
        // 12. getAnnotations() : 以Annotation[]形式返回注解信息
        Annotation[] annotations = personCls.getAnnotations();
        for (Annotation annotation : annotations) {
            System.out.println(annotation);//@java.lang.Deprecated()
        }
    }
}
