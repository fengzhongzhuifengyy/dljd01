package demo04_类加载;

/**
 * 验证类加载的准备阶段
 */
public class Reflection02 {
    public static void main(String[] args) {
        /*
            分析类加载的链路 - 准备阶段: 属性是如何处理的
            n1为实例属性,不是静态变量,因此在准备阶段是不会分配内存的
            n2是静态变量,分配内存n2的默认初始化为 0,而不是20
            n3是static final(常量),他和静态变量不一样,他会一次性的分配,因为一旦赋值就不会改变了, n3直接= 30
         */

    }
}

class A{
    public  int n1 = 10;
    public static int n2 = 20;
    public static final int n3 = 30;
}