package demo04_类加载;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

/**
 *  反射机制是java实现动态语言的关键,也就是通过反射实现类的动态加载
 *  1. 静态加载:编译时加载相关的类,如果没有则报错,依赖性太强
 *  2. 动态加载:运行时加载所需要的类,如果运行时不用该类,则不报错,降低了依赖性
 */
public class Reflection01 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入key");
        String s = scanner.nextLine();
        switch (s){
            case "1":
                // Dog dog = new Dog;// 编译的时候就会加载这个类--静态加载
                // dog.cry();
                break;
            case "2":
                Class<?> cls = Class.forName("Person"); //这里的反射就是动态加载
                Object o = cls.newInstance();
                Method method = cls.getMethod("hi");
                method.invoke(o);
                System.out.println("ok");
                break;
            default:
                System.out.println("test");

        }
        /*
            因为new Dog() 是静态加载,因此必须编写Dog
            Person类是动态加载,所以,没有编写Person类也不会报错
         */
    }
}
