package demo04_类加载;

/**
 *   验证类加载的验证
 */
public class Cat {

}
