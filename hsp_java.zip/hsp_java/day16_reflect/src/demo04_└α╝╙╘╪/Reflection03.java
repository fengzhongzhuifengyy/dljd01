package demo04_类加载;

/**
 *  演示类加载的初始化阶段
 */
public class Reflection03 {
    public static void main(String[] args) {
        new B();
        /*
            分析:
            1.加载B类,生成B类的class对象
            2.连接int num = 0;
            3.初始化阶段:
            <clinit>()是由编译器按照语句在源文件中出现的顺序,依次自动收集类中所有的静态变量的赋值动作和静态代码块中的语句,并收集合并
            clinit(){
                System.out.println("B的静态代码块被执行...");
                num = 300;
                num = 100;
            }
            合并:num = 100;
            4.执行构造器
         */
        System.out.println("===============");
        System.out.println(B.num);//直接使用类的静态成员也会导致类的加载,但是不会执行构造器

        /*
            最终执行结果:
            B的静态代码块被执行...
            B的构造器被执行...
            ===============
            100
            为什么"B的静态代码块被执行..."不加载呢? 因为静态成员只会加载一次
         */
    }
}

class B{
    static {
        System.out.println("B的静态代码块被执行...");
        num = 300;
    }

    static int  num = 100;

    public B() {
        System.out.println("B的构造器被执行...");
    }
}
