package demo06_反射创建实例;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 *  通过反射创建对象
 *  1.通过反射创建某类的对象，要求该类中必须有 public 的无参构造
 *  2.通过调用某个特定构造器的方式，实现创建某类的对象
 */
public class Reflect01 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        //1.先获取到User类的Class对象
        Class<?> userClass = Class.forName("com.hspjava.day16_反射.demo06_反射创建实例.User");

        //2.通过public的无参构造器创建实例
        Object obj = userClass.newInstance();
        System.out.println(obj);//User[ name='Tom, age=36]

        //3.通过public的有参构造器创建实例
        //3.1得到对应的构造器对象
        Constructor<?> constructor = userClass.getConstructor(String.class);
        //3.2创建实例并传入实参
        Object jack = constructor.newInstance("Jack");//User[ name='Jack, age=36]
        System.out.println(jack);

        //4.通过非public的有参构造器创建实例
        //4.1 得到对应的构造器对象
        Constructor<?> declaredConstructor = userClass.getDeclaredConstructor(String.class, int.class);

        // Object jack1 = declaredConstructor.newInstance("Jack", 44);
        // System.out.println(jack1);
        //此时发现会报错:私有的无法进行创建,怎么办呢? 进行爆破
        // 4.2 进行爆破
        declaredConstructor.setAccessible(true);//暴力破解,使用反射可以访问private构造器/方法/属性
        // 4.3 创建实例并传入实参
        Object jack1 = declaredConstructor.newInstance("Jack", 44);
        System.out.println(jack1);//User[ name='Jack, age=44]
    }
}
