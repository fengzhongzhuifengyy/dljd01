package demo06_反射创建实例;

import java.lang.reflect.Field;

/**
 *  通过反射得到对象属性
 */
public class Reflect02 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        //1.得到Student类对应的Class对象
        Class<?> studentClass = Class.forName("com.hspjava.day16_反射.demo06_反射创建实例.Student");
        //2.创建对象
        Object o = studentClass.newInstance();// o的运行类型就是Student
        System.out.println(o.getClass().getName());//com.hspjava.day16_反射.demo06_反射创建实例.Student
        //3.获取public属性对象
        Field age = studentClass.getField("age");
        System.out.println(age.getName());
        //设置值
        age.set(o, 80);
        System.out.println(o);//Student age=80 name=null
        //查询值
        System.out.println(age.get(o));// 80

        //4.使用反射操作name属性
        //4.1得到name属性的对象
        Field name = studentClass.getDeclaredField("name");
        name.setAccessible(true);//爆破
        //方法一
        name.set(o, "张三");
        System.out.println(o);// Student age=80 name=张三
        //获取属性值
        System.out.println(name.get(o));// 张三
        //4.2此时会发现报错,无法操作"private static" --进行爆破

        //方法二:因为是静态的属性,这个o可以是null
        name.set(null, "李四");
        System.out.println(o);// Student age=80 name=张三
        //获取属性值
        System.out.println(name.get(null));// 李四
    }
}
