package demo06_反射创建实例;

public class User {
    private String name = "Tom";
    private int age = 36;

    public User() {
    }

    private User(String name, int age) { //私有的有参构造器
        this.name = name;
        this.age = age;
    }

    public User(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User" +
                "[ name='" + name+
                ", age=" + age + "]";
    }
}
