package demo06_反射创建实例;

public class Boss {
    public int age;
    private static String name;

    public Boss(){

    }

    private static String say(int n, String s, char c){
        return n + " " + s + " " + c;
    }

    public void hi(String s){
        System.out.println("hi" + s);
    }
}
