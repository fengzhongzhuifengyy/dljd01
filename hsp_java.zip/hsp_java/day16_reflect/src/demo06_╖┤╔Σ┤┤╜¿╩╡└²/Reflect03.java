package demo06_反射创建实例;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 演示通过反射调用方法
 */
public class Reflect03 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        //1.得到Boss类对应的Class对象
        Class<?> bossClass = Class.forName("com.hspjava.day16_反射.demo06_反射创建实例.Boss");
        //2.创建对象
        Object o = bossClass.newInstance();
        //3.得到public的方法对象
        Method declaredMethod = bossClass.getDeclaredMethod("hi", String.class);
        declaredMethod.invoke(o, "张三你好");//hi张三你好
        //4.调用私有的方法
        Method say = bossClass.getDeclaredMethod("say", int.class, String.class, char.class);
        say.setAccessible(true);//say()私有的需要爆破
        System.out.println(say.invoke(o, 1, "1", '1'));//1 1 1
        //5.针对say()为静态方法,可以直接使用null代替o
        System.out.println(say.invoke(null, 2, "2", '2'));// 2 2 2
        //6.返回值:在反射中,如果方法有返回值,统一返回Object,但是它的运行类型和方法定义的返回值类型一致
        Object returnValue = say.invoke(null, 3, "3", '3');
        System.out.println("returnValue的运行类型" + returnValue.getClass());//returnValue的运行类型class java.lang.String
    }
}
