package demo07_章节练习;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 *  1.定义PrivateTest的类,有私有的name属性,并且属性值为hellokity
 *  2.提供getName的共有方法
 *  3.创建PrivateTest的类,利用Class类得到私有的name属性,修改私有的name属性值,并调用getName()的方法打印name属性值
 */
public class Homework01 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException, NoSuchMethodException, InvocationTargetException {
        //1.得到PrivateTest的Class类
        Class<?> cls = Class.forName("com.hspjava.day16_反射.demo07_章节练习.PrivateTest");

        //2.创建cls对象的实例
        Object o = cls.newInstance();

        //3.得到私有的属性
        Field name = cls.getDeclaredField("name");
        name.setAccessible(true);//属性爆破
        System.out.println(name.get(o));
        //4.修改私有的name属性值
        name.set(o, "李四");
        System.out.println(name.get(o));
        //5.调用getName的方法
        Method getName = cls.getDeclaredMethod("getName");
        System.out.println(getName.invoke(o));
    }
}
