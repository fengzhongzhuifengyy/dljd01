package demo07_章节练习;

public class PrivateTest {
    private String name = "hello kitty";

    public String getName() {
        return name;
    }
}
