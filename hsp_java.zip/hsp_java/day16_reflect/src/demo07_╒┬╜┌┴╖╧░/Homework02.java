package demo07_章节练习;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 1.利用Class类的forName()得到File类的Class对象
 * 2.在控制台打印File类的所有构造器
 * 3.通过newInstance的方法创建File对象,并创建E:\\mynew.txt文件
 * 提示:
 * File file = new File("E:\\mynew.txt");//内存
 * file.createNewFile();//真正创建
 */
public class Homework02 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        //1.得到File的Class对象
        Class<?> fileClass = Class.forName("java.io.File");
        //2.打印File类的所有构造器
        Constructor<?>[] constructors = fileClass.getDeclaredConstructors();
        for (Constructor constructor : constructors) {
            System.out.println(constructor);
        }
        //3.创建fileClass对象,完成文件创建
        String filepath = "e:\\5.txt";
        Constructor<?> declaredConstructor = fileClass.getDeclaredConstructor(String.class);
        Object o = declaredConstructor.newInstance(filepath);
        //4.得到创建文件的方法
        Method createNewFile = fileClass.getMethod("createNewFile");
        createNewFile.invoke(o);
        System.out.println("文件创建完成");
    }
}
