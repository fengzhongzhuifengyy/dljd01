package demo02_反射机制;


import com.hspedu.java.day16_反射.demo01_引出反射.Cat;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 *  测试反射的性能
 */
public class Reflection02 {
    public static void main(String[] args) throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
        m1();
        m2();
    }
    //传统方法调用hi()
    public static void m1(){
        Cat cat = new Cat();
        long start = System.currentTimeMillis();
        for (int i = 0; i < 90; i++) {
            cat.hi();
        }
        long end = System.currentTimeMillis();
        System.out.println("传统方法调用hi()耗时: " + (end - start) ); //传统方法调用hi()耗时: 4
    }

    //反射方法调用hi()
    public static void m2() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Class cls = Class.forName("com.hspjava.day16_反射.demo01_引出反射.Cat");
        Object o = cls.newInstance();
        Method ms = cls.getMethod("hi");
        long start = System.currentTimeMillis();
        for (int i = 0; i < 90; i++) {
            ms.invoke(o);
        }
        long end = System.currentTimeMillis();
        System.out.println("反射方法调用hi()耗时: " + (end - start) );//反射方法调用hi()耗时: 6
    }
}
