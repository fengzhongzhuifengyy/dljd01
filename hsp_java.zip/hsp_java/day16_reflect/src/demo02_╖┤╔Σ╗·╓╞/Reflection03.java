package demo02_反射机制;


import com.hspedu.java.day16_反射.demo01_引出反射.Cat;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 *  反射性能的优化
 */
public class Reflection03 {
    public static void main(String[] args) throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
        m1();
        m2();
        m3();
    }
    //传统方法调用hi()
    public static void m1(){
        Cat cat = new Cat();
        long start = System.currentTimeMillis();
        for (int i = 0; i < 90; i++) {
            cat.hi();
        }
        long end = System.currentTimeMillis();
        System.out.println("传统方法调用hi()耗时: " + (end - start) ); //传统方法调用hi()耗时: 4
    }

    //反射方法调用hi()
    public static void m2() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Class cls = Class.forName("com.hspjava.day16_反射.demo01_引出反射.Cat");
        Object o = cls.newInstance();
        Method ms = cls.getMethod("hi");
        long start = System.currentTimeMillis();
        for (int i = 0; i < 90; i++) {
            ms.invoke(o);
        }
        long end = System.currentTimeMillis();
        System.out.println("反射方法调用hi()耗时: " + (end - start) );//反射方法调用hi()耗时: 6
    }

    //反射方法调用hi()优化--关闭检测
    public static void m3() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Class cls = Class.forName("com.hspjava.day16_反射.demo01_引出反射.Cat");
        Object o = cls.newInstance();
        Method ms = cls.getMethod("hi");
        ms.setAccessible(true);
        long start = System.currentTimeMillis();
        for (int i = 0; i < 90; i++) {
            ms.invoke(o);
        }
        long end = System.currentTimeMillis();
        System.out.println("反射优化方法调用hi()耗时: " + (end - start) );//反射优化方法调用hi()耗时: 3
    }
}
