package demo08_动态代理;

/**
 *  演示静态代理模式
 *  特点: 代理类与被代理类在编译期间就被确定下来
 */
public class Reflection01 {
    public static void main(String[] args) {
        //创建被代理类的对象
        ClothFactory nike = new Nike();
        //创建代理类的对象
        ClothFactory proxyCloth = new ProxyCloth(nike);
        proxyCloth.produceCloth();
    }
}

interface ClothFactory{
    void produceCloth();
}

//代理类
class ProxyCloth implements ClothFactory{

    private ClothFactory clothFactory; //用被代理类对象进行实例化

    public ProxyCloth(ClothFactory clothFactory) {
        this.clothFactory = clothFactory;
    }

    @Override
    public void produceCloth() {
        System.out.println("开始代理衣服工厂...");
        clothFactory.produceCloth();
        System.out.println("代理Nike衣服工厂...");
    }
}

//被代理类
class Nike implements ClothFactory{

    @Override
    public void produceCloth() {
        System.out.println("Nike生产一批衣服");
    }
}
