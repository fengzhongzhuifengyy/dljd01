package demo07_可变参数;

// 有三个方法， 分别实现返回姓名和两门课成绩(总分)，
// 返回姓名和三门课成绩(总分)， 返回姓名和五门课成绩（总分） 。
// 封装成一个可变参数的方法
public class VarParameterExercise01 {
    public static void main(String[] args) {
        Method03 method03 = new Method03();
        String result =  method03.showScore("刘海涛", 18, 19, 20);
        System.out.println(result);
    }
}

class Method03{

    public String showScore(String name, double... scores){
        int res = 0;
        for (int i = 0; i < scores.length; i++){
            res += scores[i];
        }

       return name + "的成绩总和是: " + res;

    }
}
