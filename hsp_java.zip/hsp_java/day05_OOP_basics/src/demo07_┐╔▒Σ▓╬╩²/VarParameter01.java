package demo07_可变参数;

// 类 HspMethod， 方法 sum ,可以计算 2 个数的和， 3 个数的和 ， 4. 5，
public class VarParameter01 {
    public static void main(String[] args) {
        Method01 method01 = new Method01();
        System.out.println(method01.sum(1, 5, 9));
    }
}


class Method01{

    /*
        老韩解读:
            1.int...表示接受的是可变参数,类型是int,即可以接收多个int(0 - 多);
            2.使用可变参数时,可以当做数组来使用,即nums当做数组
     */
    public int sum(int... nums){
//        System.out.println(nums.length);
        // 遍历求和
        int res = 0;
        for(int i =0; i < nums.length; i++) {
            res += nums[i];
        }
        return res;

    }
}