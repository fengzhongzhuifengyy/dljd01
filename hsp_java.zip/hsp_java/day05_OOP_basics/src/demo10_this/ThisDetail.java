package demo10_this;

public class ThisDetail {
    public static void main(String[] args) {
        Demo demo = new Demo();
        demo.f2();

        // 细节3: this不能在类定义的外部使用,只能在类定义的方法中使用
//        this.f1;  Error:(9, 13) java: 不是语句
    }
}


class Demo{

    /* 细节1:访问成员方法的语法: this.方法名(形参)*/

    public void f1(){
//        this("张三",5); Error:(16, 13) java: 对this的调用必须是构造器中的第一个语句
        System.out.println("f1方法");
        // 验证f1调构造器
    }

    public void f2(){
        System.out.println("f2方法");
        // 调用本类的方法f1()
        // 方式1:
        f1();
        //方式2:
        this.f1();

    }


    /* 细节2:访问构造器语法: this(参数列表)  注意: 只能在构造器中使用(即只能在构造器中访问另外一个构造器)
     对this的调用必须是构造器中的第一个语句
     并且只能在构造器中使用 */

    public Demo(){
        this("jack",10);
        System.out.println("这是无参构造");

        // 要求: 访问有参构造器
//        this("jack",10); // Error:对this的调用必须是构造器中的第一个语句
    }

    public Demo(String name, int age){
        System.out.println("这是有参构造器");
    }
}