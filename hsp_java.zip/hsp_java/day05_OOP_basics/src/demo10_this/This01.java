package demo10_this;

public class This01 {
    public static void main(String[] args) {
        Dog dog1 = new Dog("大壮", 3);
        dog1.info();

        // 打印对象dog1的hashCode,与this的hashCode进行比较
        System.out.println("dog1的hashCode: " + dog1.hashCode());


        Dog dog2 = new Dog("小风", 2);
        dog2.info();

        // 打印对象dog2的hashCode,与this的hashCode进行比较
        System.out.println("dog2的hashCode: " + dog2.hashCode());
    }
}


class Dog{

    String name;
    int age;

    public Dog(String name, int age){
        this.age = age;
        this.name = name;
        System.out.println("this的hashCode: " + this.hashCode());
    }

    /**
     *  输出对象属性的信息详情
     */
    public void info(){
        System.out.println("this.name=" + this.name + "this.age = " + this.age + "this.hashCode()=" + this.hashCode());

    }
}
