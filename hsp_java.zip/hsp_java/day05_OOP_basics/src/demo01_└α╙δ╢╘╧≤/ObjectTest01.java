package demo01_类与对象;

/*
    类与对象的基础入门:
    张老太养了两只猫猫:一只名字叫小白,今年 3 岁,白色。 还有一只叫小花,今年 100 岁,花色。请编写一个程序， 当用户
    输入小猫的名字时,就显示该猫的名字，年龄，颜色。如果用户输入的小猫名错误， 则显示 张老太没有这只猫猫。
 */
public class ObjectTest01 {
    public static void main(String[] args) {

        // 思路1:先试用变量解决
        // 可以看出不利于数据管理(把每只猫的信息拆解了);效率低下
//        String catName1 = "小白";
//        String catName2 = "小花";
//
//        int catAge1 = 3;
//        int catAge2 = 100;
//
//        String catColor1 = "白色";
//        String catColor2 = "花色";

        // 思路2:再试用数组解决
        // 但是有问题：
        /* 1、数据类型(年龄)体现不出来；
           2、只能通过数组的下标来索取信息，造成变量名与内容对应关系不明确。
           3、无法体现猫的相关行为
        */

//        String[] cat1 = {"小白", "3", "白色"};
//        String[] cat2 = {"小花", "100", "花色"};

        // 实例化一个对象:
        /*
            老韩解读:
            1.new Cat() 创建一只猫
            2.Cat cat1 = new Cat(); 把创建的猫赋给cat1
            3.cat1就是一个对象
         */
        Cat cat1 = new Cat();
        cat1.name = "小白";
        cat1.age = 3;
        cat1.color = "白色";

        // 创建了第二只猫,并赋值属性
        Cat cat2 = new Cat();
        cat2.name = "小花";
        cat2.age = 100;
        cat2.color = "花色";

        // 怎么访问对象的属性呢?
        System.out.println("第一只猫的信息: " + cat1.name + " " + cat1.age + " " + cat1.color);
        System.out.println("第一只猫的信息: " + cat2.name + " " + cat2.age + " " + cat2.color);

    }
}


// 使用oop方式:
// 定义一个猫类 -- 自定义的数据类型
class Cat{

    // attribute
    String name;
    int age;
    String color;
    // 新增一个属性,很便捷
    double weight;
}