package demo03_成员方法;
/*
    成员方法的优点:
 */
// 请遍历一个数组 , 输出数组的各个元素值。int [][] map = {{0,0,1},{1,1,1},{1,1,3}};
public class Method02 {
    public static void main(String[] args) {


        int[][] map = {{0,0,1},{1,1,1},{1,1,3}};

        // 传统方式:直接for循环遍历
//        for (int i = 0; i < map.length; i++) {
//            for (int j = 0; j <map[i].length ; j++) {
//                System.out.print(map[i][j] + "\t");
//            }
//            System.out.println();
//        }

        // 要求再次遍历map数组怎么办呢? 再次遍历,代码复用

        MyTools myTools = new MyTools();
        myTools.printArr(map);
    }
}

// 定义一个类 MyTools ,然后写一个成员方法，调用方法实现多次复用
class MyTools{

    // 方法 接收一个二维数组
    public void printArr(int[][] map){
        // 对传入的数组遍历
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j <map[i].length ; j++) {
                System.out.print(map[i][j] + "\t");
            }
            System.out.println();
        }

    }
}