package demo03_成员方法;

// 编写类 BB ， 有一个方法： 判断一个数是奇数 odd 还是偶数, 返回 boolean
public class MethodExercise01 {
    public static void main(String[] args) {

        BB bb = new BB();
        if (bb.odd(5)) {
            System.out.println("是偶数");
        } else {
            System.out.println("是奇数");
        }
    }
}

class BB {

    // 判断奇偶性方法
    public boolean odd(int n) {

//        if (n % 2 == 0) {
//            return true;
//        } else {
//            return false;
//        }

        // 三元运算符
//       return (n % 2 == 0) ? true : false;

        return (n % 2 == 0);
    }
}
