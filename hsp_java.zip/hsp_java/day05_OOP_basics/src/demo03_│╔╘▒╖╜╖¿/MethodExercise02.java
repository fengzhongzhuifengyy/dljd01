package demo03_成员方法;

// 根据行、 列、 字符打印 对应行数和列数的字符， 比如： 行： 4， 列： 4， 字符#,则打印相应的效果
public class MethodExercise02 {
    public static void main(String[] args) {
        DD dd = new DD();
        dd.printNum(4, 3, '&');
    }
}

class DD {
    public void printNum(int row, int column, char num) {
        System.out.println("行数为" + row + "列数是" + column + "字符为" + num);
        for (int i = 0; i < row; i++){
            for (int j = 0; j < column; j++) {
                System.out.print(num + "\t");
            }
            System.out.println();
        }
    }
}