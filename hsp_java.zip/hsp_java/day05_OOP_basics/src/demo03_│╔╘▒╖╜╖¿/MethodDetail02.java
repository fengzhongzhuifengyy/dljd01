package demo03_成员方法;

public class MethodDetail02 {
    public static void main(String[] args) {
        A a = new A();
        a.sayOK();

        a.m1();

    }
}


class A {

    // 1.同一个类中的方法可以直接调用
    public void print(int n){
        System.out.println("print()方法调用n = " + n);
    }

    public void sayOK(){ // sayOK调用 print()方法
        print(10);

        System.out.println("验证返回,继续执行sayOK()");
    }

    // 2.跨类的方法A调用方法B类方法：需要通过对象名调用
    public void m1(){
        System.out.println("m1开始");
        // 先创建B的对象
        B b = new B();
        b.hi();
        System.out.println("m1继续");
    }
}

class B{

    public void hi(){
        System.out.println("B类中的hi()被执行");
    }
}