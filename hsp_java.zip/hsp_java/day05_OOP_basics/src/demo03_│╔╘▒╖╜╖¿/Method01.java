package demo03_成员方法;

/*
    成员方法简介
 */
// 添加 speak 成员方法,输出 “我是一个好人”
// 添加 cal01 成员方法,可以计算从 1+..+1000 的结果
// 添加 cal02 成员方法,该方法可以接收一个数 n， 计算从 1+..+n 的结果
// 添加 getSum 成员方法,可以计算两个数的和
public class Method01 {
    public static void main(String[] args) {

        // 方法的使用
        /*
            1.方法写好后,如果不去调用,不会执行对应语句;
            2.先创建对象,然后调用其方法即可
        */
        Person p1 = new Person();
        p1.speak(); // 调用speak方法

        p1.cal01(); // 调用cal01方法

        p1.cal02(20); // 调用cal02方法,同时给n = 20

        // 不接收结果
        p1.getSum(10,15); // 调用getSum方法,同时给m = 10, n = 15

        // 接收结果
       int sum = p1.getSum(10,15);
       System.out.println("getSum返回的值: " + sum);
    }

}


class Person{

    String name;
    int age;

    // 添加 speak 成员方法,输出 “我是一个好人”
    /*
        老韩解读:
        1.public 表示方法是公开的
        2.void 代表方法没有返回值
        3.speak 方法名
        4.() 代表形参列表,当前为空
        5.{} 代表方法体,写要执行的代码
     */
    public void speak(){
        System.out.println("我是一个好人");
    }

    // 添加 cal01 成员方法,可以计算从 1+..+1000 的结果
    public void cal01(){
        int result = 0;
        for (int i = 1; i <=1000 ; i++) {
            result += i;
        }
        System.out.println("cal01的结果为: " + result);
    }

    // 添加 cal02 成员方法,该方法可以接收一个数 n， 计算从 1+..+n 的结果
    /*
        老韩解读:
        1. (int n) 形参列表: 表示当前有一个形参n ,可以接收调用者输入
     */
    public void cal02(int n){
        int res = 0;
        for (int i = 1; i <= n ; i++) {
            res += i;
        }
        System.out.println("cal02的result = " + res);
    }

    // 添加 getSum 成员方法,可以计算两个数的和
    /*
        老韩解读:
        1. public表示方法是公开的
        2. int 表示方法执行后,返回一个int值
        3. getSum 方法名
        4. (int m, int n) 形参列表: 可以接收调用者传入的2个数
        5. return res 表示把res的值返回给调用者(看调用者接收不接收)
     */
    public int getSum(int m, int n){

        int res = m + n;
        return res;
    }

}