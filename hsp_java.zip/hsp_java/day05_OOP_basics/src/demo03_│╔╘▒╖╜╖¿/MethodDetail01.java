package demo03_成员方法;

public class MethodDetail01 {
    public static void main(String[] args) {

        /*
            使用细节:
            1.一个方法最多一个返回值,如果需要返回多个使用"数组"
         */
        AA aa = new AA();
        int[] res = aa.getSum(4, 3);
        System.out.println("和= " + res[0] + "差=" + res[1]);

        /*
            2.返回类型可以为任意类型,包含基本类型或者引用类型(数组、对象)
         */

        /*
            3. 如果方法要求有返回数据类型， 则方法体中最后的执行语句必须为 return 值;
               而且要求返回值类型必须和 return 的值类型一致或兼容
         */

        /*
            4. 如果方法是void,则方法中可以没有return语句,或者只写return
         */

        /*
            5.方法名见名知意
         */

        /*
            6.调用带参数的方法是,一定对应着参数列表传入相同的类型或兼容类型的参数
         */
        byte b1 = 1;
        byte b2 = 2;
        aa.getSum(b1, b2); // byte -> int ok
//        aa.getSum(1.1, 1.2); // double --> int

        /*
            7.方法定义时的参数成为形式参数;方法调用时传入的参数成为实际参数; 实参与形参的类型要一致或者兼容、个数、顺序必须一致
         */
//        aa.getSum(4); //原因: 实际参数列表和形式参数列表长度不同
        /*
            8.方法不能嵌套
         */
    }
}


class AA {

    // 返回一个数组
    public int[] getSum(int m, int n) {

        int[] resArr = new int[2];

        resArr[0] = m + n;
        resArr[1] = m - n;
        return resArr;
    }

    // 返回值类型必须和 return 的值类型一致或兼容
    public double f1() {
        double d1 = 1.1 * 3;
        int n = 100;
        return n;
    }

    // 如果方法是void,则方法中可以没有return语句,或者只写return
    public void f2() {
        System.out.println("返回值为void");
        // return;
        // return 10;
    }

    // 方法不能嵌套
    public void f3(){
        System.out.println("方法嵌套");

        // 错误的写法
//        public void f4(){
//
//        }
    }
}