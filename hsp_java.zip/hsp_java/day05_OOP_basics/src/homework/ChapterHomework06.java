package homework;

// 编写创建一个Cale计算类,在其中定义两个变量表示操作两个数,
// 定义四个方法实现求和/差/乘/商(要求除数为0的话提示)
//并创建两个对象,分别测试
public class ChapterHomework06 {
    public static void main(String[] args) {
        Cale cale = new Cale();
        cale.calcChen(1,1);

        /*
            除法要注意
         */
        Double res = cale.calcChu(1,0);
        if (res != null) {
            System.out.println(res);
        }
    }
}

class Cale{

    public double calcJia (double a, double b){
        return a+b;
    }

    public double calcJian (double a, double b){
        return a - b;
    }

    public double calcChen (double a, double b){
        return a * b;
    }

    public Double calcChu (double a, double b){
        if (b == 0){
            System.out.println(" 除数不能为0,输入不合法,请重新输入");
            return null;
        }else{
            return a/b;
        }
    }
}
