package homework;


import java.util.Random;

// 有个人Tom设计它的成员变量,成员方法,可以电脑猜拳
// 电脑每次都会随机生成0(石头), 1(剪刀), 2(布)
// 并要可以显示Tom的输赢次数(清单)
public class ChapterHomework14 {
    public static void main(String[] args) {

        // 创建一个二维数组，用来接收局数，Tom出拳情况以及电脑出拳情况

        // 创建一个一维数组，用来接收输赢情况

        // 循环
    }
}

// 思路: 1.构建一个Tom类,
class Tom{

    // 电脑出拳的数
    int GameNum;

    // 玩家出拳的数
    int personNum;

    // 比赛的次数
    int count = 1;

    // 玩家赢的次数
    int winCountNum;

    /**
     *  电脑随机出拳的方法
     */
    public int getGameNum() {
        Random random = new Random();
        personNum = random.nextInt(3); // 0 - 2
        return personNum;
    }


    /**
     *  玩家出拳的方法
     */


    /**
     *  判断输赢的情况
     */

    /**
     *  记录玩家赢的次数
     */

}


