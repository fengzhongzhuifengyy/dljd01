package homework;

// 定义一个圆类Circle,定义属性: 半径,提供显示圆周长功能的方法,提供显示圆面积的方法
public class ChapterHomework05 {
    public static void main(String[] args) {
        Circle circle = new Circle(3.14);
        circle.calcPerimeter();
        circle.calcProportion();
    }
}

class Circle {

    double radius;
//    final double PI = 3.14;

    public Circle() {

    }
    public Circle(double radius) {
        this.radius = radius;
    }

    // 计算圆周长
    public void calcPerimeter(){
        System.out.println("圆的周长为 " + (2 * Math.PI* this.radius) );
    }

    // 计算圆面积
    public void calcProportion() {
        System.out.println("圆的面积为 " + (Math.PI * this.radius * this.radius));
    }

    // 添加一个方法setRadius,修改对象的半径值
    public void setRadius(double radius){
        this.radius = radius;
    }
}
