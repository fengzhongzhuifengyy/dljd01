package homework;

// 创建一个Employee类,属性有(名字,性别,年龄.职位,薪水),提供3个构造方法,可以初始化(1)名字,性别,年龄
// 职位,薪水 2.名字,性别,年龄 3 职位 薪水, 要求充分复用构造器
public class ChapterHomework12 {
    public static void main(String[] args) {

    }
}

class Employee{
    String name;
    char sex;
    int age;
    String job;
    double salary;

    public Employee(){

    }

    public Employee(String name, char sex, int age){
        this.name = name;
        this.sex = sex;
        this.age = age;
    }

    public Employee(String job, double salary){
        this.job = job;
        this.salary = salary;
    }

    public Employee(String name, char sex, int age, String job, double salary ) {
        this(name, sex, age);
//        this(job, salary);
        this.job = job;
        this.salary = salary;
    }
}
