package homework;

// 编写类A02,定义方法find,实现查找某个字符串是否在字符串数组中,并返回索引,如果找不到返回-1
public class ChapterHomework02 {
    public static void main(String[] args) {
        String[] strings = {"abc", "c", "b"};
        A02 a02 = new A02();
        if(a02.findString("c", strings) != -1) {
            System.out.println("字符串在字符串数组中");
        } else {
            System.out.println("字符串是不在字符串数组中");
        }
    }

}


class A02{

    // 实现查找某个字符串是否在字符串数组中,并返回索引
    public int findString(String s1, String[] strings) {
        for (int i =0; i < strings.length; i++){
            if (s1.equals(strings[i])){
                return i;
            }
        }
        return -1;
    }
}