package homework;

// 设计一个Dog类,有名字、颜色和年龄属性，定义输出方法show()显示其信息
// 并创建对象,进行测试(提示this属性)
public class ChapterHomework07 {
    public static void main(String[] args) {

        Dog dog = new Dog("张三", "red", 10);
        dog.show(dog);
    }
}

class Dog {

    String name;
    String color;
    int age;

    public Dog(String name, String color, int age) {
        this.name = name;
        this.color = color;
        this.age = age;
    }

    public void show(Dog dog) {
        System.out.println("狗的信息如下: " + "狗的姓名: " + this.name +
                    "狗的颜色: " + this.color + "狗的年龄: " + this.age);
    }
}
