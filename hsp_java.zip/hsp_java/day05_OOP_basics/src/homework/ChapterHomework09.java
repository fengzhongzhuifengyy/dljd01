package homework;


// 定义Music类,里面有音乐名name,音乐时长times属性,并有播放功能和返回本身属性信息的功能方法getInfo
public class ChapterHomework09 {
    public static void main(String[] args) {
        new Music("交响曲", "5分钟").play();
        new Music("交响曲", "5分钟").getInfo();
    }
}

class Music{
    String name;
    String times;

    public Music(){}
    public Music(String name, String times){
        this.name = name;
        this.times = times;
    }

    public void play() {
        System.out.println("开始播放" + this.name);
    }

    public void getInfo() {
        System.out.println("基本信息如下: " + "歌曲名称 " + this.name + "歌曲时间" + this.times);
    }
}
