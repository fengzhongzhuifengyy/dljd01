package homework;


// 将对象作为参数传递给方法
// 1.定一个Circle类,包含一个double型的radius属性代表圆的半径,findArea()返回圆的面积
// 2.定一个类PassObject,在类中定义一个方法printAreas(),该方法定义如下:public void printAreas(Circle c, int times)
// 3.在PrintAreas方法中打印输出1到times之间的每个整数半径值,以及对应的面积:例如 times=5,则输出半径1,2,3,4,5,以及对应圆的面积
// 4.在main方法中调用printAreas()方法,调用完毕后输出当前半径值
public class ChapterHomework13 {
    public static void main(String[] args) {
        Circle circle = new Circle();
        PassObject passObject = new PassObject();
        passObject.printAreas(circle,5);
    }
}

class PassObject{

    /**
     *  实现根据半径输出对应圆的面积
     * @param c
     * @param times
     */
    public void printAreas(Circle c, int times){

        for (int i = 1; i <= times; i++) {
            c.setRadius(i); // 修改c对象的半径值,每次for循环都new一次对象不合理,因此设置一个修改半径值的方法setRadius()
            System.out.println("当前的半径为 " + c.radius);
            c.calcProportion();
            System.out.println("========================");
        }
    }
}
