package homework;
// 编写类A01,定义方法max,实现某个求double数组的最大值,并返回
public class ChapterHomework01 {
    public static void main(String[] args) {
        A01 a01 = new A01();
        /*
            方式一:传入的数组为空数组;
         */
        double[] arr = {};
        Double res = a01.maxDouble(arr);
        if(res != null){
            System.out.println(res);
        }else {
            System.out.println("arr数组的为空数组或者为null");
        }

        /*
            方式二:如果传入的数组为空怎么办呢?
         */
        double[] arr1 = null;
    }
}

class A01{

    // 优先业务代码的实现,再来考虑代码的健壮性

    /*
       为什么要用Double类来返回呢? 因为如果是double的话,数组为空或者数组为null时就无法处理异常
     */
    // 求某个数组的最大值
    public Double maxDouble(double[] doubles) {
        // 注意保证这个数组不能为空数组,至少有一个元素
        if(doubles != null && doubles.length > 0){

            double maxNum = doubles[0];
            for (int i =1; i < doubles.length; i++){

                if (maxNum < doubles[i]){
                maxNum = doubles[i];
                }
            }
            return maxNum; // double值
        }
        return null; // 空
    }
}

