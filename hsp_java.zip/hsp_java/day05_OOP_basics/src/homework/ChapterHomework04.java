package homework;

// 编写一个类A03,实现数组的复制功能copyArr,输入旧数组,返回一个新数组,元素和新数组一样
public class ChapterHomework04 {
    public static void main(String[] args) {
        int[] arrs = {1,2,3,4,5,6,7,8,9,0};
        A03 a03 = new A03();
        int[] res = a03.copyArr(arrs);

        for (int i =0; i < res.length; i++){
            System.out.print(arrs[i] + "\t");
        }
    }
}

class A03{
    // 数组的复制功能
    public int[] copyArr(int[] arrs) {
        // 在堆中创建了一个长度一致的数组
        int[] newArrs = new int[arrs.length];
        for (int i =0; i < arrs.length; i++){
            newArrs[i] = arrs[i];
        }
        return newArrs;
    }
}
