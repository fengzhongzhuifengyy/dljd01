package homework;

// 给顶一个java程序,输出编译后的结果
public class ChapterHomework08 {
    public static void main(String[] args) {
        /*
            解读:
            1. new Test() 被称之为 "匿名对象",匿名对象只能用一次,使用后就不能再使用了,直接被销毁

         */
        new Test().count1();
        Test t1 = new Test();
        t1.count2();
        t1.count2();
    }
}


class Test{
    int count = 9;
    public void count1(){
        count = 10; // 此时的count = this.count
        System.out.println("count1 = " + count);
    }

    public void count2(){
        System.out.println("count1 = " + count++);
    }
}