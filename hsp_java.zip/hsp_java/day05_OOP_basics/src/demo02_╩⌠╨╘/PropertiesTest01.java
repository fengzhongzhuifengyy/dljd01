package demo02_属性;

/**
 * 对象的属性会有默认值，遵循数组的规则：
 * int 0，short 0, byte 0, long 0, float 0.0,double 0.0，char \u0000，boolean false，String null
 */
public class PropertiesTest01 {
    public static void main(String[] args) {

        // 创建Person对象
        // p1是对象名(对象引用)
        // new Person() 创建的对象空间及空间数据，才是真正的对象
        Person p1 = new Person();
        System.out.println("当前人的信息：" + "age = " + p1.age + " name = " + p1.name +
                            " 薪水：" + p1.sal + " 是否通过："+ p1.isPass); // age = 0 name = null 薪水：0.0 是否通过：false
    }
}


class Person {
    // 4个属性
     int age;
     String name;
     double sal;
     boolean isPass;
}