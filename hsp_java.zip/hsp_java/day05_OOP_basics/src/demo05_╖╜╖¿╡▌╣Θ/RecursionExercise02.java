package com.hspedu.java.day05_面向对象基础.demo05_方法递归;

// 猴子吃桃问题：有一堆桃子，猴子第一天吃了其中的一半，并再多吃了一个！
// 以后每天猴子都吃其中的一半，然后再多吃一个。当到第10天时，想再吃时（即还没有吃）
// 发现只有一个桃子了。问题最初共有所少个桃子
public class RecursionExercise02 {
    public static void main(String[] args) {
        T2 t2 = new T2();
        int n = 9;
        int result = t2.eat(n);
        if( result != -1) {
            System.out.println("第" + n + "天有" + result + "个果子");
        }
    }
}

class T2 {
    // 分析：采用倒叙思想
    // day10 ：1
    // day9 ：（day10*2）+1
    // day8 : (day9*2) + 1


    public int eat(int day) {

        if (day == 10) {
            return 1;
        } else if (day >=0 && day <= 9) {

            return eat((day + 1) + 1) * 2; // 这个是关键

        } else {
            System.out.println("输入的天数" + day + "不合法");
            return -1;
        }
    }

}

