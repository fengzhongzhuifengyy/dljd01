package com.hspedu.java.day05_面向对象基础.demo05_方法递归;

// 请使用递归的方式求出斐波那契数：1,1,2,3,5,8,13...给你一个整数n求出它的值是多少
public class RecursionExercise01 {
    public static void main(String[] args) {

        T1 t1 = new T1();
        System.out.println(t1.fibonacci(5));

    }
}

class T1{
    //思路分析：
    //1.当n=1 result =1；
    //2.当n=2 result =2；
    //3.当n >= 3  result=前两个数的和

    public int fibonacci(int n){

        if(n >=1) {
            if (n == 1 || n == 2) {
                return 1;
            } else {
                return fibonacci(n - 1) + fibonacci(n - 2);
            }
        }else {
            System.out.println("要求输入的数不合法！");
            return -1;
        }
    }
}
