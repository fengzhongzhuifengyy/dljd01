package com.hspedu.java.day05_面向对象基础.demo05_方法递归;

// 递归调用应用实例: 迷宫问题:
// 1.小球得到的路径,和程序员设置的找路策略有关:即找路的上下左右的顺序有关
// 2,再得到小球的路径时,可以先使用(下右上左),再改成(上右下左),看看路径是不是有变化
// 3.测试回溯现象
// 4.扩展思考:如何求出最短路径
public class RecursionExercise03 {
    public static void main(String[] args) {

        /*
            思路:
                1.先创建迷宫,用二维数组表示int[][] map = new int[8][7]
                2.先规定map数组的元素值:0 表示可以走;1 表示不可以走
                3.画出迷宫
         */
    }
}
