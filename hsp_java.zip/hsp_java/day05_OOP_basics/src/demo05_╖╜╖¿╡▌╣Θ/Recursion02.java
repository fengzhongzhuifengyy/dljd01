package com.hspedu.java.day05_面向对象基础.demo05_方法递归;

// 2.阶乘
public class Recursion02 {
    public static void main(String[] args) {
        T t = new T();
        t.factorial(5);
    }
}

class T{

    // 阶乘(factorial)
    public int factorial(int n){
        if (n == 1){
            return 1;
        }else {
            return factorial(n -1) * n;
        }
    }
}
