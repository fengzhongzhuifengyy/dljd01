package com.hspedu.java.day05_面向对象基础.demo05_方法递归;

// 1.打印问题
// 每一个栈都是独立去执行
public class Recursion01 {
    public static void main(String[] args) {
        Question question = new Question();
        question.test(4); // 输出什么呢?
        System.out.println("===========");
        question.test1(4);
    }
}


class Question{

    public void test(int n){
        if(n > 2){
            test(n -1);
        }

        System.out.println("n = " + n);// n = 2; n = 3; n =4
    }

    // 进入了if之后就build值再执行else语句
    public void test1(int n){
        if(n > 2){
            test1(n -1);
        }else{
            System.out.println("n = " + n);  // n = 2
        }

    }
}
