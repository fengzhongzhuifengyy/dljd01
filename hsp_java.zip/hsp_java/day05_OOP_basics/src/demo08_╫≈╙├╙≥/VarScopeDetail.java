package demo08_作用域;

public class VarScopeDetail {
    public static void main(String[] args) {
        Person p1 = new Person();
        /*
            属性的生命周期长,伴随着对象的创建而创建,对象的销毁而销毁,
            局部变量,生命周期较短,伴随他的代码块的执行而创建,伴随着代码块的结束而死忙,即在次方法的调用过程中
         */
        p1.say();
        // 当执行say方法时,say方法的局部变量name会创建,当say执行完毕后,这个name就会销毁,但是这个属性(全局变量)仍然可以使用

        T t = new T();
        t.test(); // 第一种跨类访问对象属性的方式

        t.test2(p1); // 第二种跨类访问对象属性的方式

    }
}


class Person{

    String name = "jack";

    // 细节4:属性可以加修饰符
    private int age = 20;

    public void say(){
        String name ="king";
        // 细节1:属性和局部变量可以重名,访问时遵循就近原则
        System.out.println("say() name" + name);
    }

    public void hi(){
        String address = "北京";
        // 细节2:在同一个作用域中,比如一个成员方法中,不能重名
//        String address = "上海";
        String name = "rose";

        // 细节4: 局部变量不可以加修饰符
//        private int age = 10; // Modifier 'private' not allowed here
    }
}

class T{
    // 细节3:属性:可以在本类中使用,也可以在其他类中使用(通过对象调用);
    public void test(){
        Person person = new Person();
        System.out.println(person.name);
    }

    public void test2(Person person){
        System.out.println(person.name);
    }
}