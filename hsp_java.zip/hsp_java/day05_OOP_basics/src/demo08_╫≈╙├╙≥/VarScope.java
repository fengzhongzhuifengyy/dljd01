package demo08_作用域;

public class VarScope {
    public static void main(String[] args) {

    }
}

class Cat{
    // 属性在定义时可以直接赋值
    int age = 20;


    //全局变量可以不赋值,直接使用,有默认值;
    //局部变量必须赋值后才可使用,因为没有默认值
    double weight; // 0.0

    // 代码块也可以定义局部变量
    {
        int num = 4;
    }

    public void cry(){
        // 1.局部变量一般是指在成员方法中定义的变量
        // 2.n和name就是局部变量
        // 3.n和name的作用域就是在cry()中

        int n = 10;
        String name = "小花";
        // 在cry()使用全局变量age
        System.out.println("在cry中使用属性 age = " + age);
    }


    public void eat(){
        // 在eat()中使用全局变量
        System.out.println("在eat中使用属性age = " + age);

        // 在eat中使用cry的变量
//        System.out.println("在eat中使用cry的属性 name = " + name); // 错误

        // 在eat中使用代码块的变量
//        System.out.println("在eat中使用代码块的变量 num" + num);// 错误
    }

    public void hi(){
        int num;
//        System.out.println("num =" + num); //Variable 'num' might not have been initialized
        System.out.println("weight =" + weight);
    }
}
