package demo04_方法传参机制;

// 方法的参数传递:
    // 1.基本数据类型是值传递,形参的变化不会影响实参
public class MethodParameter01 {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        Swap swap = new Swap();
        swap.swap(a, b);
        /*
            这边就是值传递的关键
         */
        System.out.println("main: a = " + a + " b = " + b); // a=10,b=20

    }
}

class Swap{

    public void swap(int a, int b){
        // a和b交换前
        System.out.println("start : a = " + a + " b = " + b); // a=10,b=20
        // 交换a,b
        int temp = a;
        a = b;
        b = temp;
        // a和b交换后
        System.out.println("end : a = " + a + " b = " + b); // a=20,b=10
    }
}