package demo04_方法传参机制;

//  引用类型的传参
//    B 类中编写一个方法 test100， 可以接收一个数组， 在方法中修改该数组， 看看原来的数组是否变化？ 会变化
//    B 类中编写一个方法 test200， 可以接收一个 Person(age,sal)对象， 在方法中修改该对象属性， 看看原来的对象是否变化? 会变化
public class MethodParameter02 {
    public static void main(String[] args) {

        B b = new B();
        int[] nums =new int[]{2, 3};
        b.test(nums);

        for (int i =0; i < nums.length; i++){
            System.out.println(nums[i] + "\t");
        }
        System.out.println("========================");

        Person p = new Person(10,"989");
        b.test01(p);
        System.out.println(p.age); // 100
        System.out.println(p.sal); // 1000


        //测试题, 如果 test01 执行的是 p = null ,下面的结果是? 10 , 989
        //测试题, 如果 test01 执行的是 p = new Person();..., 下面输出的是 10 , 989
    }
}

class B {
    //B 类中编写一个方法 test100， 可以接收一个数组， 在方法中修改该数组
    public void test(int[] nums){
        nums[0] = 1;
    }

    public void test01(Person p){
        p.age =100;
        p.sal = "1000";

//        p = null;
//        Person p = new Person(0, "33");
    }

}

class Person{
    int age;
    String sal;


    public Person(int age, String sal){
        this.sal = sal;
        this.age = age;
    }

    public Person() {

    }
}