package demo04_方法传参机制;

// 编写一个方法 copyPerson， 可以复制一个 Person 对象， 返回复制的对象。 克隆对象， 注意要求得到新对象和原来的
// 对象是两个独立的对象， 只是他们的属性相同
public class MethodParameterExercise01 {
    public static void main(String[] args) {
        Person person = new Person(2, "方方");
        myTools myTools = new myTools();

        // 这里的p2 就是方法执行结束的return p1
        Person p2 = myTools.copyPerson(person);

        // 到此 p与p2都是Person对象,但是两个独立,只是属性相同
        System.out.println("p的属性: " + person.age + " " + person.sal);
        System.out.println("p的属性: " + p2.age + " " + p2.sal);

        // 这里老师提示: 可以通过 输出对象的hashCode看看是否是同一个对象
        System.out.println(person);
        System.out.println(p2);

        // 这里也可以通过对象比较
        System.out.println(person == p2); // false
    }
}

class myTools{

    //编写方法的思路
    //1. 方法的返回类型 Person
    //2. 方法的名字 copyPerson
    //3. 方法的形参 (Person p)
    //4. 方法体, 创建一个新对象， 并复制属性， 返回即可
    public Person copyPerson(Person p){
        Person p1 = new Person();
        p1.age = p.age;
        p1.sal = p.sal;
        return p1;
    }
}