package demo09_构造器;

public class constructor01 {
    public static void main(String[] args) {

        // 创建并初始化对象
        Person person = new Person("smith", 25);
        System.out.println("person对象信息如下");
        System.out.println(person.name);
        System.out.println(person.age);

        // 创建并初始化对象年龄
        Person person1 = new Person(18);

        // 创建并初始化对象名称
        Person person2 = new Person("张三");

        // 可以调用构造器吗? 不可以
//        person.Person();


        // 创建Dog对象
        Dog dog = new Dog();// 此时无参就报错了,怎么解决呢? 显式的解决一下

    }
}

class Person {

    // 在创建人类的时候,就直接指定这个对象的年龄和姓名
    String name;
    int age;

    // 构造器
    /*
        1.构造器么有返回值
        2.构造器的名称和类名必须一致
     */
    public Person(String name, int age) {
        System.out.println("构造器被调用,不是创建对象,完成对象属性的初始化");
        this.name = name;
        this.age = age;
    }

    // 演示构造器的重载
    // 要求创建人类对象的时候只指定年龄
    public Person(int age) {
        System.out.println("这里只指定年龄");
        this.age = age;
    }

    public Person(String name) {
        System.out.println("这里只指定名称");
        this.name = name;
    }
}


class Dog {
    // 如果程序员没有定义构造器,系统会自动给类生成一个默认无参的构造器
    /*
        默认构造器的样式:
        Dog() {

        }
     */

    //一旦定义了自己的构造器,默认的构造器就覆盖了,就不能再使用默认的无参构造器,除非显式的定义一下,即这样声明一下:Dog(){}
    public Dog(String name) {

    }

    public Dog() {
    }
}