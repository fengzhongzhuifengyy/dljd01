package demo06_方法重载;

//  定义三个重载方法 max()， 第一个方法， 返回两个 int 值中的最大值，
//  第二个方法， 返回两个 double 值中的最大值， 第三个方法，返回三个 double 值中的最大值， 并分别调用三个方法
public class OverloadExercise02 {
    public static void main(String[] args) {
        MyMethod myMethod = new MyMethod();

        System.out.println(myMethod.max(4,5));

        System.out.println(myMethod.max(1.1, 1.2));

        System.out.println(myMethod.max(4.0,3.8,4.1));

    }
}

class MyMethod{


    public int max(int x, int y){
        return x >= y ? x : y;
    }

    public double max(double x, double y){

        return x >= y ? x : y;
    }

    public double max(double u, double v, double w) {

        double max1 = (u >= v) ? u : v;
        return max1 >= w ? max1 : w;
    }

}
