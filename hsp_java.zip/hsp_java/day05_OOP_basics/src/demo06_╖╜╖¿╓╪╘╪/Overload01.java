package demo06_方法重载;
// 基础入门:1.方法名一定要相同 2.形参列表必须不同:形参类型/个数/顺序不同 3.参数名没有要求 4.返回值无要求
public class Overload01 {
    public static void main(String[] args) {

    }
}

class Calculate{

    public int calculator(int a, int b){
        return a+b;
    }

    public double calculator(double a, double b){
        return a+b;
    }
}