package demo06_方法重载;

//编写程序， 类 Methods 中定义三个重载方法并调用。 方法名为 m。
//三个方法分别接收一个 int 参数、 两个 int 参数、 一个字符串参数。 分别执行平方运算并输出结果，
//相乘并输出结果， 输出字符串信息。 在主类的 main ()方法中分别用参数区别调用三个方法
public class OverloadExercise01 {
    public static void main(String[] args) {
        Methods methods = new Methods();
        methods.m(4);
        methods.m(3,4);
        methods.m("真简单");
    }
}

class Methods{

    public void m(int a){
        System.out.println("平方 = " + a * a);
    }

    public void m(int a, int b){
        System.out.println("相乘 = " + a * b);
    }

    public void m(String s){
        System.out.println("字符串 = " + s);
    }
}
