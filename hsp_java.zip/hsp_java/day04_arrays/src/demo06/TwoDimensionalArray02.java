package demo06;

//	二维数组的动态初始化(内存布局)
public class TwoDimensionalArray02 {

	public static void main(String[] args) {
		
		int[][] arr = new int[2][3];
		
		//	赋值
		arr[1][1] = 8;
		
		for (int i = 0; i < arr.length; i++) {
			
			for (int j = 0; j < arr[i].length; j++) {
				
				System.out.print(arr[i][j] + " ");
			}
			//	换行
			System.out.println();
		}
		
		/**
		 * 	赋值之后程序输出:
		 *  0 0 0 
			0 8 0
		 */
		
		// 另外一种初始化方式:
		// 先声明:
		String[][] s1;
		// 再赋值
		s1 = new String[1][2];
		
		for (int i = 0; i < s1.length; i++) {
			
			for (int j = 0; j < s1[i].length; j++) {
				
				System.out.print(s1[i][j] + "\t");
			}
		}
		
		
	}

}


