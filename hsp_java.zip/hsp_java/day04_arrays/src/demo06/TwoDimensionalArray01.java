package demo06;

//	二维数组的快速入门
public class TwoDimensionalArray01 {
	public static void main(String[] args) {
		
		/*
		 	请用二维数组输出如下图形
		 	0 0 0 0 0 0
		 	0 0 1 0 0 0
		 	0 2 0 3 0 0
		 	0 0 0 0 0 0
		 */
		
		int[][] arr = {{0, 0, 0, 0, 0, 0}, {0, 0, 1, 0, 0, 0}, {0, 2, 0, 3, 0, 0}, {0, 0, 0, 0, 0, 0}};
		
		/**
		 * 	关于二维数组的概念:
		 * 	1.从定义形式上看 int[][] : 原来的一维数组的每个元素是一个一维数组
		 * 
		 */
		System.out.println("二维数组的元素个数" + arr.length);
		// 2 二维数组的每个元素是一维数组,所以如果需要得到每一个一维数组的值,还需要再次遍历
		
		// 3 如果我们要访问第i个一位数组的第j个值 arr[i][j]
		System.out.println(arr[3][4]);
		
		for (int i = 0; i < arr.length; i++) { // 遍历二维数组的每个元素(一维数组)的个数
			
			/*
			 * 1.arr[i] : 表示二维数组的 第i个元素 (即也是一个 一维数组)
			 * 2.arr[i].length : 得到 对应的 每个一维数组的长度
			 */
			for(int j = 0; j < arr[i].length; j++ ) { // 遍历二维数组的每个元素(一维数组)的每个元素
				
				System.out.print(arr[i][j] + "\t");
			}
			// 每个元素(一维数组)换行
			System.out.println();
		}
	}
}


