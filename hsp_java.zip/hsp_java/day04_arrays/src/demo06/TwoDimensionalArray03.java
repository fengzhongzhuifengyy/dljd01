package demo06;

//	二维数组之列数不确定性
public class TwoDimensionalArray03 {

	public static void main(String[] args) {
		
		/**
		 * 	看一下需求:动态添加下面的二维数组,并输出:
		 * 	i = 0 : 1
		 * 	i = 1 : 2  2
		 * 	i = 2 : 3  3  3
		 */
		
		// 一共有三个一维数组,每个一维数组的元素是不一样的
		
		// 定义一个二维数组,这个二维数组的一维数组为3
		int[][] arr = new int[3][];
		
		// 遍历这个二维数组,给一维数组的元素进行赋值
		for (int i = 0; i < arr.length; i++) { // 遍历每个一维数组
			
			/*
			 	给每一个一维数组开空间;非常重要
			 	
			 	如果没有给一维数组开空间的(new),那么arr[i]就是null
			 	
			 	如果直接忽略就会报错,数组空指针
			 */
			// 先声明,开辟空间
			arr[i] = new int[i + 1];  // 开空间,才能进行赋值 new 完了给个地址
			
			// 遍历二维数组的一维数组(元素),并给一维数组的每个元素赋值
			for (int j = 0; j < arr[i].length; j++) {
				
				arr[i][j] = i + 1;
			}
		}
		
		// 赋值完成后,遍历查看
		for (int i = 0; i < arr.length; i++) {
			
			for (int j = 0; j < arr[i].length; j++) {
				
				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}
	}
}
