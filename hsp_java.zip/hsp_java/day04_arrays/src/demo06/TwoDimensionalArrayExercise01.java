package demo06;

/*
 	int arr[][] = {{4,6}, {1,4,5,7}, {-2}};遍历该二维数组并求和
 */
public class TwoDimensionalArrayExercise01 {

	public static void main(String[] args) {
		
		// 定义求和变量
		int sum = 0;
		
		// 定义二维数组
		int arr[][] = {{4,6}, {1,4,5,7}, {-2}};
		
		// 遍历二维数组
		for (int i = 0; i < arr.length; i++) {
			
			for (int j = 0; j < arr[i].length; j++) {
				
				System.out.print(arr[i][j] + "\t");
				
				// 求和
				sum += arr[i][j];
			}
			System.out.println();
		}
		
		System.out.println("二维数组之和为: " + sum);
	}

}
