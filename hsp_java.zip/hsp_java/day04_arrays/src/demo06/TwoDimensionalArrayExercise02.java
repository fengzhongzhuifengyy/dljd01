package demo06;

/*
 	用二维数组打印一个10行的杨辉三角
 	
 	1
 	1 1
 	1 2 1
 	1 3 3 1
 	1 4 6 4 1
 	1 5 10 10 5 1
 	......
 	
 */

public class TwoDimensionalArrayExercise02 {
	public static void main(String[] args) {
		
		//	思路分析:
		//	1.第一行有一个元素,第n行有n个元素
		//	2.每一行的第一个元素和最后一个元素都为1
		//	3.从第三行开始,对于非第一个元素和最后一个元素的值: arr[i][j] = arr[i-1][j] + arr[i-1][j-1]
		
		int[][] arr = new int[10][];
		
		for (int i = 0; i < arr.length; i++) { // 遍历二维数组的每个元素(一维数组)
			
			// 给每个二维数组的元素(行)开辟空间
			arr[i] = new int[i + 1];
			
//			// 定义每一行的首位赋值1
//			arr[i][0] = 1;
//			
//			// 定义每一行的最后一位赋值1
//			arr[i][arr[i].length -1] = 1;
//			
//			// 从第三行开始,找规律:一个数 = (上一行的同一列的数) + (上一行的同一列-1)
//			if (i >= 2) {
//				
//				for (int j = 1; j < arr[i].length -1; j++) {
//					arr[i][j] = arr[i-1][j] + arr[i-1][j-1];
//				}
//			}
			
			// 老师的做法:
			for (int j = 0; j < arr[i].length; j++) {
				
				// 每一行的第一个元素和最后一个元素都为1
				if (j == 0 || j == arr[i].length -1) {
					arr[i][j] = 1;
				}else { // 走到这里就表示不是第一个或者最后一个,是中间的匀速
					arr[i][j] = arr[i-1][j] + arr[i-1][j-1];
				}
			}
			
		}
		
		
		// 遍历验证
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}
	}
}
