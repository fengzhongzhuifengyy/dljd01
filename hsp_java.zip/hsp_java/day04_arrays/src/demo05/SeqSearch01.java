package demo05;

import java.util.Scanner;

// 查找: 顺序查找

// 案例1: 有一个数列:白眉鹰王,金毛狮王,紫衫龙王,青翼蝠王猜数游戏: 
// 从键盘中任意输入一个名称:判断数列中是否包含此名称{顺序查找},要求:如果找到了,就提示找到,并给出下标值

public class SeqSearch01 {

	public static void main(String[] args) {
		
		/*
		 * 	思路分析:
		 * 	1.定义一个字符串数组;
		 * 	2.接收用户输入,遍历数组,逐一比较,如果有就提示信息,并退出
		 */
		
		String[] guesss = {"白眉鹰王", "金毛狮王", "紫衫龙王", "青翼蝠王"};
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("请输入倚天屠龙记明教四大护法之一: ");
		
		String name = sc.next();
		
		/*
		 * 	这里发现,无法实现提示找不到
		 * 
		 * 	这里给一个编程思想(技巧):定义一个判断的标志;通过这个标志值的改变来判断是否进行对应的输出
		 */
		// 定义一个标志给个初始值;判断有没有改变
		int flag = -1;
		for (int i = 0; i < guesss.length; i++) {
			// 比较 
			if( guesss[i].equals(name)) {
				System.out.println("找到了,下标值为:" + i);
				// 当找到的时候,将这个标志改为下标i
				flag = i;
				break;
			}
		}
		
		// 此时通过flag进行判断:
		if (flag == -1) {
			System.out.println("没有找到");
		}
		sc.close();
	}

}
