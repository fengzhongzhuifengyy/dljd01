package demo02;

// 演示数组的翻转: 数组元素之间的交换
public class ArrayReverse01 {

	public static void main(String[] args) {
		
		// 定义一个数组
		int[] arr = {11, 22, 33, 44, 55, 66};
		
		/*
		 * 思路:
		 * 1.把arr[0] 和 arr[5] 进行交换;  --> {66, 22, 33, 44, 55, 11}
		 * 2.把arr[1] 和 arr[4] 进行交换;  -->{66, 55, 33, 44, 22, 11}
		 * 3.把arr[2] 和 arr[3] 进行交换;结束 --> {66, 55, 44, 33, 22, 11}
		 * 4.可以看出一共交换3次 = arr.length / 2
		 * 5.每次交换时,对应的下标 是 arr[i] 和 arr[arr.length - 1 - i ]
		 */
		
		int temp = 0; // 定义交换的值的变量
		int len = arr.length; // 计算数组的长度 
		
		// 因为交换的次数总共为数组的长度 /2,所以循环的次数也是这么多
		for (int i = 0; i <  len / 2; i++) {
			
			// 将arr[len-1-i]的值传递给temp
			temp = arr[len -1 -i];
			// 将第一个值给最后一个
			arr[len -1 -i] = arr[i];
			// 再将最后一个临时存的值给第一个,实现交换
			arr[i] = temp;
		}
		
		System.out.println("反转后的数组:");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
}
