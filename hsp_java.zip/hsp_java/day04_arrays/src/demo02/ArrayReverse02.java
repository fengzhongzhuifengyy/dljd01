package demo02;

// 数组的翻转:倒序赋值的方法
public class ArrayReverse02 {

	public static void main(String[] args) {
		
		int[] arr = {11, 22, 33, 44, 55, 66};
		
		/*
		 * 思路:
		 * 1.先创建一个新的数组arr2,长度相同
		 * 2.逆序遍历数组,将每个元素拷贝到arr2的元素中(顺序拷贝)
		 * 3.建议增加一个循环变量j 0 > 5,作为新数组的下标
		 * 4.当for循环结束的时候,arr2就是一个逆序的数组
		 * 5.让arr 指向 arr2 的的数据空间,此时arr原来的数据空间就没有空间引用了,就会被当做垃圾销毁
		 */
		
		
		int[] arr2 = new int[arr.length];
		
		for (int i = arr.length -1, j = 0; i >= 0; i-- , j++) { //逆序遍历;这个j是核心 用来表示新数组的下标进行赋值
			
			// i是从后往前的index;j就是新的从前后的index
			arr2[j] = arr[i];
		}
		
		// 当for循环结束的时候,arr2就是一个逆序的数组
		// 让arr 指向 arr2 的的数据空间,此时arr原来的数据空间就没有空间引用了,就会被当做垃圾销毁
		
		// 将arr2地址指向arr,指向同一个地址
		arr = arr2;
		System.out.println("----arr的元素情况----");
		// 输出arr数组
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
}
