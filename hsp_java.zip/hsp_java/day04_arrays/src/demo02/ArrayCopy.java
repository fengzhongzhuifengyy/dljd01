package demo02;

// 数组拷贝
public class ArrayCopy {

	public static void main(String[] args) {

		// 将 int[ ] arr1 = {10, 20, 30} 拷贝到arr2数组要求数据空间是独立的

		int[] arr1 = { 10, 20, 30 };

		// 先创建一个新的数组,开辟新的数据空间,大小保证和arr1.length

		int[] arr2 = new int[arr1.length];

		// 遍历arr1,把每个元素copy到arr2
		for (int i = 0; i < arr2.length; i++) {
			arr2[i] = arr1[i];
		}

		// 查看拷贝结果
		for (int i = 0; i < arr2.length; i++) {
			System.out.print("arr2 数组元素值为: " + arr2[i] + " ");
		}
		System.out.println();
		// 修改arr2[0]
		arr2[0] = 100;
		
		// 查看arr2 修改结果
		for (int i = 0; i < arr2.length; i++) {
			System.out.print("arr2 数组修改元素值后为: " + arr2[i] + " ");
		}
		System.out.println();
		// 查看arr1的結果是否受到影响: 不会有影响
		for (int i = 0; i < arr1.length; i++) {
			System.out.print("arr1数组修改元素值后为: " + arr1[i] + " ");
		}
	}
}
