package homework;

/*
    写出冒泡排序的代码:
 */
public class ChapterHomework05 {
    public static void main(String[] args) {

        int[] numbers = {15, 18, 5, 69, 70};

        int temp;
        // 冒泡排序:
        for (int i = 0; i < numbers.length -1; i++ ) { // 控制几轮

        for (int j = 0; j < numbers.length -1 - i; j++ ){ // 每一轮比较次数

            if(numbers[j] > numbers[j+1]) {
                // 调换位置
                temp = numbers[j];
                numbers[j] = numbers[j+1];
                numbers[j+1] = temp;
            }
        }
    }

        // 遍历验证
        for (int i = 0; i < numbers.length ; i++) {
            System.out.print(numbers[i] + "\t");
        }
    }
}
