package homework;

/*
	第一题:声明: int[] x,y[]; 以下选项允许通过编译的是:  2; 5 
	
	1. x[0] = y; 
	2. y[0] = x;
	3. y[0][0] = x;
	4. x[0][0] = y;
	5  y[0][0] = x[0];
	6  x = y
	
	// 分析:
	x是int类型的一维数组;y是int类型的二维数组
 */
public class ChapterHomework01 {
	public static void main(String[] args) {
		
		String[] s1 = new String[]{"1", "2"};
	}

}

/*
 	第二题:
 	定义数组正确的是:
 	1. String strs[] = {'a', 'b', 'c'};F
 	2. String[] strs = {"a", "b", "c"};T
 	3. String[] strs = new String{"a", "b", "c"};F
 	4. String[] strs = new String[]{"a", "b", "c"};T
 	5. String[] strs = new String[3]{"a", "b", "c"};F
 */

/*
 	第三题:
 	String foo = "blue";
 	boolean[] bar = new boolean[2];
 	if(bar[0]){
 		foo = "green";
 	}
 	System.out.println(foo);   // blue
 */


/*
	第四题:
	以下java代码的输出结果为 : 1 3 5 7
	int num = 1;
	while(num < 10){
	
		System.out.print(num);
		if(num > 5){
			break;
		}
		num +=2;
	}
 */