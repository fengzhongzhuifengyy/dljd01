package homework;

import java.util.Scanner;

/*
	已知有个升序的数组,要求插入一个元素,该数组顺序依然是升序,比如:[10, 12, 45, 90],添加23后,数组为[10, 12, 23, 45, 90]
 */
public class ChapterHomework02 {
	
	public static void main(String[] args) {

		/*
			老韩解读:
			思路: 本质是数组扩容 + 定位
			1.我们先确定添加数应该插入到哪个索引
			2.然后扩容
		 */
		// 先定义原数组
		int[] numbers = {10, 12, 45, 90};
		
		//	将来插入的位置
		int index = -1;
		
		Scanner sc = new Scanner(System.in);

		System.out.println("请输入你想插入的数字：");

		int insertNum = sc.nextInt();

		/*
			怎么确定添加的位置呢?
			1.遍历number这个数组,如果发现insertNum <= number[i],说明i就是我们插入的位置
			使用index保留起来,即index = i;

			2.考虑到如果遍历完后,没有发现insertNum <= number[i];说明 index = numbers.length
		 */
		//	遍历原始数组
		for (int i = 0; i < numbers.length; i++) {
			
			//	如果insertNum <= numbers[i],此时就是插入的位置
			if(insertNum <= numbers[i]) {
				index = i;
				break; // 找到位置后就必须马上退出,否则程序还会运行(90 > 23)
			}
		}
		
		//	通过index判断，是否找到插入的位置：如果index没有改变说明插入的数是比数组中所有的数都大
		if (index == -1) {
			index = numbers.length;
		}

		/*
			开始扩容:
			将numbers的元素拷贝到arrNew,并且要跳过index位置
			分析:
			int[] numbers = {10, 12, 45, 90};

			newArrs = {[] [] [] [] [] }
			当 index = j = 2时,就应该跳过此位置
		 */
		//	定义一个新数组
		int[] newArrs = new int[numbers.length + 1];
		
		//	遍历这个数组，为这个数组进行赋值(其中i是控制newArrs的下标；j用来控制原来数组（numbers）的下标)
		for (int i = 0, j = 0; i < newArrs.length; i++) {
			
			//	判断只有当i与这个索引不等时，说明没有到插入位置，
			if(i != index) { // 说明可以把numbers的元素拷贝到newArr
				newArrs[i] = numbers[j];
				j++;
			}else { // i = index 表示i这个位置就是要插入的位置
				newArrs[i] = insertNum;
			}

		}
		
		//	替换数组,将原来的数组就成为了垃圾,被销毁
		numbers = newArrs;
		
		//	再次遍历numbers查看是否插入成功
		for (int i = 0; i < numbers.length; i++) {
			
			System.out.print(numbers[i] + "\t");
		}
	}
}
