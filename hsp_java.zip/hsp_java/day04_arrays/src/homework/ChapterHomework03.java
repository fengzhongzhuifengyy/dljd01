package homework;

/*
    随机生成10个整数(1-100的范围)保存到数组,并倒叙打印以及求平均值/求最大值和最大值的下标,并查找结果里是否有8
 */
public class ChapterHomework03 {
    public static void main(String[] args) {

        int[] myMath = new int[10];

        for (int i = 0; i < 10; i++){
            // 随机生成1- 100的整数
            myMath[i] = (int)(Math.random() * 100) + 1;

        }

        // 遍历顺序查看
        System.out.println("随机生成的顺序数组为: ");
        for (int i = 0; i < myMath.length ; i++) {

            System.out.print(myMath[i] + " ");
        }
        System.out.println();


        // 倒叙打印
        System.out.println("随机生成的倒序数组为: ");
        for (int i = myMath.length - 1, j = 0; i >= 0 ; i--) {
            System.out.print(myMath[i] + " ");
        }
        System.out.println();

        // 平均值
        double sum = 0;
        for (int i = 0; i < myMath.length ; i++) {
            sum += myMath[i];

            
        }
        System.out.println("平均值为: " + sum / 10);

        // 最大值以及最大值的下标
        int maxNum = myMath[0];
        int index = -1;
        for (int i = 1; i < myMath.length ; i++) {

            if(maxNum < myMath[i]){
                maxNum = myMath[i];
                index =i;
            }
        }
        if (index == -1) {
            index = 0;
        }
        System.out.println("最大值: " + maxNum);
        System.out.println("最大值索引: " + index);

        // 查找结果中是否有8
        int flag = -1;
        int findNum = 8;
        for (int i = 0; i < myMath.length ; i++) {
            if (myMath[i] == findNum) {
                System.out.println("找到了");
                flag = i;
                break;
            }
        }

        if (flag == -1){
            System.out.println("随机结果没有8");
        }

    }


}
