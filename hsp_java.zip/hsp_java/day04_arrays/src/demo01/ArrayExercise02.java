package demo01;


// 求出数组int[]的最大值{4, -1, 9, 10, 23},并得到对应的下标
public class ArrayExercise02 {

	public static void main(String[] args) {
		
		/*
		 * 思路分析:
		 * 1.定义int数组int[] arr = {4, -1, 9, 10, 23};
		 * 2.假定 max = arr[0]是最大值,maxIndex = 0;
		 * 3.从下标1开始遍历数组,如果max < 当前数, 说明max不是真的最大值,此时(值交换)将 max = 当前元素;maxIndex = 当前元素的下标
		 * 4.当我们遍历数组后,这个max就是最大值,maxIndex为最大值对应的下标
		 */
		
		int[] arr = {4, -1, 9, 10, 23}; 
		
		// 假设第一个元素为最大值
		int max = arr[0];
		// 最大元素的下标
		int maxIndex = 0;
				
		for (int i = 1; i < arr.length; i++) { // 自己跟自己比没有意义,所以从下标1开始比较
			
			if (max < arr[i]) { // 如果 max 小于 当前值
				
				max = arr[i]; // 将当前值与max设定值进行交换
				
				maxIndex = i; // 最大值的索引也就是这个i
			}
		}
		
		// 遍历完成时,就是最大值和最大值索引
		System.out.println("max = " + max + "," + "maxIndex = " + maxIndex);
	}
}
