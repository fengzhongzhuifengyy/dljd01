package demo01;

// 数组使用细节
public class ArrayDetail {
	public static void main(String[] args) {

		// 1.数组是 多个相同类型数据的组合, 实现对这些数据的统一管理
//		int[] arr1 = {1, 2, 3, 1.1, "hello"}; // double --> int

		/*
		 * Type mismatch: cannot convert from double to int Type mismatch: cannot
		 * convert from String to int
		 */
		double[] arr2 = { 11.2, 10, 13.2 }; // int --> double 自动类型提升

		// 2.数组中的元素可以是任何数据类型,包括基本数据类型和引用数据类型,但是不能混用
		String[] arr3 = { "北京", "jack", "milan" };

		// 3.数组创建后,如果没有赋值,则有默认值
		short[] arr4 = new short[3];
		for (int i = 0; i < arr4.length; i++) {
			System.out.println(arr4[i]); // 0 0 0
		}

		// 4.数组下标必须在指定范围内使用,否则报错: 下标越界异常ArrayIndexOutOfBoundsException
		/*
		 * 数组的下标/索引 最小是0 最大 数组长度-1
		 */
		System.out.println(arr2[3]);
		System.out.println(arr3[3]);
	}
}
