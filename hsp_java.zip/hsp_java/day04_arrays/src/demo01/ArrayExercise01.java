package demo01;
// 创建一个char类型的26个元素的数组,A-Z,使用for循环访问所有元素并打印出来;提示: 'A' + 1 = 'B'
public class ArrayExercise01 {

	public static void main(String[] args) {
		
		/*
		 * 	思路分析:
		 * 
		 * 	定义一个数组 char[] arr = new char[26];
		 * 	因为 'A' + 1 = 'B' 使用for循环
		 */
		
		char[] arr = new char[26];
		
		for (int i = 0; i < arr.length; i++) {
			
			arr[i] = (char)('A' + i);  // 'A' = 1 为int,需要强转
		}
		
		// 循环输出
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}
}
