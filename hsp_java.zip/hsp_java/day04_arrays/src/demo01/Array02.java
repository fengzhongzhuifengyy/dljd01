package demo01;

import java.util.Scanner;

// 演示动态初始化:

// 循环输入5个成绩,保存到数组中
public class Array02 {

	public static void main(String[] args) {
		
		// 创建double数组,长度5
		//第一种动态分配:
//		double[] scores = new double[5];
		
		//第二种分配空间
		double[] scores; //声明数组,这是 scores 为null
		
		scores = new double[5]; // 分配内存空间,可以存放数据
		
		Scanner myScanner = new Scanner(System.in);
		
		// 循环输入
		for(int i = 0; i < scores.length; i++) {
			System.out.println("请输入第" + (i+1) +"个元素的值: ");
			scores[i] = myScanner.nextDouble();
		}
		
		// 循环输出
		for (int i = 0; i < scores.length; i++) {
			System.out.print("该数组的元素为: "+scores[i] + "\t");
		}
		
		myScanner.close();
	}
}
