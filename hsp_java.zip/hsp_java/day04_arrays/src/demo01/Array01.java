package demo01;

//	数组的引出:
//	一个养鸡场有6只鸡,它们的体重分别是3Kg,5Kg,1Kg,3.4Kg,2Kg,50kg;请问这6只鸡的总体重是多少?平均体重是多少?
public class Array01 {

	public static void main(String[] args) {
		
		/**
		 * 	传统的方式:6个变量 求和求平均数
		 */
		double hen1 = 3; 
		double hen2 = 5;
		double hen3 = 1;
		double hen4 = 3.4;
		double hen5 = 2;
		double hen6 = 50;
		
		double sumWeight = hen1 + hen2 + hen3 + hen4 + hen5 +hen6;
		
		double avgWeight = sumWeight / 6;
		System.out.println(sumWeight + ";" + avgWeight);
		
		// 	引出"数组"来解决此问题:
		
		//	1.定义一个数组,解读如下:
		/*
		 * double[] : 表示 是double类型的数组,数组名称 hens
		 * {3, 5, 1, 3.4, 2, 50} : 表示数组的值(元素),依次表示数组的第几个元素
		 */
		double[] hens = {3, 5, 1, 3.4, 2, 50}; 
		
		//	2.遍历数组,得到数组所以元素的和
		/*
		 * 1.我们可以通过hens[下标]来访问(得到)数组的元素,下标是从0开始编号的
		 * 	比如 hens[0] = 第一个元素
		 * 
		 * 2.通过for就可以循环的取出数组的元素
		 * 3.使用变量sum=总和,将数组的元素进行累计
		 */
		double sum = 0;
		
		// 通过 数组名.length得到数组的长度
		for(int i = 0; i < hens.length; i++) {
			System.out.println("第"+ i +"个元素的值为: " + hens[i]);
			sum += hens[i];	
		}
		
		//总体重
		System.out.println("总体重sum =" + sum);
		//平均体重
		System.out.println("平均体重avg = " + (sum / hens.length));
		

	}

}
