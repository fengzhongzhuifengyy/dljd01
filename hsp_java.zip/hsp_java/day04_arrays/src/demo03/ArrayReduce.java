package com.hspedu.java.day04_数组.demo03;

// 数组缩减:
// 有一个数组{1, 2, 3, 4, 5},可以将该数组进行缩减,提示用户是否继续缩减,每次缩减最后一个元素,当只剩下最后一个数组时,提示不再缩减
public class ArrayReduce {

}
