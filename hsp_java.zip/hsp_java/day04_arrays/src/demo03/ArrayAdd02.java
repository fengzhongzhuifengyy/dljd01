package com.hspedu.java.day04_数组.demo03;

import java.util.Scanner;

// 	数组的扩容
// 	用户可以通过如下的方法决定是否继续添加,添加成功,是否继续? y/n
//	使用do-while break实现
public class ArrayAdd02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[] arr1 = {1, 2, 3};
		
		do {
			
			//	创建一个数组(比之前加一)
			int[] arr2 = new int[arr1.length +1];
			
			//	遍历arr1数组进行copy
			for (int i = 0; i < arr1.length; i++) {
				arr2[i] = arr1[i];
			}
			
			// 询问是否进行赋值
			System.out.println("请添加一个整数: ");
			
			// 将值赋给arr2最后一位进行新增
			arr2[arr2.length-1] = sc.nextInt();
			
			// 将arr2的引用指向arr1,实现扩容
			arr1 = arr2;
			
			// 输出arr,查看是否添加成功
			for(int i = 0; i < arr1.length; i++ ) {
				System.out.print(arr1[i] + " ");
			}
			
			// 进行判断是否继续添加
			System.out.println("是否继续添加?y/n");
			
			
			if ('n' == sc.next().charAt(0)) {
				break;
			}
		}while(true);
		
		System.out.println("程序结束");
		sc.close();
	}
}
