package com.hspedu.java.day04_数组.demo03;

import java.util.Scanner;

// 数组的扩容
public class ArrayAdd01 {

	public static void main(String[] args) {

		/* 要求:
		 * 1) 原始数组使用静态分配 int[] arr = {1, 2, 3}; 
		 * 2) 增加元素4,直接放在数组的最后arr = {1, 2, 3, 4};
		 * 3) 用户可以通过如下的方法决定是否继续添加,添加成功,是否继续? y/n
		 */
		/*
		 * 思路分析: 1.定义原始数组 int[] arr = {1, 2, 3}; 
		 * 2.arr[3] = 4;是不行的;因此定义一个新数组int[] arrNew= new int[arr.length + 1] 
		 * 3.将新增的元素4 赋值给 arrNew[arrnew.length - 1](最后一位);其余的拷贝
		 * 4.因为要给arr 扩容,所以:将arrNew的引用指向arr; arr = arrNew; 实现了扩容
		 */

		int[] arr = { 1, 2, 3 };

		Scanner myScanner = new Scanner(System.in);

		int[] arrNew;

		for (;;) {

			System.out.println("请输入您要添加的元素: ");

			arrNew = new int[arr.length + 1];

			// 数组拷贝 arr 拷贝到 arrNew
			for (int i = 0; i < arr.length; i++) {
				arrNew[i] = arr[i];
			}

			// 新增最后一个元素
			arrNew[arrNew.length - 1] = myScanner.nextInt();

			// 将arrNew的引用指向arr,实现arr的扩容
			arr = arrNew;

			System.out.println("新增成功");
			
			// 遍历是否扩容成功
			for (int i = 0; i < arr.length; i++) {
				System.out.print(arr[i] + "\t ");
			}

			System.out.println("您是否要添加元素,y/n: ");

			if ("y".equals(myScanner.next())) {
				continue;

			} else {
				break;
			}

		}

		System.out.println("程序結束了");

				myScanner.close();

	}

}
