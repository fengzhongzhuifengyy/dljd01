package demo04;

// 冒泡排序法:
// 我们将5个无序: 24,69,80,57,13使用冒泡排序将其排列成一个从小到大的有序数列
// 总结冒泡排序的特点:
// 1.我们数组一共5个元素;
// 2.一共进行了4轮排序,可以看成是我们的外层循环;
// 3.每一轮排序可以确定一个数的位置,比如第一轮排序确定最大数,第二轮排序,确定第二大的数位置,依次类推;
// 4.当进行比较时,如果前面的数大于后面的数,就交换[我们要求是从小到大]
// 5.每一轮的比较 也在减少 4->3->2->1;
public class BubbleSort {

	public static void main(String[] args) {

		/**
		 * 整体思路: 先简后繁, 先死后活
		 * 
		 * 1.打印第一轮 -第四轮的排序
		 */

		int[] arr = { 24, 69, 80, 57, 13 };
		int temp;

//		// 第一轮
//		for (int i = 0; i < 4; i++) {
//			// 若第一个数大于第二个数,右移交换
//			if (arr[i] > arr[i + 1]) {
//				temp = arr[i];
//				arr[i] = arr[i + 1];
//				arr[i + 1] = temp;
//			}
//		}
//
//		// 第二轮
//		for (int i = 0; i < 3; i++) {
//			// 若第一个数大于第二个数,右移交换
//			if (arr[i] > arr[i + 1]) {
//				temp = arr[i];
//				arr[i] = arr[i + 1];
//				arr[i + 1] = temp;
//			}
//		}
//
//		// 第三轮
//		for (int i = 0; i < 2; i++) {
//			// 若第一个数大于第二个数,右移交换
//			if (arr[i] > arr[i + 1]) {
//				temp = arr[i];
//				arr[i] = arr[i + 1];
//				arr[i + 1] = temp;
//			}
//		}
//		// 第四轮
//		for (int i = 0; i < 1; i++) {
//			// 若第一个数大于第二个数,右移交换
//			if (arr[i] > arr[i + 1]) {
//				temp = arr[i];
//				arr[i] = arr[i + 1];
//				arr[i + 1] = temp;
//			}
//		}
		
		
		// 2.以上的代码可以明显的发现有重合的地方,那么进行代码合并
		
		// 3.合并完成后进行 先死后活 将数组中轮数/次数 = 4 -->arr.length -1
		
		for (int i = 0; i < arr.length -1; i++) { // 外层控制轮数
			
			for (int j = 0; j < arr.length -1 - i; j++) { // 内层控制每一轮交换的次数
				// 若第一个数大于第二个数,右移交换
				if (arr[j] > arr[j + 1]) {
					temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
		
		// 遍历查看数组是否按照从大到小进行排序
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}

}
