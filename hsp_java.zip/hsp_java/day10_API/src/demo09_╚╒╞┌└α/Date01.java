package demo09_日期类;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *  Date类介绍
 */
public class Date01 {
    public static void main(String[] args) throws ParseException {
        /*
            1.获取当前系统时间
            2.java.util.Date,不能引入java.sql.date
            3.默认输出的日期格式为国外的方式,所以通常进行格式转换 SimpleDateFormat
         */
        Date date = new Date();//获取当前系统时间
        System.out.println(date);//Wed May 04 23:23:34 CST 2022
        // 创建SimpleDateFormat对象,可以指定相应的格式
        //相应的格式,是规定好的,不能乱写
        /*
            y  Year  Year  1996; 96
            Y  Week year  Year  2009; 09
            M  Month in year (context sensitive)  Month  July; Jul; 07
            L  Month in year (standalone form)  Month  July; Jul; 07
            w  Week in year  Number  27
            W  Week in month  Number  2
            D  Day in year  Number  189
            d  Day in month  Number  10
            F  Day of week in month  Number  2
            E  Day name in week  Text  Tuesday; Tue
            u  Day number of week (1 = Monday, ..., 7 = Sunday)  Number  1
            a  Am/pm marker  Text  PM
            H  Hour in day (0-23)  Number  0
            k  Hour in day (1-24)  Number  24
            K  Hour in am/pm (0-11)  Number  0
            h  Hour in am/pm (1-12)  Number  12
            m  Minute in hour  Number  30
            s  Second in minute  Number  55
            S  Millisecond  Number  978
            z  Time zone  General time zone  Pacific Standard Time; PST; GMT-08:00
            Z  Time zone  RFC 822 time zone  -0800
            X  Time zone  ISO 8601 time zone  -08; -0800; -08:00
         */
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 hh:mm:ss E");
        String format = simpleDateFormat.format(date);
        System.out.println(format);//2022年05月04日 11:47:42 星期三

        //4.通过指定毫秒数得到时间
        Date date1 = new Date(123456789);
        System.out.println(date1);//Fri Jan 02 18:17:36 CST 1970
        System.out.println(simpleDateFormat.format(date1));//1970年01月02日 06:17:36 星期五
        //5.获取某个时间对应的毫秒数
        System.out.println(date.getTime());//1651679219790

        //6.可以把一个格式化的字符串,转成对应的Date,得到的Date输出时还是按照国外的形式,如果希望指定格式输出,需要转换
        //注意:这个String -> Date,使用的simpleDateFormat格式需要和你给的String的格式一样,否则会抛出转换异常
        String s = "2022年05月04 11:47:42 星期三";
        Date parse = simpleDateFormat.parse(s);
        System.out.println(parse);//Wed May 04 11:47:42 CST 2022
        //ParseException: Unparseable date: "2022年05月04 11:47:42 星期三"
    }
}

