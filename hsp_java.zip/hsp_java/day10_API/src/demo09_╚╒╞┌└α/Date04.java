package demo09_日期类;

import java.util.Date;
import java.time.Instant;

/**
 *  日期类的时间戳 : Instant
 */
public class Date04 {
    public static void main(String[] args) {

        //1.通过静态方法now() 表示当前时间的时间戳对象
        Instant now = Instant.now();
        System.out.println(now);//2022-05-05T23:24:35.755Z
        //2.通过Date.from()可以把Instance转换成Date
        Date date = Date.from(now);
        System.out.println(date);//Fri May 06 07:27:16 CST 2022
        //3.将Date转换为Instant,通过Date.toInstant()进行转换
        Instant instant = date.toInstant();
        System.out.println(instant);//2022-06-11T08:26:05.450Z
    }
}
