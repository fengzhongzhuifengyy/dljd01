package demo09_日期类;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *  LocalDate/LocalTime/LocalDateTime 的方法使用
 */
public class Date03 {
    public static void main(String[] args) {
        //1.使用now()可以返回当前日期时间的对象
        LocalDateTime localDateTime = LocalDateTime.now();//LocalDate.now(); localTime.now()
        System.out.println(localDateTime);//2022-05-06T06:58:41.668
        System.out.println("年" + localDateTime.getYear());
        System.out.println("月" + localDateTime.getMonth());
        System.out.println("月" + localDateTime.getMonthValue());//MAY
        System.out.println("日" + localDateTime.getDayOfMonth());//5
        System.out.println("时" + localDateTime.getHour());
        System.out.println("分" + localDateTime.getMinute());
        System.out.println("秒" + localDateTime.getSecond());
        //LocalDate.now(); localTime.now() 用法类似,不同的是获取的字段不一样

        //2.格式日期类: 使用DateTimeFormat对象来进行格式化
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String format = dateTimeFormatter.format(localDateTime);
        System.out.println("格式化的日期" + format);
    }
}
