package demo09_日期类;

import java.util.Calendar;

/**
 *  Calendar类介绍及方法
 */
public class Date02 {
    public static void main(String[] args) {
        /*
            1.Calendar是抽象类,并且构造器是protected
            2.可以通过getInstance() 来获取实例
            3.提供了大量的方法和字段来使用
         */
//        Calendar calendar = new Calendar(); //'Calendar' 为 abstract；无法实例化
        Calendar calendar = Calendar.getInstance();
        System.out.println("calendar=" + calendar);// 可以看出对象有如下字段信息
        //calendar=java.util.GregorianCalendar[time=1651789017510,
        // areFieldsSet=true,areAllFieldsSet=true,lenient=true,
        // zone=sun.util.calendar.ZoneInfo[id="Asia/Shanghai",
        // offset=28800000,dstSavings=0,useDaylight=false,
        // transitions=19,lastRule=null],firstDayOfWeek=1,
        // minimalDaysInFirstWeek=1,ERA=1,YEAR=2022,
        // MONTH=4,WEEK_OF_YEAR=19,WEEK_OF_MONTH=1,DAY_OF_MONTH=6,
        // DAY_OF_YEAR=126,DAY_OF_WEEK=6,DAY_OF_WEEK_IN_MONTH=1,
        // AM_PM=0,HOUR=6,HOUR_OF_DAY=6,MINUTE=16,SECOND=57,
        // MILLISECOND=510,ZONE_OFFSET=28800000,DST_OFFSET=0]

        //4.获取日历对象的某个字段
        /*
            Calendar.YEAR: 表示Calendar类某个字段,通过 实例.get() --面向对象的思想
         */
        System.out.println("年" + calendar.get(Calendar.YEAR));

        /*
            这里为什么要加1,因为Calendar返回月份的时候,是按照0开始编号的
         */
        System.out.println("月" + calendar.get(Calendar.MONTH) + 1) ;
        System.out.println("日" + calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println("时" + calendar.get(Calendar.HOUR));
        System.out.println("分" + calendar.get(Calendar.MINUTE));
        System.out.println("秒" + calendar.get(Calendar.SECOND));

        //5.Calendar没有专门的格式化方法，所以需要程序员自己来组合显示
        System.out.println(calendar.get(Calendar.YEAR) + "年" + (calendar.get(Calendar.MONTH) + 1) + "月" +
                        calendar.get(Calendar.DAY_OF_MONTH) + "日" +
                        calendar.get(Calendar.HOUR) + "时" +
                        calendar.get(Calendar.MINUTE) + "分" +
                        calendar.get(Calendar.SECOND) + "秒"
                );
        //6.如果需要按照24小时来暂时时间
        System.out.println(calendar.get(Calendar.HOUR_OF_DAY));
    }
}
