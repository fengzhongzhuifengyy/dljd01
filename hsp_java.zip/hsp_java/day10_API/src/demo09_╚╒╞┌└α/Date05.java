package demo09_日期类;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *  plus() 和 minus()
 */
public class Date05 {
    public static void main(String[] args) {
        LocalDateTime localDateTime = LocalDateTime.now();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        //1.提供plus和minus方法可以对当前时间进行加或者减
        //增加890天时什么日期
        LocalDateTime localDateTime1 = localDateTime.plusDays(890);
        System.out.println(dateTimeFormatter.format(localDateTime1));//2024-10-12 08:05:15

        //减去3456分钟前是什么时候
        LocalDateTime localDateTime2 = localDateTime.minusMinutes(3456);
        System.out.println(dateTimeFormatter.format(localDateTime2));//2022-05-03 22:30:36

    }
}
