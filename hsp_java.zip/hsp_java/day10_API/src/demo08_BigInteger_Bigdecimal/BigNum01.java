package demo08_BigInteger_Bigdecimal;

import java.math.BigInteger;

/**
 *  演示 BigInteger类
 */
public class BigNum01 {
    public static void main(String[] args) {

//        long l = 3215644878999999999999999L; // 过大的整数
//        System.out.println("l=" + l);

        //当我们处理很大的整数时,long无法使用,可以使用BigInteger类
        BigInteger bigInteger = new BigInteger("3215644878999999999999999");
        System.out.println(bigInteger);//3215644878999999999999999
        /*
            1.在对BigInteger进行 加减乘除的时候,需要使用对应的方法,不能直接进行
            2.加减乘除的结果不会直接影响原数据
         */
//        System.out.println(bigInteger + 1);//运算符 '+' 不能应用于 'java.math.BigInteger'、'int'

        //加
        BigInteger bigInteger1 = new BigInteger("200");
        System.out.println(bigInteger.add(bigInteger1));//3215644879000000000000199
        //减
        System.out.println(bigInteger.subtract(bigInteger1));//3215644878999999999999799
        //乘
        System.out.println(bigInteger.multiply(bigInteger1));//643128975799999999999999800
        //除
        System.out.println(bigInteger.divide(bigInteger1));//16078224394999999999999
    }
}
