package demo08_BigInteger_Bigdecimal;

import java.math.BigDecimal;

/**
 *  演示 BigDecimal类
 */
public class BigNum02 {
    public static void main(String[] args) {

        double d  = 548989496816.131454848489516234514524523451d;
        System.out.println(d); //5.489894968161315E11

        //当我们需要保存一个精度很高的数时,精度不够用了,使用BigDecimal类
        BigDecimal bigDecimal = new BigDecimal("548989496816.131454848489516234514524523451");
        System.out.println(bigDecimal);//548989496816.131454848489516234514524523451
        /*
            1.如果对BigDecimal进行运算,加减乘除,也是需要使用对应的方法
            2.创建一个需要操作的BigDecimal然后调用相应的方法即可
         */
//        System.out.println(bigDecimal + 1);//运算符 '+' 不能应用于 'java.math.BigDecimal'、'int'
        BigDecimal bigDecimal1 = new BigDecimal("1.1111111111111111111");
        //加
        System.out.println(bigDecimal.add(bigDecimal1));//548989496817.242565959600627345614524523451

        //减
        System.out.println(bigDecimal.subtract(bigDecimal1));//548989496815.020343737378405123414524523451

        //乘
        System.out.println(bigDecimal.multiply(bigDecimal1));//609988329795.7016164922218014070591221944067831529498386164061

        //除 可能会出现异常(ArithmeticException),因为除不尽的情况下,就会出现无限循环小数,怎么解决呢?-----在调用divide()时,指定精度即可 BigDecimal.ROUND_CEILING
        // 如果有无限循环小数,就会保留"分子"的精度
        System.out.println(bigDecimal.divide(bigDecimal1,BigDecimal.ROUND_CEILING));//java.lang.ArithmeticException: Non-terminating decimal expansion; no exact representable decimal result.
        //494090547134.518309368581470082408255164792
    }
}
