package demo01_包装类;

/**
 *  包装类
 */
public class Wrapper01 {
    public static void main(String[] args) {
//        boolean -> Boolean
//        char -> Character
//        byte -> Byte
    }
}
