package demo01_包装类;

/**
 *  Integer面试题1
 */
public class Wrapper06 {
    public static void main(String[] args) {
        //看看下面代码输出什么?
        Integer i = new Integer(1);
        Integer j = new Integer(1);
        System.out.println(i == j);//false

        Integer m = 1;
        Integer n = 1;
        System.out.println(m == n);//true

        Integer x = 128;
        Integer y = 128;
        System.out.println(x == y);//false
    }
}
/*
    分析:
    1.两个不同的对象,必然不同
    2.默认: Integer m = Integer.valueOf(1);
        分析源码:
        public static Integer valueOf(int i) {
            //-128 ~ 127就直接返回
        if (i >= IntegerCache.low && i <= IntegerCache.high)
            return IntegerCache.cache[i + (-IntegerCache.low)];
            //否则重新new
        return new Integer(i);
    }
 */