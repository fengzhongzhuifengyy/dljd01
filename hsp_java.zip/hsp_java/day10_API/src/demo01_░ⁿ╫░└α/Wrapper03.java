package demo01_包装类;

/**
 *  测试题
 */
public class Wrapper03 {
    public static void main(String[] args) {
        // 下面的代码是否正确
        Double d = 100d; //ok
        Float f = 1.5f; //ok
        //下面的输出结果是否一致
        Object object = true ? new Integer(1) : Double.valueOf(2.0); //1.0
        System.out.println(object);

        Object Object1;
        if (true){
            Object1 = new Integer(1);
        }else {
            Object1 = Double.valueOf(2.0);
        }
        System.out.println(Object1); //1

        /*
            为什么会出现一个1.0,一个1呢?
            三元运算符输出是1.0不是1,因为三元运算符是一个整体,以最高精度来提升优先级
            if-else就不是按照整体来,按照分支来实现,所以是1
         */
    }
}
