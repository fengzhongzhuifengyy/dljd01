package demo01_包装类;

/**
 *  演示:包装类型和String类型的相互转换
 */
public class Wrapper04 {
    public static void main(String[] args) {
        //包装类(Integer) -> String
        Integer n1 = 10; //自动装箱
        //方式1
        String str1 = n1 + ""; //str1是独立出来的
        //方式2:toString()
        String str2 = n1.toString();
        //方式3:String.valueOf()
        String str3 = String.valueOf(n1);

        //String --> Integer
        String s = "12345";
        Integer num1 = Integer.parseInt(s);//这边也使用到了自动装箱
        Integer num2 = new Integer(s);
    }
}
