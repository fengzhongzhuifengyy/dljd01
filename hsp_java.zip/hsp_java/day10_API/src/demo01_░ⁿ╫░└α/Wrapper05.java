package demo01_包装类;

/**
 *  演示: 包装类的常用方法(Integer Character)
 */
public class Wrapper05 {
    public static void main(String[] args) {
        Integer n1 = 100;
        Integer n2 = 200;
        System.out.println(Integer.MAX_VALUE); //返回最小值
        System.out.println(Integer.MIN_VALUE); //返回最大值

        System.out.println(Character.isDigit('1'));//判断是不是数字
        System.out.println(Character.isLetter('a'));//判断是不是字母
        System.out.println(Character.isUpperCase('C'));//判断是不是大写
        System.out.println(Character.isLowerCase('c'));//判断是不是小写
        System.out.println(Character.isWhitespace(' '));//判断是不是空格

        System.out.println(Character.toUpperCase('b'));//转换成大写
        System.out.println(Character.toLowerCase('B'));//转换成小写

        /*
            2147483647
            -2147483648
            true
            true
            true
            true
            true
            B
            b
         */
    }
}
