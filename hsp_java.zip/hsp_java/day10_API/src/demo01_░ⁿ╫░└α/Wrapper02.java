package demo01_包装类;

/**
 *  演示 int 和 Integer的装箱和拆箱
 */
public class Wrapper02 {
    public static void main(String[] args) {
        //jdk5之前是手动装箱和拆箱
        int n1 = 100;
        //手动装箱(int -> Integer)
        Integer n2 = new Integer(n1);
        System.out.println(n2);
        Integer n3 = Integer.valueOf(n1);
        System.out.println(n3);
        //手动拆箱(Integer -> int)
        int n4 = n2.intValue();
        System.out.println(n4);

        //jdk5之后已自动实现自动装箱和拆箱
        //自动装箱
        int num1 = 200;
        Integer num2 = num1; // 底层使用的是 Integer.valueOf(num1);
        //自动拆箱
        int num3 = num2; // 底层使用的是num2.intValue();

    }
}
