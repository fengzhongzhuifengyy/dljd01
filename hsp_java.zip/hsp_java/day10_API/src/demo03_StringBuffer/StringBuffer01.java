package demo03_StringBuffer;

/**
 *  StringBuffer结构剖析
 */
public class StringBuffer01 {
    public static void main(String[] args) {
        /*
            分析:
            1.StringBuffer的直接父类是AbstractStringBuilder
            2.StringBuffer实现了Serializable, 即StringBuffer的对象也是可以串行化的
            3.针对下面的"hello",它的位置到底在哪里???? ---查看源码: 有属性char[] value,不是final修饰,该value数组存放 字符串内容,引出存放在堆中,而不是常量池
                abstract class AbstractStringBuilder implements Appendable, CharSequence {
                    char[] value;
            4.StringBuffer 是一个final类,不能被继承
            5,因为StringBuffer字符内容是存储在char[] values,所以在变化(增加/删除)不用每次都更换地址,即创建新的对象
     */

        StringBuffer stringBuffer = new StringBuffer("hello");
    }
}
