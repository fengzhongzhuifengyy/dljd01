package demo03_StringBuffer;

public class StringBufferExercise01 {
    public static void main(String[] args) {
        String str = null;
        StringBuffer sb = new StringBuffer();
        sb.append(str);
        /*
            此时查看底层源码:知道调用的是abstractStringBuilder 的 appendNull(),返回的值存有"null"
         */
        System.out.println(sb.length());//4
        System.out.println(sb);//null
        StringBuffer sb1 = new StringBuffer(str);
        /*
            查看源码:
            public StringBuffer(String str) {
                super(str.length() + 16);
                append(str);
            }
            str.length()报错空指针异常
         */
        System.out.println(sb1);
    }
}
