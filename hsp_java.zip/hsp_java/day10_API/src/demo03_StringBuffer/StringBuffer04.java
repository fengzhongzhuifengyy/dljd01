package demo03_StringBuffer;

/**
 *  StringBuffer的常见方法
 */
public class StringBuffer04 {
    public static void main(String[] args) {

        StringBuffer s = new StringBuffer("hello");
        //增
        s.append(',');//hello,
        s.append("张三丰");//hello,张三丰
        s.append("赵敏").append(100).append(true).append(10.5);//hello,张三丰赵敏100true10.5
        System.out.println(s.toString());//s.toString(),可以追源码查看

        //删除
        //要求删除索引为>=start && <end的字符; 删除[11,14)
        s.delete(11,14);
        System.out.println(s);//hello,张三丰赵敏true10.5

        //修改
        //将[9,11)替换为"周芷若"
        s.replace(9, 11, "周芷若");
        System.out.println(s);//hello,张三丰周芷若true10.5

        //插入
        //在索引为9的位置插入"赵敏",原来索引为9的内容自动后移
        s.insert(9, "赵敏");
        System.out.println(s);//hello,张三丰赵敏周芷若true10.5

        //长度
        System.out.println(s.length());//22

    }
}
