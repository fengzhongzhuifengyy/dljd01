package demo03_StringBuffer;

import java.util.Scanner;

/**
 *  输入商品名称和商品价格,要求打印效果实例,使用前面学习的方法完成:
 * 商品名 商品价格
 * 手机   123,456,789
 * 要求:价格的小数点前面每三位用逗号隔开
 */
public class StringBufferExercise02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入你的商品: ");
        String str1 = sc.next();
        System.out.println("请输入你的价格: ");
        Double price = sc.nextDouble();
        String str2 = price.toString();
//        System.out.println(str2);
        String s1 = "商品名\t商品价格\n";
        StringBuffer sb1 = new StringBuffer(s1);
        sb1.append(str1);
//        System.out.println(sb1);
        //重点处理价格,思路:1.转换成StringBuffer进行操作insert ","操作 ;2.插入的思路就是找到数字的.进行向前3位插入
        StringBuffer sb2 = new StringBuffer(str2);
//        int i = stringBuffer1.lastIndexOf(".");
//        stringBuffer1.insert(i - 3, ',');

        //当价格数字过长就需要进行循环处理
        for (int x = sb2.indexOf(".") - 3 ; x > 0; x -= 3){
            sb2.insert( x,',');
        }
        System.out.println(sb2);
        //进行字符串的拼接
        sb1.append("\t\t").append(sb2);
        System.out.println(sb1);
    }

}
