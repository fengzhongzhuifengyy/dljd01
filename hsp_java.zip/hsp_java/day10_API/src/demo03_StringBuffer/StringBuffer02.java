package demo03_StringBuffer;

/**
 *  StringBuffer的构造器
 */
public class StringBuffer02 {
    public static void main(String[] args) {

        //构造器使用
        //创建一个大小为16的char[],用于存放字符内容
        StringBuffer stringBuffer = new StringBuffer();
        
        //通过构造器可以指定char[]的大小
        StringBuffer stringBuffer1 = new StringBuffer(100);
        
        //通过给一个String创建StringBuffer,char[]大小就是str.length+16
        StringBuffer hello = new StringBuffer("hello");

    }
}
