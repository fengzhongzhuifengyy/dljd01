package demo03_StringBuffer;

/**
 *  StringBuffer的转换
 */
public class StringBuffer03 {
    public static void main(String[] args) {

        //String --> StringBuffer
        String str = "hello";
        //方式1 使用构造器
        //注意:返回的才是StringBuffer对象,对str本身没有影响
        StringBuffer stringBuffer = new StringBuffer(str);
        //方式2 通过append()
        StringBuffer stringBuffer1 = new StringBuffer();
        StringBuffer stringBuffer2 =  stringBuffer1.append(str);


        //StringBuffer --> String
        StringBuffer stringBuffer3 = new StringBuffer(100);
        //方式1 通过toString()
        stringBuffer3.toString();

        //方式2 通过构造器
        String string = new String(stringBuffer1);

    }
}
