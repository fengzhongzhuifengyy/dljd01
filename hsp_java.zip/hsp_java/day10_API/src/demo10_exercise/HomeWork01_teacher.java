package demo10_exercise;

/**
 *  编程题:
 *  1.将字符串中指定部分进行反转,比如将"abcdef"反转为"aedcbf"
 *  2.编写方法 public static String reverse(String str, int start, int end)
 */
public class HomeWork01_teacher {
    /*
        思路分析:
        1.先定义方法
        2.把String转换为char[],因为char[]的元素是可以交换的
        3.画出分析示意图:i向右移动,j向左移动,每移动一次,i与j进行交换,直到 i > j 停止交换,当然i=j就不考虑交换没意义
        4.代码实现
     */
    public static void main(String[] args) {
        String str = "abcdef";
        int start = str.indexOf("b");
        int end = str.indexOf("e");
        try {
            str = reverse(str, 1, 100);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }
    }

    public static String reverse(String str, int start, int end){
        //对输入的参数做校验
        //这里有重要的编程技巧:因为不正确的条件比较发散
        //1.先写出正确的输入条件;
        //2.然后取反即可
        if (!(str != null && start >=0 && end > start && end < str.length())){
            throw new RuntimeException("参数不正确");
        }
        char[] chars = str.toCharArray();
        char temp = ' ';
        for (int i = start, j = end; i < j; i++, j--){
            temp = chars[i];
            chars[i] = chars[j];
            chars[j] = temp;
        }
        //使用chars[]重写构建一个String
        return new String(chars);
    }
}
