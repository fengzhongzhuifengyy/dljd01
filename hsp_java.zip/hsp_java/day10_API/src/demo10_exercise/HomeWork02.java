package demo10_exercise;

/**
 * 编程题:
 * 输入用户名、密码、邮箱，如果信息录入正确，则提示注册成功，否则生成异常对象，要求：
 * 1.用户名长度为2或者3或者4
 * 2.密码的长度为6，要求全为数字（isDigit）
 * 3.邮箱中包含@和. 并且@在.之前
 */
public class HomeWork02 {
    public static void main(String[] args) {
        try {
            PersonInfo personInfo = new PersonInfo("张三s6", "555556", "123.123@com");
            System.out.println(personInfo);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

class PersonInfo {
    private String name;
    private String passwd;
    private String email;

    public PersonInfo(String name, String passwd, String email) {
        setName(name);
        setPasswd(passwd);
        setEmail(email);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.length() == 2 || name.length() == 3 || name.length() == 4) {
            this.name = name;
        } else {
            throw new RuntimeException("用户名长度为2或者3或者4");
        }
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        if (passwd.length() != 6) {
            throw new RuntimeException("密码长度不合理");
        }
        if (!(Integer.parseInt(passwd) >= 0)) {
            throw new RuntimeException("密码不是纯数字");
        }
        this.passwd = passwd;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        int index = -1;
        if (email.indexOf("@") == index || email.indexOf(".") == index) {
            throw new RuntimeException("邮箱格式非法");
        }
        if (email.indexOf("@") > email.indexOf(".")) {
            throw new RuntimeException("邮箱@在.之后,格式不正确");
        }
        this.email = email;
    }

    @Override
    public String toString() {
        return "PersonInfo{" +
                "name='" + name + '\'' +
                ", passwd='" + passwd + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
