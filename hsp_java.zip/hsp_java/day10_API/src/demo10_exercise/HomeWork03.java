package demo10_exercise;

/**
 *  编程题:
 *  1.编写java程序,输入形式为: Han shun Ping的人名,以Ping,Han.S的形式打印出来,其中.S是中间单词的首字母
 *  2.例如输入"Willian jefferson Clinton",输出形式为: Clinton,Willian.J
 */
public class HomeWork03 {

    public static void main(String[] args) {
        String name = "Willian jefferson Clinton";
        System.out.println(nameReversion(name));
    }

    public static String nameReversion(String name){
        String[] s = name.split(" ");
        return s[s.length -1].concat(",").concat(s[0]).concat(".").concat(s[1].toUpperCase().charAt(0) + "");
    }
}
