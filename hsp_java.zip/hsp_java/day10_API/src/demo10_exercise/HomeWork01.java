package demo10_exercise;

/**
 *  编程题:
 *  1.将字符串中指定部分进行反转,比如将"abcdef"反转为"aedcbf"
 *  2.编写方法 public static String reverse(String str, int start, int end)
 */
public class HomeWork01 {
    public static void main(String[] args) {
        String str = "abcdef";
        int start = str.indexOf("b");
        int end = str.indexOf("e");
        System.out.println(reverse(str, start, end));
    }

    public static String reverse(String str, int start, int end){
        char[] chars = str.toCharArray();
        char[] copyChars = new char[chars.length];
        if (start >= chars.length || end >= chars.length){
            return "false";
        }
        for (int i = 0,j = end; i < chars.length; i++) {
            if (i >= start && i <= end){
               copyChars[i] = chars[j];
               j--;
            }else {
                copyChars[i] = chars[i];
            }
        }
        chars = copyChars;
        return new String(chars);
    }
}
