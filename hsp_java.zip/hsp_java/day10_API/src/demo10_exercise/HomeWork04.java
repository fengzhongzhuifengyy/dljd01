package demo10_exercise;

/**
 *  编程题:
 *  输入字符串,判断里面有多少个大写字母,多少个小写字母,多少个数字
 */
public class HomeWork04 {
    public static void main(String[] args) {
        String s = "ajsdhf12635467HEUYQRLQWE";
        decide(s);
    }

    public static void decide(String str){

        if (str == null){
            throw new RuntimeException("String 不合法");
        }
        char[] chars = str.toCharArray();
        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] >= 'A' && chars[i] <= 'Z'){
                num1++;
            }else if (chars[i] >= 'a' && chars[i] <= 'z'){
                num2++;
            }else if (chars[i] >= '0' && chars[i] <= '9'){
                num3++;
            }else {

            }
        }
        System.out.println(num1 + "个大写字母");
        System.out.println(num2 + "个小写字母");
        System.out.println(num3 + "个数字");
    }
}
