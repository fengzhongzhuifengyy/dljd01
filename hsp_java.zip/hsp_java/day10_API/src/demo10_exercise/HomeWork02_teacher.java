package demo10_exercise;

/**
 *  编程题:
 *  输入用户名、密码、邮箱，如果信息录入正确，则提示注册成功，否则生成异常对象，要求：
 *  1.用户名长度为2或者3或者4
 *  2.密码的长度为6，要求全为数字（isDigit）
 *  3.邮箱中包含@和. 并且@在.之前
 */
public class HomeWork02_teacher {
    /*
        分析:
        1.先编写方法userRegister(String name, String passwd, String email)
        2.针对输入的内容进行校验,就抛出异常给出提示
        3.单独写一个方法,来判断密码是否全部是数字,返回boolean
     */
    public static void main(String[] args) {
        String name = "jack";
        String pwd = "123456";
        String email = "123@sk.com";

        try {
            userRegister(name, pwd, email);
            System.out.println("注册成功");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void userRegister(String name, String passwd, String email){
        int userLength = name.length();
        if (!(userLength >=2 && userLength <= 4)){
            throw new RuntimeException("用户名长度为2或者3或者4");
        }

        if (!(passwd.length() == 6 && isDigit(passwd))){
            throw new RuntimeException("密码的长度为6，要求全为数字");
        }

        int i = email.indexOf("@");
        int j = email.indexOf(".");
        // i >0 ,j > i ---> j>0(存在i), j>i(. > @)
        if (!(i > 0 || j > i)){
            throw new RuntimeException("邮箱中包含@和. 并且@在.之前");
        }
    }

    public static boolean isDigit(String str){
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            //字符有在非'0' - '9'之间,说明不是纯数字
            if (chars[i] < '0' || chars[i] > '9'){
                return false;
            }
        }
        //执行到这里,说明是纯数字
        return true;
    }


}
