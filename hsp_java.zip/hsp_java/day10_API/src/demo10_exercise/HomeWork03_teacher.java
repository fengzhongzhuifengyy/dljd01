package demo10_exercise;

/**
 *  编程题:
 *  1.编写java程序,输入形式为: Han shun Ping的人名,以Ping,Han.S的形式打印出来,其中.S是中间单词的首字母
 *  2.例如输入"Willian jefferson Clinton",输出形式为: Clinton,Willian.J
 */
public class HomeWork03_teacher {
    /*
        分析:
        1.使用split() 进行分割
        2.对得到的String[] 进行格式化String.format()
        3.对输入的字符串进行校验即可
     */
    public static void main(String[] args) {
        String name = "Willian jefferson Clinton";
        printName(name);
    }

    public static void  printName(String name){

        if (name == null){
            System.out.println("name不能为空");
            return;
        }
        String[] str = name.split(" ");
        if (str.length != 3){
            System.out.println("输入的字符串格式不正确");
            return;
        }
        String format = String.format("%s,%s .%c", str[2], str[0], str[1].toUpperCase().charAt(0));
        System.out.println(format);
    }
}
