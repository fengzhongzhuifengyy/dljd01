package demo05_Math;

/**
 *  Math方法
 */
public class Math01 {
    public static void main(String[] args) {
        //Math的常用方法都是静态方法
        //1.abs 绝对值
        int num1 = Math.abs(-1);
        System.out.println(num1);//1

        //2.pow 求幂
        double num2 = Math.pow(2, 4);
        System.out.println(num2);//16.0

        //3.ceil 向上取整,返回>=该参数的最小整数(转成double)
        double num3 = Math.ceil(10.5);
        System.out.println(num3);//11

        //4.floor 向下取整,返回<=该参数的最大整数(转成double)
        double num4 = Math.floor(-4.9999);
        System.out.println(num4);//-5.0

        //5.round 四舍五入,返回类型为long
        long num5 = Math.round(789.23);
        System.out.println(num5);//789

        //6.sqrt 开方
        double num6 = Math.sqrt(9.0);
        System.out.println(num6);//3.0

        //7.random 随机数[0.0 - 1.0)
        //思考: 请写出获取a-b之间的一个随机整数,a b均为整数? 2 -7
        /*
            分析:
             Math.random() * (b-a) 返回的就是 0 <= 数 <= b-a
            (1) (int)(a) <= x <= (int)(a + Math.random() * (b-a +1) )
            (2) 使用具体的数给小伙伴介绍 a = 2 b = 7
            (int)(a + Math.random() * (b-a +1) ) = (int)( 2 + Math.random()*6)
            Math.random()*6 返回的是 0 <= x < 6 小数
            2 + Math.random()*6 返回的就是 2<= x < 8 小数
            (int)(2 + Math.random()*6) = 2 <= x <= 7
            (3) 公式就是 (int)(a + Math.random() * (b-a +1) )
         */
        for (int i=0; i<10; i++ ) {
            int num7 = (int)(2 + Math.random()*(7-2+1));
            System.out.println(num7);
        }

        //8.max 求两个数的最大值
        double num8 = Math.max(10.2, 5.3);
        System.out.println(num8);//10.2

        //9.min 求两个数的最小值
        double num9 = Math.min(10.2, 5.3);
        System.out.println(num9);//5.3
    }
}
