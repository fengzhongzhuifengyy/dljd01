package demo07_System类;

import java.util.Arrays;

/**
 * System方法
 */
public class System01 {
    public static void main(String[] args) {

        //1.exit() 退出当前程序
        /*
            1.exit(0):表示程序退出的状态
            2.0表示状态:正常状态
         */
        System.out.println("程序开始");
//        System.exit(0);
        System.out.println("程序退出");

        //2.arraycopy() 复制数组元素,比较适合底层调用,一般使用Arrays.copyOf()完成数组复制
        int[] src = {1, 2, 3};
        int[] dest = new int[3];
        /*
            1.主要搞清楚这5个参数的含义
                     @param     src         the source array.  源数组
                     @param     srcPos      starting position in the source array.  从源数组的哪个索引位置开始拷贝
                     @param     dest        the destination array.  目标数组
                     @param     destPos     starting position in the destination data.  把源数组的数据拷贝到 目标数组的哪个索引
                     @param     length      the number of array elements to be copied.  从源数组拷贝多少个数据到目标数组
         */
        System.arraycopy(src, 0, dest, 0, 3);
        System.out.println(Arrays.toString(dest));//[1,2,3]

        // 3.currentTimeMillis():返回当前时间距离 1970-1-1 的毫秒数
        System.out.println(System.currentTimeMillis());//1651674503268
    }
}
