package com.hspedu.java. day10_常用类.demo06_Arrays类;

import java.util.Arrays;
import java.util.List;

/**
 *  二分法查找binarySearch()/copyOf()/fill()/equals()/
 */
public class Arrays03 {
    public static void main(String[] args) {
        Integer[] arr = {1, 2, 90, 123, 456};
        /*
            分析:
            1.binarySearch()通过二分法查找,要求必须排好序
            2.要求该数组必须是有序的,如果数组是无序的无法使用
            3.如果数组中不存在就返回 return -(low + 1) //key not found 含义就是: 找不到就在应该假设存在的位置上
         */
        int index1 = Arrays.binarySearch(arr, 2);
        System.out.println("index1 = " + index1);//1
        int index2 = Arrays.binarySearch(arr, 678);
        System.out.println("index2 = " +index2);//-6
        /*
            思考为啥是-6,查看源码
            return -(low + 1) //key not found 含义就是: 找不到就在应该假设存在的位置上
         */

        // copyOf() 数组元素的复制
        /*
            1.Arrays.copyOf(arr, arr.length):拷贝arr.length个元素到newArray中
            2.如果拷贝的长度 > arr.length 就在新数组的后面 增加 null
            3. 如果拷贝长度 < 0 就抛出异常 NegativeArraySizeException
            4. 该方法的底层使用的是 System.arraycopy()
         */

        Integer[] newArray = Arrays.copyOf(arr, 10);
        System.out.println(Arrays.toString(newArray)); //[1, 2, 90, 123, 456, null, null, null, null, null]

        // fill() 数组的填充
        /*
            1. 使用 99 去填充 num 数组，可以理解成是替换原来的元素
         */
        System.out.println("填充后");
        Arrays.fill(newArray,99);
        System.out.println(Arrays.toString(newArray));//[99, 99, 99, 99, 99, 99, 99, 99, 99, 99]

        // equals() 比较两个数组元素内容是否完全一致
        /*
            1. 如果 arr 和 arr2 数组的元素一样，则方法 true;
            2. 如果不是完全一样，就返回 false
        */
        Integer[] arr1 = {1, 2, 90, 123, 456};
        System.out.println(Arrays.equals(arr, arr1)); //true

        // asList() 将一个数组值,转换为list
        /*
            1.asList()，会将 (1, 2, 90, 123, 456) 数据转成一个 List 集合
            2.返回的 asList 编译类型 List(接口)
            3.asList 运行类型 java.util.Arrays#ArrayList, 是 Arrays 类的
                 静态内部类 private static class ArrayList<E> extendsAbstractList<E>
                 implements RandomAccess, java.io.Serializable
         */
        List<Integer> asList = Arrays.asList(arr);
        System.out.println("asList = " + asList);//asList = [1, 2, 90, 123, 456]
        System.out.println("asList的运行类型" + asList.getClass()); //asList的运行类型class java.util.Arrays$ArrayList
    }
}
