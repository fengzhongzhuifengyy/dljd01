package com.hspedu.java. day10_常用类.demo06_Arrays类;

import java.util.Arrays;
import java.util.Comparator;

/**
 *  自定义Arrays模拟排序
 */
public class Arrays02 {
    public static void main(String[] args) {
        int[] arrs = {1, -1, 8, 0, 20};
        burbleSort(arrs);

        burbleSortCustomized(arrs, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                int i1 = (Integer)o1;
                int i2 = (Integer)o2;
                return i2 - i1; // 此处就控制是顺序还是逆序进行排序
            }
        });

    }

    //使用冒泡排序实现
    public static void burbleSort(int[] arrs){
        for (int i = 0; i < arrs.length -1; i++){
            for (int j = 0; j < arrs.length -1 - i; j++) {
                if (arrs[j] > arrs[j+1]){
                    int temp = arrs[j];
                    arrs[j] = arrs[j+1];
                    arrs[j+1] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(arrs));
    }

    // 需求:结合冒泡+定制
    public static void burbleSortCustomized(int[] arrs, Comparator c){
        for (int i = 0; i < arrs.length -1; i++){
            for (int j = 0; j < arrs.length -1 - i; j++) {
                //此处发生了比较,可以判断进行是按照从大到小还是从小到大进行排序
                //数组的排序由c.compare(arrs[j], arrs[j+1]) 来决定
                if (c.compare(arrs[j], arrs[j+1]) > 0){
                    int temp = arrs[j];
                    arrs[j] = arrs[j+1];
                    arrs[j+1] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(arrs));
    }
}
