package com.hspedu.java. day10_常用类.demo06_Arrays类;

import java.util.Arrays;
import java.util.Comparator;

/**
 *  Arrays类的常见方法
 */
public class Arrays01 {
    public static void main(String[] args) {
        Integer[] integers = {1, 30, 90};
        //遍历数组老方法
        for (Integer values:integers){
            System.out.print(values + " ");//1 30 90
        }
        //新方法 Arrays.toString() 显示数组信息
        System.out.println(Arrays.toString(integers));//[1, 30, 90]

        //sort() 的使用
        Integer[] arr = {1, -1, 50, 30, 90};
        //之前我们使用冒泡排序,现在我们直接使用sort()
        //因为数组是引用类型,所以通过sort()排序后,会直接影响到实参arr的原本顺序
        //通过最后的排序结果可以看出,该方法是重载的,是默认排序(从小到大)
        Arrays.sort(arr);
        System.out.println("默认排序后");
        System.out.println(Arrays.toString(arr)); //[-1, 1, 30, 50, 90]

        //也可以通过传入一个接口Comparator实现定制排序
        //调用定制排序时传入两个参数(1)排序的数组 (2)实现Comparator接口的内部类,需要实现一个compare()
        //这里体现接口编程的方式,查看源码: -->
        /*
        1.Arrays.sort(arr, new Comparator() -->
        2.(最终到)TimSort 类的 private static <T> void binarySort(T[] a, int lo, int hi, int start,Comparator<? super T> c)()
        3.执行到 binarySort 方法的代码, 会根据动态绑定机制 c.compare()执行我们传入的匿名内部类的 compare ()
            while (left < right) {
                int mid = (left + right) >>> 1;
                if (c.compare(pivot, a[mid]) < 0)
                    right = mid;
                else
                    left = mid + 1;
            }
        4.new Comparator() {
         @Override
         public int compare(Object o1, Object o2) {
             Integer i1 = (Integer) o1;
             Integer i2 = (Integer) o2;
             return i2 - i1;
            }
         }
       5.public int compare(Object o1, Object o2) 返回的值>0 还是 <0 会影响整个排序结果, 这就充分体现了 接口编程+动态绑定+匿名内部类的综合使用;
       将来的底层框架和源码的使用方式，会非常常见
         */
        Arrays.sort(arr, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                Integer i1 = (Integer)o1;
                Integer i2 = (Integer)o2;
                return i2 - i1;
            }
        });
        System.out.println("定制排序后");
        System.out.println(Arrays.toString(arr)); //[90, 50, 30, 1, -1]
    }
}
