package com.hspedu.java. day10_常用类.demo06_Arrays类;


import java.util.Arrays;
import java.util.Comparator;

/**
 * 自定义 Book 类，里面包含 name 和 price，按 price排序(从大到小)。要求使用两种方式排序 , 有一个 Book[] books = 4 本书对象.
 * 使用前面学习过的传递 实现 Comparator 接口匿名内部类，也称为定制排序。
 * 可以按照 price (1)从大到小 (2)从小到大 (3) 按照书名长度从大到小
 * Book[] books = new Book[4];
 * books[0] = new Book("红楼梦", 100);
 * books[1] = new Book("金瓶梅新", 90);
 * books[2] = new Book("青年文摘20年", 5);
 * books[3] = new Book("java从入门到放弃~", 300);
 */
public class ArraysExercise01 {
    public static void main(String[] args) {
        Book[] books = new Book[4];
        books[0] = new Book("红楼梦", 100);
        books[1] = new Book("金瓶梅新", 90);
        books[2] = new Book("青年文摘20年", 5);
        books[3] = new Book("java从入门到放弃~", 300);

        //price (1)从大到小
        Arrays.sort(books, new Comparator(){
            @Override
            public int compare(Object o1, Object o2) {
                //这里如果是对Book[]排序,因此这里的o1 与 o2就是Book对象
                Book b1 = (Book)o1;
                Book b2 = (Book)o2;
                //这里针对返回值为double做了转换处理
                double priceOf = b1.getPrice() - b2.getPrice();
                //这里如果与我们的需求不一致就需要调整返回值进行处理
                if (priceOf > 0){
                    return -1;
                }else if (priceOf < 0){
                    return 1;
                }else {
                    return 0;
                }
            }
        });
        System.out.println(Arrays.toString(books));//此处需要将Book的toString()重写
    }
}



class Book {

    private String name;
    private double price;

    public Book(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}