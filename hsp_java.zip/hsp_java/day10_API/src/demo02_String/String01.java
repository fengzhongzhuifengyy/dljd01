package demo02_String;

/**
 *  String的继承实现
 */
public class String01 {
    public static void main(String[] args) {

        /*
            查看源码:
            public final class String
                implements java.io.Serializable, Comparable<String>, CharSequence {...}
            1.String implements Serializable,说明:String可以串行化,实现网络传输
            2.String implements Comparable,说明:String对象可以相互比较
            3.String implements CharSequence,说明:实现了字符序列
         */

        //1.String对象用于保存字符串,也就是一组字符序列;
        //2."123"就是字符串常量,双引号括起来的字符序列
        //3.字符串的字符使用unicode字符编码,一个字符(不区分字母还是汉字)占两个字节
        //4.String类较常用的构造方法很多,重载
        //5.String 类实现了接口 Serializable【String 可以串行化:可以在网络传输】
        //                 接口 Comparable [String 对象可以比较大小]
        //6.String是final修饰,不能被其他的类继承
        //7. String 有属性 private final char value[]; 用于存放字符串内容(The value is used for character storage)
        //8. 一定要注意：value 是一个 final 类型， 不可以修改(需要功力)：即 value 不能指向新的地址，但是单个字符内容是可以变化
        String s1 = "123";
        final char[] values = {'a', 'b', 'c'};
        values[0] = 'd';
        char[] v2 = {'e', 'f'};
        //8. 一定要注意：value 是一个 final 类型， 不可以修改(需要功力)：即 value 不能指向
        // 新的地址，但是单个字符内容是可以变化
//        values = v2;

        System.out.println(s1.intern());
    }
}
