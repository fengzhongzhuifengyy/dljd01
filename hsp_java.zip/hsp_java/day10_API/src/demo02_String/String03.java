package demo02_String;

/**
 * String的常用方法
 */
public class String03 {
    public static void main(String[] args) {
        //equals(): 区分大小写,判断内容是否相等
        String str1 = "hello";
        String str2 = "Hello";
        System.out.println(str1.equals(str2));//false

        //equalsIgnoreCase: 忽略大小写判断内容是否相等
        String str3 = "jhoN";
        if ("jhon".equalsIgnoreCase(str3)) {
            System.out.println("success");//success
        } else {
            System.out.println("fail");
        }

        //length(): 获取字符的个数,字符串的长度
        System.out.println("123".length());//3

        //indexOf(): 获取字符在字符在字符串中第一次出现的索引,索引从0开始,如果找不到,返回-1
        String str4 = "123@321";
        int index1 = str4.indexOf('@');
        System.out.println(index1);//3
        System.out.println("45".indexOf("5"));//1
        System.out.println(str4.indexOf("123"));//0

        //lastIndexOf(): 获取字符在字符串中最后一次出现的索引,索引从0开始,如果找不到,返回-1
        String str5 = "123@321";
        int index2 = str5.lastIndexOf("1");
        System.out.println(index2);//6

        //subString(): 截取指定范围的子串
        String str6 = "hello,456";
        System.out.println(str6.substring(6));//截取后面的字符从索引6开始截取至后面所有的内容 456
        System.out.println(str6.substring(0, 5));///截取后面的字符从索引0取到索引5-1即{[0,5)} hello

        //trim():去除前后空格
        String str7 = " 4 56 ";
        System.out.println(str7.trim());//4 56

        //charAt():获取某个索引处的字符,注意不能使用Str[index]这种方式
        String str8 = "slb";
        System.out.println(str8.charAt(0));//s

        //toUperCase():将字符串转换成大写
        String str9 = "txl";
        System.out.println(str9.toUpperCase());//TXL

        //toLowerCase():将字符串转换成小写
        String str10 = "TJJ";
        System.out.println(str10.toLowerCase());//tjj

        //concat():进行字符串拼接
        String str11 = "孙悟空";
        str11 = str11.concat("猪八戒").concat("沙和尚").concat("白龙马");
        System.out.println(str11);//孙悟空猪八戒沙和尚白龙马

        //replace(): 替换字符串中的字符(old, new)
        //注意:str12.replace()执行后返回的结果是新的替换过的内容(str),对Str12没有任何影响
        String str12 = "孙2悟2空2";
        System.out.println(str12.replace('2', 's'));//孙s悟s空s
        System.out.println(str12.replace("2", "3"));//孙3悟3空3
        System.out.println(str12);//孙2悟2空2

        //split(): 分隔字符串,对于某些字符串我们需要转义| \\\等
        //分析split():
        //以","为标准,对str13进行分割,返回的是String[]
        String str13 = "123,456,789";
        String[] split1 = str13.split(",");
        for (String values:split1){
            System.out.print(values + " ");//123 456 789
        }
        System.out.println("某些符号需要进行转义,转义符'\'");
        String str14 = "E:\\aaa\\bbb";
        String[] split2 = str14.split("\\\\");
        for (String values:split2){
            System.out.print(values + " ");//E: aaa bbb
        }
        System.out.println();

        //compareTo(): 比较两个字符串的大小,如果前者大,则返回正数,后者大,则返回负数,如果相等,返回0
        //根据源码解读: 1.如果长度相同并且每个字符相同就返回0( return len1 - len2;); 2.如果长度相同或者不相同,但是在进行比较时可以区分大小,返回:(if (c1 != c2) {
        //                        return c1 - c2;
        //                    }); 3.如果前面部分都相同长度不同,就返回str15.length() - str16.length() 本质:(return len1 - len2;)
        String str15 = "hap";
        String str16 = "hap1";
        System.out.println(str15.compareTo(str16));// -1
        /*
            compareTo()源码:
            public int compareTo(String anotherString) {
                int len1 = value.length;
                int len2 = anotherString.value.length;
                int lim = Math.min(len1, len2);
                char v1[] = value;
                char v2[] = anotherString.value;

                int k = 0;
                while (k < lim) {
                    char c1 = v1[k];
                    char c2 = v2[k];
                    if (c1 != c2) {
                        return c1 - c2;
                    }
                k++;
        }
        return len1 - len2;
    }
         */

        //toCharArray(): 转换成字符数组
        String str17 = "happy";
        char[] ch = str17.toCharArray();
        for (char values:ch){
            System.out.print(values + " ");//h a p p y
        }
        //format(): 格式化字符串,%s字符串, %c字符, %d整型, %.2f浮点型
        String name = "jack";
        int age = 15;
        double score = 98.336;
        char gender = '男';
        String info = "我的姓名是" + name + "我的年龄" + age + "我的成绩" + score + "我的性别" + gender;
        String info2 = String.format("我的姓名是%s我的年龄%d我的成绩%.2f我的性别%c", name, age, score, gender);
        System.out.println(info);
        System.out.println(info2);
        //1. %s , %d , %.2f %c 称为占位符
        //2. 这些占位符由后面变量来替换
        //3. %s 表示后面由 字符串来替换
        //4. %d 是整数来替换
        //5. %.2f 表示使用小数来替换，替换后，只会保留小数点两位, 并且进行四舍五入的处理
        //6. %c 使用 char 类型来替换
    }
}
