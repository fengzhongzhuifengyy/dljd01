package demo02_String;

/**
 *  字符串特性
 */
public class String02 {
    public static void main(String[] args) {
        String a = "hello";

        String b = "abc";

        String c = a + b;
        /*
            分析源码:
            1.先创建一个StringBuilder sb = new StringBuilder();
            2.执行sb.append("hello");
            3.再次执行sb.append("abc")
            4.再次调用sb.toString()会返回String str = "helloabc"
            5.最终其实是让 str 指向堆中的对象(String)value[]的指向池中的"helloabc"
            //最终结果是常量池3个堆中2个
            小结:
            底层StringBuilder sb = new StringBuilder();sb.append(a);sb.append(b);sb是在堆中,并且append是在原来的字符串的基础上追加的
            规则:
            String c1 = "ab" + "cd";常量相加,看的是池
            String c1 = ab + cd;变量相加,是在堆中
         */
        String d = "helloabc";
        System.out.println(c == d);//真还是假? false 因为c的底层是在堆中创建的对象
        String e  = "hello" + "abc";//直接看池
        System.out.println(d == e);//真还是假? true
    }
}
