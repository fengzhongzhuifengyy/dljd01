package demo01;

import java.util.Scanner;

//	定义两个int变量，判断二者的和，是否能被3整除又能被5整除。打印提示信息
public class Ifexercise03 {
	
	public static void main(String[] args) {
		
		System.out.println("请输入第一个整数：");
		
		Scanner myScanner1 = new Scanner(System.in);
		
		int num1 = myScanner1.nextInt();
		
		System.out.println("请输入第二个整数数：");
		
		Scanner myScanner2 = new Scanner(System.in);
		
		int num2 = myScanner2.nextInt();
		
		int result = num1 + num2;
		
		if (result % 3 ==0 && result % 5 == 0) {
			
			System.out.println("您输入的这两数之和" + result + "能被3整除又能被5整除");
		}else {
			System.out.println("您输入的这两数之和" + result + "不能被3整除又不能被5整除");
		}
		
		myScanner1.close();
		myScanner2.close();
	}

}
