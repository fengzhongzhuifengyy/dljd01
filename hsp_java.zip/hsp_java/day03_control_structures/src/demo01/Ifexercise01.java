package demo01;

public class Ifexercise01 {

	public static void main(String[] args) {
		
		int x = 7;
		int y = 4;
		if (x > 5) {
			
			if (y > 5) {
				System.out.println(x + y);
			}
				System.out.println("韩顺平教育");
		}else {
			System.out.println("x is" + x);
		}

	}

}
