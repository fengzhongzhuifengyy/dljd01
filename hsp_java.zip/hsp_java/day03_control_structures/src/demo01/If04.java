package demo01;

import java.util.Scanner;

/**
 * 
 * 	嵌套分支:
 * 		if（条件表达式0）{
 * 
			if（条件表达式1）{
				执行代码块1；
			}else if（条件表达式2）{
				执行代码块2；
			}else{
				执行代码块3；		
			}
			
		}
 *
 */
public class If04 {
	public static void main(String[] args) {
		
		Scanner	sc = new Scanner(System.in);
		
		System.out.print("请输入你的性别：");
		
		// 返回你输入的第一个字符串的第一个字符
		char gender = sc.next().charAt(0);
		
		System.out.print("请输入你的分数：");
		
		double score = sc.nextDouble();
		
		
		if (score > 8.0) {
			
			if (gender == '男') {
				System.out.println("您分到了男生组!");
			}else if (gender == '女') {
				System.out.println("您分到了女生组!");
			}else {
				System.out.println("您输入的性别不合法!");
			}
			
		}else {
			System.out.println("您被淘汰了!");
		}
		
		sc.close();
	}
}
