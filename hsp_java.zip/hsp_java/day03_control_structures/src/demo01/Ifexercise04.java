package demo01;

import java.util.Scanner;

//	判断一个年份是不是一个闰年，闰年的条件：1、年份能被4整除，但不能被100整除； 2、能被400 整除
public class Ifexercise04 {

	public static void main(String[] args) {
		
		System.out.println("请输入您想要知道的年份：");
		
		Scanner myScanner = new Scanner(System.in);
		
		int year = myScanner.nextInt();
		
		if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
			
			System.out.println("您输入的是闰年!");
		}else {
			System.out.println("您输入的不是闰年!");
		}
		myScanner.close();

	}

}
