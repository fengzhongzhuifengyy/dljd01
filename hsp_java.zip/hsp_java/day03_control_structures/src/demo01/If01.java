package demo01;

import java.util.Scanner;

/**
 * 	单分支语句：
 * 		if（条件表达式）{
			执行代码块；（可以有多条语句）
		}
 *
 */
public class If01 {

	public static void main(String[] args) {
		
		System.out.print("请输入你的年龄：");
		Scanner	sc = new Scanner(System.in);
		int age = sc.nextInt();
		if (age >= 18) {
			System.out.println("你的年龄大于18，要对自己的行为负责，送入监狱");
		}

		System.out.println("程序继续...");
		sc.close();
	}

}
