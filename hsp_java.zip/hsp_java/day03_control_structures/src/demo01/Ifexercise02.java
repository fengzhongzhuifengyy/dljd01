package demo01;

import java.util.Scanner;


// 编写程序，声明2个double型变量并赋值，判断第一个数大于10.0且第二个数小于20.0.打印两数之和
public class Ifexercise02 {

	public static void main(String[] args) {
		
		System.out.println("请输入第一个浮点数：");
		
		Scanner myScanner1 = new Scanner(System.in);
		
		double num1 = myScanner1.nextDouble();
		
		System.out.println("请输入第二个浮点数：");
		
		Scanner myScanner2 = new Scanner(System.in);
		
		double num2 = myScanner2.nextDouble();
		
		if (num1 > 10.0 && num2 < 20.0) {
			
			System.out.println("您输入的两数之和为：" + (num1 +num2));
		}
		
		System.out.println("对不起,我要不起啊!");
		
		myScanner1.close();
		myScanner2.close();
		
	}
}
