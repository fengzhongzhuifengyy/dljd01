package demo01;

import java.util.Scanner;

/**
 * 
 * 	多分支语句:1.多分支可以没有else,如果所有的条件都不成立,表示程序没有入口;2.如果有else,则表示如果所有的条件都不成立,默认执行else后面的语句;3.找到一个入口,后面的判断就不会执行了
 *
 */
public class If03 {

	public static void main(String[] args) {
		
		System.out.println("请输入信用分: ");
		Scanner sc = new Scanner(System.in);
		
		int grade  = sc.nextInt();
		
		// 先对输入的信用分进行一个范围的判断
		if (grade >= 1 && grade <= 100) {
			
			if (grade == 100) {
				System.out.println("信用极好");
			}else if (grade > 80 && grade <= 99) {
				System.out.println("信用优秀");
			}else if (grade >= 60 && grade <= 80) {
				System.out.println("信用一般");
			}else {
				System.out.println("信用不行");
			}
			
		}else {
			System.out.println("请输入1-100的信用分数: ");
		}
		sc.close();
	}

}
