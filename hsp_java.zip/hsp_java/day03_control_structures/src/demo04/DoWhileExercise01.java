package com.hspedu.java.day03_控制结构.demo04;

public class DoWhileExercise01 {

	public static void main(String[] args) {
		
		// 打印1-100
		int i = 1;
		// 计算1 - 100的和
		int sum= 0;
		
		// 定义end变量
		int end = 100;
		do {
			System.out.println("i = " + i);
			sum += i;
			i++;
		}while(i <= end);
		System.out.println("sum = " + sum);
		System.out.println("-------------------------");
		
		// 打印 1-200之间能被5整除但是不能被3整除的个数
		
		// 开始值
		int start = 1;
		
		// 结束值
		int endNum = 200;
		
		// 取余条件1
		int temp1 = 3;
		
		// 取余条件2
		int temp2 = 5;
		
		// 计算个数count
		int count = 0;
		
		do {
			if (start % temp2 == 0 && start % temp1 != 0) {
				System.out.println("star = " + start);
				count++;
			}
			start++;
		} while (start <= endNum);
		
		System.out.println("count = " +count);
	}

}
