package com.hspedu.java.day03_控制结构.demo04;

/**
 * 	打印1 -100 之间所有能被3整除的数
 */
public class WhileExercise01 {
	public static void main(String[] args) {
		
		/**
		 * 	化繁为简,先死后活
		 */
		
		int i = 1;
		int j = 100;
		int t = 3;
		while (i <= j) {
			
			if (i % t == 0) {
				System.out.println("i = " + i);
			}
			i++;
		}
	}
}
