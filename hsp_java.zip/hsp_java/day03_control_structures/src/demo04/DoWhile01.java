package com.hspedu.java.day03_控制结构.demo04;

public class DoWhile01 {

	public static void main(String[] args) {
		
		// 输出10句 你好韩顺平教育
		int i =1;
		do {
			System.out.println("你好韩顺平教育");
			i++;
		} while (i <= 10);
		
		System.out.println("退出do-while语句" + i);
	}

}
