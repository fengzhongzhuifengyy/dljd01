package com.hspedu.java.day03_控制结构.demo04;

import java.util.Scanner;

public class DoWhileExercise02 {

	public static void main(String[] args) {
		
		//	如果李三不还钱,则老韩一直使出5连鞭,直到李三说还钱为止;sysou(老韩问:"还钱吗?" y/n) do while
		
		/**
		 * 	化繁为简:
		 * 	1.不停的问还钱吗?
		 * 	
		 * 	2.使用char来接收是否还钱 answer; 那么接收必须使用Scanner对象来接收
		 * 
		 * 	3.在do while中判断如果是y就不再循环了
		 */
		
		//	标志
		boolean flag = true;
		
		Scanner sc = new Scanner(System.in);
		
		//	使用char来接收是否还钱
		char answer = ' ';
		
//		do {
//			
//			System.out.println("老韩问:\"还钱吗?\" y/n");
//			answer = sc.next().charAt(0);
//			System.out.println("他的回答是: " + answer);
//			if (answer == 'y') {
//				flag = false;
//			}
//			
//			
//		} while (flag);
		
		
		// 老师的写法:
		do{			
			System.out.println("老韩问:\"还钱吗?\" y/n");
			answer = sc.next().charAt(0);
			System.out.println("他的回答是: " + answer);
			
		} while (answer != 'y'); // 判断的条件很关键
		
		System.out.println("李三还钱了");
	}

}
