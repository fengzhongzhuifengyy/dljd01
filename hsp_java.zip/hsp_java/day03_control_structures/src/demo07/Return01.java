package demo07;

// return
public class Return01 {

	public static void main(String[] args) {
		
		for (int i = 1; i <= 5; i++) {
			
			if (i ==3) {
				System.out.println("韩顺平教育" + i);
//				break; 
				/**
				 * hello
				   hello
				       韩顺平教育3
				   go on
				 */
				
//				continue;
				/**
				 *  hello
					hello
					韩顺平教育3
					hello
					hello
					go on
				 */
				
				return;
				/**
				 *  hello
					hello
					韩顺平教育3
				 */
			}
			
			System.out.println("hello");
		}
		
		System.out.println("go on");
	}
}
