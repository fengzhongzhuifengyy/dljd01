package demo03;


/**
 * 
 * for:
 * 		for（循环遍历初始化; 循环条件; 循环变量迭代）{
			循环操作语句；
		}
 *
 *	1.循环条件返回一个布尔值的表达式
 *	2.for(;循环判断条件;)中的初始化和变量迭代可以写到其他地方,但是两边的分号不能省略
 * 	3.循环初始化值可以有多条初始化条件,但是要求类型一样,并且中间用","隔开
 */
public class For01 {

	public static void main(String[] args) {
		
		//	2.for(;循环判断条件;)中的初始化和变量迭代可以写到其他地方,但是两边的分号不能省略
		/*
		 * 	这种拆出来i变量的作用就是为了,要使用这个i变量,如果放在for循环里,i变量就只作用于for循环
		 */
		int i = 1;
		for(; i<= 10;) {
			i++;
			System.out.println("你好,韩顺平教育");
		}
		
		System.out.println(i);
		
		/*
		 * 	补充:for(;;) ,一般会搭配break
		 */
//		for(;;) {
//			System.out.println("这是死循环");
//			break;
//		}
		
		
		//	3.循环初始化值可以有多条初始化条件,但是要求类型一样,并且中间用","隔开
		
		int count = 3;
		for(int x = 0, j = 0; x < count; x++, j += 2) {
			
			System.out.println("x = " + x + "j = " + j);
		}
		
	}
}
