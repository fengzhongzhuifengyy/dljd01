package demo03;

/**
 * 
 * 	1.打印1-100之间所有的是9的倍数的整数,统计个数 及总和
 *
 */
/*
 * 	老韩的两个思想:
 * 	1.化繁为简: 将复杂的需求,拆解成简单的需求,逐步完成
 * 	2.先死后活:先考虑固定的值,然后转成可以灵活变化的值
 */
public class ForExercise01 {

	public static void main(String[] args) {
		
		/**
		 * 	思路分析之化繁为简
		 * 	1.先完成 1 -100 的值;
		 * 	2.在输出的过程中进行一次过滤,只输出9的倍数
		 * 	3.统计个数 定义一个变量 int count = 0;当if条件满足时,+1;
		 * 
		 * 	为了适应更好的需求:我们把范围的起始值与结束值,做成变量,就更加灵活了
		 * 	
		 * 	还可以更进一步,将这个9改成变量
		 */
		//	个数
		int number = 0;
		//	总和
		int count = 0;
		//	起始值
		int star = 1;
		//	结束值
		int end = 100;
		//	倍数值
		int original = 9;
		
		for (int i = star; i <= end; i++) {
			
			if (i % original == 0) {
				
				System.out.println("i = " + i );
				
				number++;
				
				count+=i;
			}
		}
		
		System.out.println("1-100之间是9的倍数的个数为: " + number);
		System.out.println("1-100之间是9的倍数的总和为: " + count);

	}

}
