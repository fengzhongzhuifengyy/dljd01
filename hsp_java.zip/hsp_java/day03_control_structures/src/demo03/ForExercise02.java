package demo03;

/**
 * 
 * 	完成下图的打印:
 * 	0 + 5 = 5;
 * 	1 + 4 = 5;
 * 	2 + 3 = 5;
 * 	3 + 2 = 5;
 * 	4 + 1 = 5;
 * 	5 + 0 = 5;
 *
 */
public class ForExercise02 {
	
	public static void main(String[] args) {
	
		
//		for (int i = 0, j = 5; i < 6 &&j >= 0; i++, j-- ) {
//			
//			System.out.println(i + " + " + j + " = " + (i + j) );
//		}
//		
		
		
		/**
		 * 	化繁为简:
		 * 	打印 0-5,分析得出 第二个数 = 5 - i
		 * 
		 * 	先死后活:
		 * 	1. 5 --> 变量n
		 * 
		 */
		int n = 5;
		for (int i = 0; i <= n; i++) {
			System.out.println(i + " + " + (n - i) + " = n ");
		}
		
		// 换行
		System.out.println();
	}

}
