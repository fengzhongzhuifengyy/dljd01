package demo05;

// 打一个菱形
public class MultilayerCircleExercise04 {
	public static void main(String[] args) {
		
		// 先打印上半层数(h + 1) / 2
		for (int i = 1; i <= 5; i++) {
			
			// 打印前5层,每层的空白(5 -i)
			for (int j = 1; j <= 5 - i; j++) {
				System.out.print(" ");
			}
			
			// 打印每层的空白之后的黑*
			for (int k = 1; k <= 2 * i - 1; k++) {
				
				// 判断是不是第一个 以及是不是最后一个
				if (k == 1 || k == 2 * i -1) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			
			// 换行
			System.out.println();
		}
		
		// 打印下半层(h / 2)
		for (int i = 1; i <= 4; i++) {
			// 打印第6层-9层,每层的空白(x == i)
			for (int x = 1; x <= i ; x++) {
				 System.out.print(" ");
			}
			
			// 打印每层的*
			for (int y = 1; y <= 9 - 2 * i; y++) {
				if (y == 1 || y == 9 - 2 * i) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
							
			}
						
			System.out.println();			
		}

	}
}
