package demo05;

/**
 * 
 *	经典打印空心金字塔: 请编写一个程序,可以接收一个整数,表示层数(totalLevel),打印出金字塔;[化繁为简,先死后活]
 *		*		1			 *		1      2 * 1 - 1	有4个空格(层数 -1)		                          *        1     当前行的第一个位置是* 最后一个也为*
 *		**      2			***		3	   2 * 2 - 1          有3个空格(层数 -1)                        *   *      2    当前行的第一个位置是* 最后一个也为*
 *		***     3  --->    *****    5      2 * 3 - 1          有2个空格(层数 -1)      --->             *     *     2    当前行的第一个位置是* 最后一个也为*
 *		****	4		  *******	7	   2 * 4 - 1          有1个空格(层数 -1)                      *       *    2    当前行的第一个位置是* 最后一个也为*
 *		*****	5		 *********  9      2 * 5 - 1          有0个空格(层数 -1)                      *********    9    当最后一层全部输出*
 *							
 */
public class MultilayerCircleExercise03 {
	public static void main(String[] args) {
		
		/**
		 * 思路分析:
		 * 	1.先打印一个矩形
		 */
		for (int i = 0; i < 5; i++) {
			System.out.println("*****");
		}
		System.out.println("-----------------------");
		/**
		 * 2.打印半个金字塔
		 */
		// 控制*打印的层数
		for (int i = 1; i <= 5; i++) {
			// 控制每层*的个数
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			// 每打印完一层的*后就需要换行
			System.out.println();
		}
		System.out.println("-----------------------");
		/**
		 * 3.打印全的金字塔:
		 * 	1) 先打空格;
		 *  2) 再输出*
		 */
		for (int i = 1; i <= 5; i++) {
			
			// 再输出*之前,打印 空格
			for (int k = 1; k <= 5-i; k++) {
				System.out.print(" ");
			}
			
			// 输出每层的*,与空格进行拼接
			for (int j = 1; j <= (2*i-1); j++) {
				System.out.print("*");
			}
			
			System.out.println();
		}
		System.out.println("-------------------");
		/**
		 * 4.打印空金字塔:
		 * 	当前行的第一个位置是*,最后一个位置也是*
		 *  最后一层输出全部*
		 */
		
		
		/**
		 * 先死后活: 
		 * 
		 * int totalLevel = 5;
		 */
		int totalLevel = 6;
		// 控制打印层数 --5
		for (int i = 1; i <= totalLevel; i++) {
			
			// 先打印空格
			for (int j = 1; j <= totalLevel - i; j++) {
				System.out.print(" ");
			}
			
			// 控制每层的*
			// 当前行的第一个位置是*,最后一个位置也是*
			// 其他为空
			for (int k = 1; k <= 2 * i - 1; k++) {
				// 前行的第一个位置     最后一个位置       最后一行为全部
				if (k == 1 || k == 2 * i - 1 || i == totalLevel) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println("");
		}
	}
}
