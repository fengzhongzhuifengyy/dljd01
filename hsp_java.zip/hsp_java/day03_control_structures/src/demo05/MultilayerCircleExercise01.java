package demo05;

import java.util.Scanner;

/**
 * 1.统计三个班成绩情况,每个班有5名同学,求出各个班的平均分和所有班级的平均分[学生的分数从键盘输入]
 * 2.统计三个班及格人数,每个班有5名学生
 */
public class MultilayerCircleExercise01 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

//		double classScore = 0;

        double allClassScore = 0;

        for (int i = 1; i <= 3; i++) {

            double classScore = 0;

            for (int j = 1; j <= 5; j++) {

                System.out.println("请输入" + i + "班的第" + j + "位学生的成绩");
                classScore += sc.nextDouble();
            }
            System.out.println("第" + i + "班的平均分为 :  " + (classScore / 5));
            allClassScore += classScore;
        }

        System.out.println("所有班级的平均分为: " + (allClassScore / 15));
    }
}
