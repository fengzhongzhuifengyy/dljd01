package demo02;

import java.util.Scanner;

/**
 * 2.对于学生成绩大于60分的输出"合格",低于60分的输出"不合格"(注:输入的成绩不能大于100,提示成绩/60)
 * <p>
 * 这里我们需要一个转换:
 * 如果成绩在[60 , 100] ,(int)(成绩 / 60) = 1
 * 如果成绩在[60 , 100] ,(int)(成绩 / 60) = 0
 */
public class SwitchExercise02 {

    public static void main(String[] args) {

        Scanner myScanner = new Scanner(System.in);

        System.out.println("请输入您的成绩:  ");
        double d = myScanner.nextDouble();
        int score = (int) d / 60;

        // 使用if-else保证输入的成绩是有效的
        if (d >= 0 && d <= 100) {
            switch (score) {
                case 0:
                    System.out.println("不合格");
                    break;

                case 1:
                    System.out.println("合格");
                    break;

//			default:
//				System.out.println("您输入的成绩不在0 - 100之间");
            }
        } else {
            System.out.println("您输入的成绩不在0 - 100之间");
        }


        myScanner.close();
    }
}
