package demo02;

/**
 * 
 * 1.表达式数据类型, 应是case后的常量类型一致,或者是可以自动转换成可以相互比较的类型,比如输入的是字符,而常量值是int
 * 2.switch(表达式)中的表达式的返回值必须是: (byte / short / int / char / enum / String)
 * 3.case子局中的值必须为常量值或者常量表达式,不能是变量
 * 4.default子句是可选的,当没有匹配到case时,执行default,当然default注释也没有问题,表示什么也不输出
 * 5.break语句用来执行完一个case分支后使程序跳出switch语句;如果没有写break,程序会执行到switch结尾
 *
 */
public class SwitchDetail {

	public static void main(String[] args) {
		//	1.表达式数据类型, 应是case后的常量类型一致,或者是可以自动转换成可以相互比较的类型,比如输入的是字符,而常量值是int
		String s1 = "zz";
		switch (s1) {
		case "a":
			System.out.println("ok1");
			break;
			
//		case 20:
//			System.out.println("ok2");
//			break;

		default:
			break;
		}
		
		//	2.switch(表达式)中的表达式的返回值必须是: (byte / short / int / char / enum / String)
//		double d1 = 10.3;
//		switch (d1) {
//		case 10.3:
//			System.out.println("ook1");
//			break;
//
//		default:
//			break;
//		}
		
		// 3.case子局中的值必须为常量值(1, a ...)或者是常量表达式,不能是变量
		char c2 = 'a';
		switch (c2) {
		case 'a':
			
			break;
			
//		case c2:
//			
//			break;
			
		case 'a' +1:

		default:
			break;
		}
	}

}
