package demo02;

import java.util.Scanner;

/**
 * 
 * 1.使用switch把小写类型的char型转成大写(键盘输入),只转换a,b,c,d,e其他输出other
 *
 */
public class SwitchExercise01 {

	public static void main(String[] args) {
		
		Scanner myScanner = new Scanner(System.in);
		
		System.out.println("请输入a,b,c,d,e中任意一个字符: ");
		
		char ch = myScanner.next().charAt(0);
		
		switch (ch) {
		case 'a':
			ch = 'A';
			System.out.println(ch);
			break;

		case 'b':
			ch = 'B';
			System.out.println(ch);
			break;
			
		case 'c':
			ch = 'C';
			System.out.println(ch);
			break;
			
		case 'd':
			ch = 'D';
			System.out.println(ch);
			break;
			
		default:
			System.out.println("您输入的字符有误,请重新输入!");
			break;
		}
		
		myScanner.close();
	}
}
