package demo06;

/**
 * 
 * 	跳转控制语句:
 * 		随机生成一个1-100的一个数,直到生成了99,看看你一共用了几次;提示使用(int)(Math.random()*100)+1
 * 		random :double 0.0 - 1.0 
 *
 */
public class Break01 {
	public static void main(String[] args) {
		
		/**
		 * 	思路分析: 
		 * 		1.随机生成1-100的数 for死循环
		 * 		2.判断这个数到99 终止循环(通过break)
		 * 		3.记录这个数的随机次数,定义一个变量进行统计
		 */
		
		int sum = 0;
		for (; ;) {
			int randomNum = (int)(Math.random()*100) +1;
			System.out.println(randomNum);
			sum++;
			if (randomNum == 99) {
				break;
			}
			
		}
		System.out.println("sum= " + sum);
	}
}
