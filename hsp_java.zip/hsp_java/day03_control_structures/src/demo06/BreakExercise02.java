package demo06;

import java.util.Scanner;

// 实现登录验证,有3次机会,如果用户名为"丁真",密码"666"提示登录成功,否则提示还有几次机会[for + break]
public class BreakExercise02 {
	public static void main(String[] args) {
		
		/**
		 * 	思路分析:
		 * 	1.创建Scanner对象接收用户输入
		 * 	2.定义String name ; String password;
		 * 	3.最多循环3次,如果满足条件就退出
		 */
		
		Scanner myScanner = new Scanner(System.in);
		// 定义总共3次机会
		int chance = 3;
		String name = "";
		String password = "";
		
		// 定义初始的机会,记录还有几次登录的机会
		int number = 3;
		for (int i = 0; i < chance; i++) {
			System.out.print("请输入您的账号: ");
			name = myScanner.next();
			System.out.print("请输入您的密码: ");
			password = myScanner.next();
			if ("丁真".equals(name) && "666".equals(password)) {
				System.out.println("登录成功!");
				break;
			}else {
				number -= 1;
				System.out.println("还有" + number + "次机会");
			}
			
			if (number == 0) {
				System.out.println("您输入次数过多,请5分钟后稍后重试");
				break;
			}
		}
		myScanner.close();
	}
}
