package demo06;

public class BreakDetail01 {

	public static void main(String[] args) {
		
		label1:
			for (int i = 1; i <= 4; i++) {
				
		label2:
				for (int j = 1; j <= 10; j++) {
				
					if (j ==3) {
//						break label2; // 等价于 break
						break label1;
					}
					System.out.println("j =" + j);
				}
			}
	}
}
