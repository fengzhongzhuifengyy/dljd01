package homework;

import java.util.Scanner;

// 判断一个整数是否是水仙花数: 一个3位数,其各个位上的数字立方和等于本身,例如: 153 = 1^3 + 5^3 +  3^3
public class ChapterHomework04 {

	public static void main(String[] args) {
		
		/**
		 * 	思路分析:
		 * 	1.先得到这个整数的百位,十位,个位;
		 * 	n的百位 = n / 100;
		 * 	n的十位=(n % 100) / 10;
		 * 	n的个位=n % 10;
		 * 	2.判断即可
		 */
		
		Scanner myScanner = new Scanner(System.in);
		
		System.out.println("请输入一个3位数整数: ");
		
		int number = myScanner.nextInt();
		
		// 取出这个数的百位数:
		int hundred = number/100;
		System.out.println(hundred);
		
		// 取出这个数的十位数:
		int ten = (number % 100) / 10;
		System.out.println(ten);
		
		// 取出这个数的个位数:
		int units = number % 10;
		System.out.println(units);
		
		if(number == (hundred * hundred * hundred) + (ten * ten * ten) + (units * units * units) ) {
			System.out.println(number + "是水仙花数");
		}else {
			System.out.println(number + "不是水仙花数");
		}
		
		myScanner.close();
	}
}
