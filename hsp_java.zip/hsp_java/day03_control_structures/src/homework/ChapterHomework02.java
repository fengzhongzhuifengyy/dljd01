package homework;

import java.util.Scanner;

// 实现判断一个整数,属于哪个范围 : 大于0 小于0 等于0
public class ChapterHomework02 {

	public static void main(String[] args) {
		
		Scanner myScanner = new Scanner(System.in);
		
		System.out.println("请输入一个整数: ");
		
		int number = myScanner.nextInt();
		
		if (number > 0) {
			System.out.println(number + "大于0");
		}else if (number < 0) {
			System.out.println(number + "小于0");
		}else {
			System.out.println(number + "等于0");
		}
		
		myScanner.close();
	}
}
