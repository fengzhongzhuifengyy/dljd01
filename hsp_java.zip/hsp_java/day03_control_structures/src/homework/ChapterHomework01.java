package homework;

// 编程实现如下功能:
// 某人有100,000元,每次经过路口,需要交费,规则如下:
// 1)当现金 > 50000时,每次交5%
// 2)当现金<= 50000时,每次交1000
// 编程计算该人可以经过多少路口,要求使用while break方式完成
public class ChapterHomework01 {
	
	public static void main(String[] args) {
		
		/**
		 * 思路分析:
		 * 1.定义 double cash 保存 100000;
		 * 2.根据题目要求分出3种情况:
		 * 		1. cash > 50000; 2. 1000<= cash <= 50000; 3.cash < 1000;
		 * 3.使用多分支 if -elseif -else
		 * 4.使用一个变量来保存经过的路口
		 */
		
		double cash = 100000;
		
		int number = 0; // 过路口的次数
		
		while(true) {
			
			if (cash > 50000) {
//				cash -= (cash * 0.05);
				cash *= 0.95; // 写法优化 表示过了这个路口,还有这么多钱
				number ++;
			}else if (cash >= 1000) { // 注意这里有个隐藏条件 cash <= 50000
				cash -= 1000;
				number ++;
			}else {
				break;
			}
						
		}
		
		System.out.println("number = " + number);
	}

}
