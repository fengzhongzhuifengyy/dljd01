package homework;

// 求出 1-1/2+1/3-1/4.....1/100的和
public class ChapterHomework07 {

	public static void main(String[] args) {
		
		double sum = 0;
		for (int i = 1; i <= 100; i++) {
			
			// 判断分母是奇数还是偶数,然后做不同的处理
			if (i % 2 == 0) {
				
				sum -= (1.0 / i); // 核心是这个1.0
			}
			
			if (i % 2 != 0) {
				
				sum += (1.0 / i);
			}
			
		}
		System.out.println("sum = " + sum);
		
		
		/**
		 *	 思路分析:
		 *	从上面看可以得到:
		 *	1.一共有100数,他们的分子固定为1,分母从1-100
		 *	2.当分母为奇数时,为正数;当分母是偶数时,为负数
		 *	3.使用for循环 + 判断
		 *	4.把结果存放在double sum
		 *	
		 */
		/*
		 * 	按照上面的编程,得到的结果为1.0,肯定是不正常的
		 * 	那么怎么办呢?
		 * 	这里有一个隐藏的条件,(1/2 =0)  所以要把公式的分子写成1.0才能保留精度,得到精确的值
		 */
	}
}
