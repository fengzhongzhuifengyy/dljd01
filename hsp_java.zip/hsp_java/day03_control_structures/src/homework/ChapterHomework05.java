package homework;

// 输出 1-100 之间不能被5整除的数,每5个一行
public class ChapterHomework05 {

	public static void main(String[] args) {
		
		/**
		 * 	思路分析:
		 * 	1.先输出1-100的所有数
		 * 	2.然后过滤输出,不能被5整除的数
		 * 	3.每5个一行,我们使用一个计数器count,统计输出的个数,当count % 5 = 0说明(到了5的倍数)输出了5 个了.这时我们输出一个换行即可
		 */
//		int number = 0; // 记录每一行的个数
//		for( int i = 1; i <= 100; i++) {
//						
//			if (i % 5 != 0) {
//				number += 1;
//				
//				if (number <= 5) {
//					System.out.print(i + " ");
//				}else {
//					System.out.println();
//					System.out.print(i + " ");
//					number = 1;
//				}
//			}
//		}
		
		 /**老师的做法*/
		int count = 0; //统计输出的个数
		
		for (int i = 1; i <= 100; i++) {
			
			if(i % 5 != 0) {
				count++;
				System.out.print(i + "\t");
				
				// 判断,每满5个就另起一行输出,输出一行
				if(count % 5 ==0) {
					System.out.println();
				}
				
			}
		}
	}
}
