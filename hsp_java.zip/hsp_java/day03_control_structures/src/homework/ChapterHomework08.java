package homework;

// 求 1+ (1+2) + (1+2+3) + ( 1+2+3+4 ) +...+(1+2+3+4+...+100)的结果
public class ChapterHomework08 {

	public static void main(String[] args) {
		
		/**
		 * 	思路分析:
		 * 	1. 一共有100项相加
		 * 	2.每一项的数字在逐渐增加
		 * 	3.很像一个双层循环
		 * 	4.这个i可以表示第几项,同时也是当前项最后一个数
		 * 	5.使用sum进行累加
		 */
		int sum = 0;
		for (int i = 1; i <= 100; i++) { // i可以表示第几项,同时也是当前项最后一个数
			
			for (int j = 1; j <= i; j++) { // 内层是对1~i进行循环
				sum += j;
			}
		}
		System.out.println("sum = " + sum);
	}
}
