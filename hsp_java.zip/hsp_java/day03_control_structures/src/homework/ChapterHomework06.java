package homework;

// 输出小写的a-z以及大写的Z-A
public class ChapterHomework06 {

	public static void main(String[] args) {
		
		for (char i = 97; i <= 122; i++) {
			System.out.print(i+ " ");
		}
		System.out.println();
		
		for (char i = 90; i >= 65; i--) {
			System.out.print(i + " ");
		}
		System.out.println();
		
		/**
		 * 	思路分析:
		 * 	'b' = 'a' + 1;
		 * 	'c' = 'a' + 2;
		 * 	for循环
		 */
		for (char i = 'a'; i <= 'z'; i++) {
			System.out.print(i);
		}
		System.out.println();
		
		for (char i = 'Z'; i >= 'A'; i--) {
			System.out.print(i);
		}
	}
}
