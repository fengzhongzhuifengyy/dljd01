package houserent.service;

import com.hspjava.project.houserent.domain.House;

public class HouseService {

    private int countNumber = 1; //已经存在的房屋数量初始值
    private int idNumber = 0; // 房屋的id初始值
    private int index = -1; // 房屋数组的索引

    /**
     * 返回所有的房屋信息
     * 此时房屋的信息放在那里呢？ -->通过数组实现
     */
    House[] houses;

    // 初始化对象的时候创建这个数组的长度
    public HouseService(int size) {
        houses = new House[size];
        // 为了测试默认创建对象时插入数组
        houses[0] = new House(0, "jack", "112", "南京市", 1550, "已出租");
    }

    public House[] list() {
        for (int i = 0; i < houses.length; i++) {
            if (houses[i] != null) {// 考虑有存在null的情况
                System.out.println(houses[i]);
            }
        }
        return houses;
    }

    public boolean add(House house) {
        // 判断是否可以添加，此时考虑到需要定义一个变量用来确定已经存在的房屋数量；
        if (countNumber == houses.length) {
            System.out.println("数组已满，无法添加！");
            return false;
        }
        // 此时开始添加房屋
        houses[countNumber++] = house;
        // countNumber++;

        // 实现id系统自增
        // idNumber++;
        house.setId(++idNumber);
        return true;
    }

    public boolean delete(int id) {
        // 考虑删除的id是否存在
        for (int i = 0; i < houses.length; i++) {
            if (id == houses[i].getId()) {
                // 此时考虑如何删除，数组删除的为索引，所以必须知道索引为何，因此定义变量index
                index = i;
                break;
            }
        }

        // 开始判断通过索引如何删除
        if (index != -1) {
            // 删除其中一个数组，就相当于将他之后的房屋数组元素，向前交换
            for (int i = index; i < countNumber - 1; i++) { // 此时可以知道最后一个删掉，那么他后面的再向前移就会报错空指针
                // 之后的每个数组元素，向前交换
                houses[i] = houses[i + 1];
            }
            // 将当前存在的房屋的最后的位置，置空，不是数组，数组很长，最后都是null
            houses[countNumber-1] = null;
            // 当前的房屋数量-1
            countNumber--;
            return true;
        }
        System.out.println("您输入的id不存在，请重新输入！");
        return false;

    }

    public House query(int id) {
        // 考虑id是否存在
        for (int i = 0; i < countNumber; i++) {
            if (id == houses[i].getId()) {
                return houses[i];
            }
        }
        System.out.println("您输入的房屋id不存在，请重新输入！");
        return null;
    }
}
