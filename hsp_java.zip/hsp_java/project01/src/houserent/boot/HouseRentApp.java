package houserent.boot;
import com.hspedu.java.project.houserent.view.HouseView;

public class HouseRentApp {
    public static void main(String[] args) {

    new HouseView().mainView();

    }
}
