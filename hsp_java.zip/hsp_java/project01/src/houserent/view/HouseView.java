package houserent.view;

import com.hspjava.project.houserent.domain.House;
import com.hspjava.project.houserent.service.HouseService;
import com.hspjava.project.houserent.utils.Utility;

/**
 *  1、显示主菜单
 *  2、接收用户信息
 *  3、调用HouseService完成对房屋信息的各种操作
 */
public class HouseView {
    private boolean loop = true; // 控制显示菜单
    private char key = ' ';  // 接收用户选择的是哪个菜单
    private HouseService houseService = new HouseService(5);

    /**
     * 显示主菜单
     */
    public void mainView() {


        do{
            System.out.println("--------房屋出租系统--------");
            System.out.println("\t\t\t1 新 增 房 源");
            System.out.println("\t\t\t2 查 找 房 源");
            System.out.println("\t\t\t3 删 除 房 屋");
            System.out.println("\t\t\t4 修 改 房 屋 信 息");
            System.out.println("\t\t\t5 房 屋 列 表");
            System.out.println("\t\t\t6 退       出");

            System.out.print("请输入你的选择（1-6）：");
            key = Utility.readMenuSelection();
            switch (key){
                case '1':
                    addHouse();
                    break;
                case '2':
                    queryHouse();
                    break;
                case '3':
                    deleteHouse();
                    break;
                case '4':
                    updateHouse();
                    break;
                case '5':
                    listHouse();
                    break;
                case '6':
                    exitHouse();
                    break;
                default:
                    System.out.println("你输入的不合理，请重新输入!");

            }
        }while (loop);
    }

    /**
     * 功能：房屋列表查询
     */
    public void listHouse(){
        System.out.println("---------------房屋列表---------------");
        System.out.println("编号\t房主\t电话\t地址\t月租\t状态（未出租/已出租）");
        houseService.list();
        System.out.println("-------------房屋列表完成-------------");
    }

    /**
     * 功能：添加房屋
     */
    public void addHouse(){
        System.out.println("---------------添加房屋---------------");
        System.out.print("姓名：");
        String name = Utility.readString(3);
        System.out.print("电话：");
        String phone = Utility.readString(3);
        System.out.print("地址：");
        String address = Utility.readString(15);
        System.out.print("月租：");
        int rent = Utility.readInt();
        System.out.print("状态（未出租/已出租）：");
        String status = Utility.readString(3);
        House house = new House(1, name, phone, address, rent, status);
        if (houseService.add(house)){
            System.out.println("添加成功！");
        }else {
            System.out.println("添加失败！");
        }
        System.out.println("---------------添加完成---------------");
    }

    /**
     * 删除房屋
     */
    public void deleteHouse(){
        System.out.println("---------------删除房屋---------------");
        System.out.print("请选择待删除编号（-1退出）：");
        int id = Utility.readInt();
        if (id == -1){
            return;
        }
        System.out.print("确认是否删除（Y/N），请小心选择：");
        char temp = Utility.readConfirmSelection();
        if (temp == 'N'){
            return;
        }
        char c = Utility.readConfirmSelection();
        if (c == 'N'){
            return;
        }
        houseService.delete(id);
        System.out.println("---------------删除完成---------------");
    }

    /**
     * 功能：退出房屋
     */
    public void exitHouse(){
        for (;;) {
            System.out.print("确认是否退出（Y/N）：");
            char c = Utility.readConfirmSelection();
            if (c == 'Y'){
                System.out.println("退出成功！");
                loop = false;
                break;
            }
            return;
        }
    }

    /**
     * 功能：根据id查询
     */
    public void queryHouse(){
        System.out.println("---------------查找房屋---------------");
        System.out.print("请输入你要查找的id：");
        int id = Utility.readInt();
        if (houseService.query(id) != null) {
            System.out.println(houseService.query(id));
        }
    }

    /**
     * 功能：修改房屋信息
     */
    public void updateHouse(){
        System.out.println("---------------修改房屋---------------");
        System.out.print("请输入要修改的房屋编号（-1表示退出）：");
        int updateId = Utility.readInt();
        if (updateId == -1){
            System.out.println("放弃修改");
            return;
        }
        House updateHouse = houseService.query(updateId);
        if (updateHouse == null){
            System.out.println("修改的房屋不存在！");
            return;
        }
        System.out.print("姓名（" + updateHouse.getName() + "）:");
        String name = Utility.readString(8,updateHouse.getName()); // enter表示不修改
        if (!(name.equals(updateHouse.getName()))){
            updateHouse.setName(name);
        }
        System.out.print("电话：（" + updateHouse.getPhone() + "）:");
        String phone = Utility.readString(8,updateHouse.getPhone()); // enter表示不修改
        if (!(phone.equals(updateHouse.getPhone()))){
            updateHouse.setPhone(name);
        }
        System.out.print("地址：（" + updateHouse.getAddress() + "）:");
        String address = Utility.readString(8,updateHouse.getAddress()); // enter表示不修改
        if (!(address.equals(updateHouse.getAddress()))){
            updateHouse.setPhone(address);
        }
        System.out.print("租金（" + updateHouse.getRent() + "）:");
        int rent = Utility.readInt(updateHouse.getRent()); // enter表示不修改
        if (rent != updateHouse.getRent()){
            updateHouse.setRent(rent);
        }
        System.out.print("状态（" + updateHouse.getState() + "）:");
        String state = Utility.readString(8,updateHouse.getState()); // enter表示不修改
        if (!(state.equals(updateHouse.getState()))){
            updateHouse.setState(state);
        }
        System.out.println("---------------修改完成---------------");
    }
}