package smallChange;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class SmallChangeSystem {
    // 化繁为简
    // 1.先完成显示菜单,并可以选择菜单,给出对应的提示
    // 2.完成零钱通明细
    //  思路: (1)可以把收益入账和消费,保存到数组,(2)可以使用对象,(3)简单的话可以使用String拼接
    // 3.完成收益入账
    // 4.消费
    // 5.提示循环退出:
    //  思路: 建议一段代码,完成一个小功能,尽量不要混在一起
    //      1)定义一个变量,用来接收用户的输入
    //      2)使用 while + break 来实现用户循环输入
    //      3)当用户退出后再来判断,用户的输入是y/n,进行退出

    public static void main(String[] args) {

        // 定义相关变量
        boolean loop = true;
        Scanner myScanner = new Scanner(System.in);
        // 2.完成零钱通明细
        String details = "---------零钱通明细---------\n";

        // 3.完成收益入账
        double money = 0;
        double balance = 0;
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy--MM--dd HH:mm"); // 用于日期格式化的对象

        // 4.消费
        String note = "";

        //5

        do {

            System.out.println("==========零钱通菜单=========");
            System.out.println("\t\t\t1 零钱通明细");
            System.out.println("\t\t\t2 收益入账");
            System.out.println("\t\t\t3 消费");
            System.out.println("\t\t\t4 退出");
            System.out.print("请选择(1-4): ");
            String choose = myScanner.next();

            switch (choose) {

                case "1":
                    System.out.println(details);
                    break;
                case "2":
                    System.out.print("收益入账金额:");
                    money = myScanner.nextDouble();
                    // 判断金额的合理性,找出不正确金额的条件,给出提示即可,就直接break; 找正确的接着走,条件比较广不建议
                    if(money <= 0){
                        System.out.println("入账金额范围需要大于0");
                        break;
                    }

                    balance += money;

                    // 获取当前日期
                    date = new Date();

                    // 拼接收益入账信息到details
                    details += "收益入账\t+" + money + "\t" + sdf.format(date) + "\t余额:" + balance + "\n";
                    break;
                case "3":
                    System.out.print("消费金额:");
                    money = myScanner.nextDouble();
                    if (money <= 0 || money > balance){
                        System.out.println("你的金额应该在 0 - " + balance + "之间");
                        break;
                    }
                    System.out.print("消费说明:");
                    note = myScanner.next();
                    balance -= money;
                    date = new Date();
                    details += note + "\t-" + money + "\t" + sdf.format(date) + "\t余额:" + balance + "\n";
                    break;
                case "4":
                    String str = "";
                    // 用户循环输入y/n
                    while (true) {
                        System.out.println("是否确认退出?y/n: ");
                        str = myScanner.next();
                        if ("y".equals(str) || "n".equals(str)) { // 进行判断y/n,退出循环,否则出不来
                            break;
                        }
                    }
                    // 程序走到这一步说明,str = y || n;如果是n的话就不做处理
                    if (str.equals("y")) {
                        loop = false;
                    }
                    break;
                default:
                    System.out.println("您输入的选择不合法,请重新选择");
            }

        } while (loop);

        System.out.println("-----退出了零钱通项目------");
    }
}
