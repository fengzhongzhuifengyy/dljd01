package smallChange;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

class SmallChangeSystemOOP {

    // 定义相关变量
    boolean loop = true;
    Scanner myScanner = new Scanner(System.in);
    // 2.完成零钱通明细
    String details = "---------零钱通明细---------\n";

    // 3.完成收益入账
    double money = 0;
    double balance = 0;
    Date date = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy--MM--dd HH:mm"); // 用于日期格式化的对象

    // 4.消费
    String note = "";

    /**
     * 零钱通菜单
     */
    public void printMenu() {
        do {
            System.out.println("==========零钱通菜单=========");
            System.out.println("\t\t\t1 零钱通明细");
            System.out.println("\t\t\t2 收益入账");
            System.out.println("\t\t\t3 消费");
            System.out.println("\t\t\t4 退出");
            System.out.print("请选择(1-4): ");
            String choose = myScanner.next();

            switch (choose) {
                case "1":
                    this.changeDetails();
                    break;
                case "2":
                    this.earningsRecorded();
                    break;
                case "3":
                    this.amountOfConsumption();
                    break;
                case "4":
                    this.exit();
                    break;
                default:
                    System.out.println("您输入的选择不合法,请重新选择");
            }

        } while (loop);

        System.out.println("-----退出了零钱通项目------");
    }

    /**
     * 零钱通明细
     */
    public void changeDetails() {
        System.out.println(details);
    }

    /**
     * 收益入账
     */
    public void earningsRecorded() {
        System.out.print("收益入账金额:");
        money = myScanner.nextDouble();
        // 判断金额的合理性,找出不正确金额的条件,给出提示即可,就直接break; 找正确的接着走,条件比较广不建议
        if (money <= 0) {
            System.out.println("入账金额范围需要大于0");
            return;
        }
        balance += money;
        // 获取当前日期
        date = new Date();
        // 拼接收益入账信息到details
        details += "收益入账\t+" + money + "\t" + sdf.format(date) + "\t余额:" + balance + "\n";
    }

    /**
     * 消费金额
     */
    public void amountOfConsumption() {
        System.out.print("消费金额:");
        money = myScanner.nextDouble();
        if (money <= 0 || money > balance) {
            System.out.println("你的金额应该在 0 - " + balance + "之间");
            return;
        }
        System.out.print("消费说明:");
        note = myScanner.next();
        balance -= money;
        date = new Date();
        details += note + "\t-" + money + "\t" +
                sdf.format(date) + "\t余额:" + balance + "\n";
    }

    /**
     * 退出
     */
    public void exit() {
        String str = "";
        // 用户循环输入y/n
        while (true) {
            System.out.println("是否确认退出?y/n: ");
            str = myScanner.next();
            if ("y".equals(str) || "n".equals(str)) { // 进行判断y/n,退出循环,否则出不来
                break;
            }
        }
        // 程序走到这一步说明,str = y || n;如果是n的话就不做处理
        if (str.equals("y")) {
            loop = false;
        }
    }

}





