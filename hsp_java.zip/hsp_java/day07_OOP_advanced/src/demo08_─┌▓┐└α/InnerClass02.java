package demo08_内部类;

/**
 *  演示局部内部类的使用
 */
public class InnerClass02 {
    public static void main(String[] args) {
        Outer02 outer02 = new Outer02();
        outer02.m1();
        //⑥外部其他类 --> 不能访问局部内部类(因为局部内部类地位是个局部变量)
//        InnerClass001 InnerClass001 = new InnerClass001(); //无法解析符号 'InnerClass001'
        System.out.println(outer02);
    }
}

class Outer02{
    private int n1 = 100;
    private void m2(){
        System.out.println("私有方法m2");
    }
    public void m1(){
        //局部内部类是定义在外部类的局部位置,比如方法中,并且有类名
        //②不能添加访问修饰符,因为其地位就是一个布局变量(类),局部变量不能使用修饰符,但是可以使用final修饰符,因为局部变量也可以使用final修饰符
         final class InnerClass001{ // 局部内部类(本质还是一个类)
             //⑦如果外部类和局内部类的成员重名时,默认遵从就近原则,如果想访问外部类的成员,则可以使用(外部类名.this.447成员)去访问
             private int n1 =200;
            //①可以直接访问外部的所有成员,包括私有的
            public void f1(){
                //④局部内部类--访问--->外部类成员(访问方式:直接访问)100
                System.out.println("n1 = " + n1); //200
                //Outer02.this是什么意思呢? 本质就是外部类的对象,谁调用m1(),则Outer02.this就是哪个对象 --> 验证
                System.out.println("外部的n1 = " + Outer02.this.n1);//100
                m2(); //私有方法m2
                //验证本质就是外部类的对象,谁调用f1(),则Outer02.this就是哪个对象,打印hashCode,此时这个对象就是outer02
                System.out.println(Outer02.this); //可以看出是一致的
            }
        }
        //⑤外部类--访问--->局部内部类的成员,(访问方式:创建对象再访问,注意: 必须在作用域中)
        InnerClass001 innerClass001 = new InnerClass001();
        innerClass001.f1();
        //可以看出在局部范围内(方法),还是可以继承的,但是加上final修饰之后,就不可以
//        class InnerClass03 extends InnerClass02{
//
//        }
    }
    /*
        ③作用域:仅仅在定义它的方法或者代码块中
     */
    {
        class InnerClass03{

        }
    }
}