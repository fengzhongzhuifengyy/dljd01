package demo08_内部类;

/**
 *  匿名内部类介绍
 */
public class InnerClass03 {
    public static void main(String[] args) {
        OutClass03 outClass03 = new OutClass03();
        outClass03.m1();
        outClass03.m2();
        outClass03.m3();
    }
}

class OutClass03{
    private int n = 100;

    public void m1(){
        /**
          基于接口的匿名内部类
        */
        // 1.需求: 想使用A接口,并创建对象? --> 传统方式解决: 写一个实现类,并创建对象引用
        A a = new B();
        a.cry();
        // 这样的写法的问题是什么? --> B类只是使用一次,以后再也不使用了 --> 使用匿名内部类来简化开发
        /*
           aa的编译类型 --> A
           aa的运行类型 --> 就是匿名内部类,XXX-->OutClass03$1
           class XXX implments A{
                public void cry() {
                    System.out.println("匿名叫唤");
                }
           }
           jdk底层在创建匿名内部类OutClass03$1,立即就创建了OutClass03$1实例,并将地址返回给aa
           匿名内部类使用一次就不能再使用了,注意: 类不能使用,但是实例(对象)aa可以使用
           标点符号; 要保留
         */
        A aa = new A() {
            public void cry() {
                System.out.println("匿名叫唤");
            }
        };
        aa.cry();
        System.out.println("aa的运行类型" + aa.getClass()); // aa的运行类型 OutClass03$1,可见是底层实现,getClass()获取对象的运行类型
        aa.cry();
    }

    /**
     *  基于类的匿名内部类
     */
    public void m2(){
        // 匿名内部类
        /*
            1.C的编译类型 --> C
            2.C的运行类型 --> 匿名内部类 OutClass03$2
            3.底层还是会创建类
            class OutClass03$2 extends C{

            }
            4.同时也直接返回了匿名内部类OutClass03$2的实例
            5.标点符号; 要保留
            6.注意匿名类的参数列表str 会传递给C的构造器
         */
        C c = new C("str"){
            // 匿名内部类可以重写f1()
            @Override
            public void f1() {
                System.out.println("匿名内部类可以重写f1()");
            }
        };
        System.out.println("c的运行类型" + c.getClass());
    }

    public void m3(){

        /**
         *  基于抽象类的匿名内部类
         */
        // 可以看出必须写出其抽象方法
        new D(){
            @Override
            void eat() {
                System.out.println("匿名内部类的eat()");
            }
        }.eat();
    }
}


interface A {
    void cry();
}

class C {
    public C(String str){

    }
    public void f1(){

    }
}
abstract class D{
    abstract void eat();
}

class B implements A{
    @Override
    public void cry() {
        System.out.println("叫唤...");
    }
}