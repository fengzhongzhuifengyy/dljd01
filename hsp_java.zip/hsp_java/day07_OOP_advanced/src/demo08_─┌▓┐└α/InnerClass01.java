package demo08_内部类;
// 内部类简介
/*
    定义在局部位置上
        局部内部类(有类名)
        匿名内部类(没有类名)
    定义在成员位置上
        成员内部类(无static)
        静态内部类(有static)
 */
public class InnerClass01 { // 外部其他类
}

class OuterClass{

    private int n1 = 10;

    public void m1(){
        System.out.println("m1()");
    }

    public OuterClass(int n1) {
        this.n1 = n1;
    }

    {
        System.out.println("代码块");
    }
    // 内部类
    class InnerClass{

    }
}
