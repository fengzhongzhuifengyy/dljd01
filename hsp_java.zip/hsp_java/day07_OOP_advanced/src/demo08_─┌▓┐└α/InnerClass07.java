package demo08_内部类;

/**
 * 静态内部类
 */
public class InnerClass07 {
    public static void main(String[] args) {
        OutClass07 outClass07 = new OutClass07();
        outClass07.m1();

        //6.外部其他类--访问-->静态内部类
        //①因为静态内部类,是可以通过类名直接访问(前提是满足访问权限)
        OutClass07.InnerClass07 innerClass07 = new OutClass07.InnerClass07();
        innerClass07.say();
        //②编写一个方法,可以返回静态类内部类的对象实例
        OutClass07.InnerClass07 innerClass071 = outClass07.getInnerClass07Instance();
        innerClass071.say();
        //③编写一个静态的方法,直接使用外部类名.方法
        OutClass07.getInnerClass07Instance01();
    }
}

class OutClass07{
    private int n1 =10;
    private static String  name = "张三";
    private static void cry(){
        System.out.println("静态方法cry");
    }

    //InnerClass07就是静态内部类
    //1.放在外部类的成员位置,使用static修饰
    static class InnerClass07{
        private static String name = "李四";
        public void say(){
            //2.可以直接访问外部类的所有静态成员,包含私有的,但是不能直接访问非静态的成员
//            System.out.println("n1=" + n1);// 无法从 static 上下文引用非 static 字段 'n1'
            System.out.println("就近name=" +name);
            //6.如果外部类和静态内部类成员重名时,静态内部类访问的话,默认遵循就近原则,如果想访问外部类的成员,则可以使用(外部类名.成员)去访问
            System.out.println("外部类name=" +OutClass07.name);
            cry();
        }
    }

    //3.可以添加任意访问修饰符(public protected 默认 private),因为他的地位就是个成员
    private static class InnerClass071{

    }
    //4.作用域也是整个类体
    public void m1(){
        //5.外部类--访问-->静态内部类[访问方式:创建对象,再访问]
        new InnerClass07().say();
    }

    public InnerClass07 getInnerClass07Instance(){
        return new InnerClass07();
    }
    public static InnerClass07 getInnerClass07Instance01(){
        return new InnerClass07();
    }
}