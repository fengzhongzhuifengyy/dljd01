package demo08_内部类;

/**
 * 匿名内部类细节
 */
public class InnerClass04 {
    public static void main(String[] args) {
        OutClass04 outClass04 = new OutClass04();
        outClass04.f1();
    }
}

class OutClass04{
    private int n1 = 99;
    public void f1(){
        int n1 = 100;
        // 创建一个基于类的的匿名内部类
        A04 a04 = new A04(){
            @Override
            public void hi() {
                System.out.println("匿名内部类的hi()1");
                // 访问外部的私有属性
                System.out.println("外部类的私有属性n1" + OutClass04.this.n1);
            }
        };
        a04.hi();// 动态绑定OutClass04$1

        // 也可以直接调用,匿名内部类本身也是返回了一个对象,传参都可以
        new A04(){
            @Override
            public void hi() {
                System.out.println("匿名内部类的hi()2");
            }
        }.hi();
    }

}

class A04{
    public void hi(){
        System.out.println("A01的hi()...");
    }
}