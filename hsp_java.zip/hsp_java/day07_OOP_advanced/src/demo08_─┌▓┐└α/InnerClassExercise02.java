package demo08_内部类;
// 查看代码结果
public class InnerClassExercise02 {//外部类
    public InnerClassExercise02() {//构造器
        Inner s1 = new Inner();
        s1.a = 10;
        Inner s2 = new Inner();
        System.out.println(s2.a);
    }
    class Inner { //内部类，成员内部类
        public int a = 5;
    }
    public static void main(String[] args) {
        InnerClassExercise02 t = new InnerClassExercise02();
        Inner r = t.new Inner();//5
        System.out.println(r.a);//5
    }
}