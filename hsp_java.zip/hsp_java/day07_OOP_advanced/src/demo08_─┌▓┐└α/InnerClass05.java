package demo08_内部类;

/**
 * 匿名内部类的最接实践:传统方法是硬编码,如果实现类修改,则所有引用此方法都修改;简洁高效
 */
public class InnerClass05 {
    public static void main(String[] args) {
        //当做实参直接传参,简洁高效
        f1(new A05() {
            @Override
            public void show() {
                System.out.println("这是一幅名画");
            }
        });
        //传统方式:先写一个实现类,实现接口方法,f1再调用实现类f1(new Example)
        f1(new Example());
    }

    // 静态方法,形参是接口类型
    public static void f1(A05 a05){
        a05.show(); //a05的编译类型是A05,但是这个方法怎么写完全可以自己去实现
    }
}
//接口
interface A05{
    void show();
}
//传统方式: 编写实现类
class Example implements A05{
    @Override
    public void show() {
        System.out.println("传统的一幅画");
    }
}




