package demo08_内部类;

/**
 * 成员内部类
 */
public class InnerClass06 {
    public static void main(String[] args) {
        OuterClass06 outerClass06 = new OuterClass06();
        outerClass06.test();
        //6.外部其他类--访问-->成员内部类,三种方式
        //①outerClass06.new InnerClass06();相当于把 new InnerClass06() 当做是outerClass06对象的成员;就是个语法不用特别纠结
        OuterClass06.InnerClass06 innerClass06 = outerClass06.new InnerClass06();
        innerClass06.say();

        //②在外部类中编写一个方法,返回内部类的对象实例
        OuterClass06.InnerClass06 innerClass066 = outerClass06.getInnerClassO6Instance();// 返回的是InnerClass06
        innerClass066.say();

        //③外部类的实例.内部类实例.成员 本质还是第一种
        new OuterClass06().new InnerClass06().say();
    }
}

class OuterClass06{

    private int n1 = 100;
    public String name = "张三";
    private void say(){
        System.out.println("OuterClass06.say()...");
    }
    private void say1(){
        System.out.println("OuterClass06.say1()...");
    }
    //1.成员内部类是定义在外部内的成员位置上
    class InnerClass06{
        private int n1 = 99;
        public void say(){
            //4.成员内部类--访问-->外部类成员[访问方式:直接访问]
            //7.如果外部类和内部类成员重名时,内部访问的话,默认遵循就近原则,如果想访问外部类的成员,则可以使用(外部类名.this.成员)去访问
            System.out.println("n1=" + n1 + "\tname=" + name + "\t外部n1= " + OuterClass06.this.n1);
            System.out.println("成员内部类InnerClass06的say()...");
            say1();
//            say();
            OuterClass06.this.say();
        }
    }

    // 2.可以添加任意访问修饰符(public protected 默认 private),因为它的地位就是一个成员
    protected class InnerClass061{

    }
    // 3.作用域:和外部类的其他成员一样,为整个类体

    //用方法体现内部类
    //5.外部类--访问-->成员内部类[访问方式:创建对象,再访问]
    public void test(){
        // 在这里我们使用了成员内部类
        new InnerClass06().say();
    }

    //在外部类中编写一个方法,返回内部类的对象实例
    public InnerClass06 getInnerClassO6Instance(){
        return new InnerClass06();
    }
}
