package demo05_final;

// 请写出程序,计算圆形的面积,要求圆周率为3.14,赋值的3个位置都写一下
public class FinalExercise01 {
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.setRadius(2);
        System.out.println(circle.Area());
        System.out.println(circle.Area1());
        System.out.println(circle.Area2());
    }
}

class Circle{

    private double radius;
    // 1.直接定义
    public static final double PI = 3.14;

    public double Area(){
        return getRadius() * getRadius() * PI;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    // 2.构造器
    public  final double PI1;
    public Circle(){
        PI1 = 3.14;
    }
    public double Area1(){
        return getRadius() * getRadius() * PI1;
    }

    // 代码块中
    public  final double PI2;
    {
        PI2 = 3.14;
    }
    public double Area2(){
        return getRadius() * getRadius() * PI2;
    }
}

// 练习2
//class SomeThing{
//    public int addOne (final int x){  // final 可以为形参
//        ++x; // 错误不能修改final的值
//        return x+1; //正确,不影响x的值
//    }
//}