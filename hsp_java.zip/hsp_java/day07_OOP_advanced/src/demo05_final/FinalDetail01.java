package demo05_final;

public class FinalDetail01 {
    public static void main(String[] args) {
        B01 b01 = new B01();

        new D01().cal();
    }
}

class A01{
    // final修饰的属性在定义时,必须赋初值,并且不能修改
    // 1.直接定义
    public final double TAX_RATE = 0.08;
    // 2.构造器中
    public final double TAX_RATE2;
    public A01() {
        TAX_RATE2 = 0.07;
    }
    // 3.代码块
    public final double TAX_RATE3;
    {
      TAX_RATE3 = 0.09;
    }

    // 如果final修饰的属性是静态的,则初始化的位置只能是定义与静态代码块中
    public static final double NUM = 0.01; // 直接定义
    // 静态代码块
    public static final double NUM1;
    static {
        NUM1 = 0.02;
    }

    // 构造器呢? 因为构造器是创建对象之后.static不需要创建对象
//    public static final double NUM2;
//    public A01(String name){
//        NUM2 = 0.03;
//    }
}
// final类不能继承,但是可以实例化对象 main方法中证明可以实例化
final class B01{

}

// 如果类不是final类,但是含有final方法,则该方法虽然不能重写但是可以被继承

class C01 {

    public final void cal(){
        System.out.println("final");
    }
}
// 能继承这个cal方法吗? 在main方法中调用,发现可以继承该final方法
class D01 extends C01{

}
