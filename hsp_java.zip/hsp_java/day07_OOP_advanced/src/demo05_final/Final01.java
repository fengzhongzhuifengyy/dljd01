package demo05_final;

public class Final01 {
    public static void main(String[] args) {
//        new C().TAX_RATE = 0.09; // 无法将值赋给 final 变量 'TAX_RATE'
    }
}
// 要求A不能被其他类继承
final class A {

}

//class B extends A {} // 无法从final 'com.hspjava.day07_面向对象高级.demo05_final.A' 继承

class C{
    // 要求hi()不能被子类重写
    public final void hi(){
        // 要求局部变量不能改 局部常量
        final double NUMBER = 0.01;
//        NUMBER = 0.09; // 无法将值赋给 final 变量 'NUMBER'
    }

    // 要求属性不能修改
    public final double TAX_RATE = 0.08;
}

class D extends  C{

//    @Override
//    public void hi() { // 'hi()' 无法重写 'com.hspjava.day07_面向对象高级.demo05_final.C' 中的 'hi()'；重写的方法为 final
//        super.hi();
//    }
}