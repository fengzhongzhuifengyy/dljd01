package demo05_final;

public class FinalDetail02 {
    public static void main(String[] args) {
        System.out.println(B02.NUM);
        /*
            只会打印100
            去掉final 之后,就会打印
            B02静态代码块被执行
            100
         */
    }
}

// 一个类是final,就没有必要再将方法修饰成final方法
final class A02{
    public final void f1(){ // 类已经无法继承,方法就更不会被重写了

    }
}

// final和static往往搭配使用,效率更高,不会导致类加载 --- main方法中可以看出 底层的内部优化,不会加载类
class B02{
    public final static int NUM = 100;
    static {
        System.out.println("B02静态代码块被执行");
    }
}

