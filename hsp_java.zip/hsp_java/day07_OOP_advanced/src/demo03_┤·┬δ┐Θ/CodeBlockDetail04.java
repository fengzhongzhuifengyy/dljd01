package demo03_代码块;

public class CodeBlockDetail04 {
    public static void main(String[] args) {
        B01 b01 = new B01();// 先进行类加载,再创建对象
        /*
                getVal01
                A02 的一个静态代码块..
                getVal03
                B02 的一个静态代码块..
                A02 的第一个普通代码块..
                getVal02
                A02 的构造器
                getVal04
                B02 的第一个普通代码块..
                B02 的构造器
         */

        C01 c01 = new C01();
    }
}


class A01{
    private static int n1 = getVal01();
    static {
        System.out.println("A02 的一个静态代码块..");
    }
    {
        System.out.println("A02 的第一个普通代码块..");
    }
    public int n3 = getVal02();//普通属性的初始化
    public static int getVal01() {
        System.out.println("getVal01");
        return 10;
    }
    public int getVal02() {
        System.out.println("getVal02");
        return 10;
    }
    public A01() {//构造器
    //隐藏
    //super()
    //普通代码和普通属性的初始化......
        System.out.println("A02 的构造器");
    }
}

class B01 extends A01{
    private static int n3 = getVal03();
    static {
        System.out.println("B02 的一个静态代码块..");
    }
    public int n5 = getVal04();
    {
        System.out.println("B02 的第一个普通代码块..");
    }
    public static int getVal03() {
        System.out.println("getVal03");
        return 10;
    }
    public int getVal04() {
        System.out.println("getVal04");
        return 10;
    }
    //一定要慢慢的去品..
    public B01() {//构造器
        //隐藏了
        //super()
        //普通代码块和普通属性的初始化...
        System.out.println("B02 的构造器");
    }
}

class C01{
    private int n1 = 100;
    private static int n2 = 200;
    private void f1(){
        System.out.println("普通方法f1");
    }
    private static void f2(){
        System.out.println("静态方法f2");
    }

    static {
//        System.out.println(n1);
        System.out.println(n2);
//        f1();
        f2();
    };

    {
        System.out.println(n1);
        System.out.println(n2);
        f1();
        f2();
    }
}
