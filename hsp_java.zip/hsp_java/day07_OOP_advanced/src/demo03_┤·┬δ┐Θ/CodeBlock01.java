package demo03_代码块;

public class CodeBlock01 {
    public static void main(String[] args) {

        Movie movie = new Movie("你好,李焕英");
        /*
                电影屏幕打开
                广告打开
                电影正式开始
                Movie(name)
            可以看出 代码块的调用顺序优先于构造器
         */
    }
}


class Movie{

    private String name;
    private double price;
    private String director;

    // 3个构造器 ->重载
    /*
        下面的三个构造器都有相同的语句,代码繁琐
        可以把相同的语句,放入到代码块中即可;
        当我们不管调用哪个构造器创建对象,都会先调用代码块的内容
        可以看出 代码块的调用顺序优先于构造器
     */
    {
        System.out.println("电影屏幕打开");
        System.out.println("广告打开");
        System.out.println("电影正式开始");
    }
    public Movie(String name) {
        // System.out.println("电影屏幕打开");
        // System.out.println("广告打开");
        // System.out.println("电影正式开始");
        System.out.println("Movie(name)");
        this.name = name;
    }

    public Movie(String name, double price) {
        // System.out.println("电影屏幕打开");
        // System.out.println("广告打开");
        // System.out.println("电影正式开始");
        this.name = name;
        this.price = price;
    }

    public Movie(String name, double price, String director) {
        // System.out.println("电影屏幕打开");
        // System.out.println("广告打开");
        // System.out.println("电影正式开始");
        this.name = name;
        this.price = price;
        this.director = director;
    }
}
