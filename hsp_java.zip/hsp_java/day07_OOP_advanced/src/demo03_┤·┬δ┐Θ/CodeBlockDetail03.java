package demo03_代码块;

public class CodeBlockDetail03 {
    public static void main(String[] args) {
        BBB bbb = new BBB(); // AAA的普通代码块 AAA的无参构造器 BBB的普通代码块 BBB的无参构造器
    }
}

class AAA{
    {
        System.out.println("AAA的普通代码块");
    }
    public AAA() {
        System.out.println("AAA的无参构造器");
    }
}

class BBB extends AAA{

    {
        System.out.println("BBB的普通代码块");
    }

    public BBB(){
        // 1.super()
        // 2.调用本类的代码块
        System.out.println("BBB的无参构造器");
    }

}
