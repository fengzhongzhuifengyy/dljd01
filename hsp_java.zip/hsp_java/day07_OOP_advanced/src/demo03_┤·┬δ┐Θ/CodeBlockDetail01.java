package demo03_代码块;

public class CodeBlockDetail01 {
    public static void main(String[] args) {

        // 类什么时候被加载?
        // 1.创建对象实例
        AA aa = new AA(); // AA的静态代码块被执行
        System.out.println("创建对象实例------");
        // 2.创建子类对象,父类也会被加载,而且,父类会先加载子类后加载
        BB bb = new BB(); // BB的静态代码块被执行
        System.out.println("创建子类实例对象-----");
        /*
            为什么不输出父类的静态代码块呢? 因为静态代码块只会执行一次
         */
        // 3.使用类的静态成员时
        Cat.n1 = 1000; // Animal的静态代码块被执行 Cat的静态代码块被执行
        System.out.println("使用类的静态成员-----");

        // 静态代码块只会执行一次
        CC cc = new CC();
        CC cc1 = new CC(); // CC的静态代码块被执行

        // 普通代码块在创建对象时, 会被隐式调用
        // 被创建一次,就会调用一次
        // 如果只是使用类的静态成员时,普通代码块并不会被执行
        DD dd = new DD(); // DD的普通代码块被执行
        DD dd1 = new DD(); // DD的普通代码块被执行
        DD.n2 = 100; // 调用类的静态成员,普通代码块并没有输出
        /*
            结论: 普通代码块,在new对象时被调用,而且是没创建一个对象,就调用一次
            可以简单理解: 普通代码块是构造器的补充
         */
    }
}

class AA{

    // 静态代码块
    static {
        System.out.println("AA的静态代码块被执行");
    }
}

class BB extends AA{

    // 静态代码块
    static {
        System.out.println("BB的静态代码块被执行");
    }
}

class Animal{

    static {
        System.out.println("Animal的静态代码块被执行");
    }
}

class Cat extends Animal{

    public static int n1 = 999;
    static {
        System.out.println("Cat的静态代码块被执行");
    }
}

class CC {

    static {
        System.out.println("CC的静态代码块被执行");
    }
}

class DD {

    public static int n2 = 10;
    {
        System.out.println("DD的普通代码块被执行");
    }
}