package demo01_类变量和类方法.kn03_静态方法;

public class StaticMethod {
    public static void main(String[] args) {
        //创建2个学生对象,累计学费
        Stu stu1 = new Stu("tom");
        stu1.payFee(100);
        Stu.payFee(100);

        Stu stu2 = new Stu("marry");
        stu2.payFee(200);
        Stu.payFee(200);

        // 输出当前收到的总学费
        Stu.showFee();

        // 静态方法的使用场景:
        // 工具类
        System.out.println("9的开方: " + Math.sqrt(9));
        // 通用的方法
        System.out.println(MyTools.sum(10, 20));
    }
}


class Stu{

    // 普通属性
    private String name;
    // 静态变量,累计学生的学费
    private static double fee;

    public Stu(String name) {
        this.name = name;
    }
    /*
    * 说明:
    * 1.当方法使用了static修饰后,该方法就是静态方法
    * 2.静态方法就可以访问静态变量
    * */
    // 累加学费
    public static void payFee(double fee){
        Stu.fee += fee;
    }
    // 显示总学费
    public static void showFee(){
        System.out.println("总收到的学费: " + Stu.fee);
    }
}

class MyTools{

    // 求和
    public static double sum(double n1, double n2){
        return n1 + n2;
    }
}