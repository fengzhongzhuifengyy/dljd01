package demo01_类变量和类方法.kn03_静态方法;

public class StaticMethodDetails {
    public static void main(String[] args) {

        D.hi();

        // 非静态方法不能通过类名调用
        // D.say();  需要先创建对象再调用


    }
}

class D{
    private int n1 = 100;

    private static int n2 =200;

    public void say(){ //普通方法可以访问非静态成员,静态成员
        hi();
        hello();
        n2 = 400;
        n1 = 100;
    }


    public static void hi(){

        // 类方法中不允许使用和对象有关的关键字,比如this和super,普通方法(成员方法)可以
        // this.n1;


        // 类方法中 只能访问 静态变量和静态方法
        hello();
        n2 = 300;
        System.out.println(D.n2);
        // this.n2 = 300;
        // this.n1 = 400;

        // 不能从静态上下文中引用非静态方法“say()”
        // say();
        // n1 = 10;
        new D().say();
        new D().n1 = 200;

    }

    public static void hello(){

    }
}
