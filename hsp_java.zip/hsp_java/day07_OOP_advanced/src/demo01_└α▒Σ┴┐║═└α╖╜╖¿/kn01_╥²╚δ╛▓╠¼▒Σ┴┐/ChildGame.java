package demo01_类变量和类方法.kn01_引入静态变量;

// 引入静态变量:有一群小孩在玩堆雪人,不时有新的小孩加入,请问如何知道现在共有多少人在玩?
public class ChildGame {
    public static void main(String[] args) {

        // int count = 0;

        Child child1 = new Child("1");
        child1.join();
        // count++
        child1.count++;

        Child child2 = new Child("2");
        child2.join();
        // count++
        child2.count++;

        // 类变量,可以通过类名来访问
        System.out.println("共有" + Child.count + "加入了游戏"); //2

        // 此时,看下各个对象的count情况
        System.out.println(child1.count); // 2
        System.out.println(child2.count); // 2
    }
}


class Child{

    private String name;

    // 定义一个类变量(静态变量) 表示计数
    /*
        该变量的最大特点就是会被Child类的所有对象实例共享
     */
    public static int count = 0;

    public Child(String name){
        this.name = name;
    }

    public void join(){
        System.out.println(name + "加入了游戏");
    }
}