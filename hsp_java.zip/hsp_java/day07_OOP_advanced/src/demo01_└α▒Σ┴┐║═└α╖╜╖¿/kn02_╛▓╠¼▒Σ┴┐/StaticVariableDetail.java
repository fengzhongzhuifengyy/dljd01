package demo01_类变量和类方法.kn02_静态变量;

public class StaticVariableDetail {
    public static void main(String[] args) {

        // 5. 实例变量不能通过类名.变量名访问
        // System.out.println(B.name);

        B b = new B();
        System.out.println(b.n1);

        // 6.类变量是在类加载的时候就初始化了,也就是说,即使你没有创建对象,只要类加载,就可以使用类变量
        System.out.println(C.name);

    }
}

class B{

    public int n1 = 100;

}


class C{
    public static String name = "北京";
}