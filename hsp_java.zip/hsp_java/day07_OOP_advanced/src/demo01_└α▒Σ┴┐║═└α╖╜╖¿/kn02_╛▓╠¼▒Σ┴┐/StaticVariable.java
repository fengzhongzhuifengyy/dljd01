package demo01_类变量和类方法.kn02_静态变量;

/*说明:
    类变量是随着类加载而创建的,所以即使没有创建对象实例也是可以访问的
*/
public class StaticVariable {
    public static void main(String[] args) {

        // 类名.类变量名
        System.out.println(A.name);

        // 那么使用对象来访问可以吗? 可以,但是要注意访问修饰符的使用范围
        A a = new A();
        System.out.println(a.name);

    }
}

class A{

    // 类变量的访问,必须也要遵守访问权限
    public static String name = "txl";
}
