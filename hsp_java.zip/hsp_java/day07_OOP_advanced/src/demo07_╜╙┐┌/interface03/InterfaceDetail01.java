package demo07_接口.interface03;

public class InterfaceDetail01 {
    public static void main(String[] args) {
          // 1.接口不能被实例化
//        new InterfaceA03(); // 'InterfaceA03' 为 abstract；无法实例化
    }
}

interface InterfaceA03{

    void a();
    public abstract void b(); // 2.public abstract 都是冗余的
    void hi();

}

// 3.一个普通的类实现接口,就必须实现该接口的所有抽象方法
class A03 implements InterfaceA03{ // alt + enter 提示

    @Override
    public void a() {

    }

    @Override
    public void b() {

    }

    @Override
    public void hi() {

    }
}

// 4.抽象类实现接口时可以不实现接口的(抽象)方法
abstract class B03 implements InterfaceA03{

}