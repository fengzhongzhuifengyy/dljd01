package demo07_接口.interface03;

public class interfaceDetail02 {
    public static void main(String[] args) {
        // 1.证明接口的属性都是static
        System.out.println(InterfaceA04.n1);
        // 2.证明接口的属性都是static
//        InterfaceA04.n1 =30; // 无法将值赋给 final 变量 'n1'
        // 3.证明接口的属性都是public
    }
}

interface InterfaceA04{

//    protected int n = 2; // 此处不允许使用修饰符 'protected'
    int n1 = 1; // 2. public static final int n1 =1;如何证明?
    void hi();
}

interface InterfaceA05{
    void show();
}


// 1.一个类可以同时实现多个接口
class B04 implements InterfaceA04, InterfaceA05{

    @Override
    public void hi() {

    }

    @Override
    public void show() {

    }
}

// 3.接口与接口是继承(多继承),类与接口是实现
interface InterfaceA06 extends InterfaceA04, InterfaceA05{

}

// 4. 接口的修饰符只能是 public和默认,这点和类的修饰符是一样的
//private interface InterfaceA07{ // 此处不允许使用修饰符 'private'
//
//}