package demo07_接口.interface01;

public interface USB {

    // 规定接口的相关方法--规范
    public void start();
    public void stop();
}
