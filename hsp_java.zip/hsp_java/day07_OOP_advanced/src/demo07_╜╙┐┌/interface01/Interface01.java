package demo07_接口.interface01;

public class Interface01 {
    public static void main(String[] args) {

        // 创建手机,相机对象
        Camera camera = new Camera();
        Phone phone = new Phone();

        // 创建计算机
        Computer computer = new Computer();
        computer.work(camera); // 把照相机接入到计算机
        System.out.println("-------------");
        computer.work(phone);// 把相机接入到计算机

        // 补充多态数组
        USB[] myUsb = new USB[2];
        myUsb[0] = new Phone();
        myUsb[1] = new Camera();

        for (int i = 0; i < myUsb.length; i++) {
            // 调用start()
            myUsb[i].start();
            // 调用phone独有的怎么办? -- 向下转型
//            myUsb[i].call
            if (myUsb[i] instanceof Phone){
                ((Phone) myUsb[i]).call();
            }

       }

    }
}
