package demo07_接口.interface01;

public class Computer {
    //编写方法
    public void work(USB usb){
        // 通过接口来调用方法
        usb.start();
        usb.stop();
    }
}
