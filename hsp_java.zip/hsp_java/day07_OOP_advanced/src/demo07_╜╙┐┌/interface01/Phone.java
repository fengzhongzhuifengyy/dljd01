package demo07_接口.interface01;

public class Phone implements USB { // 实现接口,就是把接口的方法实现
    @Override
    public void start() {
        System.out.println("手机开始工作");
    }

    @Override
    public void stop() {
        System.out.println("手机停止工作");
    }

    public void call(){
        System.out.println("手机可以打电话");
    }
}
