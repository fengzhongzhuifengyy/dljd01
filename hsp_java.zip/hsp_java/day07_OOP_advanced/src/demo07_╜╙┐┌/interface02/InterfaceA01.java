package demo07_接口.interface02;

public interface InterfaceA01 {

    // 属性
    public int num = 10;
    //  方法
    // 在接口中,抽象方法可以省略abstract关键字
    public void hi();
    // 可以有默认实现方法,需要使用default关键字修饰
    default void ok(){
        System.out.println("ok");
    }
    // 可以有静态方法,有具体实现
    public static void cry(){
        System.out.println("cry");
    }
}
