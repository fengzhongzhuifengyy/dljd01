package demo07_接口.interface02;

public class Interface02 {
}
