package demo07_接口.interface02;

public class A01 implements InterfaceA01{
    /*
        1.如果一个类实现接口,需要将该接口所有的抽象方法都实现
     */
    @Override
    public void hi() {

    }
}
