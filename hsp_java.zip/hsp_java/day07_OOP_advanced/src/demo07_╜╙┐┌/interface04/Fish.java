package demo07_接口.interface04;

public interface Fish {

    void swimming();
}
