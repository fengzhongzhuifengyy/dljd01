package demo07_接口.interface04;

public class LittleMonkey extends Monkey implements Bird, Fish{
    public static final int x =1;
    public LittleMonkey(String name) {
        super(name);
    }


    @Override
    public void fly() {
        System.out.println(getName() + "像鸟儿一样飞翔");
    }

    @Override
    public void swimming() {
        System.out.println(getName() + "像鱼儿一样游泳" );
    }


    public void test(){
        System.out.println(x);
    }
}