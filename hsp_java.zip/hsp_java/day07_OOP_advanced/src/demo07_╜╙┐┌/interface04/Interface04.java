package demo07_接口.interface04;

public class Interface04 {
    public static void main(String[] args) {

        LittleMonkey littleMonkey = new LittleMonkey("悟空");
        littleMonkey.climb();
        littleMonkey.fly();
        littleMonkey.swimming();
    }
}
