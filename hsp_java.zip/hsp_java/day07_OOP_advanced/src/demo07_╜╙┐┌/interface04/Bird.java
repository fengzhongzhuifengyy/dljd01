package demo07_接口.interface04;

public interface Bird {
    public static final int x =1;
    void fly();
}
