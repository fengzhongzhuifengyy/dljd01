package demo07_接口.interface04;

public class Monkey {
    private String name;
    public int x;

    public Monkey(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void climb(){
        System.out.println(getName() + "会爬树");
    }
}
