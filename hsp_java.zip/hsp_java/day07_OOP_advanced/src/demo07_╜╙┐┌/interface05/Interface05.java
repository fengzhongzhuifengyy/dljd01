package demo07_接口.interface05;

public class Interface05 {
    // 接口引用 指向 实现类 对象
    A05 a05 = new Teacher();
    // 多态怎么传递呢?
    A06 a06 = new Teacher(); // 无法传递,怎么实现?
}

interface A05 extends A06{

}

interface A06{

}

class Teacher implements A05{ // 也可以看出,实现也是一层一层,从最高层开始,这就是多态传递现象

}

// C(class)-implements->A(interface) -extends-> B(interface)
// 此时 B b = new C(); 就可以进行传递