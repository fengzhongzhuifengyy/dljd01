package demo02_main介绍;

public class Main01 {

    private static String str = "hspedu";

    private String str1 = "ss";

    public static void hi(){
        System.out.println("hi...");
    }

    public void show(){
        System.out.println("show...");
    }


    public static void main(String[] args) {

        // 静态方法可以访问本类的静态属性
        System.out.println(str);
        // 静态方法可以访问本类的静态ff
        hi();
        // 静态方法不可以访问本类的非静态属性/方法
        // show();
        // System.out.println(str1);

        // 想要访问就必须创建类的实例
        Main01 main01 = new Main01();
        System.out.println(main01.str1);
        main01.show();

    }
}
