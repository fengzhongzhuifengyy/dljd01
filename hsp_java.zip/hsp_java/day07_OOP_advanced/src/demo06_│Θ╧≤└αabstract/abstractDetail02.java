package demo06_抽象类abstract;

public class abstractDetail02 {
}
// 抽象类的本质还是抽象类,所有可以有类的各种成员
abstract class A02{
    public int n1 =10;
    public static int n2 = 20;

    public A02(int n1) {
        this.n1 = n1;
    }
    public abstract void f1();
    public static void f2(){
        System.out.println("f2()");
    }

}
// 如果一个类继承了抽象类,则它必须实现抽象类的所有抽象方法,除非他自己也声明为abstract类
abstract class B02 {
    public abstract void hi();
}

abstract class C02 extends B02{ // 类 "C02" 必须声明为抽象，或为实现 "B02" 中的抽象方法 "hi()"

}
class D02 extends B02{
    @Override
    public void hi() { // 实现父类的抽象方法
        System.out.println("重写hi()");
    }
}

//抽象方法不能使用private final 和static类修饰,因为这些关键字都是和重写违背的
abstract class E02{

    // 抽象方法
//    public static abstract void hi();
}