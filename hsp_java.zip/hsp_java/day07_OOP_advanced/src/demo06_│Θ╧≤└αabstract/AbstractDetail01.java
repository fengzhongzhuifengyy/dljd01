package demo06_抽象类abstract;

public class AbstractDetail01 {
    public static void main(String[] args) {
          // 抽象类不能实例化
//        A01 a01 = new A01(); // A01' 为 abstract；无法实例化
    }
}

abstract class A01{

    // 抽象类不一定要包含abstract方法
    public void f1(){
    }
    // 类包含了抽象方法,则这个类就必须声明为abstract
    public abstract void f2();

    //abstract只能修饰类和方法,不能修饰属性和其他的
//    public abstract int num = 5; // 此处不允许使用修饰符 'abstract'
}
