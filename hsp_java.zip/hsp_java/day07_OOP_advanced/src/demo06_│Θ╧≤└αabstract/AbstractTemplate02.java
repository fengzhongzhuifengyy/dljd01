package demo06_抽象类abstract;

public class AbstractTemplate02 {
    public static void main(String[] args) {
        A04 a04 = new A04();
        a04.calculateTime();

        B04 b04 = new B04();
        b04.calculateTime();
    }
}


// 思考如何进行改良? 1.将共有的任务提取出来,缺陷:扩展能力太弱
class A04 {
    public void calculateTime(){
        // 得到开始的时间
        long startTime = System.currentTimeMillis();
        job();
        // 得到结束的时间
        long endTime = System.currentTimeMillis();
        System.out.println("执行的时间: " + (endTime -startTime));
    }

    // 计算1-10000000的和
    public void job(){
        int num = 0;
        for (int i = 0; i < 10000000; i++) {
            num += i;
        }
    }
}


class B04 {
    public void calculateTime(){
        // 得到开始的时间
        long startTime = System.currentTimeMillis();
        job();
        // 得到结束的时间
        long endTime = System.currentTimeMillis();
        System.out.println("执行的时间: " + (endTime -startTime));
    }

    // 计算1-80000000的和
    public void job() {
        int num = 0;
        for (int i = 0; i < 80000000; i++) {
            num += i;
        }
    }
}
