package demo06_抽象类abstract;

public class AbstractTemplate01 {
    public static void main(String[] args) {
        A03 a03 = new A03();
        a03.job();

        B03 b03 = new B03();
        b03.job();
    }
}


class A03{
    // 计算1-10000000的和
    public void job(){

        // 得到开始的时间
        long startTime = System.currentTimeMillis();
        int num = 0;
        for (int i = 0; i < 10000000; i++) {
            num += i;
        }
        // 得到结束的时间
        long endTime = System.currentTimeMillis();
        System.out.println("执行的时间: " + (endTime -startTime));
    }
}


class B03{
    // 计算1-80000000的和
    public void job(){

        // 得到开始的时间
        long startTime = System.currentTimeMillis();
        int num = 0;
        for (int i = 0; i < 80000000; i++) {
            num += i;
        }
        // 得到结束的时间
        long endTime = System.currentTimeMillis();
        System.out.println("执行的时间: " + (endTime -startTime));
    }

//    public void job1(){
//        long startTime = System.currentTimeMillis();
//        int num = 0;
//        for (int i = 0; i < 100000000; i++) {
//            num += i;
//        }
//        // 得到结束的时间
//        long endTime = System.currentTimeMillis();
//        System.out.println("执行的时间: " + (endTime -startTime));
//    }
}


