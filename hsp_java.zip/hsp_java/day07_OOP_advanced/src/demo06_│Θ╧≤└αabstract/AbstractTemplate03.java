package demo06_抽象类abstract;

// 模板设计 进行优化
/*
      设计一个抽象类Template,实现:
        ①编写calculateTime(),计算损耗时时间
        ②编写抽象方法code()
        ③编写子类继承抽象类Template,实现code()
 */
public class AbstractTemplate03 {
    public static void main(String[] args) {
        Template a05 = new A05();
        a05.calculateTime();
    }
}

/**
 *  抽象类--模板设计模式
 */
abstract class Template {

    public abstract void job(); // 抽象方法

    //    计算损耗时时间
    public void calculateTime() { // 非抽象方法调用抽象方法
        // 得到开始的时间
        long startTime = System.currentTimeMillis();
        job(); //进行动态绑定机制
        // 得到结束的时间
        long endTime = System.currentTimeMillis();
        System.out.println("执行的时间: " + (endTime - startTime));
    }

}

class A05 extends Template {
    // 计算1-10000000的和
    public void job() {
        int num = 0;
        for (int i = 0; i < 10000000; i++) {
            num += i;
        }

    }
}


class B05 extends Template {
    // 计算1-80000000的和
    public void job() {

        int num = 0;
        for (int i = 0; i < 80000000; i++) {
            num += i;
        }
    }
}