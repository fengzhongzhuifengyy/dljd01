package com.hspedu.java.day07_面向对象高级.demo04_单例模式;
// 饿汉式
public class SingleMode01 {
    public static void main(String[] args) {

//        GirlFriend girlFriend1 = new GirlFriend("小花");
//        GirlFriend girlFriend2 = new GirlFriend("小红");
        // 说明创建了两个对象,就不是单例

        // 通过方法获取对象
        GirlFriend girlFriend = GirlFriend.getInstance();
        System.out.println(girlFriend);

        // 再次获取
        GirlFriend girlFriend1 = GirlFriend.getInstance();
        System.out.println(girlFriend1);
        // 看出两个是同一个对象,static只会初始化一次
        System.out.println(girlFriend == girlFriend1);

    }
}

// 类 GirlFriend,要求只能有一个女盆友
class GirlFriend {

    /*
        如何保证只能创建一个GirlFriend对象?
        饿汉式: 只要类加载就已创建了对象
        1.将构造器私有化
        2.类的内部创建对象
        3.再提供一个公共的静态方法
     */
    private String name;

    private GirlFriend(String name) {
        this.name = name;
    }
    // 使用static才能被使用
    private static GirlFriend girlFriend = new GirlFriend("瑶瑶");
    public static GirlFriend getInstance(){
        return girlFriend; // 此时需要将girlFriend对象静态实现,才能直接引用
    }

    //重写toString(),返回属性信息
    @Override
    public String toString() {
        return "GirlFriend{" +
                "name='" + name + '\'' +
                '}';
    }
}
