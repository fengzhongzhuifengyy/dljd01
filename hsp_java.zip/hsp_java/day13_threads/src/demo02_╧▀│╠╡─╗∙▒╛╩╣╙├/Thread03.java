package demo02_线程的基本使用;

/**
 * 线程终止:启动一个线程T要求在main线程中区停止一个线程T
 */
public class Thread03 {
    public static void main(String[] args) throws InterruptedException {
        T t = new T();
        t.start();//启动T线程

        /*
            如果希望main线程 控制T线程的终止,必须修改loop
            让t退出run(),从而终止t1线程 -> 通知方式
         */
        System.out.println("main线程休眠10s");
        Thread.sleep(10 * 1000);
        System.out.println("结束T线程");
        t.setLoop(false);
    }
}

class T extends Thread {
    private boolean loop = true;

    public boolean isLoop() {
        return loop;
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }
    //必须要重写run()
    @Override
    public void run() {
        while (loop) {
            System.out.println("T进程开始...");
            try {
                Thread.sleep(50);//休眠50ms
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}