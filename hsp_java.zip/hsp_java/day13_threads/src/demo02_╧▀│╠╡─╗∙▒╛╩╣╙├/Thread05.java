package demo02_线程的基本使用;

/**
 * main线程创建一个子线程,每隔1s输出hello,输出20次,
 * 主线程每隔1s输出hi,输出20次,
 * 要求:两个线程同时执行,当主线程输出5次后,就让子线程运行完毕,主线程再继续
 */

public class Thread05 {
    public static void main(String[] args) throws InterruptedException {
        T3 t3 = new T3();
        t3.start();

        for (int i = 0; i < 10; i++) {
            Thread.sleep(1000);
            System.out.println("主线程hi" + i);
            if (i == 4) {
                // t3.start();//这里就是主线程先行
                t3.join();
            }
        }
        System.out.println("主线程结束");
    }
}

class T3 extends Thread {
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            try {
                Thread.sleep(1000);
                System.out.println("子线程hello" + i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("子线程结束");
    }
}