package demo02_线程的基本使用;

/**
 * 案例:将一个线程设置成守护线程
 */
public class Thread06 {
    public static void main(String[] args) throws InterruptedException {
        MyDaemonThread myDaemonThread = new MyDaemonThread();
        Thread thread = new Thread(myDaemonThread);
        //此时只要将子线程设置成守护进程
        thread.setDaemon(true);//必须要先设置成守护进程
        thread.start();
        for (int i = 0; i < 10; i++) {
            System.out.println("宝强在辛苦工作");
            Thread.sleep(1000);
        }
        System.out.println("主线程结束");

        // thread.setDaemon(true);//放在这里会抛异常:java.lang.IllegalThreadStateException,需要放在线程前面
    }
}

class MyDaemonThread implements Runnable {
    @Override
    public void run() {
        for (; ; ) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("马蓉和宋哲快乐聊天");
        }

    }
}
