package demo02_线程的基本使用;

/**
 *  线程常用的方法1
 */
public class Thread04 {
    public static void main(String[] args) throws InterruptedException {

        //测试相关异常
        S s = new S();
        s.setName("张三");//设置线程名称
        s.setPriority(Thread.MIN_PRIORITY);//设置优先级
        s.start();

        //主线程打印5个hi就中断子线程循环
        for (int i = 0; i < 5; i++) {
            Thread.sleep(1000);
            System.out.println("hi" + i);
        }
        System.out.println(s.getName() + "的优先级为: " + s.getPriority());
        s.interrupt();//执行到这里就会中断s线程的休眠
    }
}

class S extends Thread{
    @Override
    public void run() {
        while (true){
            for (int i = 0; i < 100; i++) {
                System.out.println(Thread.currentThread().getName() + "吃包子");
            }

            try {
                System.out.println("休眠中");
                sleep(20000);
            } catch (InterruptedException e) {
                //中断异常
                System.out.println(Thread.currentThread().getName()+"被 interrupt了");
            }
        }
    }
}
