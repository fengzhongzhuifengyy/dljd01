package demo02_线程的基本使用;

/**
 *  售票系统,编程模拟三个售票窗口售票100,分别使用Thread和实现Runnable方式,并分析有什么问题 ---出现超卖
 */
public class Thread02 {
    public static void main(String[] args) {

        TicketSys1 ticketSys11 = new TicketSys1();
        TicketSys1 ticketSys12 = new TicketSys1();
        TicketSys1 ticketSys13 = new TicketSys1();
        System.out.println("Thread线程开始售卖");
        ticketSys11.start();
        ticketSys12.start();
        ticketSys13.start();

        TicketSys2 ticketSys2 = new TicketSys2();
        Thread thread1 = new Thread(ticketSys2);
        Thread thread2 = new Thread(ticketSys2);
        Thread thread3 = new Thread(ticketSys2);
        thread1.start();
        thread2.start();
        thread3.start();


    }
}

class TicketSys1 extends Thread{
    private static int ticketNum = 100;//让多个线程共享 ticketNum

    @Override
    public void run() {

        while (true) {
            if (ticketNum <= 0){
                System.out.println("售票结束");
                break;
            }
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("窗口1" + Thread.currentThread().getName() + "售出一张票" + "剩余票数" + (--ticketNum));
        }
    }
}



class TicketSys2 implements Runnable{
    private static int ticketNum = 100;//让多个线程共享 ticketNum

    @Override
    public void run() {
        while (true) {
            if (ticketNum <= 0){
                System.out.println("售票结束");
                break;
            }
            try {
                Thread.sleep(40);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("窗口2" + Thread.currentThread().getName() + "售出一张票" + "剩余票数" + (--ticketNum));
        }
    }
}