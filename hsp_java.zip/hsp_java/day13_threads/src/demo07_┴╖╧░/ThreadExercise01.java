package demo07_练习;

import java.util.Scanner;

/**
 * 编程题:
 * 1.在main方法中启动两个线程
 * 2.在第一个线程循环打印100以内的整数
 * 3.直到第二个线程从键盘读取了"Q"命令
 */
public class ThreadExercise01 {
    public static void main(String[] args) throws InterruptedException {
        A a = new A();
        B b = new B(a);//这里很重要,要把a对象传给b,来控制
        a.start();
        b.start();
    }
}

class A extends Thread {
    private boolean loop = true;

    @Override
    public void run() {
        //1.循环间隔1s随机打印1-100
        while (loop) {
            //随机打印 1-100
            System.out.println((int) (Math.random() * 100 + 1));
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("A线程退出...");
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }
}

class B extends Thread {
    private A a;
    private Scanner sc = new Scanner(System.in);

    public B(A a) { //构造器中直接传入A对象
        this.a = a;
    }

    @Override
    public void run() {

        for (; ; ) {
            System.out.println("请输入你的选择(Q表示退出): ");
            char chars = sc.next().toUpperCase().charAt(0);
            if (chars == 'Q') {
                //以通知的方式结束我们的A线程
                a.setLoop(false);
                break;
            }
        }
        System.out.println("B线程退出...");
    }

}
