package demo07_练习;

/**
 * 编程提:
 * 1.有2个用户分别从一张卡上取钱(总价10000)
 * 2.每次都取1000,当余额不足时,就不能取款了
 * 3.不能出现超取的现象 ==>线程同步
 */
public class ThreadExercise02 {
    public static void main(String[] args) {
        T t = new T();
        new Thread(t).start();//用户1
        new Thread(t).start();//用户2
    }
}

//1.这里涉及多个线程共享资源,用Runnable实现
class T implements Runnable {
    private static double balance = 10000;
    private boolean loop = true;
    @Override
    public void run() {

       while (loop){
           // 1.这里使用sync实现了线程同步
           // 2.当多个线程执行到这里时,就会获取this对象的锁
           // 3.哪个线程争取到this对象锁,就执行sync代码块
           // 4.争取不到对象锁的,就blocked,准备继续争夺
            synchronized (this){
                if (balance < 1000) {
                    System.out.println("余额不足,无法取钱...");
                    // loop = false;
                    break;
                }
                balance -= 1000;
                System.out.println(Thread.currentThread().getName() + "余额剩余: " + balance);
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // //取钱===> 方法sync
    // public /*synchronized*/ void withdraw() {
    //     balance -= 1000;
    // }
}