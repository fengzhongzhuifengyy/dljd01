package demo04_线程同步sync;

/**
 *  售票系统,编程模拟三个售票窗口售票100,分别使用Thread和实现Runnable方式,并分析有什么问题 ---同步解决
 */
public class Thread01 {
    public static void main(String[] args) {

        TicketSys2 ticketSys2 = new TicketSys2();
        new Thread(ticketSys2).start();//第1个线程-窗口
        new Thread(ticketSys2).start();//第2个线程-窗口
        new Thread(ticketSys2).start();//第3个线程-窗口
    }
}


class TicketSys2 implements Runnable{
    private static int ticketNum = 100;//让多个线程共享 ticketNum
    private boolean flag = true;

    @Override
    public void run() {
        while (flag) {
            sell();
        }
    }

    //方法中进程同步控制
    //这时的锁在this对象(TicketSys2)
    public synchronized void sell(){
            if (ticketNum <= 0){
                System.out.println("售票结束");
                flag = false;
                return;
            }
            //休眠
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //打印结果
            System.out.println("窗口" + Thread.currentThread().getName() + "售出一张票" + "剩余票数" + (--ticketNum));
        }
}
