package demo01_创建线程的方式;

/**
 * 线程应用案例 2-实现 Runnable 接口
 * 编写程序,该程序每隔1秒,在控制台输出"hi",输出10次后退出
 */
public class Thread02 {
    public static void main(String[] args) {
        // Dog dog = new Dog();
        // // dog.start();//这里不能调用
        // //处理:
        // //创建了Thread对象,把dog对象(实现Runnable),放入Thread
        // Thread thread = new Thread(dog);
        // /*
        //     这里底层使用了设计模式[代理模式]---->模拟
        //     源码:
        //         public Thread(Runnable target) {
        //             init(null, target, "Thread-" + nextThreadNum(), 0);
        //         }
        //  */
        // thread.start();


        //模拟代理模式实现
        Tiger tiger = new Tiger();
        proxy proxy = new proxy(tiger);
        proxy.start();


    }
}

class Dog implements Runnable{
    int count = 0;
    @Override
    public void run() {
        while (true) {
            System.out.println("hi" + count++ + Thread.currentThread().getName());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (count == 8){
                break;
            }
        }
    }
}

// 线程代理类 , 模拟了一个极简的 Thread 类
class proxy implements Runnable{//你可以把Proxy类当做线程代理

    private Runnable target = null; //属性,类型是 Runnable

    @Override
    public void run() {
        if (target != null){
            target.run();//这里动态绑定(运行类型就是传进来的类型)
        }
    }
    //构造器
    public proxy(Runnable target) {
        this.target = target;
    }

    public void start(){
        start0();//这个方法时真正实现多线程方法
    }

    public void start0(){
        run();
    }
}

class Animal{}
class Tiger extends Animal implements Runnable{

    @Override
    public void run() {
        System.out.println("老虎嗷嗷叫");
    }
}
