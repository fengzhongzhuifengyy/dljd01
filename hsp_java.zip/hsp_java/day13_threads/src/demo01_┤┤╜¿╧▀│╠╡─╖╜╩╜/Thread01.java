package demo01_创建线程的方式;

/**
 *  继承Thread类
 */
public class Thread01 {
    public static void main(String[] args) throws InterruptedException {
        //创建一个cat对象,可以当做线程使用
        Cat cat = new Cat();
        cat.start();//启动线程 -> 最终调用的还是Cat的run()
        /*
            源码解读:
            (1)
                public synchronized void start() {
                    start0();
                }
            (2)
                //start0() 是本地方法，是 JVM 调用, 底层是 c/c++实现
                //真正实现多线程的效果， 是 start0(), 而不是 run
                private native void start0();
         */
        // cat.run();//run()就是一个普通的方法,并没有真正的启动一个线程,就会把这个run()执行完毕才向下执行,即for循环等run()结束才会执行

        //当main线程启动一个子线程后Thread-0,主线程不会阻塞,会继续执行
        //这时主线程与子线程会交替中执行
        for (int i = 0; i < 60; i++) {
            System.out.println("主线程执行i=" + i + Thread.currentThread().getName());//main
            // 让主线程也休眠
            Thread.sleep(1000);
        }
    }
}
/**
    1.请编写程序,开启一个线程,该线程每隔1s,在控制台输出"喵喵,我是小猫咪"
    2.对上体改进,当输出80次时,结束该线程
    3.使用JConsole监控线程执行情况
 */

/*
    说明:
    1.当一个类继承了Thread类,该类就可以当做线程使用
    2.重写run(),写上自己的业务逻辑
    3.run()是Thread类实现了Runnable接口的方法

        @Override
        public void run() {
            if (target != null) {
                target.run();
            }
        }
 */
class Cat extends Thread{


    @Override
    public void run() {//重写run(),写上自己的业务逻辑
        int count = 0;
        while(true){
            System.out.println("喵喵,我是小猫咪" + count++);
            System.out.println(Thread.currentThread().getName());
            //让该线程休眠一秒
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
           if (count == 80){
               break;
           }
        }
    }
}
