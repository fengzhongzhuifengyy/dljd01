package com.hspedu.java.day13_多线程.demo03_线程的状态;

/**
 *  线程的几种状态
 */
public class Thread01 {
    public static void main(String[] args) throws InterruptedException {
        T1 t1 = new T1();
        Thread thread = new Thread(t1);
        System.out.println("状态1" + thread.getState());//状态1NEW
        thread.start();
        System.out.println("状态2" + thread.getState());//状态2RUNNABLE
        while (Thread.State.TERMINATED != thread.getState()){
            System.out.println("状态3" + thread.getState());//状态3RUNNABLE
            Thread.sleep(1000);//主线程休眠
        }
        System.out.println("状态4" + thread.getState());//状态4TERMINATED
    }
}

class T1 implements Runnable{

    int count = 0;
    @Override
    public void run() {

        while (true) {
            System.out.println("hello" + count++);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (count == 10){
                break;
            }
        }

    }
}