package demo05_互斥锁;

/**
 * 代码块演示锁
 */
public class Thread01 {
    public static void main(String[] args) {
        TicketSys3 ticketSys3 = new TicketSys3();
        new Thread(ticketSys3).start();//线程1
        new Thread(ticketSys3).start();//线程2
        new Thread(ticketSys3).start();//线程3
    }
}

class TicketSys3 implements Runnable {

    private static int ticketNum = 1000;
    private boolean loop = true;//控制run()变量


    @Override
    public void run() {
        while (loop) {
            sell();
        }
    }

    Object obj = new Object();

    /*
        在方法内部 代码块中写synchronized,同步代码块,互斥锁还是加在this对象
     */
    public /*synchronized*/ void sell() {
        synchronized (/*this*/ obj) { //因为时操作的同一个对象
            if (ticketNum <= 0) {
                System.out.println("售票结束");
                loop = false;
                return;
            }
            //休眠
            try {
                Thread.sleep(30);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //打印结果
            System.out.println("窗口" + Thread.currentThread().getName() + "售出一张票" + "剩余票数" + (--ticketNum));
        }

    }


    //同步方法(静态的)的锁为当前类本身
    //下面是静态同步方法,锁是加在 类.class 上(TicketSys3.class)
    public synchronized static void m1() {

    }

    public static void m2() {
        synchronized (/*this*/TicketSys3.class){//不能使用this,只能使用当前类
            System.out.println("m2");
        }

    }


}
