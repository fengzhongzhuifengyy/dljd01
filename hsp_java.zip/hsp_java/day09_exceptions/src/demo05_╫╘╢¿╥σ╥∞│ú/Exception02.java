package demo05_自定义异常;

/**
 * 案例下面输出什么
 */
public class Exception02 {
    public static void main(String[] args) {
        try {
            ReturnExceptionDemo.methodA();
        } catch (Exception e) {
            System.out.println(e.getMessage()); //3 制造异常
        }
            ReturnExceptionDemo.methodB();//这里还是会继续运行
    }
}

class ReturnExceptionDemo{
    static void methodA(){
        try {
            System.out.println("进入A方法"); //1
            throw new RuntimeException("制造异常");
        }finally {
            System.out.println("A方法的finally"); //2
        }
    }

    static void methodB(){
        try {
            System.out.println("进入B方法");// 4
            return;
        } finally {
            System.out.println("B方法的finally");// 5
        }
    }
}
