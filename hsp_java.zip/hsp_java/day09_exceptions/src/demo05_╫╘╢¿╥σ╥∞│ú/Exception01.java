package demo05_自定义异常;

/**
 * 自定义异常案例
 */
public class Exception01 {
    public static void main(String[] args) {
        //当我们接收Person对象年龄时,要求范围在18 -120之间,
        //否则抛出自定义异常(要求继承RuntimeException),并给出提示信息

        int age = 180;
        if (!(age >= 18 && age < 120)){
            throw new AgeException("年龄需要在10-120岁");
        }
        System.out.println("年龄范围正确");
    }
}

//自定义异常类
/*
    1.继承RuntimeException
    2.编写构造器
    3.一般来说,继承RuntimeException做成运行时异常:好处时,我们可以使用默认的处理机制
 */
class AgeException extends RuntimeException{
    public AgeException(String message) {
        super(message);
    }
}

