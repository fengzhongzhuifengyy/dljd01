package demo04_throws;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 *  ThrowsDetail
 */
public class ThrowsDetail01 {
    public static void main(String[] args) //throws ArithmeticException --默认
    {
        f1();
    }

    public static void f1() //throws ArithmeticException --默认
    {
        //1.对于编译异常,程序中必须处理,比如try-catch或者throws
        //2.对于运行时异常,程序中如果没有处理,默认使用throws的方式处理(默认的方式)
        int n1 = 10;
        int n2 = 0;
        double n3 = n1 / n2;
    }

    public static void f2() throws FileNotFoundException{
        //思考:此时调用f3()会怎么样?
        //发现会报错:未处理 异常: java.io.FileNotFoundException? 原因是什么呢?
        //1.因为f3()抛出的是一个编译异常FileNotFoundException
        //2.这时,就要去f2()必须处理这个编译异常
        f3();//抛出异常(要么1.try-catch;2.继续throws)
    }

    public static void f3() throws FileNotFoundException {
        FileInputStream fileInputStream = new FileInputStream("d://aaa.com");
    }

    public static void f4(){
        //此时这里调用f5会有报错吗?
        //1.发现没有错,因为f5()是拥有运行时异常,
        //2.而java中并不要求一定要处理运行异常,因为有默认处理机制
        f5();
    }

    public static void f5() throws ArithmeticException{

    }
}

//3.子类重写父类的方法时,对抛出异常的规定:子类重写的方法,所抛出的异常类型要么和子类的异常一致.要么为父类抛出异常类型的子类型
class Father{

    public void method() throws RuntimeException{

    }
}

class Son extends Father{
    @Override
    public void method() throws NullPointerException{
//        public void method() throws Exception{  //大于异常父类
//        public void method() throws FileNotFoundException { //非异常子类

    }
}
