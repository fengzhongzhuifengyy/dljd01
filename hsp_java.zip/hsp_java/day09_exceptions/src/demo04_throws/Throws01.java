package demo04_throws;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * throws
 */
public class Throws01 {
    public static void main(String[] args) {

    }
    //throws后面的异常类型可以是方法中产生的异常类型,也可以是它(异常)的父类 FileNotFoundException/Exception
    //在方法声明中用throws语句可以声明抛出异常的列表(多个异常)
    public void f2() throws FileNotFoundException, NullPointerException, ArithmeticException{
        //创建一个文件流对象
        //此时编译就异常:未处理 异常: java.io.FileNotFoundException
        //处理方式: 1.try-catch;2.使用throws抛出异常(throws FileNotFoundException),让调用f1()的调用者(方法)处理
        FileInputStream fileInputStream = new FileInputStream("d://aaa.com");
    }
}

