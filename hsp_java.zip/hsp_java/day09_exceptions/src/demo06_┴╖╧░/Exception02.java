package demo06_练习;

/**
 *  说出一下代码是否会报错,是什么异常
 */
public class Exception02 {
    public static void main(String[] args) {
        if (args[4].equals("jhon")){ //可能发生 空指针/数组越界
            System.out.println("AA");
        }else {
            System.out.println("BB");
        }
        Object o = args[2]; //String -> Object ok
        Integer i = (Integer) o; // String -->int
    }
}
