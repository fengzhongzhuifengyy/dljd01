package demo06_练习;

/**
 * 写出结果
 */
public class Exception04 {
    public static void main(String[] args) {
        try {
            showExec();
            System.out.println("A");
        } catch (Exception e) {
            System.out.println("B");
        } finally {
            System.out.println("C");
        }
        System.out.println("D");
    }

    public static void showExec() throws Exception {
        throw new Exception();
    }
}
