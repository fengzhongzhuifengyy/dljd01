package demo01_异常引入;

/**
 *  异常引入
 */
public class Exception01 {
    public static void main(String[] args) {

        int num1 = 10;
        int num2 = 0;
        /*
            1.当程序执行时,程序就会出现异常 ArithmeticException(算术异常)
            2.当抛出异常后,程序就退出了,下面的代码就不在执行了
            3.如果程序员，认为一段代码可能出现异常/问题，可以使用 try-catch 异常处理机制来解决,从而保证程序的健壮性
            4.将该代码块->选中->快捷键 ctrl + alt + t -> 选中 try-catch
            5.如果进行异常处理，那么即使出现了异常，程序可以继续执行
         */
        try {
            int res = num1 / num2;
        } catch (Exception e) {
            //e.printStackTrace();
            System.out.println("打印异常信息: " + e.getMessage());//输出异常信息
        }
        System.out.println("程序是否继续运行");
    }
}
