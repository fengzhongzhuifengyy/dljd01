package com.hspedu.java.day09_异常.demo03_try_catch;

/**
 * try-catch
 */
public class Exception01 {
    public static void main(String[] args) {
        //try -catch
        //1. 如果异常发生了，则异常发生后面的代码不会执行，直接进入到 catch 块
        //2. 如果异常没有发生，则顺序执行 try 的代码块，不会进入到 catch
        //3. 如果希望不管是否发生异常，都执行某段代码(比如关闭连接，释放资源等)则使用如下代码- finally

        try {
            String name1 = "韩顺平";
            int num1 = Integer.parseInt(name1);//发生异常
            System.out.println("数字" + num1);//这处代码就不会执行
        } catch (NumberFormatException e) {
            System.out.println("异常信息" + e.getMessage());
        } finally {
            System.out.println("finally执行...");
        }
        System.out.println("程序继续运行");

        //4.可以有多个catch语句,捕获不同的异常,要求父类异常在后,子类异常在前,比如Exception在后,NullPointerException在前,如果发生异常,只会匹配一个catch
        /*
            如果try代码块有多个异常
            可以使用多个 catch 分别捕获不同的异常，相应处理
            要求子类异常写在前面，父类异常写在后面
         */
        try {
            Person person = new Person();
            person = null;
            System.out.println(person.getName()); //NullPointerException
            int n1 = 10;
            int n2 = 0;
            int res = n1 / n2; //ArithmeticException
        } catch (NullPointerException e) {
            System.out.println("空指针异常" + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("算数异常" + e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        //5.可以直接使用try-finally配合使用,这种用法相当于没有捕获异常,因此程序会直接崩掉;应用场景:就是执行一段代码,不管是否发生异常,都必须执行某个业务逻辑
        /*
            try{
            //代码
            }finally{
            //总是执行
            }
         */
        try {
            int n3 =100;
            int n4 = 0;
            int result = n3 /n4;
        } finally {
            System.out.println("执行finally");
        }
        System.out.println("程序继续");
    }
}

class Person {

    private String name = "jack";

    public String getName() {
        return name;
    }

}
