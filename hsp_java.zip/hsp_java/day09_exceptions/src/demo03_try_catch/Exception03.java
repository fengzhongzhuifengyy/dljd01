package com.hspedu.java.day09_异常.demo03_try_catch;

import java.util.Scanner;

/**
 * 如果用户输入的不是一个整数，就提示他反复输入，直到输入一个整数为止
 */
public class Exception03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

//        for (;;){
//            System.out.println("输入: ");
//            String n1 = scanner.next();
//            try {
//                int n2 = Integer.parseInt(n1);
//                break;
//            } catch (Exception e) {
//                System.out.println(e.getMessage());
//            }
//        }
        // 自己写的碰到的原因:nextInt方法在发生异常后，不再接受用户输入的任何数据，而是徘徊在异常区域，如果外部使用死循环，就会导致死循环的发生。;解决方法：重新实例化Scanner对象 用new Scanner(System.in)代替上述代码中的sc即可
        // 当输入非整型数时，系统会抛出 InputMismatchException 异常时不会清除键盘缓冲区中的字符串，因此循环调用nextInt()时,仍然能够读取到上次输入的字符串,导致陷入死循环，
        // 使用新对象,会"清空"缓冲? 而使用next() + Integer.parseInt() 则不会产生此问题。
//        方法1:实例化Scanner对象 用new Scanner(System.in)代替代码中的scanner即可
        for (;;){
            System.out.println("输入: ");
            try {
//                scanner.nextInt();
                new Scanner(System.in).nextInt();
                break;
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        // 方法2:catch中，加一句：input.next()
        for (;;){
            System.out.println("输入: ");
            try {
                scanner.nextInt();
                new Scanner(System.in).nextInt();
                break;
            } catch (Exception e) {
                System.out.println(e.getMessage());
                scanner.nextInt();
            }
        }
    }
}


