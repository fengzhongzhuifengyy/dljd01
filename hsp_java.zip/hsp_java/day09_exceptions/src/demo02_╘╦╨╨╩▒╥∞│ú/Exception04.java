package demo02_运行时异常;

/**
 *  NumberFormatException:当应用程序试图将字符串转换成一种数值类型，但该字符串不能转换为适当格式时，抛出该异常 => 使用异常我们可以确保输入是满足条件数字.
 */
public class Exception04 {
    public static void main(String[] args) {
        String name = "1234";
        int num = Integer.parseInt(name);
        System.out.println(num);

        String name1 = "韩顺平";
        int num1 = Integer.parseInt(name1);
        System.out.println(num1);
    }
}
