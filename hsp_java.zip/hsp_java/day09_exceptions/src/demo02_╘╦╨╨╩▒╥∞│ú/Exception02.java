package demo02_运行时异常;

/**
 *  ArrayIndexOutOfBoundsException:用非法索引访问数组时抛出的异常。如果索引为负或大于等于数组大小，则该索引为非法索引
 */
public class Exception02 {
    public static void main(String[] args) {
        int[] arr = {1,2,4};
        for (int i=0; i <= arr.length; i++){
            System.out.println(arr[i]);
        }
    }
}
