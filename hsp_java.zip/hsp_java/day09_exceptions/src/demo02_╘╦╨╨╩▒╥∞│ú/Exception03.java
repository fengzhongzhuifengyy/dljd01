package demo02_运行时异常;

/**
 *  ClassCastException:当试图将对象强制转换为不是实例的子类时，抛出该异常。
 */
public class Exception03 {
    public static void main(String[] args) {
        A a = new B();
        B b = (B)a;//ok
        C c = (C)a;//将B --> C
    }
}

class A {}
class B extends A {}
class C extends A {}