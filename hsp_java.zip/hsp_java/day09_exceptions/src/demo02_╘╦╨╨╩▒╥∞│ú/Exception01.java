package demo02_运行时异常;

/**
 *  1.NullPointerException:当应用程序试图在需要对象的地方使用 null 时，抛出该异常
 */
public class Exception01 {
    public static void main(String[] args) {

        String name = null;
        System.out.println(name.length());
    }
}
